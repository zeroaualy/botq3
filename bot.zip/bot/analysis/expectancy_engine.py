"""
Expectancy Engine - Performance Tracking System
Tracks expectancy by asset, timeframe, score range, strategy
"""
import logging
from typing import Dict, List, Optional
from collections import defaultdict

logger = logging.getLogger(__name__)


class ExpectancyEngine:
    """
    Tracks and calculates expectancy metrics
    
    Expectancy = (Win% × Avg Win) - (Loss% × Avg Loss)
    """
    
    def __init__(self):
        self.trades = []
        self.expectancy_by_asset = defaultdict(lambda: {"wins": 0, "losses": 0, "total_pnl": 0})
        self.expectancy_by_score_range = defaultdict(lambda: {"wins": 0, "losses": 0, "total_pnl": 0})
        self.expectancy_by_session = defaultdict(lambda: {"wins": 0, "losses": 0, "total_pnl": 0})
    
    def record_trade(self, trade: Dict):
        """
        Record a completed trade
        
        Args:
            trade: Dict with keys:
                - asset: str
                - result: "WIN" | "LOSS"
                - pnl: float
                - score: int
                - session: str (e.g., "LONDON", "NY", "ASIAN")
        """
        self.trades.append(trade)
        
        asset = trade.get("asset", "UNKNOWN")
        result = trade.get("result")
        pnl = trade.get("pnl", 0)
        score = trade.get("score", 0)
        session = trade.get("session", "UNKNOWN")
        
        # Update by asset
        if result == "WIN":
            self.expectancy_by_asset[asset]["wins"] += 1
        elif result == "LOSS":
            self.expectancy_by_asset[asset]["losses"] += 1
        self.expectancy_by_asset[asset]["total_pnl"] += pnl
        
        # Update by score range
        score_range = self._get_score_range(score)
        if result == "WIN":
            self.expectancy_by_score_range[score_range]["wins"] += 1
        elif result == "LOSS":
            self.expectancy_by_score_range[score_range]["losses"] += 1
        self.expectancy_by_score_range[score_range]["total_pnl"] += pnl
        
        # Update by session
        if result == "WIN":
            self.expectancy_by_session[session]["wins"] += 1
        elif result == "LOSS":
            self.expectancy_by_session[session]["losses"] += 1
        self.expectancy_by_session[session]["total_pnl"] += pnl
    
    def get_expectancy(self, category: str, key: str) -> Optional[float]:
        """
        Get expectancy for a specific category
        
        Args:
            category: "asset" | "score_range" | "session"
            key: Specific key within category
            
        Returns:
            float: Expectancy value or None
        """
        data_map = {
            "asset": self.expectancy_by_asset,
            "score_range": self.expectancy_by_score_range,
            "session": self.expectancy_by_session
        }
        
        data = data_map.get(category, {}).get(key)
        if not data:
            return None
        
        wins = data["wins"]
        losses = data["losses"]
        total = wins + losses
        
        if total == 0:
            return None
        
        win_rate = wins / total
        loss_rate = losses / total
        
        # Calculate average win/loss
        win_trades = [t["pnl"] for t in self.trades 
                      if t.get("result") == "WIN" and self._matches_category(t, category, key)]
        loss_trades = [abs(t["pnl"]) for t in self.trades 
                       if t.get("result") == "LOSS" and self._matches_category(t, category, key)]
        
        avg_win = sum(win_trades) / len(win_trades) if win_trades else 0
        avg_loss = sum(loss_trades) / len(loss_trades) if loss_trades else 0
        
        # Expectancy formula
        expectancy = (win_rate * avg_win) - (loss_rate * avg_loss)
        
        return round(expectancy, 2)
    
    def should_skip_asset(self, asset: str, min_trades: int = 10) -> bool:
        """
        Check if asset should be skipped based on negative expectancy
        
        Args:
            asset: Asset name
            min_trades: Minimum trades before making decision
            
        Returns:
            bool: True if should skip
        """
        data = self.expectancy_by_asset.get(asset)
        if not data:
            return False
        
        total_trades = data["wins"] + data["losses"]
        if total_trades < min_trades:
            return False  # Not enough data
        
        expectancy = self.get_expectancy("asset", asset)
        
        # Skip if expectancy is negative
        return expectancy is not None and expectancy < -1.0
    
    def get_performance_summary(self) -> Dict:
        """Get overall performance summary"""
        total_trades = len(self.trades)
        if total_trades == 0:
            return {"total_trades": 0, "winrate": 0, "total_pnl": 0}
        
        wins = sum(1 for t in self.trades if t.get("result") == "WIN")
        losses = sum(1 for t in self.trades if t.get("result") == "LOSS")
        total_pnl = sum(t.get("pnl", 0) for t in self.trades)
        
        winrate = (wins / total_trades) * 100 if total_trades > 0 else 0
        
        return {
            "total_trades": total_trades,
            "wins": wins,
            "losses": losses,
            "winrate": round(winrate, 2),
            "total_pnl": round(total_pnl, 2)
        }
    
    def _get_score_range(self, score: int) -> str:
        """Get score range bucket"""
        if score >= 80:
            return "80-100"
        elif score >= 70:
            return "70-79"
        elif score >= 60:
            return "60-69"
        else:
            return "below-60"
    
    def _matches_category(self, trade: Dict, category: str, key: str) -> bool:
        """Check if trade matches category filter"""
        if category == "asset":
            return trade.get("asset") == key
        elif category == "score_range":
            return self._get_score_range(trade.get("score", 0)) == key
        elif category == "session":
            return trade.get("session") == key
        return False
