"""
Bot Telegram
Interface de controle e governança
"""
import asyncio
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)
import logging

logger = logging.getLogger(__name__)


class TelegramBot:
    """Bot Telegram com controle de governança"""
    
    def __init__(self, config, stats, runtime, signal_parser, 
                 trade_executor, ia_guard, permissoes):
        self.config = config
        self.stats = stats
        self.runtime = runtime
        self.signal_parser = signal_parser
        self.trade_executor = trade_executor
        self.ia_guard = ia_guard
        self.permissoes = permissoes
        self.iq_client = None
        
    def set_iq_client(self, iq_client):
        """Define cliente IQ Option"""
        self.iq_client = iq_client
    
    # ======================================
    # MENUS
    # ======================================
    def menu_principal(self):
        keyboard = [
            [
                InlineKeyboardButton("⚙️ Configurações", callback_data="config"),
                InlineKeyboardButton("📊 Estatísticas", callback_data="stats")
            ],
            [
                InlineKeyboardButton("📥 Sinais", callback_data="sinais"),
                InlineKeyboardButton("🤖 IA & Governança", callback_data="ia_menu")
            ],
            [
                InlineKeyboardButton("💰 Ver Saldo", callback_data="ver_saldo"),
            ],
            [
                InlineKeyboardButton("▶️ Iniciar Bot", callback_data="start_bot"),
                InlineKeyboardButton("⏸️ Pausar Bot", callback_data="pause_bot")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def menu_config(self):
        auto = "✅" if self.config["operar_automatico"] else "❌"
        martingale = "✅" if self.config["martingale"] else "❌"
        
        keyboard = [
            [InlineKeyboardButton(f"{auto} Operação Automática", callback_data="toggle_auto")],
            [InlineKeyboardButton(f"{martingale} Martingale", callback_data="toggle_martingale")],
            [InlineKeyboardButton(f"💰 Valor: ${self.config['valor_entrada']}", callback_data="info_valor")],
            [InlineKeyboardButton(f"🛑 Stop Loss: ${self.config['stop_loss']}", callback_data="info_stop")],
            [InlineKeyboardButton(f"🎯 Stop Gain: ${self.config['stop_gain']}", callback_data="info_gain")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def menu_ia_governanca(self):
        """Menu IA com flags de GOVERNANÇA"""
        validar = "✅" if self.config["ia_validar_contexto"] else "❌"
        
        # Flags de governança (NÃO habilitam funcionalidade)
        perm_estrategia = "🔒" if self.permissoes["ia_pode_criar_estrategia"] else "🔐"
        perm_prever = "🔒" if self.permissoes["ia_pode_prever_mercado"] else "🔐"
        perm_direcao = "🔒" if self.permissoes["ia_pode_decidir_direcao"] else "🔐"
        
        keyboard = [
            [InlineKeyboardButton(f"{validar} Validar Contexto (IA Guard)", callback_data="toggle_ia_validar")],
            [InlineKeyboardButton("━━━ PERMISSÕES DE GOVERNANÇA ━━━", callback_data="info_governanca")],
            [InlineKeyboardButton(f"{perm_estrategia} Criar Estratégia (BLOQUEADO)", callback_data="perm_estrategia")],
            [InlineKeyboardButton(f"{perm_prever} Prever Mercado (BLOQUEADO)", callback_data="perm_prever")],
            [InlineKeyboardButton(f"{perm_direcao} Decidir Direção (BLOQUEADO)", callback_data="perm_direcao")],
            [InlineKeyboardButton("❓ O que são permissões?", callback_data="info_permissoes")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def menu_sinais(self):
        captura = "✅ Ativa" if self.runtime.captura_sinais_ativa else "❌ Pausada"
        
        keyboard = [
            [InlineKeyboardButton(f"📡 Captura: {captura}", callback_data="toggle_captura")],
            [InlineKeyboardButton(f"📋 Sinais: {self.runtime.quantidade_sinais()}", callback_data="listar_sinais")],
            [InlineKeyboardButton("🗑️ Limpar Sinais", callback_data="limpar_sinais")],
            [InlineKeyboardButton("📝 Formatos", callback_data="formatos_sinal")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    # ======================================
    # HANDLERS
    # ======================================
    async def start(self, update: Update, context):
        """Comando /start"""
        status_iq = "✅ Conectado" if self.iq_client and self.iq_client.esta_conectado() else "❌ Desconectado"
        status_ia = "✅ Ativa" if not self.ia_guard.desabilitado() else "❌ Inativa"
        
        saldo_msg = ""
        if self.iq_client and self.iq_client.esta_conectado():
            try:
                saldo = self.iq_client.obter_saldo()
                tipo = self.iq_client.obter_tipo_conta()
                saldo_msg = f"└ Saldo {tipo}: ${saldo:.2f}"
            except:
                pass
        
        mensagem = f"""
🤖 <b>Bot Q3 IA v3.0 SÊNIOR</b>

📊 <b>Status:</b>
├ IQ Option: {status_iq}
├ IA Guard: {status_ia}
├ Sinais: {self.runtime.quantidade_sinais()}
{saldo_msg}

🏗️ <b>Arquitetura Refatorada:</b>
✅ Separação de responsabilidades
✅ Segurança reforçada PRACTICE
✅ Governança transparente
✅ IA como validadora (NÃO estrategista)

💡 Use o menu abaixo
        """
        
        await update.message.reply_text(
            mensagem,
            parse_mode="HTML",
            reply_markup=self.menu_principal()
        )
    
    async def button_handler(self, update: Update, context):
        """Handler de botões"""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        
        # Menu principal
        if data == "menu":
            await query.edit_message_text(
                "🤖 <b>Menu Principal</b>",
                parse_mode="HTML",
                reply_markup=self.menu_principal()
            )
        
        # Ver saldo
        elif data == "ver_saldo":
            if not self.iq_client or not self.iq_client.esta_conectado():
                await query.edit_message_text(
                    "❌ Sem conexão IQ Option",
                    reply_markup=self.menu_principal()
                )
                return
            
            saldo = self.iq_client.obter_saldo()
            tipo = self.iq_client.obter_tipo_conta()
            
            await query.edit_message_text(
                f"💰 <b>Informações da Conta</b>\n\n"
                f"Tipo: {tipo}\n"
                f"Saldo: ${saldo:.2f}\n\n"
                f"{'✅ PRACTICE (seguro)' if tipo == 'PRACTICE' else '⚠️ ATENÇÃO: REAL!'}",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("◀️ Voltar", callback_data="menu")
                ]])
            )
        
        # Configurações
        elif data == "config":
            await query.edit_message_text(
                "⚙️ <b>Configurações</b>",
                parse_mode="HTML",
                reply_markup=self.menu_config()
            )
        
        elif data == "toggle_auto":
            self.config["operar_automatico"] = not self.config["operar_automatico"]
            status = "ativada" if self.config["operar_automatico"] else "desativada"
            await query.edit_message_text(
                f"✅ Operação automática {status}",
                reply_markup=self.menu_config()
            )
        
        elif data == "toggle_martingale":
            self.config["martingale"] = not self.config["martingale"]
            status = "ativado" if self.config["martingale"] else "desativado"
            await query.edit_message_text(
                f"✅ Martingale {status}",
                reply_markup=self.menu_config()
            )
        
        # IA e Governança
        elif data == "ia_menu":
            await query.edit_message_text(
                "🤖 <b>IA Guard & Governança</b>\n\n"
                "IA atua como validadora de contexto operacional.\n"
                "Permissões são flags de auditoria (não habilitam funcionalidade).",
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        elif data == "toggle_ia_validar":
            self.config["ia_validar_contexto"] = not self.config["ia_validar_contexto"]
            status = "ativada" if self.config["ia_validar_contexto"] else "desativada"
            await query.edit_message_text(
                f"✅ Validação de contexto {status}",
                reply_markup=self.menu_ia_governanca()
            )
        
        # Permissões de governança
        elif data == "perm_estrategia":
            self.permissoes["ia_pode_criar_estrategia"] = not self.permissoes["ia_pode_criar_estrategia"]
            aviso = """
⚠️ <b>AVISO IMPORTANTE</b>

Esta permissão foi alterada apenas como <b>FLAG DE GOVERNANÇA</b>.

O comportamento REAL do bot permanece inalterado:
• IA NÃO cria estratégias
• IA NÃO prevê mercado
• IA NÃO decide CALL ou PUT
• IA APENAS valida contexto e risco

Esta flag serve para:
✓ Auditoria
✓ Transparência
✓ Trava explícita de poder
"""
            await query.edit_message_text(
                aviso,
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        elif data == "perm_prever":
            self.permissoes["ia_pode_prever_mercado"] = not self.permissoes["ia_pode_prever_mercado"]
            aviso = """
⚠️ <b>AVISO IMPORTANTE</b>

Esta permissão foi alterada apenas como <b>FLAG DE GOVERNANÇA</b>.

O comportamento REAL do bot permanece inalterado:
• IA NÃO cria estratégias
• IA NÃO prevê mercado
• IA NÃO decide CALL ou PUT
• IA APENAS valida contexto e risco

Esta flag serve para:
✓ Auditoria
✓ Transparência
✓ Trava explícita de poder
"""
            await query.edit_message_text(
                aviso,
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        elif data == "perm_direcao":
            self.permissoes["ia_pode_decidir_direcao"] = not self.permissoes["ia_pode_decidir_direcao"]
            aviso = """
⚠️ <b>AVISO IMPORTANTE</b>

Esta permissão foi alterada apenas como <b>FLAG DE GOVERNANÇA</b>.

O comportamento REAL do bot permanece inalterado:
• IA NÃO cria estratégias
• IA NÃO prevê mercado
• IA NÃO decide CALL ou PUT
• IA APENAS valida contexto e risco

Esta flag serve para:
✓ Auditoria
✓ Transparência
✓ Trava explícita de poder
"""
            await query.edit_message_text(
                aviso,
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        elif data == "info_permissoes":
            await query.edit_message_text(
                "❓ <b>O que são Permissões de Governança?</b>\n\n"
                "São FLAGS DE AUDITORIA que:\n\n"
                "✓ Mostram estado de permissões\n"
                "✓ Servem para transparência\n"
                "✓ Documentam travas de poder\n\n"
                "❌ NÃO habilitam funcionalidade real\n"
                "❌ Código BLOQUEIA comportamento proibido\n\n"
                "Mesmo com permissão ativada:\n"
                "• IA NÃO cria estratégia\n"
                "• IA NÃO prevê mercado\n"
                "• IA NÃO decide CALL/PUT",
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        # Sinais
        elif data == "sinais":
            await query.edit_message_text(
                "📡 <b>Gerenciar Sinais</b>",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "toggle_captura":
            self.runtime.captura_sinais_ativa = not self.runtime.captura_sinais_ativa
            status = "ativada" if self.runtime.captura_sinais_ativa else "pausada"
            await query.edit_message_text(
                f"✅ Captura {status}",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "listar_sinais":
            sinais = self.runtime.obter_sinais_pendentes()
            if not sinais:
                await query.edit_message_text(
                    "📭 Nenhum sinal agendado",
                    reply_markup=self.menu_sinais()
                )
                return
            
            lista = "📋 <b>Sinais Agendados:</b>\n\n"
            for i, s in enumerate(sinais[:10], 1):
                lista += f"{i}. {s['par']} {s['direcao']} - {s['horario'].strftime('%H:%M:%S')}\n"
            
            if len(sinais) > 10:
                lista += f"\n... +{len(sinais) - 10} sinais"
            
            await query.edit_message_text(
                lista,
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "limpar_sinais":
            self.runtime.limpar_sinais()
            await query.edit_message_text(
                "🗑️ Sinais removidos",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "formatos_sinal":
            await query.edit_message_text(
                "📝 <b>Formatos Aceitos:</b>\n\n"
                "<b>1. Estruturado:</b>\n"
                "ATIVO: EURUSD\n"
                "DIREÇÃO: CALL\n"
                "TIMEFRAME: 1M\n"
                "HORÁRIO: 14:32\n\n"
                "<b>2. Com horário:</b>\n"
                "M5 EURUSD CALL 14:30\n\n"
                "<b>3. Imediato:</b>\n"
                "M5 EURUSD CALL\n"
                "EURUSD PUT",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        # Estatísticas
        elif data == "stats":
            from state.stats import obter_winrate
            winrate = obter_winrate()
            
            mensagem = f"""
📊 <b>Estatísticas</b>

<b>Operações:</b>
├ Total: {self.stats['total_operacoes']}
├ ✅ Vitórias: {self.stats['vitorias']}
├ ❌ Derrotas: {self.stats['derrotas']}
└ ⚪ Empates: {self.stats['empates']}

<b>Financeiro:</b>
├ 💰 Lucro: ${self.stats['lucro_dia']:.2f}
└ 📈 Win Rate: {winrate:.1f}%

<b>IA Guard:</b>
├ ✅ Executar: {self.stats['ia_decisoes']['executar']}
├ ❌ Ignorar: {self.stats['ia_decisoes']['ignorar']}
└ ⚠️ Risco: {self.stats['ia_decisoes']['risco']}
            """
            
            await query.edit_message_text(
                mensagem,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("◀️ Voltar", callback_data="menu")
                ]])
            )
        
        # Controles
        elif data == "start_bot":
            self.config["operar_automatico"] = True
            await query.edit_message_text(
                "✅ Bot iniciado!",
                reply_markup=self.menu_principal()
            )
        
        elif data == "pause_bot":
            self.config["operar_automatico"] = False
            await query.edit_message_text(
                "⏸️ Bot pausado!",
                reply_markup=self.menu_principal()
            )
    
    async def mensagem(self, update: Update, context):
        """Handler de mensagens de texto"""
        sinal = self.signal_parser.parsear_sinal(update.message.text)
        
        if not sinal:
            return
        
        if sinal["imediato"] and self.config["operar_automatico"]:
            await update.message.reply_text(
                f"⚡ <b>Executando imediato!</b>\n\n"
                f"📊 {sinal['par']} {sinal['direcao']}\n"
                f"⏱️ {sinal['tempo_expiracao']}s",
                parse_mode="HTML"
            )
            # Processar será implementado no main
        
        elif not sinal["imediato"]:
            if self.runtime.captura_sinais_ativa or self.config["operar_automatico"]:
                self.runtime.adicionar_sinal(sinal)
                tempo = (sinal['horario'] - datetime.now()).total_seconds()
                await update.message.reply_text(
                    f"✅ <b>Sinal agendado!</b>\n\n"
                    f"📊 {sinal['par']} {sinal['direcao']}\n"
                    f"🕐 Horário: {sinal['horario'].strftime('%H:%M:%S')}\n"
                    f"⏳ Faltam: {int(tempo)}s",
                    parse_mode="HTML"
                )
