"""
Cliente IQ Option - Bot Q3 Beta
Wrapper sobre myiq usando APENAS API pública
ZERO acesso a propriedades internas
"""
import logging
import asyncio
from typing import Tuple, Optional

logger = logging.getLogger(__name__)

# Flag global para instância
_iq_instance = None


class IQClient:
    """
    Cliente IQ Option limpo - usa apenas API pública do myiq.
    Delega validação e execução para IQIntegration.
    """
    
    def __init__(self, email: str, senha: str, config: dict):
        self.email = email
        self.senha = senha
        self.config = config
        self.iq = None
        self._connected = False
        self._integration = None
    
    async def conectar(self, max_tentativas: int = 3) -> bool:
        """Conecta à IQ Option e força conta PRACTICE"""
        global _iq_instance
        
        for tentativa in range(max_tentativas):
            try:
                logger.info(f"🔄 Conectando IQ Option ({tentativa + 1}/{max_tentativas})...")
                
                from myiq.core.client import IQOption
                
                self.iq = IQOption(self.email, self.senha)
                
                try:
                    await self.iq.start()
                    
                    if not self.iq.check_connect():
                        logger.error("❌ Falha na autenticação")
                        continue
                    
                    # Obter balances e selecionar PRACTICE
                    balances = await self.iq.get_balances()
                    
                    if not balances:
                        logger.error("❌ Não foi possível obter balances")
                        continue
                    
                    # Procurar balance PRACTICE (tipo 4)
                    practice_balance = None
                    for b in balances:
                        if b.type == 4:
                            practice_balance = b
                            break
                    
                    if not practice_balance:
                        logger.error("❌ Conta PRACTICE não encontrada")
                        continue
                    
                    # Selecionar PRACTICE
                    await self.iq.change_balance(practice_balance.id)
                    
                    logger.info(f"✅ Conectado!")
                    logger.info(f"📊 Tipo de conta: PRACTICE")
                    logger.info(f"💰 Saldo PRACTICE: ${practice_balance.amount:.2f}")
                    
                    self._connected = True
                    _iq_instance = self.iq
                    
                    # Inicializar camada de integração
                    from core.iq_integration import IQIntegration
                    self._integration = IQIntegration(self.iq, self.config)
                    
                    # Cachear o ID da conta PRACTICE
                    self._integration.practice_balance_id = practice_balance.id
                    
                    # Cachear também o ID da conta REAL se existir
                    for b in balances:
                        if b.type == 1:  # REAL
                            self._integration.real_balance_id = b.id
                            break
                    
                    return True
                    
                except Exception as e:
                    logger.error(f"❌ Erro na conexão: {e}")
                    import traceback
                    logger.error(traceback.format_exc())
                
                await asyncio.sleep(5)
                
            except Exception as e:
                logger.error(f"❌ Erro: {e}")
                import traceback
                logger.error(traceback.format_exc())
        
        return False
    
    def esta_conectado(self) -> bool:
        """Verifica se está conectado"""
        return self._connected and self.iq is not None and self.iq.check_connect()
    
    async def garantir_practice(self) -> bool:
        """
        Garante que está em PRACTICE.
        Delega para camada de integração.
        """
        if not self._integration:
            logger.error("❌ Camada de integração não inicializada")
            return False
        
        return await self._integration.ensure_practice_account()
    
    async def obter_saldo(self) -> float:
        """Retorna saldo atual da conta ativa (PRACTICE ou REAL)"""
        try:
            if not self.iq or not self._connected:
                return 0.0
            balances = await self.iq.get_balances()
            active_id = self.iq.active_balance_id
            for b in balances:
                if b.id == active_id:
                    return float(b.amount)
            # fallback: PRACTICE
            for b in balances:
                if b.type == 4:
                    return float(b.amount)
            return 0.0
        except Exception as e:
            logger.error(f"❌ Erro ao obter saldo: {e}")
            return 0.0

    def obter_tipo_conta(self) -> str:
        """Retorna tipo de conta ativa: PRACTICE ou REAL (versão síncrona)"""
        if not self.iq or not self._connected:
            return "DESCONECTADO"
        try:
            # Verificar se integration está inicializada
            if not self._integration:
                return "DESCONHECIDO"
            
            active_id = self.iq.active_balance_id
            
            # Verificar contra practice_balance_id
            if self._integration.practice_balance_id and active_id == self._integration.practice_balance_id:
                return "PRACTICE"
            
            # Verificar contra real_balance_id
            if self._integration.real_balance_id and active_id == self._integration.real_balance_id:
                return "REAL"
            
            # Se não conseguiu determinar, retornar DESCONHECIDO mas não é erro crítico
            return "DESCONHECIDO"
        except Exception as e:
            logger.error(f"Erro ao obter tipo de conta: {e}")
            return "DESCONHECIDO"
    
    async def obter_tipo_conta_async(self) -> str:
        """Retorna tipo de conta ativa: PRACTICE ou REAL (versão assíncrona - precisa)"""
        if not self.iq or not self._connected:
            return "DESCONECTADO"
        try:
            balances = await self.iq.get_balances()
            if not balances:
                return "DESCONHECIDO"
            
            active_id = self.iq.active_balance_id
            
            # Procurar o balance ativo
            for b in balances:
                if b.id == active_id:
                    # type == 4 → PRACTICE | type == 1 → REAL
                    if b.type == 4:
                        return "PRACTICE"
                    elif b.type == 1:
                        return "REAL"
                    else:
                        return "DESCONHECIDO"
            
            return "DESCONHECIDO"
        except Exception as e:
            logger.error(f"Erro ao obter tipo de conta: {e}")
            return "DESCONHECIDO"

    async def alternar_conta(self, modo: str) -> tuple:
        """
        Alterna entre PRACTICE e REAL.
        Retorna (sucesso, saldo, tipo, mensagem).
        """
        if not self._integration:
            return False, 0.0, "", "Integração não inicializada"
        return await self._integration.alternar_conta(modo)
    
    async def executar_ordem(
        self,
        par: str,
        direcao: str,
        valor: float,
        expiracao: int,
        config: dict = None
    ) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Executa ordem com validação live e seleção dinâmica de instrumento.
        
        Args:
            par: Par (ex: EURUSD, GBPUSD-OTC)
            direcao: CALL ou PUT
            valor: Valor em dólares
            expiracao: Expiração em segundos
            config: Config (opcional, usa self.config se None)
        
        Returns:
            (sucesso, order_id, mensagem_erro_pt_br)
        """
        if not self._integration:
            return False, None, "❌ Camada de integração não inicializada"
        
        if not self._connected:
            return False, None, "❌ IQ Option desconectado"
        
        # Converter expiração para minutos
        timeframe_minutes = expiracao // 60
        
        try:
            return await self._integration.execute_trade(
                asset_symbol=par,
                direction=direcao,
                amount=valor,
                timeframe_minutes=timeframe_minutes
            )
        except Exception as e:
            logger.error(f"❌ Erro ao executar ordem: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False, None, f"❌ Erro: {str(e)}"
    
    async def fechar(self):
        """Fecha conexão WebSocket com myiq graciosamente"""
        try:
            if self.iq:
                await self.iq.close()
                logger.info("✅ Conexão IQ Option encerrada")
            self._connected = False
        except Exception as e:
            logger.error(f"❌ Erro ao fechar conexão IQ Option: {e}")
