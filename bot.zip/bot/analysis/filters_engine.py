"""
Filters Engine - Session Time, OTC, Low Liquidity Filters
"""
import logging
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Dict

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class FiltersEngine:
    """Applies time-based and market state filters"""
    
    def analyze(self, asset: str, current_time: datetime = None) -> Dict:
        try:
            if current_time is None:
                current_time = datetime.now(TZ)
            
            hour = current_time.hour
            day_of_week = current_time.weekday()  # 0=Monday, 6=Sunday
            
            filters_passed = []
            filters_failed = []
            total_score = 100
            
            # OTC Filter (weekends)
            if day_of_week >= 5:  # Saturday or Sunday
                filters_failed.append("OTC_SESSION")
                total_score -= 40
            else:
                filters_passed.append("REGULAR_SESSION")
            
            # Session quality filter
            if 2 <= hour < 7:
                # Dead Asian session hours
                filters_failed.append("DEAD_HOURS")
                total_score -= 30
            elif 8 <= hour < 11 or 13 <= hour < 17 or 19 <= hour < 23:
                # Prime trading hours
                filters_passed.append("PRIME_HOURS")
                total_score += 10
            else:
                filters_passed.append("ACCEPTABLE_HOURS")
            
            # FX liquidity check
            if asset.endswith("OTC"):
                filters_failed.append("OTC_ASSET")
                total_score -= 20
            
            # Clamp score
            total_score = max(0, min(100, total_score))
            
            return {
                "filters_passed": filters_passed,
                "filters_failed": filters_failed,
                "filter_score": total_score,
                "recommended": total_score >= 60,
                "details": f"Passed: {len(filters_passed)}, Failed: {len(filters_failed)}"
            }
            
        except Exception as e:
            logger.error(f"Error in filters analysis: {e}")
            return {
                "filters_passed": [],
                "filters_failed": ["ERROR"],
                "filter_score": 0,
                "recommended": False,
                "details": str(e)
            }
