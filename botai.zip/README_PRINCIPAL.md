# 🤖 Bot Q3 IA Beta v3.1 - Com Automação de Sinais

## 🎯 Versão Atualizada com Motor de Automação Inteligente

Este é o Bot Q3 IA Beta versão 3.1, agora incluindo a nova funcionalidade **Automação de Sinais** - um motor interno que analisa o mercado em tempo real e gera sinais automaticamente.

---

## 🆕 O QUE HÁ DE NOVO - v3.1

### ✨ Automação de Sinais
- 🧠 Motor interno de análise estatística
- 📊 Análise de tendência + momentum + volume
- 🎯 Geração automática de sinais (confiança ≥ 65%)
- 🔄 Integração total com o sistema existente
- 🛡️ Todas as proteções mantidas (PRACTICE, IA Guard, Risk Manager)

---

## 📦 INSTALAÇÃO RÁPIDA

### 1. Descompactar e Entrar no Diretório
```bash
unzip bot_q3_ia_v3.1_completo.zip
cd bot_atualizado
```

### 2. Criar e Ativar Ambiente Virtual
```bash
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows
```

### 3. Instalar Dependências
```bash
pip install -r requirements.txt --break-system-packages
```

### 4. Configurar Credenciais
Edite o arquivo `state/config.py` com suas credenciais:
```python
EMAIL = "seu_email@iqoption.com"
SENHA = "sua_senha"
```

### 5. Executar
```bash
python main.py
```

---

## 🎮 COMO USAR A AUTOMAÇÃO DE SINAIS

### Pré-requisitos
1. ✅ IQ Option conectado
2. ✅ Modo Automático ativo (🔄)
3. ✅ Conta em PRACTICE

### Passos
1. Abra o bot no Telegram
2. Clique em `🔄 Automático: ⚪ PAUSADO` para ativar
3. Clique em `🧠 Automação de Sinais: ⚪ DESATIVADO` para ativar
4. Monitore as notificações de trades automáticos

Para desativar, clique novamente nos botões.

---

## 📚 DOCUMENTAÇÃO

### Documentos Principais:
- **RESUMO_EXECUTIVO.md** - Visão geral completa da implementação
- **GUIA_INSTALACAO_AUTOMACAO.md** - Guia detalhado passo a passo
- **AUTOMACAO_SINAIS_README.md** - Manual completo de uso
- **CHANGELOG_AUTOMACAO_SINAIS.md** - Detalhes técnicos

### Documentos do Sistema Original:
- **Q3_IA_BETA_README.md** - Sistema Q3 IA Beta
- **AUTO_TRADE_README.md** - Modo Automático
- **README_INSTALACAO.md** - Instalação geral

---

## 🏗️ ESTRUTURA DO PROJETO

```
bot_atualizado/
├── ai/                          # Módulos de IA
│   ├── ia_guard.py             # Validação de contexto
│   ├── q3_ia_beta.py           # Filtro estratégico
│   └── stats_optimizer.py      # Otimizador estatístico
├── bot/                         # Interface Telegram
│   └── telegram_bot.py         # Bot Telegram completo
├── core/                        # Núcleo do sistema
│   ├── auto_trader.py          # Modo automático
│   ├── iq_client.py            # Cliente IQ Option
│   ├── risk_manager.py         # Gerenciador de risco
│   ├── scheduler.py            # Agendador de sinais
│   ├── signal_engine.py        # ⭐ NOVO - Motor de Automação
│   ├── signal_parser.py        # Parser de sinais
│   └── trade_executor.py       # Executor de trades
├── myiq/                        # Biblioteca IQ Option
│   ├── core/                   # Cliente WebSocket
│   ├── http/                   # Autenticação HTTP
│   └── models/                 # Modelos de dados
├── state/                       # Estado do sistema
│   ├── config.py               # Configurações (credenciais)
│   ├── runtime.py              # Estado de runtime
│   └── stats.py                # Estatísticas
├── main.py                      # Ponto de entrada principal
├── requirements.txt             # Dependências Python
└── *.md                         # Documentação
```

---

## ⚙️ CONFIGURAÇÕES

### Arquivo: `state/config.py`

```python
# Credenciais IQ Option
EMAIL = "seu_email@exemplo.com"
SENHA = "sua_senha"

# Telegram
TOKEN = "seu_token_bot"
GRUPO_ID = seu_grupo_id

# Groq (IA)
GROQ_API_KEY = "sua_chave_groq"

# Automação de Sinais (NOVO)
CONFIG = {
    "automacao_sinais_habilitada": True,
    "automacao_confianca_minima": 65,      # % mínimo
    "automacao_intervalo_analise": 30,     # segundos
    "automacao_max_sinais_hora": 10,       # limite
}
```

---

## 🛡️ PROTEÇÕES DE SEGURANÇA

### Sempre Ativas:
✅ Opera APENAS em conta PRACTICE  
✅ IA Guard valida todos os sinais  
✅ Risk Manager controla risco  
✅ Stop Loss e Stop Gain configuráveis  
✅ Limite de sinais por hora  
✅ Confiança mínima obrigatória  

---

## 🧪 TESTES

### Testar Instalação:
```bash
python -c "from core.signal_engine import SignalEngine; print('✅ OK')"
```

### Executar Testes Automatizados:
```bash
# Testes da Automação de Sinais
python test_signal_engine.py

# Testes do AutoTrader
python test_auto_trader.py
```

---

## 📊 FUNCIONALIDADES

### Sistema Base (v3.0):
- ✅ Bot Telegram completo
- ✅ Conexão IQ Option (biblioteca myiq)
- ✅ Parser de sinais (múltiplos formatos)
- ✅ Execução automática de trades
- ✅ IA Guard (validação)
- ✅ Q3 IA Beta (filtro estratégico)
- ✅ Risk Manager (gestão de risco)
- ✅ Stats Optimizer (otimização)

### Novo em v3.1:
- ✨ **Automação de Sinais**
  - Motor de análise estatística
  - Geração automática de sinais
  - Análise multi-dimensional (tendência + momentum + volume)
  - Interface Telegram integrada
  - Proteções de segurança reforçadas

---

## 🚨 IMPORTANTE

### ⚠️ Sobre Trading:
- Trading envolve **risco de perda**
- Use apenas capital que você pode perder
- **Sempre opere primeiro em PRACTICE**
- Não há garantia de lucros
- Esta é uma ferramenta de análise, não conselho financeiro

### 🔒 Sobre Segurança:
- Mantenha suas credenciais seguras
- Não compartilhe seu arquivo `config.py`
- Use senhas fortes
- Ative 2FA na IQ Option

---

## 📞 SUPORTE

### Em caso de problemas:

1. **Verifique os logs**:
   ```bash
   tail -f logs/bot.log  # se existir
   ```

2. **Consulte a documentação**:
   - GUIA_INSTALACAO_AUTOMACAO.md
   - AUTOMACAO_SINAIS_README.md

3. **Execute os testes**:
   ```bash
   python test_signal_engine.py
   ```

4. **Verifique configurações**:
   - Credenciais corretas em `state/config.py`
   - Conexão com internet
   - Conta PRACTICE ativa

---

## 📝 CHANGELOG

### v3.1 (15/02/2026)
- ✨ Adicionado: Motor de Automação de Sinais
- ✨ Adicionado: Análise estatística em tempo real
- ✨ Adicionado: Interface Telegram para controle
- 📚 Adicionado: Documentação extensiva (1400+ linhas)
- 🧪 Adicionado: Testes automatizados

### v3.0 (Anterior)
- Sistema completo com Q3 IA Beta
- IA Guard e Risk Manager
- AutoTrader funcional

---

## 🎓 RECURSOS DE APRENDIZADO

### Para entender melhor o sistema:
1. Leia **RESUMO_EXECUTIVO.md** primeiro
2. Depois **GUIA_INSTALACAO_AUTOMACAO.md**
3. Explore **AUTOMACAO_SINAIS_README.md**
4. Veja o código em **core/signal_engine.py**

---

## ⚖️ LICENÇA

Bot Q3 IA Beta v3.1  
Todos os direitos reservados.

---

## 🙏 CRÉDITOS

- **Desenvolvimento**: Implementação profissional da Automação de Sinais
- **Biblioteca myiq**: Cliente IQ Option assíncrono
- **Groq**: LLM para IA Guard
- **python-telegram-bot**: Framework Telegram

---

**🚀 Pronto para começar! Execute `python main.py` e bom trading!**
