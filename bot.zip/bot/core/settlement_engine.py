"""
Settlement Engine - Bot Q3 Beta
Monitors trade results asynchronously after execution
Decoupled from execution layer
"""
import asyncio
import logging
from typing import Dict, Optional, Callable
from datetime import datetime

logger = logging.getLogger(__name__)


class SettlementEngine:
    """
    Async settlement watcher - spawns tasks to monitor trade results
    
    Architecture:
    1. Execution registers trade
    2. Spawns async watcher task
    3. Watcher subscribes to position-changed
    4. Waits for close event
    5. Calls callbacks with result
    """
    
    def __init__(self, iq_client):
        self.iq = iq_client
        self._active_watchers = {}  # {order_id: task}
        self._pending_results = {}  # {order_id: result_data}
        self._result_callbacks = []
        
        logger.info("✅ Settlement Engine initialized")
    
    def register_callback(self, callback: Callable):
        """Register callback for when results are ready"""
        self._result_callbacks.append(callback)
        logger.info(f"📋 Result callback registered ({len(self._result_callbacks)} total)")
    
    def register_trade(
        self,
        order_id: str,
        asset: str,
        direction: str,
        amount: float,
        expiration_seconds: int
    ):
        """
        Register trade for settlement monitoring
        
        Spawns async task to watch for result
        """
        if order_id in self._active_watchers:
            logger.warning(f"⚠️ Order {order_id} already being watched")
            return
        
        trade_info = {
            "order_id": order_id,
            "asset": asset,
            "direction": direction,
            "amount": amount,
            "expiration_seconds": expiration_seconds,
            "registered_at": datetime.now()
        }
        
        # Spawn watcher task
        task = asyncio.create_task(self._watch_settlement(trade_info))
        self._active_watchers[order_id] = task
        
        logger.info(
            f"📋 Trade registered: {order_id} | {asset} {direction} | "
            f"Amount: ${amount} | Expiration: {expiration_seconds}s"
        )
    
    async def _watch_settlement(self, trade_info: Dict):
        """
        Async watcher - monitors position-changed events for this order
        """
        order_id = trade_info["order_id"]
        expiration_seconds = trade_info["expiration_seconds"]
        
        try:
            from myiq.core.constants import EV_POSITION_CHANGED
            from myiq.core.utils import get_req_id
        except ImportError:
            EV_POSITION_CHANGED = "portfolio.position-changed"
            def get_req_id():
                import random
                import time
                return f"req_{int(time.time())}_{random.randint(1000, 9999)}"
        
        try:
            logger.info(f"⏳ Watching settlement for {order_id}...")
            
            # Subscribe to position changes for this order
            await self.iq.iq.ws.send({
                "name": "subscribeMessage",
                "request_id": get_req_id(),
                "msg": {
                    "name": "portfolio.position-changed",
                    "version": "3.0",
                    "params": {
                        "routingFilters": {
                            "ids": [order_id]
                        }
                    }
                }
            })
            
            # Create future for result
            result_future = asyncio.get_running_loop().create_future()
            
            def on_result(msg):
                """Listener for position-changed events"""
                if msg.get("name") != EV_POSITION_CHANGED:
                    return
                
                raw = msg.get("msg", {})
                msg_id = raw.get("id")
                external_id = raw.get("external_id")
                
                # Check if this is our order
                is_same_id = (str(msg_id) == str(order_id) or str(external_id) == str(order_id))
                
                if is_same_id:
                    status = raw.get("status")
                    evt = raw.get("raw_event", {}).get("binary_options_option_changed1", {})
                    
                    is_closed = (status == "closed")
                    has_result = (evt.get("result") in ["win", "loose", "equal"])
                    
                    if is_closed or has_result:
                        if not result_future.done():
                            # Extract result
                            pnl = raw.get("pnl", 0)
                            if pnl == 0 and "profit_amount" in evt:
                                profit = evt.get("profit_amount", 0)
                                amount = evt.get("amount", 0)
                                pnl = profit - amount
                            
                            outcome = evt.get("result") or raw.get("close_reason", "unknown")
                            
                            result_data = {
                                "order_id": order_id,
                                "status": "closed",
                                "result": outcome,  # win, loose, equal
                                "pnl": float(pnl),
                                "profit_amount": float(evt.get("profit_amount", 0)),
                                "amount": float(evt.get("amount", trade_info["amount"])),
                                "asset": trade_info["asset"],
                                "direction": trade_info["direction"]
                            }
                            
                            result_future.set_result(result_data)
            
            # Register listener
            self.iq.iq.dispatcher.add_listener(EV_POSITION_CHANGED, on_result)
            
            try:
                # Wait for result with timeout
                timeout = expiration_seconds + 30  # Expiration + 30s buffer
                result = await asyncio.wait_for(result_future, timeout=timeout)
                
                # Store result
                self._pending_results[order_id] = result
                
                # Notify callbacks
                for callback in self._result_callbacks:
                    try:
                        if asyncio.iscoroutinefunction(callback):
                            await callback(order_id, result)
                        else:
                            callback(order_id, result)
                    except Exception as e:
                        logger.error(f"❌ Error in result callback: {e}")
                
                logger.info(
                    f"✅ Settlement complete: {order_id} | "
                    f"Result: {result['result']} | PNL: ${result['pnl']:.2f}"
                )
                
            except asyncio.TimeoutError:
                logger.warning(f"⏱️ Settlement timeout for {order_id} (waited {timeout}s)")
                # Store timeout result
                self._pending_results[order_id] = {
                    "order_id": order_id,
                    "status": "timeout",
                    "result": "unknown",
                    "pnl": 0.0,
                    "asset": trade_info["asset"],
                    "direction": trade_info["direction"]
                }
            finally:
                # Cleanup listener
                self.iq.iq.dispatcher.remove_listener(EV_POSITION_CHANGED, on_result)
                
        except asyncio.CancelledError:
            logger.info(f"⏹️ Settlement watcher cancelled: {order_id}")
        except Exception as e:
            logger.error(f"❌ Error in settlement watcher: {e}")
            import traceback
            logger.error(traceback.format_exc())
        finally:
            # Remove from active watchers
            if order_id in self._active_watchers:
                del self._active_watchers[order_id]
    
    def get_result(self, order_id: str) -> Optional[Dict]:
        """Get cached result if available"""
        return self._pending_results.get(order_id)
    
    def has_result(self, order_id: str) -> bool:
        """Check if result is available"""
        return order_id in self._pending_results
    
    def is_watching(self, order_id: str) -> bool:
        """Check if order is being watched"""
        return order_id in self._active_watchers
    
    async def wait_for_result(self, order_id: str, timeout: float = 120) -> Optional[Dict]:
        """
        Wait for result to become available
        
        Polls until result is ready or timeout
        """
        start_time = datetime.now()
        
        while (datetime.now() - start_time).total_seconds() < timeout:
            if order_id in self._pending_results:
                return self._pending_results[order_id]
            
            await asyncio.sleep(0.5)
        
        logger.warning(f"⏱️ Timeout waiting for result: {order_id}")
        return None
    
    async def cancel_watcher(self, order_id: str):
        """Cancel watcher for specific order"""
        if order_id in self._active_watchers:
            task = self._active_watchers[order_id]
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            del self._active_watchers[order_id]
    
    async def shutdown(self):
        """Cancel all active watchers"""
        logger.info("🛑 Shutting down Settlement Engine...")
        
        tasks = list(self._active_watchers.values())
        for task in tasks:
            task.cancel()
        
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        
        self._active_watchers.clear()
        logger.info("✅ Settlement Engine shutdown complete")
    
    def get_stats(self) -> Dict:
        """Get settlement engine statistics"""
        return {
            "active_watchers": len(self._active_watchers),
            "pending_results": len(self._pending_results),
            "callbacks_registered": len(self._result_callbacks)
        }
