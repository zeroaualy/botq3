"""
Pattern Engine - Candlestick Pattern Detection
Engulfing, Inside Bar, False Breakout patterns
"""
import logging
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class PatternEngine:
    """
    Detects candlestick patterns
    
    Features:
    - Bullish/Bearish Engulfing
    - Inside bars
    - False breakout detection
    """
    
    def analyze(self, candles: List[Dict]) -> Dict:
        """
        Analyze candlestick patterns
        
        Returns:
            Dict with pattern analysis:
            {
                "pattern": str or None,
                "direction": "BULLISH" | "BEARISH" | None,
                "score": 0-100,
                "details": str
            }
        """
        try:
            if not candles or len(candles) < 10:
                return self._no_pattern_result("Insufficient candles")
            
            # Check for engulfing patterns
            engulfing = self._check_engulfing(candles[-2:])
            if engulfing["detected"]:
                return engulfing
            
            # Check for inside bar
            inside_bar = self._check_inside_bar(candles[-3:])
            if inside_bar["detected"]:
                return inside_bar
            
            # Check for false breakout
            false_breakout = self._check_false_breakout(candles[-10:])
            if false_breakout["detected"]:
                return false_breakout
            
            return self._no_pattern_result("No significant pattern")
            
        except Exception as e:
            logger.error(f"Error in pattern analysis: {e}")
            return self._no_pattern_result(f"Analysis error: {e}")
    
    def _check_engulfing(self, candles: List[Dict]) -> Dict:
        """Check for engulfing pattern"""
        if len(candles) < 2:
            return {"detected": False}
        
        prev = candles[0]
        current = candles[1]
        
        prev_body = abs(prev["close"] - prev["open"])
        curr_body = abs(current["close"] - current["open"])
        
        # Bullish engulfing
        if (prev["close"] < prev["open"] and  # Prev bearish
            current["close"] > current["open"] and  # Current bullish
            current["open"] <= prev["close"] and
            current["close"] >= prev["open"] and
            curr_body > prev_body * 1.2):  # Significantly larger
            
            return {
                "detected": True,
                "pattern": "BULLISH_ENGULFING",
                "direction": "BULLISH",
                "score": 75,
                "details": "Bullish engulfing pattern detected"
            }
        
        # Bearish engulfing
        if (prev["close"] > prev["open"] and  # Prev bullish
            current["close"] < current["open"] and  # Current bearish
            current["open"] >= prev["close"] and
            current["close"] <= prev["open"] and
            curr_body > prev_body * 1.2):
            
            return {
                "detected": True,
                "pattern": "BEARISH_ENGULFING",
                "direction": "BEARISH",
                "score": 75,
                "details": "Bearish engulfing pattern detected"
            }
        
        return {"detected": False}
    
    def _check_inside_bar(self, candles: List[Dict]) -> Dict:
        """Check for inside bar pattern"""
        if len(candles) < 2:
            return {"detected": False}
        
        mother = candles[0]
        inside = candles[1]
        
        if (inside["high"] < mother["high"] and
            inside["low"] > mother["low"]):
            
            # Direction based on close relative to mother's range
            mother_mid = (mother["high"] + mother["low"]) / 2
            direction = "BULLISH" if inside["close"] > mother_mid else "BEARISH"
            
            return {
                "detected": True,
                "pattern": "INSIDE_BAR",
                "direction": direction,
                "score": 65,
                "details": f"Inside bar pattern ({direction.lower()} bias)"
            }
        
        return {"detected": False}
    
    def _check_false_breakout(self, candles: List[Dict]) -> Dict:
        """Check for false breakout (sweep and reversal)"""
        if len(candles) < 10:
            return {"detected": False}
        
        highs = [c["high"] for c in candles[:-1]]
        lows = [c["low"] for c in candles[:-1]]
        
        recent_high = max(highs[-5:])
        recent_low = min(lows[-5:])
        
        last = candles[-1]
        
        # False breakout above (bearish)
        if (last["high"] > recent_high and
            last["close"] < recent_high):
            return {
                "detected": True,
                "pattern": "FALSE_BREAKOUT",
                "direction": "BEARISH",
                "score": 70,
                "details": "False breakout above (liquidity sweep)"
            }
        
        # False breakout below (bullish)
        if (last["low"] < recent_low and
            last["close"] > recent_low):
            return {
                "detected": True,
                "pattern": "FALSE_BREAKOUT",
                "direction": "BULLISH",
                "score": 70,
                "details": "False breakout below (liquidity sweep)"
            }
        
        return {"detected": False}
    
    def _no_pattern_result(self, reason: str) -> Dict:
        """Return no pattern result"""
        return {
            "pattern": None,
            "direction": None,
            "score": 0,
            "details": reason
        }
