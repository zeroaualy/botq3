"""
Testes da Automação de Sinais
Valida funcionalidade do SignalEngine
"""
import asyncio
import logging
from datetime import datetime
from zoneinfo import ZoneInfo

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TZ = ZoneInfo("America/Sao_Paulo")


class MockIQClient:
    """Mock do IQ Client para testes"""
    
    def __init__(self):
        self.conectado = True
        self.conta_practice = True
    
    def esta_conectado(self):
        return self.conectado
    
    def garantir_practice(self):
        return self.conta_practice
    
    def verificar_ativo_disponivel(self, ativo):
        # Simula que todos os ativos estão disponíveis
        return True, ativo
    
    class IQMock:
        @staticmethod
        def get_candles(ativo, timeframe, qtd, timestamp):
            # Simula candles
            import random
            candles = []
            base_price = 1.1000
            
            for i in range(qtd):
                open_price = base_price + random.uniform(-0.0010, 0.0010)
                close_price = open_price + random.uniform(-0.0005, 0.0005)
                high_price = max(open_price, close_price) + random.uniform(0, 0.0003)
                low_price = min(open_price, close_price) - random.uniform(0, 0.0003)
                
                candles.append({
                    "open": open_price,
                    "close": close_price,
                    "high": high_price,
                    "low": low_price,
                    "volume": random.randint(100, 1000)
                })
            
            return candles
    
    def __init__(self):
        self.conectado = True
        self.conta_practice = True
        self.iq = self.IQMock()


class MockRuntime:
    """Mock do Runtime para testes"""
    
    def __init__(self):
        self.modo_automatico_ativo = True
        self.sinais_agendados = []
    
    def adicionar_sinal(self, sinal):
        self.sinais_agendados.append(sinal)
        logger.info(f"✅ Sinal adicionado à fila: {sinal['par']} {sinal['direcao']}")


async def test_signal_engine():
    """Testa SignalEngine"""
    from core.signal_engine import SignalEngine
    
    logger.info("🧪 Iniciando testes da Automação de Sinais...")
    
    # Setup
    mock_iq = MockIQClient()
    mock_runtime = MockRuntime()
    mock_config = {
        "automacao_confianca_minima": 65,
        "automacao_intervalo_analise": 5,  # Reduzido para testes
        "automacao_max_sinais_hora": 10
    }
    
    # Criar SignalEngine
    engine = SignalEngine(
        iq_client=mock_iq,
        runtime=mock_runtime,
        config=mock_config
    )
    
    logger.info("✅ SignalEngine criado")
    
    # Teste 1: Verificar estado inicial
    logger.info("\n📋 Teste 1: Estado inicial")
    assert not engine.is_ativo(), "Engine não deve estar ativo inicialmente"
    logger.info("✅ Estado inicial correto")
    
    # Teste 2: Ativar engine
    logger.info("\n📋 Teste 2: Ativação do motor")
    sucesso = await engine.ativar()
    assert sucesso, "Ativação deve ter sucesso"
    assert engine.is_ativo(), "Engine deve estar ativo"
    logger.info("✅ Motor ativado com sucesso")
    
    # Aguardar análise
    logger.info("\n⏳ Aguardando geração de sinais (30 segundos)...")
    await asyncio.sleep(30)
    
    # Verificar se sinais foram gerados
    logger.info(f"\n📊 Sinais gerados: {len(mock_runtime.sinais_agendados)}")
    for i, sinal in enumerate(mock_runtime.sinais_agendados, 1):
        logger.info(
            f"  {i}. {sinal['par']} {sinal['direcao']} - "
            f"Confiança: {sinal.get('confianca', 0)}%"
        )
    
    # Teste 3: Obter estatísticas
    logger.info("\n📋 Teste 3: Estatísticas")
    stats = engine.obter_estatisticas()
    logger.info(f"  Ativo: {stats['ativo']}")
    logger.info(f"  Sinais última hora: {stats['sinais_ultima_hora']}")
    logger.info(f"  Confiança mínima: {stats['confianca_minima']}%")
    logger.info(f"  Intervalo análise: {stats['intervalo_analise']}s")
    logger.info(f"  Máx sinais/hora: {stats['max_sinais_hora']}")
    logger.info("✅ Estatísticas obtidas")
    
    # Teste 4: Desativar engine
    logger.info("\n📋 Teste 4: Desativação do motor")
    sucesso = await engine.desativar()
    assert sucesso, "Desativação deve ter sucesso"
    assert not engine.is_ativo(), "Engine não deve estar ativo"
    logger.info("✅ Motor desativado com sucesso")
    
    logger.info("\n🎉 Todos os testes passaram!")


async def test_analise_estatistica():
    """Testa análise estatística isolada"""
    from core.signal_engine import SignalEngine
    
    logger.info("\n🧪 Testando análise estatística...")
    
    mock_iq = MockIQClient()
    mock_runtime = MockRuntime()
    mock_config = {}
    
    engine = SignalEngine(mock_iq, mock_runtime, mock_config)
    
    # Gerar candles de teste
    candles_alta = [
        {"open": 1.1000, "close": 1.1010, "high": 1.1015, "low": 1.0995, "volume": 500}
        for _ in range(20)
    ]
    
    candles_baixa = [
        {"open": 1.1000, "close": 1.0990, "high": 1.1005, "low": 1.0985, "volume": 500}
        for _ in range(20)
    ]
    
    # Teste tendência de alta
    analise = engine._analisar_ativo(candles_alta, "EURUSD")
    logger.info(f"\nTendência de ALTA:")
    logger.info(f"  Direção: {analise['direcao']}")
    logger.info(f"  Confiança: {analise['confianca']}%")
    logger.info(f"  Score: {analise['score']:.1f}")
    logger.info(f"  Motivo: {analise['motivo']}")
    
    # Teste tendência de baixa
    analise = engine._analisar_ativo(candles_baixa, "EURUSD")
    logger.info(f"\nTendência de BAIXA:")
    logger.info(f"  Direção: {analise['direcao']}")
    logger.info(f"  Confiança: {analise['confianca']}%")
    logger.info(f"  Score: {analise['score']:.1f}")
    logger.info(f"  Motivo: {analise['motivo']}")
    
    logger.info("\n✅ Análise estatística validada")


async def main():
    """Executa todos os testes"""
    logger.info("="*60)
    logger.info("🧠 TESTES - AUTOMAÇÃO DE SINAIS")
    logger.info("="*60)
    
    try:
        # Teste de análise estatística
        await test_analise_estatistica()
        
        # Teste do SignalEngine completo
        await test_signal_engine()
        
        logger.info("\n" + "="*60)
        logger.info("✅ TODOS OS TESTES CONCLUÍDOS COM SUCESSO!")
        logger.info("="*60)
        
    except Exception as e:
        logger.error(f"\n❌ ERRO NOS TESTES: {e}")
        import traceback
        logger.error(traceback.format_exc())


if __name__ == "__main__":
    asyncio.run(main())
