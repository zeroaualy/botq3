# 🚀 GUIA RÁPIDO - MIGRAÇÃO PARA PLAYWRIGHT

## ⚡ PASSO A PASSO (10 minutos)

### 1. BACKUP DO PROJETO ATUAL
```bash
cp -r bot/ bot_backup/
```

### 2. ATUALIZAR ARQUIVOS
```bash
cd bot/

# Copiar novos arquivos (já estão no projeto)
# ✅ main_playwright.py
# ✅ core/iq_playwright_client.py
# ✅ core/playwright_trade_executor.py
# ✅ core/playwright_wrapper.py
# ✅ requirements_playwright.txt
# ✅ install_playwright.sh
```

### 3. INSTALAR PLAYWRIGHT
```bash
# Método automático (RECOMENDADO)
sudo bash install_playwright.sh

# OU método manual:
source venv/bin/activate
pip install playwright
playwright install chromium
playwright install-deps chromium
```

### 4. VERIFICAR .env
```bash
nano .env

# Deve conter:
EMAIL=seu_email@iqoption.com
SENHA=sua_senha
TOKEN=seu_token_telegram
GRUPO_ID=seu_grupo_id
GROQ_API_KEY=sua_key_groq  # Opcional
```

### 5. TESTAR PLAYWRIGHT
```bash
source venv/bin/activate
./test_playwright.sh

# Deve mostrar:
# ✅ Título: Google
# ✅ Playwright funcionando!
```

### 6. EXECUTAR BOT
```bash
# Teste manual primeiro
source venv/bin/activate
python3 main_playwright.py

# Se tudo OK, instalar como serviço:
sudo systemctl start botq3
sudo systemctl enable botq3
```

---

## 🔍 VERIFICAÇÕES

### ✅ Checklist de funcionamento

- [ ] Playwright instalado: `playwright --version`
- [ ] Chromium instalado: `playwright install chromium`
- [ ] .env configurado
- [ ] Bot iniciou sem erros
- [ ] Logs mostram "✅ Login bem-sucedido!"
- [ ] Logs mostram "✅ Conta PRACTICE confirmada"

### 🐛 Se algo falhar

**Erro: "playwright not found"**
```bash
source venv/bin/activate
pip install playwright
```

**Erro: "chromium not installed"**
```bash
playwright install chromium
playwright install-deps chromium
```

**Erro: "Login failed"**
- Verificar email/senha no .env
- IQ Option pode estar bloqueando bots
- Tentar em outro horário

**Bot não executa trade**
```bash
# Ver logs detalhados
sudo journalctl -u botq3 -f

# Procurar por:
# ✅ Login bem-sucedido
# ✅ Conta PRACTICE confirmada
# ❌ Erro ao executar trade
```

---

## 📊 DIFERENÇAS MAIN ANTIGO vs NOVO

### `main.py` (ANTIGO - API não oficial)
```python
from core.iq_client import IQClient
from core.trade_executor import TradeExecutor

iq_client = IQClient(EMAIL, SENHA)
iq_client.conectar()  # Conecta via API

trade_executor = TradeExecutor(iq_client)
status, order_id = trade_executor.executar(...)  # ❌ NÃO EXECUTA
```

### `main_playwright.py` (NOVO - Navegador real)
```python
from core.iq_playwright_client import IQPlaywrightClient
from core.playwright_trade_executor import PlaywrightTradeExecutor

iq_client = IQPlaywrightClient(EMAIL, SENHA)
await iq_client.iniciar()  # Abre navegador e loga

trade_executor = PlaywrightTradeExecutor(iq_client)
status, order_id = await trade_executor.executar(...)  # ✅ EXECUTA REAL
```

**Principais mudanças:**
1. ✨ Todas as operações agora são `async/await`
2. ✨ Usa navegador real (Playwright)
3. ✨ Executa cliques na interface
4. ✨ Confirma visualmente ordem aberta

---

## 🎯 TESTE RÁPIDO

### 1. Enviar sinal de teste

No grupo Telegram:
```
EURUSD
CALL
1M
```

### 2. Acompanhar logs
```bash
sudo journalctl -u botq3 -f
```

### 3. Verificar saída esperada
```
🔐 Tentativa de login 1/3...
✅ Login bem-sucedido!
✅ Conta PRACTICE confirmada - Saldo: $10000.00
📊 Selecionando ativo: EURUSD
💵 Definindo valor: $10
👆 Clicando em CALL...
✅ Clicou em CALL
✅ Ordem confirmada na interface
🎯 OPERAÇÃO EXECUTADA (Playwright)
```

---

## 🔄 ROLLBACK (se necessário)

Se algo der errado, voltar para versão antiga:

```bash
# Parar serviço novo
sudo systemctl stop botq3

# Restaurar backup
rm -rf bot/
mv bot_backup/ bot/
cd bot/

# Executar versão antiga
source venv/bin/activate
python3 main.py
```

---

## 💡 DICAS

### Performance VPS
- Use headless=True (já configurado)
- Feche navegador após cada operação (já implementado)
- Monitore uso de memória: `htop`

### Debugging
```bash
# Ver apenas erros
sudo journalctl -u botq3 | grep ERROR

# Ver últimas 50 linhas
sudo journalctl -u botq3 -n 50

# Seguir logs
sudo journalctl -u botq3 -f
```

### Logs importantes
```
✅ Login bem-sucedido!           # Login OK
✅ Conta PRACTICE confirmada     # Segurança OK
🎯 OPERAÇÃO EXECUTADA            # Trade executado
✅ WIN - Lucro: $18.00           # Resultado
```

---

## ⏱️ TEMPO ESTIMADO

- Instalação: ~5-10 minutos
- Configuração: ~2 minutos
- Primeiro teste: ~1 minuto

**Total: ~15 minutos**

---

## 🎉 PRONTO!

Agora seu bot:
- ✅ Executa trades REAIS
- ✅ Opera em conta PRACTICE
- ✅ Funciona 24/7 no VPS
- ✅ Reconecta automaticamente

**Próximo passo:** Enviar primeiro sinal e acompanhar execução! 🚀
