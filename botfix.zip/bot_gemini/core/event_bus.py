"""
Event Bus - Q3 IA Beta
Sistema de eventos assíncrono para comunicação interna entre componentes
"""
import asyncio
import logging
from typing import Callable, Dict, List, Any, Optional
from enum import Enum
from datetime import datetime

logger = logging.getLogger(__name__)


class EventType(str, Enum):
    """Tipos de eventos do sistema"""
    # Sinais
    SIGNAL_RECEIVED = "signal_received"
    SIGNAL_APPROVED = "signal_approved"
    SIGNAL_REJECTED = "signal_rejected"
    SIGNAL_QUEUED = "signal_queued"
    
    # Trades
    TRADE_EXECUTED = "trade_executed"
    TRADE_RESULT = "trade_result"
    TRADE_WIN = "trade_win"
    TRADE_LOSS = "trade_loss"
    
    # Risk Management
    RISK_BLOCKED = "risk_blocked"
    RISK_WARNING = "risk_warning"
    STOP_LOSS_HIT = "stop_loss_hit"
    STOP_GAIN_HIT = "stop_gain_hit"
    
    # System
    ENGINE_ERROR = "engine_error"
    ENGINE_STARTED = "engine_started"
    ENGINE_STOPPED = "engine_stopped"
    CONNECTION_LOST = "connection_lost"
    CONNECTION_RESTORED = "connection_restored"
    
    # IA
    IA_GUARD_DECISION = "ia_guard_decision"
    Q3_IA_SCORE = "q3_ia_score"
    STATS_UPDATED = "stats_updated"


class Event:
    """Representa um evento no sistema"""
    
    def __init__(self, event_type: EventType, data: Optional[Dict[str, Any]] = None, 
                 metadata: Optional[Dict[str, Any]] = None):
        """
        Inicializa um evento
        
        Args:
            event_type: Tipo do evento
            data: Dados do evento
            metadata: Metadados adicionais (timestamp, source, etc)
        """
        self.type = event_type
        self.data = data or {}
        self.metadata = metadata or {}
        self.timestamp = datetime.now()
        self.metadata['timestamp'] = self.timestamp.isoformat()
    
    def __repr__(self):
        return f"Event({self.type}, data_keys={list(self.data.keys())})"


class EventBus:
    """
    Event Bus assíncrono para comunicação entre componentes
    
    Características:
    - Publicação assíncrona de eventos
    - Múltiplos handlers por evento
    - Execução isolada de handlers (um erro não afeta outros)
    - Tratamento de exceções interno
    - Suporte a filtros por tipo de evento
    """
    
    def __init__(self):
        """Inicializa o Event Bus"""
        self._handlers: Dict[EventType, List[Callable]] = {}
        self._global_handlers: List[Callable] = []
        self._event_history: List[Event] = []
        self._max_history = 1000
        self._running = True
        
        logger.info("✅ Event Bus inicializado")
    
    def subscribe(self, event_type: EventType, handler: Callable, 
                  handler_name: Optional[str] = None) -> None:
        """
        Registra um handler para um tipo de evento específico
        
        Args:
            event_type: Tipo de evento a observar
            handler: Função async que será chamada quando o evento ocorrer
            handler_name: Nome opcional para identificação em logs
        
        Example:
            async def on_signal(event):
                print(f"Sinal recebido: {event.data}")
            
            event_bus.subscribe(EventType.SIGNAL_RECEIVED, on_signal)
        """
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        
        self._handlers[event_type].append(handler)
        
        name = handler_name or handler.__name__
        logger.info(f"📌 Handler '{name}' registrado para evento '{event_type.value}'")
    
    def subscribe_all(self, handler: Callable, handler_name: Optional[str] = None) -> None:
        """
        Registra um handler para todos os eventos
        
        Args:
            handler: Função async que será chamada para qualquer evento
            handler_name: Nome opcional para identificação em logs
        """
        self._global_handlers.append(handler)
        
        name = handler_name or handler.__name__
        logger.info(f"📌 Handler global '{name}' registrado")
    
    def unsubscribe(self, event_type: EventType, handler: Callable) -> None:
        """
        Remove um handler de um tipo de evento
        
        Args:
            event_type: Tipo de evento
            handler: Handler a ser removido
        """
        if event_type in self._handlers and handler in self._handlers[event_type]:
            self._handlers[event_type].remove(handler)
            logger.info(f"🔓 Handler removido de '{event_type.value}'")
    
    async def publish(self, event_type: EventType, data: Optional[Dict[str, Any]] = None,
                     metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Publica um evento assincronamente
        
        Args:
            event_type: Tipo do evento
            data: Dados do evento
            metadata: Metadados adicionais
        
        Example:
            await event_bus.publish(
                EventType.SIGNAL_RECEIVED,
                data={'par': 'EURUSD', 'direcao': 'CALL'},
                metadata={'source': 'signal_engine'}
            )
        """
        if not self._running:
            logger.warning(f"⚠️ Event Bus parado - evento {event_type.value} não publicado")
            return
        
        # Criar evento
        event = Event(event_type, data, metadata)
        
        # Adicionar ao histórico
        self._add_to_history(event)
        
        # Log do evento
        logger.debug(f"📤 Evento publicado: {event_type.value}")
        
        # Executar handlers específicos
        if event_type in self._handlers:
            await self._execute_handlers(self._handlers[event_type], event, event_type.value)
        
        # Executar handlers globais
        if self._global_handlers:
            await self._execute_handlers(self._global_handlers, event, "global")
    
    async def _execute_handlers(self, handlers: List[Callable], event: Event, 
                                context: str) -> None:
        """
        Executa handlers de forma isolada e assíncrona
        
        Args:
            handlers: Lista de handlers a executar
            event: Evento a processar
            context: Contexto para logging
        """
        # Criar tasks para execução paralela
        tasks = []
        for handler in handlers:
            task = asyncio.create_task(self._safe_execute_handler(handler, event, context))
            tasks.append(task)
        
        # Aguardar todas as tasks (sem falhar se alguma falhar)
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
    
    async def _safe_execute_handler(self, handler: Callable, event: Event, 
                                    context: str) -> None:
        """
        Executa um handler com tratamento de exceções
        
        Args:
            handler: Handler a executar
            event: Evento a processar
            context: Contexto para logging
        """
        try:
            # Verificar se handler é async
            if asyncio.iscoroutinefunction(handler):
                await handler(event)
            else:
                # Handler síncrono - executar em thread pool
                await asyncio.get_event_loop().run_in_executor(None, handler, event)
        
        except Exception as e:
            # Log do erro mas não propaga (isolamento)
            logger.error(
                f"❌ Erro no handler '{handler.__name__}' ({context}): {e}",
                exc_info=True
            )
    
    def _add_to_history(self, event: Event) -> None:
        """
        Adiciona evento ao histórico mantendo limite máximo
        
        Args:
            event: Evento a adicionar
        """
        self._event_history.append(event)
        
        # Manter apenas os últimos N eventos
        if len(self._event_history) > self._max_history:
            self._event_history = self._event_history[-self._max_history:]
    
    def get_history(self, event_type: Optional[EventType] = None, 
                   limit: int = 100) -> List[Event]:
        """
        Retorna histórico de eventos
        
        Args:
            event_type: Filtrar por tipo (None = todos)
            limit: Número máximo de eventos
        
        Returns:
            Lista de eventos
        """
        if event_type:
            events = [e for e in self._event_history if e.type == event_type]
        else:
            events = self._event_history
        
        return events[-limit:]
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Retorna estatísticas do Event Bus
        
        Returns:
            Dicionário com estatísticas
        """
        event_counts = {}
        for event in self._event_history:
            event_counts[event.type.value] = event_counts.get(event.type.value, 0) + 1
        
        return {
            'total_events': len(self._event_history),
            'event_types_registered': len(self._handlers),
            'total_handlers': sum(len(h) for h in self._handlers.values()),
            'global_handlers': len(self._global_handlers),
            'event_counts': event_counts,
            'running': self._running
        }
    
    def clear_history(self) -> None:
        """Limpa o histórico de eventos"""
        self._event_history.clear()
        logger.info("🗑️ Histórico de eventos limpo")
    
    async def shutdown(self) -> None:
        """Desliga o Event Bus"""
        self._running = False
        logger.info("⛔ Event Bus desligado")


# Instância global do Event Bus
_event_bus_instance: Optional[EventBus] = None


def get_event_bus() -> EventBus:
    """
    Retorna a instância global do Event Bus (singleton)
    
    Returns:
        Instância do EventBus
    """
    global _event_bus_instance
    
    if _event_bus_instance is None:
        _event_bus_instance = EventBus()
    
    return _event_bus_instance
