"""
Execution Engine — Bot Q3 Beta
THE single execution path. All trades — manual and automatic — go through here.
No parallel logic. No duplicated paths.
"""
import asyncio
import logging
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Optional, Dict, Tuple

from core.risk_manager import RiskManager
from core.martingale_manager import MartingaleManager
from db import database

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class ExecutionEngine:
    """
    Unified execution pipeline:

    execute(signal) →
        1. Slippage measurement
        2. RiskManager validation (stop loss, consecutive losses, payout, Kelly)
        3. MartingaleManager sizing
        4. IQ client execution
        5. Order confirmation (order_id existence = success)
        6. DB trade insert
        7. Result settlement (buy_blitz returns result synchronously)
        8. DB result update
        9. Martingale state update
        10. Daily stats update
        11. Telegram notification callback
    """

    def __init__(
        self,
        iq_client,
        risk_manager: RiskManager,
        martingale_manager: MartingaleManager,
        global_config: dict,
        notify_callback=None,
    ):
        self.iq = iq_client
        self.risk = risk_manager
        self.martingale = martingale_manager
        self._cfg = global_config
        self._notify = notify_callback  # async fn(message: str)

    async def execute(self, signal: Dict, signal_received_at: datetime = None) -> Dict:
        """
        Execute a trade signal end-to-end.

        signal keys: par, direcao, tempo_expiracao, [imediato, horario]
        signal_source: "manual" | "auto_generator" | "auto_trader"

        Returns result dict with all trade metadata.
        """
        if signal_received_at is None:
            signal_received_at = datetime.now(TZ)

        asset = signal.get("par", "")
        direction = signal.get("direcao", "").upper()
        expiracao = int(signal.get("tempo_expiracao", 60))
        signal_source = signal.get("signal_source", "manual")
        signal_id = signal.get("signal_id")

        # ── 1. Slippage ──────────────────────────────────────
        now = datetime.now(TZ)
        # Ensure timezone-aware (guard against naive datetimes)
        if signal_received_at.tzinfo is None:
            signal_received_at = signal_received_at.replace(tzinfo=TZ)
        slippage_ms = max(0, int((now - signal_received_at).total_seconds() * 1000))
        logger.info(f"⏱️ Slippage: {slippage_ms}ms | {asset} {direction}")

        # ── 2. Validate asset live & get payout ──────────────
        if not self.iq.esta_conectado():
            await self._notify_err("🔌 IQ Option desconectado")
            return self._fail("desconectado")

        validation = await self.iq._integration.validate_asset_live(asset)
        if not validation.get("valid"):
            msg = validation.get("error", "Ativo indisponível")
            await self._notify_err(f"❌ {asset}: {msg}")
            return self._fail(msg)

        payout_pct = float(validation.get("payout", 0))

        # ── 3. Risk validation ────────────────────────────────
        can_exec, reason, amount = await self.risk.validar_operacao(
            signal, payout_pct, slippage_ms
        )
        if not can_exec:
            await self._notify_err(f"🛡️ Bloqueado: {reason}")
            return self._fail(reason)

        # ── 4. Martingale sizing ──────────────────────────────
        if self.martingale.enabled:
            mg_amount, mg_level = self.martingale.get_next_value()
            if mg_amount == 0.0:
                await self._notify_err(
                    f"⛔ Martingale no nível máximo ({mg_level})\n"
                    "Use /resetmartingale para reiniciar."
                )
                return self._fail("martingale_max_level")
            amount = mg_amount
            martingale_level = mg_level
        else:
            martingale_level = 0

        # ── 5. Balance check ─────────────────────────────────
        saldo = await self.iq.obter_saldo()
        if saldo < amount:
            msg = f"💰 Saldo insuficiente (${saldo:.2f} < ${amount:.2f})"
            await self._notify_err(msg)
            return self._fail(msg)

        # ── 6. Notify pre-execution ───────────────────────────
        if self._notify:
            await self._notify(
                f"⚡ <b>Executando</b>\n"
                f"📊 {asset} {direction} · {expiracao}s\n"
                f"💰 ${amount:.2f} · Payout {payout_pct:.0f}%"
                + (f" · Martingale L{martingale_level}" if self.martingale.enabled else "")
            )

        # ── 7. Insert pre-result trade record ─────────────────
        trade_id = await database.insert_trade(
            asset=asset,
            direction=direction,
            amount=amount,
            payout=payout_pct,
            martingale_level=martingale_level,
            slippage_ms=slippage_ms,
            signal_source=signal_source,
            signal_id=signal_id,
        )

        # ── 8. Execute trade ──────────────────────────────────
        self.risk.registrar_inicio()
        execution_start = datetime.now(TZ)

        try:
            ok, order_id, error_msg = await self.iq.executar_ordem(
                asset, direction, amount, expiracao
            )
        except Exception as e:
            self.risk.registrar_fim()
            logger.error(f"❌ Execution exception: {e}", exc_info=True)
            return self._fail(str(e))

        # ── 9. Confirm order (order_id = success) ─────────────
        if not ok or not order_id:
            self.risk.registrar_fim()
            msg = error_msg or "Ordem não confirmada pela API"
            await self._notify_err(f"❌ {asset} {direction} — {msg}")
            return self._fail(msg)

        exec_ms = int((datetime.now(TZ) - execution_start).total_seconds() * 1000)
        logger.info(f"✅ Ordem executada: ID={order_id} em {exec_ms}ms")

        # ── 10. Parse settlement result ───────────────────────
        # buy_blitz / buy_digital_spot return the settled result synchronously.
        # The IQ integration layer handles this in executar_ordem → execute_trade.
        # Result is embedded in the return or via the settlement future inside myiq.
        # We retrieve it from the raw trade result stored in iq_integration.
        result_str, pnl = await self._settle(order_id, asset, direction, amount, expiracao)
        self.risk.registrar_fim()

        # ── 11. DB updates ────────────────────────────────────
        await database.update_trade_result(trade_id, result_str, pnl, order_id)
        await database.upsert_daily(result_str, pnl)

        # ── 12. Martingale update ─────────────────────────────
        if self.martingale.enabled:
            await self.martingale.register_result(result_str)

        # ── 13. Notify result ─────────────────────────────────
        today = await database.get_today_stats()
        emoji = {"WIN": "✅", "LOSS": "❌", "EMPATE": "⚪"}.get(result_str, "⚠️")
        saldo_novo = await self.iq.obter_saldo()

        mg_status = ""
        if self.martingale.enabled:
            st = self.martingale.get_status()
            if result_str == "LOSS" and st["level"] < st["max_levels"]:
                mg_status = f"\n🎲 Martingale L{st['level']} · Próximo: ${st['next_value']:.2f}"
            elif result_str == "WIN":
                mg_status = "\n🎲 Martingale resetado"

        if self._notify:
            await self._notify(
                f"{emoji} <b>{asset} {direction} · {result_str}</b>\n"
                f"💰 P&L: ${pnl:+.2f} · Saldo: ${saldo_novo:.2f}\n"
                f"📈 Dia: {today['wins']}W {today['losses']}L {today['draws']}E "
                f"· {today['winrate']:.0f}% · ${today['pnl']:+.2f}"
                + mg_status
            )

        return {
            "success": True,
            "order_id": order_id,
            "result": result_str,
            "pnl": pnl,
            "amount": amount,
            "payout": payout_pct,
            "slippage_ms": slippage_ms,
            "martingale_level": martingale_level,
        }

    # ─────────────────────────────────────────────────────────
    # SETTLEMENT
    # ─────────────────────────────────────────────────────────

    async def _settle(
        self,
        order_id: str,
        asset: str,
        direction: str,
        amount: float,
        expiracao: int,
    ) -> Tuple[str, float]:
        """
        buy_blitz already returns the settled result.
        The result is already in iq_integration._last_result or
        returned directly by the integration layer.

        We extract from the result that executar_ordem already resolved.
        Since iq_integration.execute_trade returns (bool, order_id, error)
        and the result dict from buy_blitz includes pnl+result, we need
        the integration layer to store the raw result for us to read here.

        For simplicity and to eliminate the race condition:
        - If iq_client exposes get_last_trade_result(order_id), use it.
        - Otherwise, wait for the settlement engine once.
        """
        # Try to get result from integration layer cache
        result_data = None
        if hasattr(self.iq, "_integration") and hasattr(self.iq._integration, "_last_trade_result"):
            result_data = self.iq._integration._last_trade_result.get(order_id)

        if not result_data:
            # Wait for settlement from SettlementEngine if registered
            timeout = expiracao + 35
            waited = 0
            while waited < timeout:
                res = await database.get_recent_trades(1)
                # fallback: poll iq_integration result cache
                if hasattr(self.iq, "_integration"):
                    cached = getattr(self.iq._integration, "_last_trade_result", {})
                    result_data = cached.get(order_id)
                    if result_data:
                        break
                await asyncio.sleep(1)
                waited += 1

        if not result_data:
            logger.warning(f"⏱️ Settlement timeout for {order_id}")
            return "DESCONHECIDO", 0.0

        outcome = result_data.get("result", "").lower()
        pnl = float(result_data.get("pnl", 0.0))

        if outcome == "win":
            return "WIN", abs(pnl)
        elif outcome in ("loose", "loss"):
            return "LOSS", -abs(amount)
        elif outcome == "equal":
            return "EMPATE", 0.0
        else:
            return "DESCONHECIDO", 0.0

    # ─────────────────────────────────────────────────────────
    # HELPERS
    # ─────────────────────────────────────────────────────────

    @staticmethod
    def _fail(reason: str) -> Dict:
        return {"success": False, "reason": reason}

    async def _notify_err(self, msg: str):
        if self._notify:
            await self._notify(msg)
        logger.warning(msg)
