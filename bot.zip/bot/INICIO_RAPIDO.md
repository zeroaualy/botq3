# 🚀 INÍCIO RÁPIDO - 5 MINUTOS

## ⚡ INSTALAÇÃO EXPRESS

### 1️⃣ Upload para VPS (30s)
```bash
# No seu computador:
scp bot_playwright_v3.1.tar.gz root@seu_vps:/root/
```

### 2️⃣ Descompactar e instalar (3 min)
```bash
# No VPS:
ssh root@seu_vps
cd /root
tar -xzf bot_playwright_v3.1.tar.gz
cd bot_playwright_v3.1
sudo bash install_playwright.sh
```

### 3️⃣ Configurar credenciais (1 min)
```bash
nano .env
```

**Cole isto e edite:**
```env
EMAIL=seu_email@iqoption.com
SENHA=sua_senha_aqui
TOKEN=seu_token_telegram
GRUPO_ID=seu_id_grupo
GROQ_API_KEY=  # Opcional, pode deixar vazio
```

Salvar: `Ctrl+O`, `Enter`, `Ctrl+X`

### 4️⃣ Testar (30s)
```bash
./test_playwright.sh
```

Deve mostrar:
```
✅ Playwright está instalado
✅ Chromium iniciado com sucesso
✅ Página criada
✅ Navegação para Google bem-sucedida
✅ Título da página: Google
✅ Navegador fechado
🎉 Playwright está funcionando perfeitamente!
```

### 5️⃣ Executar! (0s)
```bash
# Modo teste (ver logs na tela):
python3 main_playwright.py

# OU modo produção 24/7:
sudo systemctl start botq3
sudo systemctl enable botq3  # Auto-start no boot
```

---

## 📱 USAR O BOT

### Enviar sinal no Telegram

Formato simples:
```
EURUSD
CALL
1M
```

Ou formato completo:
```
Par: EURUSD-OTC
Direção: PUT
Expiração: 60s
Horário: 14:35
```

### O bot vai:
1. ✅ Receber sinal
2. 🌐 Abrir navegador
3. 🔐 Fazer login
4. 🏦 Garantir PRACTICE
5. 📊 Executar trade
6. ⏳ Aguardar resultado
7. 📊 Reportar no Telegram

---

## 📊 VER LOGS

```bash
# Logs em tempo real
sudo journalctl -u botq3 -f

# Últimas 50 linhas
sudo journalctl -u botq3 -n 50

# Filtrar erros
sudo journalctl -u botq3 | grep ERROR
```

---

## 🎛️ COMANDOS

```bash
# Iniciar
sudo systemctl start botq3

# Parar
sudo systemctl stop botq3

# Reiniciar
sudo systemctl restart botq3

# Status
sudo systemctl status botq3

# Desabilitar auto-start
sudo systemctl disable botq3
```

---

## ✅ VERIFICAÇÕES

### Bot está funcionando?
```bash
sudo systemctl status botq3
```

Deve mostrar:
```
● botq3.service - Bot Q3 IA Playwright
   Active: active (running)
```

### Logs mostram sucesso?
```bash
sudo journalctl -u botq3 -n 20
```

Deve ter:
```
✅ Login bem-sucedido!
✅ Conta PRACTICE confirmada
🤖 Bot rodando - Sistema autônomo ativo
```

---

## 🐛 PROBLEMAS?

### "playwright not found"
```bash
source venv/bin/activate
pip install playwright
playwright install chromium
```

### "Login failed"
- Verificar email/senha no .env
- Aguardar 5 minutos e tentar novamente

### Bot não executa trade
```bash
# Ver o que está acontecendo
sudo journalctl -u botq3 -f

# Reiniciar bot
sudo systemctl restart botq3
```

---

## 📚 DOCUMENTAÇÃO COMPLETA

- `README_PLAYWRIGHT.md` - Guia completo
- `GUIA_MIGRACAO.md` - Migração do v3.0
- `DOCUMENTACAO_TECNICA.md` - Detalhes técnicos
- `RESUMO_EXECUTIVO.md` - Visão geral

---

## 🎉 PRONTO!

Seu bot agora:
- ✅ Executa trades REAIS
- ✅ Opera 24/7 automaticamente
- ✅ Sempre em conta PRACTICE
- ✅ Reconecta se cair

**Boa sorte com seus trades!** 🚀

---

**Problemas? Entre em contato ou consulte a documentação.**
