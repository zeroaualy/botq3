"""
Scoring Engine - Confluence Scoring System
Aggregates all analysis results into unified score
"""
import logging
from typing import Dict, List

logger = logging.getLogger(__name__)


class ScoringEngine:
    """
    Combines all analysis results into a unified score
    
    Features:
    - Weighted scoring system
    - Confluence counting
    - Confidence level classification
    - Adaptive thresholds
    """
    
    def __init__(self):
        # Weights for each component (must sum to 1.0)
        self.weights = {
            "trend": 0.25,
            "structure": 0.20,
            "pattern": 0.15,
            "liquidity": 0.10,
            "volatility": 0.15,
            "filters": 0.15
        }
        
        # Base threshold (can be adapted)
        self.base_threshold = 65
        self.current_threshold = self.base_threshold
    
    def calculate_score(self, analysis_results: Dict) -> Dict:
        """
        Calculate unified score from all analysis results
        
        Args:
            analysis_results: Dict containing results from all engines
            
        Returns:
            Dict with:
            {
                "total_score": 0-100,
                "confluence_count": int,
                "confidence_level": "HIGH" | "MEDIUM" | "LOW",
                "direction": "CALL" | "PUT" | "NEUTRAL",
                "breakdown": Dict,
                "passes_threshold": bool
            }
        """
        try:
            scores = {}
            confluence_items = []
            
            # Extract scores from each component
            trend = analysis_results.get("trend", {})
            if trend.get("score", 0) > 0:
                scores["trend"] = trend["score"]
                if trend.get("ema_aligned"):
                    confluence_items.append("EMA_ALIGNED")
            
            structure = analysis_results.get("structure", {})
            if structure.get("score", 0) > 0:
                scores["structure"] = structure["score"]
                if structure.get("bos_detected"):
                    confluence_items.append("BOS")
            
            pattern = analysis_results.get("pattern", {})
            if pattern.get("score", 0) > 0:
                scores["pattern"] = pattern["score"]
                if pattern.get("pattern"):
                    confluence_items.append(f"PATTERN_{pattern['pattern']}")
            
            liquidity = analysis_results.get("liquidity", {})
            if liquidity.get("score", 0) > 0:
                scores["liquidity"] = liquidity["score"]
                if liquidity.get("sweep_detected"):
                    confluence_items.append("LIQUIDITY_SWEEP")
            
            volatility = analysis_results.get("volatility", {})
            if volatility.get("atr_score", 0) > 0:
                scores["volatility"] = volatility["atr_score"]
                if volatility.get("volatility_state") == "NORMAL":
                    confluence_items.append("OPTIMAL_VOLATILITY")
            
            filters = analysis_results.get("filters", {})
            if filters.get("filter_score", 0) > 0:
                scores["filters"] = filters["filter_score"]
                if filters.get("recommended"):
                    confluence_items.append("TIME_FILTER_PASS")
            
            # Calculate weighted total score
            total_score = 0
            for component, score in scores.items():
                weight = self.weights.get(component, 0)
                total_score += score * weight
            
            total_score = int(total_score)
            
            # Determine direction (majority vote)
            direction = self._determine_direction(analysis_results)
            
            # Classify confidence level
            confidence_level = self._classify_confidence(total_score, len(confluence_items))
            
            # Check if passes threshold
            passes_threshold = total_score >= self.current_threshold
            
            return {
                "total_score": total_score,
                "confluence_count": len(confluence_items),
                "confluence_items": confluence_items,
                "confidence_level": confidence_level,
                "direction": direction,
                "breakdown": scores,
                "passes_threshold": passes_threshold,
                "threshold": self.current_threshold
            }
            
        except Exception as e:
            logger.error(f"Error calculating score: {e}")
            return {
                "total_score": 0,
                "confluence_count": 0,
                "confidence_level": "LOW",
                "direction": "NEUTRAL",
                "breakdown": {},
                "passes_threshold": False
            }
    
    def _determine_direction(self, analysis_results: Dict) -> str:
        """Determine overall direction based on majority vote"""
        votes = {"BULLISH": 0, "BEARISH": 0, "CALL": 0, "PUT": 0}
        
        # Count votes from each component
        for component in ["trend", "structure", "pattern", "liquidity"]:
            result = analysis_results.get(component, {})
            direction = result.get("direction") or result.get(component)
            
            if direction in votes:
                votes[direction] += 1
        
        # Normalize CALL/PUT to BULLISH/BEARISH
        bullish_total = votes["BULLISH"] + votes["CALL"]
        bearish_total = votes["BEARISH"] + votes["PUT"]
        
        if bullish_total > bearish_total:
            return "CALL"
        elif bearish_total > bullish_total:
            return "PUT"
        else:
            return "NEUTRAL"
    
    def _classify_confidence(self, score: int, confluence_count: int) -> str:
        """Classify confidence level"""
        if score >= 80 and confluence_count >= 4:
            return "HIGH"
        elif score >= 65 and confluence_count >= 3:
            return "MEDIUM"
        else:
            return "LOW"
    
    def adapt_threshold(self, recent_performance: Dict):
        """
        Adapt threshold based on recent performance
        
        Args:
            recent_performance: Dict with performance metrics
        """
        winrate = recent_performance.get("winrate", 50)
        trades_count = recent_performance.get("trades_count", 0)
        
        # Need at least 10 trades to adapt
        if trades_count < 10:
            return
        
        # If winrate is low, increase threshold
        if winrate < 45:
            self.current_threshold = min(85, self.base_threshold + 10)
            logger.info(f"📈 Threshold increased to {self.current_threshold} (low winrate)")
        
        # If winrate is high, can decrease threshold slightly
        elif winrate > 65:
            self.current_threshold = max(60, self.base_threshold - 5)
            logger.info(f"📉 Threshold decreased to {self.current_threshold} (high winrate)")
        
        # Otherwise reset to base
        else:
            self.current_threshold = self.base_threshold
    
    def get_threshold(self) -> int:
        """Get current threshold"""
        return self.current_threshold
