#!/bin/bash

# ═══════════════════════════════════════════════════════════
# Setup do Bot Q3 IA v3.0 com Q3 IA Beta
# ═══════════════════════════════════════════════════════════

echo "═══════════════════════════════════════════════════════════"
echo "🚀 Setup do Bot Q3 IA v3.0 com Q3 IA Beta"
echo "═══════════════════════════════════════════════════════════"
echo ""

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 não encontrado. Por favor, instale Python 3.10+"
    exit 1
fi

echo "✅ Python encontrado: $(python3 --version)"
echo ""

# Instalar dependências
echo "📦 Instalando dependências..."
pip3 install -r requirements.txt --break-system-packages

if [ $? -ne 0 ]; then
    echo "⚠️ Tentando sem --break-system-packages..."
    pip3 install -r requirements.txt
fi

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ Setup concluído!"
echo ""
echo "📝 Próximos passos:"
echo "1. Edite state/config.py com suas credenciais:"
echo "   - TOKEN (Telegram Bot Token)"
echo "   - GRUPO_ID (ID do seu grupo/canal)"
echo "   - EMAIL e SENHA (IQ Option)"
echo "   - GROQ_API_KEY (Groq AI)"
echo ""
echo "2. Execute o bot:"
echo "   python3 main.py"
echo ""
echo "⚠️ IMPORTANTE:"
echo "   - O bot opera APENAS em conta PRACTICE"
echo "   - Q3 IA Beta: Filtro estratégico inteligente"
echo "   - Risk Manager: Controle adaptativo de risco"
echo "   - Stats Optimizer: Análise estatística"
echo "═══════════════════════════════════════════════════════════"
