"""
Cliente IQ Option usando biblioteca myiq
Responsável por conexão e garantia de conta PRACTICE
"""
import logging
import asyncio
import time
from typing import Tuple, Optional

logger = logging.getLogger(__name__)

# Flag global para instância
_iq_instance = None


class IQClient:
    """Cliente IQ Option com garantia de conta PRACTICE usando myiq"""
    
    def __init__(self, email, senha):
        self.email = email
        self.senha = senha
        self.iq = None
        self._connected = False
        self._practice_balance_id = None
        
    async def conectar(self, max_tentativas=3):
        """Conecta à IQ Option e força conta PRACTICE (async)"""
        global _iq_instance
        
        for tentativa in range(max_tentativas):
            try:
                logger.info(f"🔄 Conectando IQ Option ({tentativa + 1}/{max_tentativas})...")
                
                # Importar aqui para evitar problemas de circular import
                from myiq.core.client import IQOption
                
                # Criar nova instância
                self.iq = IQOption(self.email, self.senha)
                
                try:
                    # Start conecta e autentica
                    await self.iq.start()
                    
                    # Verificar conexão
                    if not self.iq.check_connect():
                        logger.error("❌ Falha na autenticação")
                        continue
                    
                    # Obter balances e selecionar PRACTICE
                    balances = await self.iq.get_balances()
                    
                    if not balances:
                        logger.error("❌ Não foi possível obter balances")
                        continue
                    
                    # Procurar balance PRACTICE (tipo 4)
                    practice_balance = None
                    for b in balances:
                        if b.type == 4:  # PRACTICE
                            practice_balance = b
                            break
                    
                    if not practice_balance:
                        logger.error("❌ Conta PRACTICE não encontrada")
                        continue
                    
                    # Selecionar PRACTICE
                    await self.iq.change_balance(practice_balance.id)
                    self._practice_balance_id = practice_balance.id
                    
                    logger.info(f"✅ Conectado!")
                    logger.info(f"📊 Tipo de conta: PRACTICE")
                    logger.info(f"💰 Saldo PRACTICE: ${practice_balance.amount:.2f}")
                    
                    self._connected = True
                    _iq_instance = self.iq
                    
                    return True
                    
                except Exception as e:
                    logger.error(f"❌ Erro na conexão assíncrona: {e}")
                    import traceback
                    logger.error(traceback.format_exc())
                
                await asyncio.sleep(5)
                
            except Exception as e:
                logger.error(f"❌ Erro: {e}")
                import traceback
                logger.error(traceback.format_exc())
        
        return False
    
    def refresh_open_assets(self) -> dict:
        """
        Atualiza cache de ativos abertos (binary + digital)
        SYNC version - no await needed
        
        Returns:
            dict: Ativos abertos organizados por tipo
        """
        try:
            if not self.iq or not self._connected:
                logger.warning("⚠️ IQ não conectado, não é possível atualizar ativos")
                return {}
            
            logger.info("🔄 Atualizando cache de ativos abertos...")
            
            # Obter todos os open times (sync call)
            open_time = self.iq.get_all_open_time()
            
            if not open_time:
                logger.warning("⚠️ get_all_open_time retornou vazio")
                return {}
            
            # Merge binary e digital
            all_assets = {}
            
            binary_assets = open_time.get("binary", {})
            digital_assets = open_time.get("digital", {})
            
            # Adicionar binary assets
            for asset_id, asset_data in binary_assets.items():
                if isinstance(asset_data, dict):
                    all_assets[asset_id] = {
                        **asset_data,
                        "option_type": "binary"
                    }
            
            # Adicionar digital assets
            for asset_id, asset_data in digital_assets.items():
                if isinstance(asset_data, dict):
                    if asset_id in all_assets:
                        all_assets[asset_id]["has_digital"] = True
                    else:
                        all_assets[asset_id] = {
                            **asset_data,
                            "option_type": "digital"
                        }
            
            # Atualizar cache interno
            self.iq.actives_cache["binary-option"] = binary_assets
            self.iq.actives_cache["digital-option"] = digital_assets
            self.iq.actives_cache["all-assets"] = all_assets
            
            # Contar ativos abertos
            binary_open = sum(1 for a in binary_assets.values() 
                            if isinstance(a, dict) and a.get("is_open", False))
            digital_open = sum(1 for a in digital_assets.values() 
                             if isinstance(a, dict) and a.get("is_open", False))
            total_open = sum(1 for a in all_assets.values() 
                           if isinstance(a, dict) and a.get("is_open", False))
            
            logger.info(
                f"✅ Assets loaded: {total_open} open "
                f"(binary: {binary_open}, digital: {digital_open}, "
                f"total: {len(all_assets)})"
            )
            
            return {
                "binary": binary_assets,
                "digital": digital_assets,
                "all": all_assets,
                "stats": {
                    "binary_total": len(binary_assets),
                    "binary_open": binary_open,
                    "digital_total": len(digital_assets),
                    "digital_open": digital_open,
                    "total_open": total_open
                }
            }
            
        except Exception as e:
            logger.error(f"❌ Erro ao atualizar ativos: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return {}
    
    async def garantir_practice(self):
        """
        SEGURANÇA CRÍTICA: Garante que está em PRACTICE (async)
        Retorna True se confirmado, False se falhou
        """
        try:
            if not self.iq or not self._connected:
                logger.error("❌ Sem conexão IQ Option")
                return False
            
            # Verificar se balance ativo é PRACTICE
            if not self._practice_balance_id:
                logger.error("❌ Balance PRACTICE não definido")
                return False
            
            if self.iq.active_balance_id != self._practice_balance_id:
                logger.warning(f"⚠️ Balance ativo não é PRACTICE")
                logger.info("🔄 Forçando mudança para PRACTICE...")
                
                # Reselecionar PRACTICE
                await self.iq.change_balance(self._practice_balance_id)
                
                # Verificar novamente
                if self.iq.active_balance_id != self._practice_balance_id:
                    logger.error(f"❌ FALHA CRÍTICA: Não conseguiu mudar para PRACTICE")
                    return False
            
            logger.info("✅ Confirmado: Operando em conta PRACTICE")
            return True
            
        except Exception as e:
            logger.error(f"❌ Erro ao verificar conta: {e}")
            return False
    
    def verificar_ativo_disponivel(self, par: str) -> Tuple[bool, Optional[str]]:
        """Verifica se ativo está aberto para binary/digital options"""
        try:
            par_limpo = par.replace("-OTC", "")
            
            if not self.iq or not self._connected:
                logger.warning("⚠️ Conexão não estabelecida, permitindo tentativa")
                return True, par_limpo
            
            # Verificar cache de ativos
            binary_actives = self.iq.actives_cache.get("binary-option", {})
            digital_actives = self.iq.actives_cache.get("digital-option", {})
            
            # Se ambos vazios, tentar refresh
            if not binary_actives and not digital_actives:
                logger.warning(f"⚠️ Cache vazio, tentando atualizar...")
                self.refresh_open_assets()
                
                # Re-obter após refresh
                binary_actives = self.iq.actives_cache.get("binary-option", {})
                digital_actives = self.iq.actives_cache.get("digital-option", {})
                
                if not binary_actives and not digital_actives:
                    logger.warning(f"⚠️ Cache ainda vazio após refresh, permitindo tentativa")
                    return True, par_limpo
            
            # Tentar em binary primeiro
            for active_id, active_data in binary_actives.items():
                if not isinstance(active_data, dict):
                    continue
                
                name = active_data.get("name", "").upper()
                underlying = active_data.get("underlying", "").upper()
                
                if par_limpo.upper() in name or par_limpo.upper() in underlying:
                    is_open = active_data.get("is_open", False)
                    
                    if is_open:
                        logger.info(f"✅ Ativo {par_limpo} disponível binary (ID: {active_id})")
                        return True, par_limpo
                    else:
                        # Tentar OTC
                        par_otc = f"{par_limpo}-OTC"
                        
                        for otc_id, otc_data in binary_actives.items():
                            if not isinstance(otc_data, dict):
                                continue
                            
                            otc_name = otc_data.get("name", "").upper()
                            otc_underlying = otc_data.get("underlying", "").upper()
                            
                            if (par_otc.upper() in otc_name or 
                                par_otc.upper() in otc_underlying or
                                (par_limpo.upper() in otc_name and "OTC" in otc_name)):
                                
                                if otc_data.get("is_open", False):
                                    logger.info(f"✅ Usando OTC: {par_otc}")
                                    return True, par_otc
                        
                        # Não encontrou em binary, tentar digital
                        break
            
            # Tentar em digital
            if digital_actives:
                for active_id, active_data in digital_actives.items():
                    if not isinstance(active_data, dict):
                        continue
                    
                    name = active_data.get("name", "").upper()
                    underlying = active_data.get("underlying", "").upper()
                    
                    if par_limpo.upper() in name or par_limpo.upper() in underlying:
                        is_open = active_data.get("is_open", False)
                        
                        if is_open:
                            logger.info(f"✅ Ativo {par_limpo} disponível digital (ID: {active_id})")
                            return True, par_limpo
            
            logger.warning(f"⚠️ Ativo {par_limpo} não encontrado ou fechado")
            return False, None
            
        except Exception as e:
            logger.error(f"❌ Erro ao verificar ativo: {e}")
            return True, par.replace("-OTC", "")
    
    async def obter_saldo(self) -> float:
        """Retorna saldo atual (async)"""
        try:
            if not self.iq or not self._connected:
                return 0.0
            
            # Obter balances novamente
            balances = await self.iq.get_balances()
            
            for b in balances:
                if b.id == self._practice_balance_id:
                    return float(b.amount)
            
            return 0.0
        except Exception as e:
            logger.error(f"❌ Erro ao obter saldo: {e}")
            return 0.0
    
    def obter_tipo_conta(self) -> str:
        """Retorna tipo de conta"""
        if not self.iq or not self._connected:
            return "DESCONECTADO"
        
        if self.iq.active_balance_id == self._practice_balance_id:
            return "PRACTICE"
        else:
            return "REAL"  # WARNING!
    
    def esta_conectado(self) -> bool:
        """Verifica se está conectado"""
        return self._connected and self.iq is not None and self.iq.check_connect()
    
    async def executar_ordem(self, par: str, direcao: str, valor: float, expiracao: int) -> Tuple[bool, Optional[str]]:
        """
        Executa ordem binary usando myiq (async)
        
        Args:
            par: Par a operar
            direcao: CALL ou PUT
            valor: Valor a investir
            expiracao: Tempo de expiração em segundos
        
        Returns:
            Tuple[bool, Optional[str]]: (sucesso, order_id)
        """
        try:
            if not await self.garantir_practice():
                logger.error("❌ Falha na verificação PRACTICE")
                return False, None
            
            # Verificar disponibilidade
            disponivel, par_final = self.verificar_ativo_disponivel(par)
            
            if not disponivel:
                logger.error(f"❌ Ativo {par} não disponível")
                return False, None
            
            # Converter direção
            direction = direcao.lower()  # "call" ou "put"
            
            # myiq usa buy_blitz, mas vamos adaptar para binary
            # Precisamos encontrar o active_id do par
            active_id = self._encontrar_active_id(par_final)
            
            if not active_id:
                logger.error(f"❌ Não foi possível encontrar ID do ativo {par_final}")
                return False, None
            
            # Executar compra usando método adaptado
            logger.info(f"🎯 Executando ordem: {par_final} {direcao} ${valor} {expiracao}s")
            
            result = await self._buy_binary(active_id, direction, valor, expiracao)
            
            if result and result.get("status") != "error":
                order_id = result.get("order_id")
                logger.info(f"✅ Ordem executada: ID {order_id}")
                return True, str(order_id)
            else:
                logger.error(f"❌ Falha na execução da ordem: {result}")
                return False, None
            
        except Exception as e:
            logger.error(f"❌ Erro ao executar ordem: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False, None
    
    def _encontrar_active_id(self, par: str) -> Optional[int]:
        """Encontra o active_id de um par"""
        try:
            par_upper = par.upper().replace("-OTC", "")
            
            # Procurar em binary-option
            binary_actives = self.iq.actives_cache.get("binary-option", {})
            
            for active_id, active_data in binary_actives.items():
                if not isinstance(active_data, dict):
                    continue
                
                name = active_data.get("name", "").upper()
                underlying = active_data.get("underlying", "").upper()
                
                if par_upper in name or par_upper in underlying:
                    return int(active_id)
            
            # Se não encontrar, tentar OTC
            if "-OTC" in par.upper():
                par_otc = par_upper + "-OTC"
                
                for active_id, active_data in binary_actives.items():
                    if not isinstance(active_data, dict):
                        continue
                    
                    name = active_data.get("name", "").upper()
                    
                    if par_otc in name or (par_upper in name and "OTC" in name):
                        return int(active_id)
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Erro ao encontrar active_id: {e}")
            return None
    
    async def _buy_binary(self, active_id: int, direction: str, amount: float, duration: int) -> dict:
        """
        Compra opção binária (adaptado do buy_blitz)
        
        Esta função é uma adaptação do método buy_blitz da myiq
        para funcionar com opções binárias (binary options).
        """
        try:
            from myiq.core.constants import OPTION_TYPE_BINARY, OP_OPEN_OPTION, EV_POSITION_CHANGED, OP_SUBSCRIBE_POSITIONS
            from myiq.core.utils import get_req_id
        except ImportError:
            # Fallback - definir constantes localmente
            OPTION_TYPE_BINARY = 1  # Binary options
            OP_OPEN_OPTION = "binary-options.open-option"
            EV_POSITION_CHANGED = "portfolio.position-changed"
            OP_SUBSCRIBE_POSITIONS = "subscribeMessage"
            
            def get_req_id():
                import random
                return f"req_{int(time.time())}_{random.randint(1000, 9999)}"
        
        if not self.iq.active_balance_id:
            raise ValueError("Saldo não selecionado. Use change_balance() primeiro.")

        # Obter payout
        profit_percent = self.iq.get_profit_percent(active_id)
        if profit_percent == 0:
            logger.warning(f"⚠️ Payout não encontrado para ativo {active_id}, usando 80%")
            profit_percent = 80
        
        req_id = get_req_id()
        server_time = self.iq.get_server_timestamp()
        if server_time == 0:
            server_time = int(time.time())

        # Calcular expiração (alinhar com próximo minuto + margem)
        expired = (server_time - (server_time % 60)) + 120
        
        body = {
            "user_balance_id": self.iq.active_balance_id,
            "active_id": active_id,
            "option_type_id": OPTION_TYPE_BINARY,
            "direction": direction.lower(),
            "expired": expired,
            "expiration_size": duration,
            "refund_value": 0,
            "price": float(amount),
            "value": 0, 
            "profit_percent": profit_percent
        }

        # Future para resposta imediata
        ack_future = self.iq.dispatcher.create_future(req_id)
        
        # Future para o ID da ordem
        order_id_future = asyncio.get_running_loop().create_future()
        
        def on_order_created(msg):
            if msg.get("name") == EV_POSITION_CHANGED:
                raw = msg.get("msg", {})
                evt = raw.get("raw_event", {}).get("binary_options_option_changed1", {})
                
                if (str(evt.get("active_id")) == str(active_id) and 
                    evt.get("direction") == direction.lower() and
                    evt.get("result") == "opened"):
                    
                    if not order_id_future.done():
                        order_id_future.set_result(raw.get("external_id") or raw.get("id"))

        self.iq.dispatcher.add_listener(EV_POSITION_CHANGED, on_order_created)
        
        logger.info(f"📤 Enviando ordem binary: {active_id} {direction} ${amount}")
        
        try:
            # Enviar Request
            await self.iq.ws.send({
                "name": "sendMessage",
                "request_id": req_id,
                "msg": {
                    "name": OP_OPEN_OPTION,
                    "version": "2.0",
                    "body": body
                }
            })
            
            # Esperar ACK
            ack = await asyncio.wait_for(ack_future, timeout=10.0)
            
            # Validar ACK
            ack_status = ack.get("status")
            if ack_status not in [0, 2000]:
                msg_err = ack.get("msg")
                if isinstance(msg_err, dict):
                    msg_err = msg_err.get("message")
                raise RuntimeError(f"Erro na abertura da ordem: {msg_err}")

            # ID da ordem
            created_order_id = ack.get("msg", {}).get("id")
            logger.info(f"✅ Ordem ACK recebido: ID {created_order_id}")

            order_id = created_order_id
            
            self.iq.dispatcher.remove_listener(EV_POSITION_CHANGED, on_order_created)

            # Subscrever para resultados
            await self.iq.ws.send({
                "name": "subscribeMessage",
                "request_id": get_req_id(),
                "msg": {
                    "name": "portfolio.position-changed",
                    "version": "3.0",
                    "params": {
                        "routingFilters": {
                            "ids": [order_id]
                        }
                    }
                }
            })

            result_future = asyncio.get_running_loop().create_future()
            
            def on_result(msg):
                if msg.get("name") == EV_POSITION_CHANGED:
                    raw = msg.get("msg", {})
                    msg_id = raw.get("id")
                    external_id = raw.get("external_id")
                    
                    is_same_id = (str(msg_id) == str(order_id) or str(external_id) == str(order_id))
                    
                    if is_same_id:
                        status = raw.get("status")
                        evt = raw.get("raw_event", {}).get("binary_options_option_changed1", {})
                        
                        is_closed = (status == "closed")
                        has_result = (evt.get("result") in ["win", "loose", "equal"])
                        
                        if is_closed or has_result:
                            if not result_future.done():
                                pnl = raw.get("pnl", 0)
                                if pnl == 0 and "profit_amount" in evt:
                                    net = evt.get("profit_amount", 0) - evt.get("amount", 0)
                                    pnl = net
                                
                                outcome = evt.get("result") or raw.get("close_reason")
                                
                                result_data = {
                                    "status": "closed",
                                    "result": outcome,
                                    "profit": pnl, 
                                    "pnl": pnl,
                                    "order_id": order_id
                                }
                                result_future.set_result(result_data)

            self.iq.dispatcher.add_listener(EV_POSITION_CHANGED, on_result)
            
            # Esperar resultado
            wait_time = max(duration, 60) + 30
            logger.info(f"⏳ Aguardando resultado (timeout: {wait_time}s)")
            
            trade_result = await asyncio.wait_for(result_future, timeout=wait_time)
            return trade_result

        except asyncio.TimeoutError:
            logger.error("❌ Timeout aguardando resultado")
            return {"status": "error", "result": "timeout", "pnl": 0}
        except Exception as e:
            logger.error(f"❌ Erro na ordem: {e}")
            raise
        finally:
            if 'on_order_created' in locals():
                self.iq.dispatcher.remove_listener(EV_POSITION_CHANGED, on_order_created)
            if 'on_result' in locals():
                self.iq.dispatcher.remove_listener(EV_POSITION_CHANGED, on_result)
    
    def verificar_resultado_ordem(self, order_id: str) -> Tuple[str, float]:
        """
        Verifica resultado de uma ordem
        
        Args:
            order_id: ID da ordem
        
        Returns:
            Tuple[str, float]: (resultado, lucro)
                resultado: "WIN", "LOSS", "EMPATE", ou "DESCONHECIDO"
                lucro: Valor de lucro/prejuízo
        """
        # Esta função não é mais necessária pois buy_binary já retorna o resultado
        # Mas vamos manter para compatibilidade
        logger.warning("⚠️ verificar_resultado_ordem não é mais necessário com myiq")
        return "DESCONHECIDO", 0.0
