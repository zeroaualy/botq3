#!/bin/bash

###############################################################################
# Script de Instalação - Bot Q3 IA com Playwright
# Para: VPS Ubuntu 20.04/22.04/24.04
# Uso: sudo bash install_playwright.sh
###############################################################################

set -e  # Parar em caso de erro

echo "=========================================="
echo "🚀 Instalação Bot Q3 IA v3.1 Playwright"
echo "=========================================="

# Verificar se está rodando como root
if [ "$EUID" -ne 0 ]; then 
   echo "❌ Execute como root: sudo bash install_playwright.sh"
   exit 1
fi

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 1. ATUALIZAR SISTEMA
echo ""
echo "${YELLOW}[1/8]${NC} Atualizando sistema..."
apt-get update -qq
apt-get upgrade -y -qq

# 2. INSTALAR PYTHON 3.10+
echo ""
echo "${YELLOW}[2/8]${NC} Verificando Python..."
if ! command -v python3 &> /dev/null; then
    echo "Instalando Python 3..."
    apt-get install -y python3 python3-pip python3-venv
else
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
    echo "✅ Python $PYTHON_VERSION instalado"
fi

# 3. INSTALAR DEPENDÊNCIAS DO SISTEMA PARA PLAYWRIGHT
echo ""
echo "${YELLOW}[3/8]${NC} Instalando dependências do Playwright..."
apt-get install -y \
    wget \
    curl \
    gnupg \
    ca-certificates \
    fonts-liberation \
    libasound2 \
    libatk-bridge2.0-0 \
    libatk1.0-0 \
    libatspi2.0-0 \
    libcups2 \
    libdbus-1-3 \
    libdrm2 \
    libgbm1 \
    libgtk-3-0 \
    libnspr4 \
    libnss3 \
    libwayland-client0 \
    libxcomposite1 \
    libxdamage1 \
    libxfixes3 \
    libxkbcommon0 \
    libxrandr2 \
    xdg-utils \
    libu2f-udev \
    libvulkan1

echo "✅ Dependências do sistema instaladas"

# 4. CRIAR AMBIENTE VIRTUAL
echo ""
echo "${YELLOW}[4/8]${NC} Criando ambiente virtual Python..."
cd /root  # ou onde seu bot está
BOT_DIR="/root/bot"

if [ ! -d "$BOT_DIR" ]; then
    echo "❌ Diretório $BOT_DIR não encontrado!"
    echo "Execute este script no diretório do bot ou ajuste BOT_DIR"
    exit 1
fi

cd "$BOT_DIR"

if [ -d "venv" ]; then
    echo "Ambiente virtual já existe, removendo..."
    rm -rf venv
fi

python3 -m venv venv
source venv/bin/activate

echo "✅ Ambiente virtual criado"

# 5. INSTALAR DEPENDÊNCIAS PYTHON
echo ""
echo "${YELLOW}[5/8]${NC} Instalando dependências Python..."

# Criar requirements.txt atualizado
cat > requirements_playwright.txt << 'EOF'
# Telegram
python-telegram-bot>=20.0

# Playwright
playwright>=1.40.0

# IA
groq

# Utilitários
python-dotenv
EOF

pip install --upgrade pip
pip install -r requirements_playwright.txt

echo "✅ Dependências Python instaladas"

# 6. INSTALAR NAVEGADORES PLAYWRIGHT
echo ""
echo "${YELLOW}[6/8]${NC} Instalando navegadores Playwright..."
echo "⚠️  Esta etapa pode demorar alguns minutos..."

playwright install chromium
playwright install-deps chromium

echo "✅ Chromium instalado via Playwright"

# 7. CONFIGURAR ARQUIVO .env
echo ""
echo "${YELLOW}[7/8]${NC} Configurando credenciais..."

if [ ! -f ".env" ]; then
    echo "Criando arquivo .env..."
    cat > .env << 'EOF'
# Credenciais IQ Option
EMAIL=seu_email@exemplo.com
SENHA=sua_senha_aqui

# Telegram
TOKEN=seu_token_telegram
GRUPO_ID=seu_grupo_id

# Groq API
GROQ_API_KEY=sua_chave_groq
EOF
    echo "${YELLOW}⚠️  IMPORTANTE: Edite o arquivo .env com suas credenciais!${NC}"
    echo "   nano .env"
else
    echo "✅ Arquivo .env já existe"
fi

# 8. CRIAR SCRIPT DE INICIALIZAÇÃO
echo ""
echo "${YELLOW}[8/8]${NC} Criando scripts auxiliares..."

# Script de execução
cat > run_bot.sh << 'EOF'
#!/bin/bash
cd /root/bot
source venv/bin/activate
python3 main_playwright.py
EOF
chmod +x run_bot.sh

# Script de teste
cat > test_playwright.sh << 'EOF'
#!/bin/bash
cd /root/bot
source venv/bin/activate
python3 -c "
from playwright.sync_api import sync_playwright
print('🧪 Testando Playwright...')
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto('https://www.google.com')
    print(f'✅ Título: {page.title()}')
    browser.close()
print('✅ Playwright funcionando!')
"
EOF
chmod +x test_playwright.sh

# Systemd service (opcional)
cat > /etc/systemd/system/botq3.service << EOF
[Unit]
Description=Bot Q3 IA Playwright
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$BOT_DIR
Environment="PATH=$BOT_DIR/venv/bin:/usr/local/bin:/usr/bin:/bin"
ExecStart=$BOT_DIR/venv/bin/python3 $BOT_DIR/main_playwright.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload

echo "✅ Scripts criados"

# RESUMO FINAL
echo ""
echo "${GREEN}=========================================="
echo "✅ INSTALAÇÃO CONCLUÍDA!"
echo "==========================================${NC}"
echo ""
echo "📋 Próximos passos:"
echo ""
echo "1️⃣  Editar credenciais:"
echo "   ${YELLOW}nano .env${NC}"
echo ""
echo "2️⃣  Testar Playwright:"
echo "   ${YELLOW}./test_playwright.sh${NC}"
echo ""
echo "3️⃣  Executar bot manualmente:"
echo "   ${YELLOW}./run_bot.sh${NC}"
echo ""
echo "4️⃣  OU executar como serviço:"
echo "   ${YELLOW}systemctl start botq3${NC}"
echo "   ${YELLOW}systemctl enable botq3${NC}  # Auto-iniciar no boot"
echo "   ${YELLOW}systemctl status botq3${NC}  # Ver status"
echo "   ${YELLOW}journalctl -u botq3 -f${NC}  # Ver logs em tempo real"
echo ""
echo "📝 Logs do bot estarão em:"
echo "   - stdout/stderr (se executar manualmente)"
echo "   - journalctl -u botq3 (se usar systemd)"
echo ""
echo "${YELLOW}⚠️  LEMBRETE IMPORTANTE:${NC}"
echo "   - Edite o arquivo ${YELLOW}.env${NC} com suas credenciais antes de executar!"
echo "   - O bot rodará em modo HEADLESS (sem janela visível)"
echo "   - Verifique os logs para acompanhar execução"
echo ""
