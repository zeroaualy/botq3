"""
Cliente Gemini API
Usa Google Cloud OAuth 2 e o projeto gen-lang-client-0628184107
"""
import logging
import os
from typing import Optional, List, Dict
import google.auth
from google.auth.transport.requests import Request
from google.oauth2 import service_account
import requests

logger = logging.getLogger(__name__)


class GeminiClient:
    """Cliente para Google Gemini API usando OAuth 2"""
    
    def __init__(self, api_key: Optional[str] = None, project_id: str = "gen-lang-client-0628184107"):
        """
        Inicializa cliente Gemini com Google OAuth 2
        
        Args:
            api_key: Chave de API (mantido para compatibilidade, mas usa OAuth se não fornecido)
            project_id: ID do projeto Google Cloud
        """
        self.project_id = project_id
        self.model_name = "gemini-1.5-turbo"
        self.api_key = api_key
        
        # Tentar usar credenciais Google Cloud
        try:
            if os.getenv('GOOGLE_APPLICATION_CREDENTIALS'):
                # Usar service account
                credentials = service_account.Credentials.from_service_account_file(
                    os.getenv('GOOGLE_APPLICATION_CREDENTIALS'),
                    scopes=['https://www.googleapis.com/auth/cloud-platform']
                )
                logger.info("🔐 Usando credenciais de service account")
            else:
                # Usar credenciais padrão
                credentials, project = google.auth.default(
                    scopes=['https://www.googleapis.com/auth/cloud-platform']
                )
                if project:
                    self.project_id = project
                logger.info("🔐 Usando credenciais padrão do Google Cloud")
            
            self.credentials = credentials
            self.use_oauth = True
            
        except Exception as e:
            logger.warning(f"⚠️ OAuth não disponível, usando API key: {e}")
            self.use_oauth = False
            if not api_key:
                raise ValueError("API key é necessária quando OAuth não está disponível")
        
        logger.info(f"✅ Cliente Gemini inicializado (projeto: {self.project_id}, modelo: {self.model_name})")
    
    def _get_access_token(self) -> str:
        """Obtém token de acesso OAuth"""
        if not self.use_oauth:
            return None
        
        if not self.credentials.valid:
            self.credentials.refresh(Request())
        
        return self.credentials.token
    
    def generate(self, prompt: str, temperature: float = 0.7, max_output_tokens: int = 512) -> str:
        """
        Gera texto usando Gemini API
        
        Args:
            prompt: Texto de entrada
            temperature: Temperatura de geração (0.0 a 1.0)
            max_output_tokens: Máximo de tokens na resposta
            
        Returns:
            Texto gerado
        """
        try:
            if self.use_oauth:
                # Usar API REST com OAuth
                url = f"https://generativelanguage.googleapis.com/v1/projects/{self.project_id}/locations/us-central1/publishers/google/models/{self.model_name}:generateContent"
                
                headers = {
                    "Authorization": f"Bearer {self._get_access_token()}",
                    "Content-Type": "application/json"
                }
                
                data = {
                    "contents": [{
                        "parts": [{"text": prompt}]
                    }],
                    "generationConfig": {
                        "temperature": temperature,
                        "maxOutputTokens": max_output_tokens
                    }
                }
                
                response = requests.post(url, json=data, headers=headers, timeout=30)
                response.raise_for_status()
                
                result = response.json()
                return result['candidates'][0]['content']['parts'][0]['text']
            
            else:
                # Fallback: usar API key com biblioteca
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                model = genai.GenerativeModel('gemini-1.5-turbo')
                
                response = model.generate_content(
                    prompt,
                    generation_config=genai.types.GenerationConfig(
                        temperature=temperature,
                        max_output_tokens=max_output_tokens
                    )
                )
                return response.text
                
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                logger.error(f"❌ Modelo não encontrado: {self.model_name}")
                logger.error(f"   Verifique se o projeto {self.project_id} tem acesso ao Gemini API")
            raise
        except Exception as e:
            logger.error(f"❌ Erro ao gerar resposta: {e}")
            raise
    
    class ChatCompletions:
        """Classe para compatibilidade com interface Groq/OpenAI"""
        
        def __init__(self, client):
            self.client = client
        
        def create(self, model: str, messages: List[Dict], temperature: float = 0.7, max_tokens: Optional[int] = None):
            """
            Cria completion compatível com interface Groq/OpenAI
            
            Args:
                model: Nome do modelo (ignorado, usa gemini-1.5-turbo)
                messages: Lista de mensagens
                temperature: Temperatura de geração
                max_tokens: Máximo de tokens
            
            Returns:
                Objeto com choices[0].message.content
            """
            # Extrair prompt da última mensagem do usuário
            prompt = ""
            for msg in messages:
                if msg.get("role") == "user":
                    prompt = msg.get("content", "")
            
            # Gerar resposta
            max_output = max_tokens if max_tokens else 512
            response_text = self.client.generate(prompt, temperature=temperature, max_output_tokens=max_output)
            
            # Criar objeto de resposta compatível
            class Choice:
                def __init__(self, text):
                    self.message = type('obj', (object,), {'content': text})()
            
            class Response:
                def __init__(self, text):
                    self.choices = [Choice(text)]
            
            return Response(response_text)
    
    @property
    def chat(self):
        """Retorna objeto chat para compatibilidade"""
        class Chat:
            def __init__(self, client):
                self.completions = GeminiClient.ChatCompletions(client)
        
        return Chat(self)
