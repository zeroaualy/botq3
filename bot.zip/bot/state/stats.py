"""
Estatísticas e estado do bot
"""

STATS = {
    "total_operacoes": 0,
    "vitorias": 0,
    "derrotas": 0,
    "empates": 0,
    "lucro_dia": 0.0,
    "historico": [],
    
    # Decisões da IA (para auditoria)
    "ia_decisoes": {
        "executar": 0,
        "ignorar": 0,
        "risco": 0
    }
}


def registrar_operacao(resultado, valor_operado, lucro=0):
    """Registra resultado de uma operação"""
    STATS["total_operacoes"] += 1
    
    if resultado == "WIN":
        STATS["vitorias"] += 1
        STATS["lucro_dia"] += lucro
    elif resultado == "LOSS":
        STATS["derrotas"] += 1
        STATS["lucro_dia"] -= valor_operado
    elif resultado == "EMPATE":
        STATS["empates"] += 1
    
    STATS["historico"].append({
        "resultado": resultado,
        "valor": valor_operado,
        "lucro": lucro,
        "timestamp": None  # Será preenchido quando integrado
    })


def registrar_decisao_ia(decisao):
    """Registra decisão da IA para auditoria"""
    decisao_lower = decisao.lower()
    if decisao_lower in STATS["ia_decisoes"]:
        STATS["ia_decisoes"][decisao_lower] += 1


def obter_winrate():
    """Calcula win rate"""
    if STATS["total_operacoes"] == 0:
        return 0.0
    return (STATS["vitorias"] / STATS["total_operacoes"]) * 100


def resetar_stats():
    """Reseta estatísticas do dia"""
    STATS["total_operacoes"] = 0
    STATS["vitorias"] = 0
    STATS["derrotas"] = 0
    STATS["empates"] = 0
    STATS["lucro_dia"] = 0.0
    STATS["historico"].clear()
    STATS["ia_decisoes"] = {"executar": 0, "ignorar": 0, "risco": 0}
