"""
Bot Q3 IA v3.0 - Arquitetura Sênior com Playwright
Executor de sinais em conta PRACTICE com automação REAL de navegador

MUDANÇAS v3.1:
- Substituída API não oficial por Playwright
- Execução REAL de trades via navegador
- Garantia de operação em PRACTICE
"""
import asyncio
import logging
from datetime import datetime
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)

# State
from state.config import TOKEN, GRUPO_ID, GROQ_API_KEY, EMAIL, SENHA, CONFIG, PERMISSOES
from state import stats
from state import runtime

# Core - NOVO PLAYWRIGHT
from core.iq_playwright_client import IQPlaywrightClient
from core.playwright_trade_executor import PlaywrightTradeExecutor
from core.signal_parser import parsear_sinal, validar_sinal
from core.scheduler import Scheduler

# AI
from ai.ia_guard import IAGuard

# Bot
from bot.telegram_bot import TelegramBot

# Groq
try:
    from groq import Groq
    GROQ_DISPONIVEL = True
except ImportError:
    GROQ_DISPONIVEL = False

# ======================================
# LOGGING
# ======================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ======================================
# INICIALIZAÇÃO
# ======================================
def inicializar_ia():
    """Inicializa cliente IA"""
    if not GROQ_DISPONIVEL:
        logger.error("❌ Groq não instalado")
        return None
    
    try:
        client = Groq(api_key=GROQ_API_KEY)
        logger.info("✅ IA Guard inicializada")
        return client
    except Exception as e:
        logger.error(f"❌ Erro na IA: {e}")
        return None


async def inicializar_sistema():
    """Inicializa todos os componentes"""
    logger.info("🚀 Iniciando Bot Q3 IA v3.1 PLAYWRIGHT...")
    
    # IA
    groq_client = inicializar_ia()
    runtime.groq_client = groq_client
    
    # IQ Option com Playwright
    logger.info("🌐 Inicializando Playwright Client...")
    iq_client = IQPlaywrightClient(EMAIL, SENHA)
    
    # Conectar (modo headless para VPS)
    conectado = await iq_client.iniciar(headless=True)
    
    if not conectado:
        logger.error("❌ Falha ao conectar com Playwright")
        logger.error("Verifique:")
        logger.error("1. Email e senha corretos")
        logger.error("2. Conexão com internet")
        logger.error("3. Playwright instalado (playwright install chromium)")
        return None, None, None, None, None
    
    runtime.iq_connection = iq_client
    
    # Componentes
    trade_executor = PlaywrightTradeExecutor(iq_client)
    ia_guard = IAGuard(groq_client)
    scheduler = Scheduler(CONFIG["tolerancia_agendamento_ms"])
    
    # Bot Telegram
    telegram_bot = TelegramBot(
        config=CONFIG,
        stats=stats.STATS,
        runtime=runtime,
        signal_parser=type('obj', (object,), {'parsear_sinal': parsear_sinal}),
        trade_executor=trade_executor,
        ia_guard=ia_guard,
        permissoes=PERMISSOES
    )
    telegram_bot.set_iq_client(iq_client)
    
    logger.info("✅ Sistema inicializado com PLAYWRIGHT")
    logger.info("🏦 Configurado para PRACTICE")
    logger.info("🌐 Navegador: Automação REAL")
    logger.info("🤖 IA Guard: Validadora de contexto")
    logger.info("🔒 Governança: Flags de auditoria ativas")
    
    return telegram_bot, trade_executor, ia_guard, scheduler, iq_client


# ======================================
# PROCESSADOR DE OPERAÇÕES
# ======================================
async def processar_operacao(app, sinal, trade_executor, ia_guard, iq_client):
    """
    Processa operação completa com Playwright
    1. Valida contexto com IA (se habilitado)
    2. Executa operação via navegador (PRACTICE)
    3. Aguarda resultado
    4. Registra estatísticas
    """
    
    # 1. VALIDAÇÃO DE CONTEXTO COM IA
    if CONFIG["ia_validar_contexto"] and not ia_guard.desabilitado():
        await app.bot.send_message(GRUPO_ID, "🤖 IA Guard validando contexto...")
        
        # Contexto operacional básico
        contexto = {
            "ativo_aberto": True,
        }
        
        decisao = await ia_guard.validar_contexto(sinal, contexto)
        stats.registrar_decisao_ia(decisao)
        
        if decisao == "IGNORAR":
            await app.bot.send_message(
                GRUPO_ID,
                f"❌ <b>IA Guard: IGNORAR</b>\n\n"
                f"📊 {sinal['par']} {sinal['direcao']}\n"
                f"Condições operacionais desfavoráveis",
                parse_mode="HTML"
            )
            return
        
        elif decisao == "RISCO":
            await app.bot.send_message(
                GRUPO_ID,
                f"⚠️ <b>IA Guard: RISCO ALTO</b>\n\n"
                f"📊 {sinal['par']} {sinal['direcao']}\n"
                f"Operação cancelada por segurança",
                parse_mode="HTML"
            )
            return
        
        await app.bot.send_message(GRUPO_ID, "✅ IA Guard: Contexto OK")
    
    # 2. EXECUTAR OPERAÇÃO VIA PLAYWRIGHT
    valor = CONFIG["valor_entrada"]
    
    saldo_antes = iq_client.obter_saldo()
    tipo_conta = iq_client.obter_tipo_conta()
    
    await app.bot.send_message(
        GRUPO_ID,
        f"💰 <b>PRÉ-OPERAÇÃO (Playwright)</b>\n\n"
        f"🏦 Conta: {tipo_conta}\n"
        f"💵 Saldo: ${saldo_antes:.2f}\n"
        f"📊 Par: {sinal['par']}\n"
        f"📈 Direção: {sinal['direcao']}\n"
        f"⏱️ Expiração: {sinal['tempo_expiracao']}s\n"
        f"🕐 Horário: {datetime.now().strftime('%H:%M:%S')}\n"
        f"🌐 Modo: Automação navegador REAL",
        parse_mode="HTML"
    )
    
    # EXECUÇÃO ASSÍNCRONA
    status, order_id = await trade_executor.executar(
        sinal["par"],
        sinal["direcao"],
        valor,
        sinal["tempo_expiracao"]
    )
    
    if not status:
        await app.bot.send_message(
            GRUPO_ID,
            "❌ <b>FALHA NA OPERAÇÃO</b>\n\n"
            "Possíveis causas:\n"
            "• Ativo fechado\n"
            "• Horário fora do expediente\n"
            "• Problema de conexão/navegador\n"
            "• Sessão expirada (reconectando...)\n"
            "• Tente -OTC",
            parse_mode="HTML"
        )
        return
    
    await app.bot.send_message(
        GRUPO_ID,
        f"🎯 <b>OPERAÇÃO EXECUTADA (Playwright)</b>\n\n"
        f"🏦 Conta: PRACTICE ✅\n"
        f"📊 Par: {sinal['par']}\n"
        f"📈 Direção: {sinal['direcao']}\n"
        f"💰 Valor: ${valor}\n"
        f"⏱️ Expiração: {sinal['tempo_expiracao']}s\n"
        f"🆔 ID: {order_id}\n"
        f"🕐 Executado: {datetime.now().strftime('%H:%M:%S')}\n"
        f"🌐 Via: Navegador automatizado",
        parse_mode="HTML"
    )
    
    # 3. AGUARDAR RESULTADO
    await app.bot.send_message(
        GRUPO_ID,
        f"⏳ Aguardando {sinal['tempo_expiracao']}s..."
    )
    
    await asyncio.sleep(sinal["tempo_expiracao"] + 5)
    
    # VERIFICAÇÃO ASSÍNCRONA
    resultado, lucro = await trade_executor.verificar_resultado(order_id)
    
    # 4. REGISTRAR ESTATÍSTICAS
    stats.registrar_operacao(resultado, valor, lucro)
    
    if resultado == "WIN":
        emoji = "✅"
    elif resultado == "LOSS":
        emoji = "❌"
    elif resultado == "EMPATE":
        emoji = "⚪"
    else:
        emoji = "⚠️"
    
    winrate = stats.obter_winrate()
    saldo_depois = iq_client.obter_saldo()
    diferenca = saldo_depois - saldo_antes
    
    await app.bot.send_message(
        GRUPO_ID,
        f"{emoji} <b>RESULTADO: {resultado}</b>\n\n"
        f"🏦 Conta: PRACTICE ✅\n"
        f"💰 Lucro op: ${lucro:.2f}\n"
        f"💵 Antes: ${saldo_antes:.2f}\n"
        f"💵 Depois: ${saldo_depois:.2f}\n"
        f"📊 Diferença: ${diferenca:.2f}\n\n"
        f"📈 <b>Resumo:</b>\n"
        f"├ Lucro dia: ${stats.STATS['lucro_dia']:.2f}\n"
        f"├ Win Rate: {winrate:.1f}%\n"
        f"└ Ops: {stats.STATS['vitorias']}W / {stats.STATS['derrotas']}L / {stats.STATS['empates']}E\n\n"
        f"🤖 <b>IA Guard:</b>\n"
        f"└ Exec: {stats.STATS['ia_decisoes']['executar']} | "
        f"Ignor: {stats.STATS['ia_decisoes']['ignorar']} | "
        f"Risco: {stats.STATS['ia_decisoes']['risco']}",
        parse_mode="HTML"
    )


# ======================================
# LOOP AUTOMÁTICO
# ======================================
async def loop_auto(app, scheduler, trade_executor, ia_guard, iq_client):
    """Loop principal - executa sinais e monitora stops"""
    
    while True:
        try:
            # Verificar sinais prontos
            sinais_prontos = scheduler.verificar_sinais_prontos(runtime.sinais_agendados)
            
            for sinal in sinais_prontos:
                runtime.remover_sinal(sinal)
                
                if CONFIG["operar_automatico"]:
                    await app.bot.send_message(
                        GRUPO_ID,
                        f"⏰ <b>Executando sinal agendado</b>\n\n"
                        f"📊 {sinal['par']} {sinal['direcao']}\n"
                        f"🕐 Previsto: {sinal['horario'].strftime('%H:%M:%S')}\n"
                        f"🕐 Real: {datetime.now().strftime('%H:%M:%S')}",
                        parse_mode="HTML"
                    )
                    await processar_operacao(app, sinal, trade_executor, ia_guard, iq_client)
                else:
                    logger.warning(f"⚠️ Bot pausado - sinal {sinal['par']} não executado")
            
            # Verificar Stop Loss
            if stats.STATS["lucro_dia"] <= -CONFIG["stop_loss"]:
                if CONFIG["operar_automatico"]:
                    CONFIG["operar_automatico"] = False
                    await app.bot.send_message(
                        GRUPO_ID,
                        f"🛑 <b>STOP LOSS ATINGIDO!</b>\n\n"
                        f"Perda: ${abs(stats.STATS['lucro_dia']):.2f}\n"
                        f"Limite: ${CONFIG['stop_loss']:.2f}\n"
                        f"Bot pausado automaticamente.\n\n"
                        f"🏦 Conta: PRACTICE ✅",
                        parse_mode="HTML"
                    )
            
            # Verificar Stop Gain
            if stats.STATS["lucro_dia"] >= CONFIG["stop_gain"]:
                if CONFIG["operar_automatico"]:
                    CONFIG["operar_automatico"] = False
                    await app.bot.send_message(
                        GRUPO_ID,
                        f"🎯 <b>STOP GAIN ATINGIDO!</b>\n\n"
                        f"Lucro: ${stats.STATS['lucro_dia']:.2f}\n"
                        f"Meta: ${CONFIG['stop_gain']:.2f}\n"
                        f"Bot pausado automaticamente.\n\n"
                        f"🏦 Conta: PRACTICE ✅",
                        parse_mode="HTML"
                    )
            
            await asyncio.sleep(1)
            
        except asyncio.CancelledError:
            logger.info("Loop automático cancelado")
            break
        except Exception as e:
            logger.error(f"Erro no loop: {e}")
            import traceback
            logger.error(traceback.format_exc())
            await asyncio.sleep(5)


# ======================================
# MAIN
# ======================================
async def main_async():
    """Ponto de entrada assíncrono"""
    
    # Inicializar componentes
    result = await inicializar_sistema()
    if result[0] is None:
        logger.error("❌ Falha na inicialização - Encerrando")
        return
    
    telegram_bot, trade_executor, ia_guard, scheduler, iq_client = result
    
    # Criar aplicação Telegram
    app = Application.builder().token(TOKEN).build()
    
    # Handlers
    app.add_handler(CommandHandler("start", telegram_bot.start))
    app.add_handler(CallbackQueryHandler(telegram_bot.button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, telegram_bot.mensagem))
    
    # Post-init e shutdown
    async def post_init(application):
        task = asyncio.create_task(loop_auto(application, scheduler, trade_executor, ia_guard, iq_client))
        application.bot_data['loop_task'] = task
        logger.info("🤖 Bot rodando - Sistema autônomo ativo com PLAYWRIGHT")
    
    async def post_shutdown(application):
        if 'loop_task' in application.bot_data:
            application.bot_data['loop_task'].cancel()
            try:
                await application.bot_data['loop_task']
            except asyncio.CancelledError:
                pass
        
        # Fechar navegador Playwright
        if iq_client:
            await iq_client.fechar()
            logger.info("🔒 Navegador Playwright fechado")
    
    app.post_init = post_init
    app.post_shutdown = post_shutdown
    
    logger.info("=" * 60)
    logger.info("🚀 Bot Q3 IA v3.1 PLAYWRIGHT pronto!")
    logger.info("🏗️ Arquitetura modular implementada")
    logger.info("🌐 Execução REAL via Playwright")
    logger.info("🔒 Segurança PRACTICE obrigatória")
    logger.info("🤖 IA Guard: Validadora (NÃO estrategista)")
    logger.info("📊 Governança transparente")
    logger.info("=" * 60)
    
    await app.run_polling()


def main():
    """Wrapper síncrono"""
    asyncio.run(main_async())


if __name__ == "__main__":
    main()
