"""
Estado de runtime do bot
Variáveis mutáveis durante execução
"""

# Lista de sinais agendados
sinais_agendados = []

# Flag de captura de sinais
captura_sinais_ativa = False

# Instância da conexão IQ Option (será preenchida em runtime)
iq_connection = None

# Cliente IA (será preenchido em runtime)
groq_client = None


def adicionar_sinal(sinal):
    """Adiciona sinal à fila de agendamento"""
    sinais_agendados.append(sinal)


def remover_sinal(sinal):
    """Remove sinal da fila"""
    if sinal in sinais_agendados:
        sinais_agendados.remove(sinal)


def limpar_sinais():
    """Limpa todos os sinais agendados"""
    sinais_agendados.clear()


def obter_sinais_pendentes():
    """Retorna lista de sinais agendados"""
    return sinais_agendados.copy()


def quantidade_sinais():
    """Retorna quantidade de sinais agendados"""
    return len(sinais_agendados)
