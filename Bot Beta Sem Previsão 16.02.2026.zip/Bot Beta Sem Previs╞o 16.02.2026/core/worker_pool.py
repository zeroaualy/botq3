"""
Worker Pool - Q3 IA Beta
Pool de workers assíncronos para processamento paralelo controlado
"""
import asyncio
import logging
from typing import Callable, Any, Optional, List, Dict
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class WorkerStatus(str, Enum):
    """Estados possíveis de um worker"""
    IDLE = "idle"
    BUSY = "busy"
    ERROR = "error"
    STOPPED = "stopped"


class Worker:
    """Worker individual que processa tarefas"""
    
    def __init__(self, worker_id: int, task_timeout: float = 30.0):
        """
        Inicializa um worker
        
        Args:
            worker_id: ID único do worker
            task_timeout: Timeout para execução de tarefas
        """
        self.id = worker_id
        self.status = WorkerStatus.IDLE
        self.task_timeout = task_timeout
        self.current_task: Optional[asyncio.Task] = None
        self.tasks_completed = 0
        self.tasks_failed = 0
        self.tasks_timeout = 0
        self.last_task_time: Optional[datetime] = None
    
    async def execute(self, func: Callable, *args, **kwargs) -> Any:
        """
        Executa uma função de forma segura
        
        Args:
            func: Função a executar
            *args: Argumentos posicionais
            **kwargs: Argumentos nomeados
        
        Returns:
            Resultado da execução ou None se erro
        """
        self.status = WorkerStatus.BUSY
        self.last_task_time = datetime.now()
        
        try:
            # Executar com timeout
            if asyncio.iscoroutinefunction(func):
                result = await asyncio.wait_for(
                    func(*args, **kwargs),
                    timeout=self.task_timeout
                )
            else:
                # Função síncrona - executar em executor
                result = await asyncio.wait_for(
                    asyncio.get_event_loop().run_in_executor(
                        None, lambda: func(*args, **kwargs)
                    ),
                    timeout=self.task_timeout
                )
            
            self.tasks_completed += 1
            self.status = WorkerStatus.IDLE
            return result
        
        except asyncio.TimeoutError:
            logger.error(
                f"⏱️ Worker {self.id}: Timeout após {self.task_timeout}s"
            )
            self.tasks_timeout += 1
            self.status = WorkerStatus.ERROR
            return None
        
        except Exception as e:
            logger.error(
                f"❌ Worker {self.id}: Erro na execução: {e}",
                exc_info=True
            )
            self.tasks_failed += 1
            self.status = WorkerStatus.ERROR
            return None
        
        finally:
            # Garantir que status não fique preso em BUSY
            if self.status == WorkerStatus.BUSY:
                self.status = WorkerStatus.IDLE
    
    def get_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas do worker"""
        return {
            'id': self.id,
            'status': self.status.value,
            'tasks_completed': self.tasks_completed,
            'tasks_failed': self.tasks_failed,
            'tasks_timeout': self.tasks_timeout,
            'last_task_time': self.last_task_time.isoformat() if self.last_task_time else None
        }


class WorkerPool:
    """
    Pool de workers assíncronos para processamento paralelo
    
    Características:
    - Número configurável de workers
    - Controle de concorrência
    - Timeout por tarefa
    - Cancelamento seguro
    - Tratamento isolado de exceções
    - Métricas detalhadas
    """
    
    def __init__(self, num_workers: int = 3, task_timeout: float = 30.0):
        """
        Inicializa o pool de workers
        
        Args:
            num_workers: Número de workers simultâneos
            task_timeout: Timeout para cada tarefa em segundos
        """
        self.num_workers = num_workers
        self.task_timeout = task_timeout
        
        # Workers
        self.workers: List[Worker] = [
            Worker(i, task_timeout) for i in range(num_workers)
        ]
        
        # Fila de tarefas
        self._task_queue: asyncio.Queue = asyncio.Queue()
        
        # Controle
        self._running = False
        self._worker_tasks: List[asyncio.Task] = []
        self._semaphore = asyncio.Semaphore(num_workers)
        
        # Métricas
        self._total_tasks_submitted = 0
        self._total_tasks_completed = 0
        self._total_tasks_failed = 0
        
        logger.info(
            f"✅ Worker Pool inicializado "
            f"(workers={num_workers}, timeout={task_timeout}s)"
        )
    
    async def start(self) -> None:
        """Inicia o pool de workers"""
        if self._running:
            logger.warning("⚠️ Worker Pool já está rodando")
            return
        
        self._running = True
        
        # Criar tasks de workers
        for worker in self.workers:
            task = asyncio.create_task(self._worker_loop(worker))
            self._worker_tasks.append(task)
        
        logger.info(f"🚀 Worker Pool iniciado ({self.num_workers} workers)")
    
    async def stop(self, wait_pending: bool = True) -> None:
        """
        Para o pool de workers
        
        Args:
            wait_pending: Se True, aguarda tarefas pendentes
        """
        if not self._running:
            logger.warning("⚠️ Worker Pool já está parado")
            return
        
        self._running = False
        
        if wait_pending:
            # Aguardar fila esvaziar
            await self._task_queue.join()
        
        # Cancelar worker tasks
        for task in self._worker_tasks:
            task.cancel()
        
        # Aguardar cancelamento
        await asyncio.gather(*self._worker_tasks, return_exceptions=True)
        
        self._worker_tasks.clear()
        
        logger.info("⛔ Worker Pool parado")
    
    async def submit(self, func: Callable, *args, **kwargs) -> asyncio.Future:
        """
        Submete uma tarefa para execução
        
        Args:
            func: Função a executar
            *args: Argumentos posicionais
            **kwargs: Argumentos nomeados
        
        Returns:
            Future que será resolvido com o resultado
        """
        if not self._running:
            raise RuntimeError("Worker Pool não está rodando")
        
        # Criar future para resultado
        future = asyncio.get_event_loop().create_future()
        
        # Adicionar à fila
        await self._task_queue.put((func, args, kwargs, future))
        
        self._total_tasks_submitted += 1
        
        return future
    
    async def execute_now(self, func: Callable, *args, **kwargs) -> Any:
        """
        Executa uma tarefa imediatamente e aguarda resultado
        
        Args:
            func: Função a executar
            *args: Argumentos posicionais
            **kwargs: Argumentos nomeados
        
        Returns:
            Resultado da execução
        """
        future = await self.submit(func, *args, **kwargs)
        return await future
    
    async def _worker_loop(self, worker: Worker) -> None:
        """
        Loop principal de um worker
        
        Args:
            worker: Worker a executar
        """
        logger.info(f"🔄 Worker {worker.id} iniciado")
        
        try:
            while self._running:
                try:
                    # Pegar próxima tarefa da fila (com timeout)
                    task_data = await asyncio.wait_for(
                        self._task_queue.get(),
                        timeout=1.0
                    )
                    
                    func, args, kwargs, future = task_data
                    
                    # Adquirir semaphore para controle de concorrência
                    async with self._semaphore:
                        # Executar tarefa
                        result = await worker.execute(func, *args, **kwargs)
                        
                        # Resolver future
                        if not future.cancelled():
                            if result is not None or worker.status != WorkerStatus.ERROR:
                                future.set_result(result)
                                self._total_tasks_completed += 1
                            else:
                                future.set_exception(
                                    Exception("Worker falhou ao executar tarefa")
                                )
                                self._total_tasks_failed += 1
                        
                        # Marcar tarefa como concluída
                        self._task_queue.task_done()
                
                except asyncio.TimeoutError:
                    # Timeout ao aguardar tarefa - continuar
                    continue
                
                except asyncio.CancelledError:
                    logger.info(f"✅ Worker {worker.id} cancelado")
                    break
                
                except Exception as e:
                    logger.error(
                        f"❌ Worker {worker.id}: Erro no loop: {e}",
                        exc_info=True
                    )
        
        finally:
            worker.status = WorkerStatus.STOPPED
            logger.info(f"⛔ Worker {worker.id} parado")
    
    def get_available_workers(self) -> int:
        """
        Retorna o número de workers disponíveis (IDLE)
        
        Returns:
            Número de workers disponíveis
        """
        return sum(1 for w in self.workers if w.status == WorkerStatus.IDLE)
    
    def get_busy_workers(self) -> int:
        """
        Retorna o número de workers ocupados (BUSY)
        
        Returns:
            Número de workers ocupados
        """
        return sum(1 for w in self.workers if w.status == WorkerStatus.BUSY)
    
    def get_queue_size(self) -> int:
        """
        Retorna o tamanho da fila de tarefas
        
        Returns:
            Número de tarefas na fila
        """
        return self._task_queue.qsize()
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas do pool
        
        Returns:
            Dicionário com métricas
        """
        return {
            'running': self._running,
            'num_workers': self.num_workers,
            'available_workers': self.get_available_workers(),
            'busy_workers': self.get_busy_workers(),
            'queue_size': self.get_queue_size(),
            'total_submitted': self._total_tasks_submitted,
            'total_completed': self._total_tasks_completed,
            'total_failed': self._total_tasks_failed,
            'workers': [w.get_stats() for w in self.workers]
        }
    
    def __repr__(self) -> str:
        """Representação string do pool"""
        return (
            f"WorkerPool(workers={self.num_workers}, "
            f"available={self.get_available_workers()}, "
            f"queue={self.get_queue_size()})"
        )
