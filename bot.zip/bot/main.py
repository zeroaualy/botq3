"""
Bot Q3 IA v3.0 - Arquitetura Sênior
Executor de sinais em conta PRACTICE com IA Guard

PRINCÍPIOS:
- Separação de responsabilidades
- Segurança PRACTICE obrigatória
- IA como validadora (NÃO estrategista)
- Governança transparente
"""
import asyncio
import logging
from datetime import datetime
from zoneinfo import ZoneInfo
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)

# Timezone oficial
TZ = ZoneInfo("America/Sao_Paulo")

# State
from state.config import TOKEN, GRUPO_ID, GEMINI_API_KEY, EMAIL, SENHA, CONFIG, PERMISSOES
from state import stats
from state import runtime

# Core
from core.iq_client import IQClient
from core.signal_parser import parsear_sinal, validar_sinal
from core.trade_executor import TradeExecutor
from core.scheduler import Scheduler
from core.auto_trader import AutoTrader

# AI
from ai.ia_guard import IAGuard
from ai.q3_ia_beta import Q3IABeta
from ai.stats_optimizer import StatsOptimizer

# Core (Risk Manager)
from core.risk_manager import RiskManager

# Bot
from bot.telegram_bot import TelegramBot

# Gemini
try:
    from core.gemini_client import GeminiClient
    GEMINI_DISPONIVEL = True
except ImportError:
    GEMINI_DISPONIVEL = False

# ======================================
# LOGGING
# ======================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ======================================
# INICIALIZAÇÃO
# ======================================
def inicializar_ia():
    """Inicializa cliente IA com validação robusta"""
    if not GEMINI_DISPONIVEL:
        logger.error("❌ Biblioteca Gemini não está instalada")
        logger.error("   Execute: pip install google-generativeai")
        return None
    
    if not GEMINI_API_KEY:
        logger.error("❌ GEMINI_API_KEY não está configurada")
        logger.error("   Verifique o arquivo .env")
        return None
    
    # Log da chave (primeiros 8 caracteres apenas - seguro)
    logger.info(f"🔑 Inicializando Gemini com chave: {GEMINI_API_KEY[:8]}...")
    
    try:
        # Criar cliente Gemini
        client = GeminiClient(api_key=GEMINI_API_KEY)
        
        logger.info("✅ IA Guard inicializada e testada com sucesso")
        return client
        
    except Exception as e:
        error_msg = str(e)
        logger.error(f"❌ Erro ao inicializar IA: {error_msg}")
        
        # Diagnóstico específico
        if "401" in error_msg or "invalid" in error_msg.lower():
            logger.error("🔴 ERRO 401: API Key inválida")
            logger.error(f"   Chave usada (primeiros 8): {GEMINI_API_KEY[:8]}...")
            logger.error(f"   Comprimento da chave: {len(GEMINI_API_KEY)}")
            logger.error("   Verifique se a chave está correta no .env")
        elif "429" in error_msg:
            logger.error("🟡 Rate limit atingido - aguarde e tente novamente")
        elif "500" in error_msg or "502" in error_msg or "503" in error_msg:
            logger.error("🟡 Servidor Gemini temporariamente indisponível")
        
        logger.warning("⚠️ Bot continuará funcionando SEM IA Guard")
        logger.warning("   Operações serão executadas com análise técnica básica")
        
        return None


async def inicializar_sistema():
    """Inicializa todos os componentes (async)"""
    logger.info("🚀 Iniciando Bot Q3 IA v3.2...")
    logger.info("="*60)
    
    # ═══════════════════════════════════════════════════════════
    # IA
    # ═══════════════════════════════════════════════════════════
    gemini_client = inicializar_ia()
    runtime.gemini_client = gemini_client
    
    # ═══════════════════════════════════════════════════════════
    # IQ OPTION
    # ═══════════════════════════════════════════════════════════
    iq_client = IQClient(EMAIL, SENHA, CONFIG)
    conectado = await iq_client.conectar()
    
    if not conectado:
        logger.warning("⚠️ Bot iniciará sem conexão IQ Option")
    else:
        # Cache de ativos não é mais usado - validação é live
        logger.info("✅ Sistema pronto para validação live de ativos")
    
    runtime.iq_connection = iq_client
    
    # ═══════════════════════════════════════════════════════════
    # STATS OPTIMIZER (Otimizador Estatístico)
    # ═══════════════════════════════════════════════════════════
    stats_optimizer = StatsOptimizer()
    runtime.stats_optimizer = stats_optimizer
    logger.info("✅ Stats Optimizer inicializado")
    
    # ═══════════════════════════════════════════════════════════
    # Q3 IA BETA (Filtro Estratégico)
    # ═══════════════════════════════════════════════════════════
    q3_ia_beta = Q3IABeta(stats_optimizer)
    runtime.q3_ia_beta = q3_ia_beta
    logger.info("✅ Q3 IA Beta inicializada")
    
    # ═══════════════════════════════════════════════════════════
    # RISK MANAGER (Controle Adaptativo de Risco)
    # ═══════════════════════════════════════════════════════════
    risk_manager = RiskManager(stats_optimizer)
    runtime.risk_manager = risk_manager
    logger.info("✅ Risk Manager inicializado")
    
    # ═══════════════════════════════════════════════════════════
    # COMPONENTES CORE
    # ═══════════════════════════════════════════════════════════
    trade_executor = TradeExecutor(iq_client)
    ia_guard = IAGuard(gemini_client)
    scheduler = Scheduler(CONFIG["tolerancia_agendamento_ms"])
    
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # AUTO TRADER
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    auto_trader = AutoTrader(
        iq_client=iq_client,
        trade_executor=trade_executor,
        config=CONFIG,
        stats=stats.STATS
    )
    runtime.auto_trader = auto_trader
    logger.info("✅ AutoTrader inicializado")
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # SIGNAL ENGINE - Motor de Automação de Sinais
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    from core.signal_engine import SignalEngine
    
    signal_engine = SignalEngine(
        iq_client=iq_client,
        runtime=runtime,
        config=CONFIG
    )
    runtime.signal_engine = signal_engine
    logger.info("✅ SignalEngine (Automação de Sinais) inicializado")
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # AUTO SIGNAL GENERATOR - MyIQ + Gemini AI
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    from core.auto_signal_generator import AutoSignalGenerator
    
    auto_signal_gen = AutoSignalGenerator(
        iq_client=iq_client,
        gemini_client=gemini_client,
        runtime=runtime,
        config=CONFIG
    )
    runtime.auto_signal_generator = auto_signal_gen
    logger.info("✅ AutoSignalGenerator (MyIQ + Gemini AI) inicializado")
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    
    # ═══════════════════════════════════════════════════════════
    # BOT TELEGRAM
    # ═══════════════════════════════════════════════════════════
    telegram_bot = TelegramBot(
        config=CONFIG,
        stats=stats.STATS,
        runtime=runtime,
        signal_parser=type('obj', (object,), {'parsear_sinal': parsear_sinal}),
        trade_executor=trade_executor,
        ia_guard=ia_guard,
        permissoes=PERMISSOES
    )
    telegram_bot.set_iq_client(iq_client)
    telegram_bot.set_auto_trader(auto_trader)
    
    logger.info("✅ Sistema inicializado com Q3 IA Beta")
    logger.info("🏦 Configurado para PRACTICE")
    logger.info("🤖 IA Guard: Validadora de contexto")
    logger.info("🧠 Q3 IA Beta: Filtro estratégico ativo")
    logger.info("🛡️ Risk Manager: Controle adaptativo ativo")
    logger.info("📊 Stats Optimizer: Análise estatística ativa")
    logger.info("🔄 AutoTrader: Pronto para execução automática")
    logger.info("🧠 SignalEngine: Motor de Automação de Sinais pronto")
    logger.info("🤖 AutoSignalGenerator: MyIQ + Gemini AI pronto")
    logger.info("🔒 Governança: Flags de auditoria ativas")
    
    return telegram_bot, trade_executor, ia_guard, scheduler, iq_client, q3_ia_beta, risk_manager, stats_optimizer


# ======================================
# PROCESSADOR DE OPERAÇÕES
# ======================================
async def processar_operacao(app, sinal, trade_executor, ia_guard, iq_client, q3_ia_beta, risk_manager, stats_optimizer):
    """
    Processa operação completa com Q3 IA Beta e Risk Manager
    
    FLUXO:
    Captura de Sinal
    ↓
    Motor Determinístico de Análise Técnica
    ↓
    Q3 IA Beta (Filtro Estratégico + Score)
    ↓
    Risk Manager Adaptativo
    ↓
    Executor de Trade
    """
    
    # ═══════════════════════════════════════════════════════════
    # 1. CONTEXTO OPERACIONAL
    # ═══════════════════════════════════════════════════════════
    contexto = {
        "ativo_aberto": True,  # Poderia verificar com iq_client
        "volatilidade": 1.0,   # Poderia calcular volatilidade real
        "tendencia_alinhada": True,  # Poderia analisar tendência real
    }
    
    # ═══════════════════════════════════════════════════════════
    # 2. Q3 IA BETA - FILTRO ESTRATÉGICO
    # ═══════════════════════════════════════════════════════════
    await app.bot.send_message(GRUPO_ID, "🧠 Q3 IA Beta avaliando sinal...")
    
    decisao_q3, score_q3, analise_q3 = await q3_ia_beta.avaliar_sinal(
        sinal=sinal,
        contexto=contexto,
        payout=80.0  # Poderia obter payout real da API
    )
    
    # Mostrar análise
    fatores_pos = "\n".join(f"  • {f}" for f in analise_q3["fatores_positivos"])
    fatores_neg = "\n".join(f"  • {f}" for f in analise_q3["fatores_negativos"])
    
    mensagem_q3 = (
        f"🧠 <b>Q3 IA Beta - Análise</b>\n\n"
        f"📊 Score: {score_q3}\n"
        f"🎯 Decisão: {decisao_q3}\n\n"
        f"<b>✅ Fatores Positivos:</b>\n{fatores_pos if fatores_pos else '  Nenhum'}\n\n"
        f"<b>❌ Fatores Negativos:</b>\n{fatores_neg if fatores_neg else '  Nenhum'}"
    )
    await app.bot.send_message(GRUPO_ID, mensagem_q3, parse_mode="HTML")
    
    # Decisão Q3 IA Beta
    if decisao_q3 == "REJEITAR":
        await app.bot.send_message(
            GRUPO_ID,
            f"❌ <b>Operação REJEITADA pela Q3 IA Beta</b>\n\n"
            f"Score insuficiente: {score_q3}",
            parse_mode="HTML"
        )
        return
    
    if decisao_q3 == "ALTO_RISCO":
        await app.bot.send_message(
            GRUPO_ID,
            f"⚠️ <b>ALTO RISCO detectado pela Q3 IA Beta</b>\n\n"
            f"Score muito baixo: {score_q3}\n"
            f"Operação cancelada por segurança",
            parse_mode="HTML"
        )
        return
    
    # ═══════════════════════════════════════════════════════════
    # 3. VALIDAÇÃO DE CONTEXTO COM IA GUARD (opcional)
    # ═══════════════════════════════════════════════════════════
    if CONFIG["ia_validar_contexto"] and not ia_guard.desabilitado():
        await app.bot.send_message(GRUPO_ID, "🤖 IA Guard validando contexto...")
        
        decisao = await ia_guard.validar_contexto(sinal, contexto)
        stats.registrar_decisao_ia(decisao)
        
        if decisao == "IGNORAR":
            await app.bot.send_message(
                GRUPO_ID,
                f"❌ <b>IA Guard: IGNORAR</b>\n\n"
                f"📊 {sinal['par']} {sinal['direcao']}\n"
                f"Condições operacionais desfavoráveis",
                parse_mode="HTML"
            )
            return
        
        elif decisao == "RISCO":
            await app.bot.send_message(
                GRUPO_ID,
                f"⚠️ <b>IA Guard: RISCO ALTO</b>\n\n"
                f"📊 {sinal['par']} {sinal['direcao']}\n"
                f"Operação cancelada por segurança",
                parse_mode="HTML"
            )
            return
        
        await app.bot.send_message(GRUPO_ID, "✅ IA Guard: Contexto OK")
    
    # ═══════════════════════════════════════════════════════════
    # 4. RISK MANAGER - VALIDAÇÃO E VALOR AJUSTADO
    # ═══════════════════════════════════════════════════════════
    await app.bot.send_message(GRUPO_ID, "🛡️ Risk Manager validando operação...")
    
    pode_executar, motivo_rm, valor_ajustado = await risk_manager.validar_operacao(
        sinal=sinal,
        contexto=contexto
    )
    
    if not pode_executar:
        await app.bot.send_message(
            GRUPO_ID,
            f"🛡️ <b>Risk Manager: BLOQUEADO</b>\n\n"
            f"Motivo: {motivo_rm}",
            parse_mode="HTML"
        )
        return
    
    await app.bot.send_message(
        GRUPO_ID,
        f"✅ Risk Manager: Operação aprovada\n"
        f"💰 Valor ajustado: ${valor_ajustado:.2f}",
        parse_mode="HTML"
    )
    
    # ═══════════════════════════════════════════════════════════
    # 5. EXECUTAR OPERAÇÃO
    # ═══════════════════════════════════════════════════════════
    valor = valor_ajustado
    
    saldo_antes = await iq_client.obter_saldo()
    tipo_conta = iq_client.obter_tipo_conta()
    
    await app.bot.send_message(
        GRUPO_ID,
        f"💰 <b>PRÉ-OPERAÇÃO</b>\n\n"
        f"🏦 Conta: {tipo_conta}\n"
        f"💵 Saldo: ${saldo_antes:.2f}\n"
        f"📊 Par: {sinal['par']}\n"
        f"📈 Direção: {sinal['direcao']}\n"
        f"⏱️ Expiração: {sinal['tempo_expiracao']}s\n"
        f"💰 Valor (ajustado): ${valor:.2f}\n"
        f"🧠 Score Q3: {score_q3}\n"
        f"🕐 Horário: {datetime.now(TZ).strftime('%H:%M:%S')}",
        parse_mode="HTML"
    )
    
    # Registrar operação iniciada
    risk_manager.registrar_operacao_iniciada()
    
    status, order_id = await trade_executor.executar(
        sinal["par"],
        sinal["direcao"],
        valor,
        sinal["tempo_expiracao"]
    )
    
    if not status:
        risk_manager.registrar_operacao_finalizada()
        await app.bot.send_message(
            GRUPO_ID,
            "❌ <b>FALHA NA OPERAÇÃO</b>\n\n"
            "Possíveis causas:\n"
            "• Ativo fechado\n"
            "• Horário fora do expediente\n"
            "• Problema de conexão\n"
            "• Tente -OTC",
            parse_mode="HTML"
        )
        return
    
    await app.bot.send_message(
        GRUPO_ID,
        f"🎯 <b>OPERAÇÃO EXECUTADA</b>\n\n"
        f"🏦 Conta: PRACTICE ✅\n"
        f"📊 Par: {sinal['par']}\n"
        f"📈 Direção: {sinal['direcao']}\n"
        f"💰 Valor: ${valor:.2f}\n"
        f"⏱️ Expiração: {sinal['tempo_expiracao']}s\n"
        f"🆔 ID: {order_id}\n"
        f"🕐 Executado: {datetime.now(TZ).strftime('%H:%M:%S')}",
        parse_mode="HTML"
    )
    
    # ═══════════════════════════════════════════════════════════
    # 6. AGUARDAR RESULTADO
    # ═══════════════════════════════════════════════════════════
    await app.bot.send_message(
        GRUPO_ID,
        f"⏳ Aguardando {sinal['tempo_expiracao']}s..."
    )
    
    await asyncio.sleep(sinal["tempo_expiracao"] + 5)
    
    resultado, lucro = trade_executor.verificar_resultado(order_id)
    
    # Registrar operação finalizada
    risk_manager.registrar_operacao_finalizada()
    
    # ═══════════════════════════════════════════════════════════
    # 7. REGISTRAR ESTATÍSTICAS (AMBOS OS SISTEMAS)
    # ═══════════════════════════════════════════════════════════
    stats.registrar_operacao(resultado, valor, lucro)
    
    # Registrar no Stats Optimizer
    stats_optimizer.registrar_operacao(
        par=sinal["par"],
        direcao=sinal["direcao"],
        resultado=resultado,
        valor_operacao=valor,
        valor_lucro=lucro,
        payout=80.0,
        score_q3=score_q3,
        contexto=contexto
    )
    
    if resultado == "WIN":
        emoji = "✅"
    elif resultado == "LOSS":
        emoji = "❌"
    elif resultado == "EMPATE":
        emoji = "⚪"
    else:
        emoji = "⚠️"
    
    winrate = stats.obter_winrate()
    saldo_depois = await iq_client.obter_saldo()
    diferenca = saldo_depois - saldo_antes
    
    # Status do Risk Manager
    status_rm = risk_manager.obter_status()
    
    await app.bot.send_message(
        GRUPO_ID,
        f"{emoji} <b>RESULTADO: {resultado}</b>\n\n"
        f"🏦 Conta: PRACTICE ✅\n"
        f"💰 Lucro op: ${lucro:.2f}\n"
        f"💵 Antes: ${saldo_antes:.2f}\n"
        f"💵 Depois: ${saldo_depois:.2f}\n"
        f"📊 Diferença: ${diferenca:.2f}\n\n"
        f"📈 <b>Resumo:</b>\n"
        f"├ Lucro dia: ${stats.STATS['lucro_dia']:.2f}\n"
        f"├ Win Rate: {winrate:.1f}%\n"
        f"└ Ops: {stats.STATS['vitorias']}W / {stats.STATS['derrotas']}L / {stats.STATS['empates']}E\n\n"
        f"🤖 <b>IA Guard:</b>\n"
        f"└ Exec: {stats.STATS['ia_decisoes']['executar']} | "
        f"Ignor: {stats.STATS['ia_decisoes']['ignorar']} | "
        f"Risco: {stats.STATS['ia_decisoes']['risco']}\n\n"
        f"🧠 <b>Q3 IA Beta:</b>\n"
        f"└ Score: {score_q3} | Decisão: {decisao_q3}\n\n"
        f"🛡️ <b>Risk Manager:</b>\n"
        f"└ Perdas consecutivas: {status_rm['perdas_consecutivas']} | "
        f"Ops ativas: {status_rm['operacoes_ativas']}",
        parse_mode="HTML"
    )


# ======================================
# LOOP AUTOMÁTICO
# ======================================
async def loop_auto(app, scheduler, trade_executor, ia_guard, iq_client, q3_ia_beta, risk_manager, stats_optimizer):
    """Loop principal - executa sinais e monitora stops"""

    reconnect_backoff = 5   # Backoff para reconexão

    while True:
        try:
            # ── Auto-reconexão IQ Option ───────────────────────────────
            if not iq_client.esta_conectado():
                logger.warning("⚠️ IQ Option desconectado - tentando reconectar...")
                try:
                    reconectado = await asyncio.wait_for(
                        iq_client.conectar(max_tentativas=2),
                        timeout=60.0
                    )
                    if reconectado:
                        logger.info("✅ IQ Option reconectado com sucesso")
                        reconnect_backoff = 5
                    else:
                        logger.error(f"❌ Reconexão falhou - aguardando {reconnect_backoff}s")
                        await asyncio.sleep(reconnect_backoff)
                        reconnect_backoff = min(reconnect_backoff * 2, 120)
                        continue
                except asyncio.TimeoutError:
                    logger.error("❌ Timeout na reconexão - aguardando...")
                    await asyncio.sleep(reconnect_backoff)
                    continue
            
            # Verificar sinais prontos
            sinais_prontos = scheduler.verificar_sinais_prontos(runtime.sinais_agendados)
            
            for sinal in sinais_prontos:
                runtime.remover_sinal(sinal)
                
                if CONFIG["operar_automatico"]:
                    await app.bot.send_message(
                        GRUPO_ID,
                        f"⏰ <b>Executando sinal agendado</b>\n\n"
                        f"📊 {sinal['par']} {sinal['direcao']}\n"
                        f"🕐 Previsto: {sinal['horario'].strftime('%H:%M:%S')}\n"
                        f"🕐 Real: {datetime.now(TZ).strftime('%H:%M:%S')}",
                        parse_mode="HTML"
                    )
                    await processar_operacao(app, sinal, trade_executor, ia_guard, iq_client, q3_ia_beta, risk_manager, stats_optimizer)
                else:
                    logger.warning(f"⚠️ Bot pausado - sinal {sinal['par']} não executado")
            
            # Verificar Stop Loss
            if stats.STATS["lucro_dia"] <= -CONFIG["stop_loss"]:
                if CONFIG["operar_automatico"]:
                    CONFIG["operar_automatico"] = False
                    await app.bot.send_message(
                        GRUPO_ID,
                        f"🛑 <b>STOP LOSS ATINGIDO!</b>\n\n"
                        f"Perda: ${abs(stats.STATS['lucro_dia']):.2f}\n"
                        f"Limite: ${CONFIG['stop_loss']:.2f}\n"
                        f"Bot pausado automaticamente.\n\n"
                        f"🏦 Conta: PRACTICE ✅",
                        parse_mode="HTML"
                    )
            
            # Verificar Stop Gain
            if stats.STATS["lucro_dia"] >= CONFIG["stop_gain"]:
                if CONFIG["operar_automatico"]:
                    CONFIG["operar_automatico"] = False
                    await app.bot.send_message(
                        GRUPO_ID,
                        f"🎯 <b>STOP GAIN ATINGIDO!</b>\n\n"
                        f"Lucro: ${stats.STATS['lucro_dia']:.2f}\n"
                        f"Meta: ${CONFIG['stop_gain']:.2f}\n"
                        f"Bot pausado automaticamente.\n\n"
                        f"🏦 Conta: PRACTICE ✅",
                        parse_mode="HTML"
                    )
            
            await asyncio.sleep(1)
            
        except asyncio.CancelledError:
            logger.info("Loop automático cancelado")
            break
        except Exception as e:
            logger.error(f"Erro no loop: {e}")
            import traceback
            logger.error(traceback.format_exc())
            await asyncio.sleep(5)


# ======================================
# MAIN
# ======================================
def main():
    """Ponto de entrada"""
    
    # Criar aplicação Telegram
    app = Application.builder().token(TOKEN).build()
    
    # Post-init e shutdown
    async def post_init(application):
        # Inicializar componentes de forma assíncrona
        telegram_bot, trade_executor, ia_guard, scheduler, iq_client, q3_ia_beta, risk_manager, stats_optimizer = await inicializar_sistema()
        
        # Armazenar componentes no bot_data
        application.bot_data['telegram_bot'] = telegram_bot
        application.bot_data['trade_executor'] = trade_executor
        application.bot_data['ia_guard'] = ia_guard
        application.bot_data['scheduler'] = scheduler
        application.bot_data['iq_client'] = iq_client
        application.bot_data['q3_ia_beta'] = q3_ia_beta
        application.bot_data['risk_manager'] = risk_manager
        application.bot_data['stats_optimizer'] = stats_optimizer
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # CONFIGURAR BOT NO AUTO TRADER
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        from state import runtime
        if runtime.auto_trader:
            runtime.auto_trader.set_telegram_bot(application.bot)
            logger.info("✅ Bot Telegram configurado no AutoTrader")
        # Injetar app no AutoSignalGenerator para show_signals_in_chat
        if runtime.auto_signal_generator:
            runtime.auto_signal_generator.set_telegram_app(application)
            logger.info("✅ Telegram app configurado no AutoSignalGenerator")
        # Guardar referência global do app para uso interno
        runtime._telegram_app = application
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        # Configurar handlers
        application.add_handler(CommandHandler("start", telegram_bot.start))
        application.add_handler(CallbackQueryHandler(telegram_bot.button_handler))
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, telegram_bot.mensagem))
        
        # Iniciar loop de auto trade
        task = asyncio.create_task(
            loop_auto(application, scheduler, trade_executor, ia_guard, iq_client, q3_ia_beta, risk_manager, stats_optimizer)
        )
        application.bot_data['loop_task'] = task
        logger.info("🤖 Bot rodando - Sistema autônomo ativo")
    
    async def post_shutdown(application):
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # DESATIVAR AUTO TRADER AO ENCERRAR
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        from state import runtime
        if runtime.auto_trader and runtime.auto_trader.is_ativo():
            await runtime.auto_trader.desativar()
            logger.info("✅ AutoTrader desativado")
        
        # Desativar signal_engine se ativo
        if runtime.signal_engine and runtime.signal_engine.is_ativo():
            await runtime.signal_engine.desativar()
            logger.info("✅ SignalEngine desativado")
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        if 'loop_task' in application.bot_data:
            application.bot_data['loop_task'].cancel()
            try:
                await application.bot_data['loop_task']
            except asyncio.CancelledError:
                pass
    
    app.post_init = post_init
    app.post_shutdown = post_shutdown
    
    logger.info("=" * 50)
    logger.info("🚀 Bot Q3 IA v3.0 com Q3 IA Beta pronto!")
    logger.info("🏗️ Arquitetura modular implementada")
    logger.info("🔒 Segurança PRACTICE obrigatória")
    logger.info("🤖 IA Guard: Validadora (NÃO estrategista)")
    logger.info("🧠 Q3 IA Beta: Filtro estratégico inteligente")
    logger.info("🛡️ Risk Manager: Controle adaptativo de risco")
    logger.info("📊 Stats Optimizer: Otimização estatística")
    logger.info("📊 Governança transparente")
    logger.info("=" * 50)
    
    app.run_polling()


if __name__ == "__main__":
    main()
