"""
Asset Cache - Q3 IA Beta
Sistema de cache com TTL para dados de ativos
"""
import asyncio
import logging
from typing import Any, Optional, Dict, Callable
from datetime import datetime, timedelta
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class CacheEntry:
    """Entrada do cache com TTL"""
    key: str
    value: Any
    created_at: datetime
    ttl_seconds: float
    hits: int = 0
    
    @property
    def is_expired(self) -> bool:
        """Verifica se a entrada expirou"""
        age = (datetime.now() - self.created_at).total_seconds()
        return age >= self.ttl_seconds
    
    @property
    def age_seconds(self) -> float:
        """Retorna a idade da entrada em segundos"""
        return (datetime.now() - self.created_at).total_seconds()


class AssetCache:
    """
    Cache com TTL e atualização automática
    
    Características:
    - TTL configurável por entrada
    - Atualização automática em background
    - Limpeza automática de entradas expiradas
    - Métricas de hit/miss
    - Suporte a callbacks de atualização
    """
    
    def __init__(self, default_ttl: float = 60.0, cleanup_interval: float = 30.0):
        """
        Inicializa o cache
        
        Args:
            default_ttl: TTL padrão em segundos
            cleanup_interval: Intervalo de limpeza em segundos
        """
        self._cache: Dict[str, CacheEntry] = {}
        self._default_ttl = default_ttl
        self._cleanup_interval = cleanup_interval
        
        # Callbacks de atualização
        self._update_callbacks: Dict[str, Callable] = {}
        
        # Métricas
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        self._auto_refreshes = 0
        
        # Tasks de background
        self._cleanup_task: Optional[asyncio.Task] = None
        self._refresh_tasks: Dict[str, asyncio.Task] = {}
        self._running = False
        
        logger.info(
            f"✅ Asset Cache inicializado "
            f"(ttl={default_ttl}s, cleanup={cleanup_interval}s)"
        )
    
    async def start(self) -> None:
        """Inicia o cache e tarefas de background"""
        if self._running:
            logger.warning("⚠️ Cache já está rodando")
            return
        
        self._running = True
        
        # Iniciar limpeza automática
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        
        logger.info("🚀 Asset Cache iniciado")
    
    async def stop(self) -> None:
        """Para o cache e tarefas de background"""
        if not self._running:
            logger.warning("⚠️ Cache já está parado")
            return
        
        self._running = False
        
        # Cancelar cleanup task
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        
        # Cancelar refresh tasks
        for task in self._refresh_tasks.values():
            task.cancel()
        
        await asyncio.gather(*self._refresh_tasks.values(), return_exceptions=True)
        self._refresh_tasks.clear()
        
        logger.info("⛔ Asset Cache parado")
    
    async def get(self, key: str, default: Any = None) -> Optional[Any]:
        """
        Obtém um valor do cache
        
        Args:
            key: Chave do cache
            default: Valor padrão se não encontrado
        
        Returns:
            Valor ou default se não encontrado/expirado
        """
        entry = self._cache.get(key)
        
        if entry is None:
            self._misses += 1
            return default
        
        if entry.is_expired:
            self._misses += 1
            await self._evict(key)
            return default
        
        # Hit!
        entry.hits += 1
        self._hits += 1
        
        return entry.value
    
    async def set(self, key: str, value: Any, ttl: Optional[float] = None,
                  auto_refresh: bool = False, 
                  refresh_callback: Optional[Callable] = None) -> None:
        """
        Define um valor no cache
        
        Args:
            key: Chave do cache
            value: Valor a armazenar
            ttl: TTL em segundos (usa default se None)
            auto_refresh: Se True, atualiza automaticamente antes de expirar
            refresh_callback: Callback async para atualização automática
        """
        ttl = ttl if ttl is not None else self._default_ttl
        
        entry = CacheEntry(
            key=key,
            value=value,
            created_at=datetime.now(),
            ttl_seconds=ttl
        )
        
        self._cache[key] = entry
        
        # Registrar callback de atualização
        if auto_refresh and refresh_callback:
            self._update_callbacks[key] = refresh_callback
            
            # Iniciar task de refresh automático
            if key not in self._refresh_tasks or self._refresh_tasks[key].done():
                self._refresh_tasks[key] = asyncio.create_task(
                    self._auto_refresh_loop(key, ttl, refresh_callback)
                )
    
    async def delete(self, key: str) -> bool:
        """
        Remove um valor do cache
        
        Args:
            key: Chave a remover
        
        Returns:
            True se removido, False se não existia
        """
        if key in self._cache:
            await self._evict(key)
            return True
        return False
    
    async def clear(self) -> int:
        """
        Limpa todo o cache
        
        Returns:
            Número de entradas removidas
        """
        count = len(self._cache)
        
        # Cancelar todas as refresh tasks
        for task in self._refresh_tasks.values():
            task.cancel()
        
        self._cache.clear()
        self._update_callbacks.clear()
        self._refresh_tasks.clear()
        
        logger.info(f"🗑️ Cache limpo ({count} entradas removidas)")
        return count
    
    def has(self, key: str) -> bool:
        """
        Verifica se uma chave existe e não está expirada
        
        Args:
            key: Chave a verificar
        
        Returns:
            True se existe e não expirou
        """
        entry = self._cache.get(key)
        return entry is not None and not entry.is_expired
    
    def size(self) -> int:
        """Retorna o número de entradas no cache"""
        return len(self._cache)
    
    async def _evict(self, key: str) -> None:
        """
        Remove uma entrada do cache
        
        Args:
            key: Chave a remover
        """
        if key in self._cache:
            del self._cache[key]
            self._evictions += 1
        
        if key in self._update_callbacks:
            del self._update_callbacks[key]
        
        if key in self._refresh_tasks:
            self._refresh_tasks[key].cancel()
            del self._refresh_tasks[key]
    
    async def _cleanup_loop(self) -> None:
        """Loop de limpeza automática de entradas expiradas"""
        logger.info("🔄 Limpeza automática do cache iniciada")
        
        try:
            while self._running:
                await asyncio.sleep(self._cleanup_interval)
                
                # Encontrar entradas expiradas
                expired_keys = [
                    key for key, entry in self._cache.items()
                    if entry.is_expired
                ]
                
                # Remover expiradas
                for key in expired_keys:
                    await self._evict(key)
                
                if expired_keys:
                    logger.debug(
                        f"🗑️ Limpeza: {len(expired_keys)} entradas expiradas removidas"
                    )
        
        except asyncio.CancelledError:
            logger.info("✅ Limpeza do cache cancelada")
        except Exception as e:
            logger.error(f"❌ Erro na limpeza do cache: {e}")
    
    async def _auto_refresh_loop(self, key: str, ttl: float, 
                                 callback: Callable) -> None:
        """
        Loop de atualização automática de uma entrada
        
        Args:
            key: Chave a atualizar
            ttl: TTL da entrada
            callback: Callback para obter novo valor
        """
        try:
            # Aguardar 80% do TTL antes de atualizar
            refresh_interval = ttl * 0.8
            
            while self._running and key in self._cache:
                await asyncio.sleep(refresh_interval)
                
                # Verificar se ainda existe
                if key not in self._cache:
                    break
                
                try:
                    # Chamar callback para obter novo valor
                    if asyncio.iscoroutinefunction(callback):
                        new_value = await callback(key)
                    else:
                        new_value = await asyncio.get_event_loop().run_in_executor(
                            None, callback, key
                        )
                    
                    # Atualizar cache
                    if new_value is not None:
                        await self.set(key, new_value, ttl, auto_refresh=True, 
                                      refresh_callback=callback)
                        self._auto_refreshes += 1
                        logger.debug(f"🔄 Cache auto-atualizado: {key}")
                
                except Exception as e:
                    logger.error(f"❌ Erro ao auto-atualizar {key}: {e}")
        
        except asyncio.CancelledError:
            logger.debug(f"✅ Auto-refresh cancelado: {key}")
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas do cache
        
        Returns:
            Dicionário com métricas
        """
        total_requests = self._hits + self._misses
        hit_rate = (self._hits / total_requests * 100) if total_requests > 0 else 0
        
        return {
            'size': len(self._cache),
            'hits': self._hits,
            'misses': self._misses,
            'hit_rate': hit_rate,
            'evictions': self._evictions,
            'auto_refreshes': self._auto_refreshes,
            'running': self._running,
            'entries': [
                {
                    'key': entry.key,
                    'age_seconds': entry.age_seconds,
                    'ttl_seconds': entry.ttl_seconds,
                    'hits': entry.hits,
                    'expired': entry.is_expired
                }
                for entry in self._cache.values()
            ]
        }
    
    def reset_metrics(self) -> None:
        """Reseta as métricas do cache"""
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        self._auto_refreshes = 0
        logger.info("📊 Métricas do cache resetadas")
    
    def __len__(self) -> int:
        """Retorna o tamanho do cache"""
        return len(self._cache)
    
    def __repr__(self) -> str:
        """Representação string do cache"""
        return f"AssetCache(size={len(self._cache)}, hit_rate={self.get_metrics()['hit_rate']:.1f}%)"


# Instância global do cache
_asset_cache_instance: Optional[AssetCache] = None


def get_asset_cache() -> AssetCache:
    """
    Retorna a instância global do cache (singleton)
    
    Returns:
        Instância do AssetCache
    """
    global _asset_cache_instance
    
    if _asset_cache_instance is None:
        _asset_cache_instance = AssetCache()
    
    return _asset_cache_instance
