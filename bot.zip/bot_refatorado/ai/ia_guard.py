"""
IA Guard - Validador de Contexto e Risco Operacional

REGRAS ABSOLUTAS:
- NÃO cria estratégia
- NÃO prevê mercado
- NÃO decide CALL ou PUT
- NÃO gera sinais
- APENAS valida contexto operacional e risco
"""
import logging

logger = logging.getLogger(__name__)


class IAGuard:
    """
    Validador de Contexto e Risco Operacional
    
    PAPEL LIMITADO:
    - Avaliar se condições operacionais são aceitáveis
    - Bloquear execuções por segurança (ex: volatilidade extrema)
    - Validar se sinal é EXECUTÁVEL
    
    NÃO FAZ:
    - Criar estratégia
    - Prever mercado
    - Decidir direção
    """
    
    def __init__(self, groq_client):
        self.groq_client = groq_client
    
    async def validar_contexto(self, sinal, contexto_operacional=None):
        """
        Valida APENAS contexto operacional
        
        Retorna: "EXECUTAR", "IGNORAR" ou "RISCO"
        """
        if not self.groq_client:
            logger.warning("⚠️ IA indisponível, executando sem validação")
            return "EXECUTAR"
        
        try:
            prompt = self._criar_prompt_validacao(sinal, contexto_operacional)
            
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=10,
            )
            
            resposta = response.choices[0].message.content.strip().upper()
            
            # Extrair decisão
            if "EXECUTAR" in resposta:
                decisao = "EXECUTAR"
            elif "RISCO" in resposta:
                decisao = "RISCO"
            else:
                decisao = "IGNORAR"
            
            logger.info(f"🤖 IA Guard: {decisao}")
            return decisao
            
        except Exception as e:
            logger.error(f"❌ Erro na IA Guard: {e}")
            return "EXECUTAR"  # Permite execução em caso de erro
    
    def _criar_prompt_validacao(self, sinal, contexto):
        """
        Cria prompt RESTRITO para validação
        
        IMPORTANTE: Prompt NÃO solicita análise técnica ou previsão
        """
        # Contexto básico (sem análise técnica)
        contexto_str = ""
        if contexto:
            if "ativo_aberto" in contexto:
                contexto_str += f"- Ativo aberto: {'Sim' if contexto['ativo_aberto'] else 'Não'}\n"
            if "atraso_execucao" in contexto:
                contexto_str += f"- Atraso de execução: {contexto['atraso_execucao']}s\n"
        
        prompt = f"""Você é um validador de CONTEXTO OPERACIONAL.

SINAL RECEBIDO:
- Par: {sinal['par']}
- Direção solicitada: {sinal['direcao']}
- Expiração: {sinal['tempo_expiracao']}s

CONTEXTO OPERACIONAL:
{contexto_str if contexto_str else "- Nenhum contexto adicional"}

TAREFA:
Avaliar APENAS se o contexto operacional permite execução segura.

NÃO analise tendência.
NÃO preveja mercado.
NÃO sugira estratégia.

RESPONDA APENAS UMA PALAVRA:
- EXECUTAR (se contexto operacional OK)
- IGNORAR (se condições ruins para operar)
- RISCO (se detectar problema grave)

Resposta:"""
        
        return prompt
    
    def desabilitado(self):
        """Verifica se IA Guard está desabilitada"""
        return self.groq_client is None


# ======================================
# BLOQUEIO DE CAPACIDADES PROIBIDAS
# ======================================
def bloquear_estrategia():
    """
    Bloqueia qualquer tentativa de criar estratégia
    Esta função é chamada se houver tentativa de uso indevido
    """
    logger.error("❌ BLOQUEIO: IA não pode criar estratégias")
    return False


def bloquear_previsao():
    """
    Bloqueia qualquer tentativa de prever mercado
    """
    logger.error("❌ BLOQUEIO: IA não pode prever mercado")
    return False


def bloquear_decisao_direcao():
    """
    Bloqueia qualquer tentativa de decidir CALL/PUT
    """
    logger.error("❌ BLOQUEIO: IA não pode decidir direção de trade")
    return False
