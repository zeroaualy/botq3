"""
IA Guard - Validador de Contexto e Risco Operacional

Responsável apenas pela validação de contexto operacional.
"""
import logging
import asyncio

logger = logging.getLogger(__name__)


class IAGuard:
    """
    Validador de Contexto e Risco Operacional
    
    FUNCIONALIDADE:
    - Validar contexto operacional (sempre ativo)
    """
    
    def __init__(self, gemini_client):
        self.gemini_client = gemini_client
        self._retry_attempts = 2
        self._retry_delay = 1.0
    
    async def _call_gemini_with_retry(self, prompt, temperature=0.1, max_tokens=10):
        """Chama Gemini API com retry automático"""
        for attempt in range(self._retry_attempts + 1):
            try:
                logger.debug(f"🔄 Chamando Gemini API (tentativa {attempt + 1}/{self._retry_attempts + 1})")
                
                response = self.gemini_client.chat.completions.create(
                    model="gemini-1.5-flash",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                
                logger.debug("✅ Resposta Gemini API recebida")
                return response.choices[0].message.content.strip()
            
            except Exception as e:
                error_msg = str(e)
                logger.error(f"❌ Erro na chamada Gemini (tentativa {attempt + 1}): {error_msg}")
                
                # Se erro 401, não retry
                if "401" in error_msg or "invalid" in error_msg.lower():
                    logger.error("🔴 Erro 401: API Key inválida - Não será feito retry")
                    raise
                
                # Se última tentativa, propagar erro
                if attempt == self._retry_attempts:
                    raise
                
                # Aguardar antes de retry
                await asyncio.sleep(self._retry_delay * (attempt + 1))
        
        raise Exception("Todas as tentativas falharam")
    
    async def validar_contexto(self, sinal, contexto_operacional=None):
        """
        Valida APENAS contexto operacional
        Esta função está sempre ativa (não depende de flags)
        
        Retorna: "EXECUTAR", "IGNORAR" ou "RISCO"
        """
        if not self.gemini_client:
            logger.warning("⚠️ IA indisponível, executando sem validação")
            return "EXECUTAR"
        
        try:
            prompt = self._criar_prompt_validacao(sinal, contexto_operacional)
            
            resposta = await self._call_gemini_with_retry(
                prompt,
                temperature=0.1,
                max_tokens=10
            )
            
            resposta = resposta.upper()
            
            # Extrair decisão
            if "EXECUTAR" in resposta:
                decisao = "EXECUTAR"
            elif "RISCO" in resposta:
                decisao = "RISCO"
            else:
                decisao = "IGNORAR"
            
            logger.info(f"🤖 IA Guard: {decisao}")
            return decisao
            
        except Exception as e:
            logger.error(f"❌ Erro na IA Guard: {e}")
            logger.warning("⚠️ Usando fallback: EXECUTAR (permitir operação)")
            return "EXECUTAR"  # Fallback: permite execução em caso de erro
    
    def _criar_prompt_validacao(self, sinal, contexto):
        """
        Cria prompt RESTRITO para validação de contexto
        Esta função não é afetada pelas flags
        """
        contexto_str = ""
        if contexto:
            if "ativo_aberto" in contexto:
                contexto_str += f"- Ativo aberto: {'Sim' if contexto['ativo_aberto'] else 'Não'}\n"
            if "atraso_execucao" in contexto:
                contexto_str += f"- Atraso de execução: {contexto['atraso_execucao']}s\n"
        
        prompt = f"""Você é um validador de CONTEXTO OPERACIONAL.

SINAL RECEBIDO:
- Par: {sinal['par']}
- Direção solicitada: {sinal['direcao']}
- Expiração: {sinal['tempo_expiracao']}s

CONTEXTO OPERACIONAL:
{contexto_str if contexto_str else "- Nenhum contexto adicional"}

TAREFA:
Avaliar APENAS se o contexto operacional permite execução segura.

NÃO analise tendência.
NÃO preveja mercado.
NÃO sugira estratégia.

RESPONDA APENAS UMA PALAVRA:
- EXECUTAR (se contexto operacional OK)
- IGNORAR (se condições ruins para operar)
- RISCO (se detectar problema grave)

Resposta:"""
        
        return prompt
    
    def desabilitado(self):
        """Verifica se IA Guard está desabilitada"""
        return self.gemini_client is None
