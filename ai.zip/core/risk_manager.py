"""
Risk Manager Adaptativo

OBJETIVO:
- Redução automática de valor após sequência de perdas
- Pausa automática após X perdas seguidas
- Ajuste de agressividade por horário
- Limite de operações simultâneas
- Bloqueio se volatilidade extrema detectada
"""
import logging
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple

logger = logging.getLogger(__name__)


class RiskManager:
    """
    Gerenciador de Risco Adaptativo
    
    Ajusta dinamicamente parâmetros de trading baseado em:
    - Sequência de perdas
    - Horário do dia
    - Volatilidade do mercado
    - Performance recente
    """
    
    def __init__(self, stats_optimizer):
        """
        Inicializa Risk Manager
        
        Args:
            stats_optimizer: Instância do otimizador estatístico
        """
        self.stats_optimizer = stats_optimizer
        self.config = {
            "valor_base": 10.0,  # Valor base para operações
            "max_perdas_pausa": 5,  # Máximo de perdas antes de pausar
            "reducao_por_perda": 0.2,  # 20% de redução por perda
            "min_valor_operacao": 2.0,  # Valor mínimo por operação
            "max_operacoes_simultaneas": 3,  # Máximo de ops paralelas
            "tempo_pausa_apos_perdas": 1800,  # 30 minutos de pausa
            "volatilidade_extrema": 2.5,  # Limite de volatilidade
        }
        
        # Estado
        self.pausado = False
        self.tempo_pausa_ate = None
        self.operacoes_ativas = 0
        self.valor_ajustado = self.config["valor_base"]
        
        logger.info("✅ Risk Manager inicializado")
    
    async def validar_operacao(
        self,
        sinal: Dict,
        contexto: Dict
    ) -> Tuple[bool, str, float]:
        """
        Valida se operação pode ser executada e retorna valor ajustado
        
        Args:
            sinal: Sinal a ser validado
            contexto: Contexto operacional
        
        Returns:
            Tuple[bool, str, float]: (pode_executar, motivo, valor_ajustado)
        """
        logger.info("🛡️ Risk Manager validando operação...")
        
        # ═══════════════════════════════════════════════════════════
        # 1. VERIFICAR SE ESTÁ PAUSADO
        # ═══════════════════════════════════════════════════════════
        if self.pausado:
            if self.tempo_pausa_ate and datetime.now() < self.tempo_pausa_ate:
                tempo_restante = (self.tempo_pausa_ate - datetime.now()).total_seconds()
                return False, f"Sistema pausado por perdas (aguardar {int(tempo_restante)}s)", 0
            else:
                self._reativar()
        
        # ═══════════════════════════════════════════════════════════
        # 2. VERIFICAR SEQUÊNCIA DE PERDAS
        # ═══════════════════════════════════════════════════════════
        perdas_consecutivas = self.stats_optimizer.obter_perdas_consecutivas()
        
        if perdas_consecutivas >= self.config["max_perdas_pausa"]:
            self._pausar_sistema()
            return False, f"PAUSA AUTOMÁTICA: {perdas_consecutivas} perdas consecutivas", 0
        
        # ═══════════════════════════════════════════════════════════
        # 3. VERIFICAR OPERAÇÕES SIMULTÂNEAS
        # ═══════════════════════════════════════════════════════════
        if self.operacoes_ativas >= self.config["max_operacoes_simultaneas"]:
            return False, f"Limite de operações simultâneas ({self.operacoes_ativas}/{self.config['max_operacoes_simultaneas']})", 0
        
        # ═══════════════════════════════════════════════════════════
        # 4. VERIFICAR VOLATILIDADE EXTREMA
        # ═══════════════════════════════════════════════════════════
        if "volatilidade" in contexto:
            if contexto["volatilidade"] >= self.config["volatilidade_extrema"]:
                return False, f"Volatilidade extrema detectada ({contexto['volatilidade']:.2f})", 0
        
        # ═══════════════════════════════════════════════════════════
        # 5. CALCULAR VALOR AJUSTADO
        # ═══════════════════════════════════════════════════════════
        valor_ajustado = self._calcular_valor_ajustado(perdas_consecutivas)
        
        # ═══════════════════════════════════════════════════════════
        # 6. VERIFICAR HORÁRIO (AJUSTE DE AGRESSIVIDADE)
        # ═══════════════════════════════════════════════════════════
        ajuste_horario = self._obter_ajuste_horario()
        valor_final = valor_ajustado * ajuste_horario
        
        # Garantir valor mínimo
        if valor_final < self.config["min_valor_operacao"]:
            valor_final = self.config["min_valor_operacao"]
        
        self.valor_ajustado = valor_final
        
        logger.info(f"✅ Risk Manager: Operação aprovada (valor: ${valor_final:.2f})")
        return True, "Aprovado pelo Risk Manager", valor_final
    
    def _calcular_valor_ajustado(self, perdas_consecutivas: int) -> float:
        """
        Calcula valor ajustado baseado em perdas consecutivas
        
        Args:
            perdas_consecutivas: Número de perdas seguidas
        
        Returns:
            float: Valor ajustado
        """
        if perdas_consecutivas == 0:
            return self.config["valor_base"]
        
        # Reduzir valor por cada perda consecutiva
        reducao_total = 1 - (perdas_consecutivas * self.config["reducao_por_perda"])
        reducao_total = max(reducao_total, 0.3)  # Mínimo 30% do valor base
        
        valor = self.config["valor_base"] * reducao_total
        
        logger.info(f"📉 Valor ajustado por perdas: ${valor:.2f} (perdas: {perdas_consecutivas})")
        return valor
    
    def _obter_ajuste_horario(self) -> float:
        """
        Retorna ajuste de agressividade baseado no horário
        
        Returns:
            float: Multiplicador de ajuste (0.5 a 1.0)
        """
        hora = datetime.now().hour
        
        # Horários de alta liquidez (mais agressivo)
        horarios_altos = [(8, 11), (13, 16), (19, 22)]
        
        for inicio, fim in horarios_altos:
            if inicio <= hora <= fim:
                return 1.0  # Agressividade normal
        
        # Horários de baixa liquidez (mais conservador)
        return 0.7
    
    def _pausar_sistema(self):
        """
        Pausa o sistema por segurança
        """
        self.pausado = True
        self.tempo_pausa_ate = datetime.now() + timedelta(
            seconds=self.config["tempo_pausa_apos_perdas"]
        )
        logger.warning(
            f"⏸️ Sistema PAUSADO até {self.tempo_pausa_ate.strftime('%H:%M:%S')}"
        )
    
    def _reativar(self):
        """
        Reativa o sistema após pausa
        """
        self.pausado = False
        self.tempo_pausa_ate = None
        self.valor_ajustado = self.config["valor_base"]
        logger.info("▶️ Sistema REATIVADO")
    
    def registrar_operacao_iniciada(self):
        """
        Registra que uma operação foi iniciada
        """
        self.operacoes_ativas += 1
        logger.info(f"📊 Operações ativas: {self.operacoes_ativas}")
    
    def registrar_operacao_finalizada(self):
        """
        Registra que uma operação foi finalizada
        """
        if self.operacoes_ativas > 0:
            self.operacoes_ativas -= 1
        logger.info(f"📊 Operações ativas: {self.operacoes_ativas}")
    
    def forcar_pausa(self, duracao_segundos: int = None):
        """
        Força pausa manual do sistema
        
        Args:
            duracao_segundos: Duração da pausa (None = usar padrão)
        """
        if duracao_segundos is None:
            duracao_segundos = self.config["tempo_pausa_apos_perdas"]
        
        self.pausado = True
        self.tempo_pausa_ate = datetime.now() + timedelta(seconds=duracao_segundos)
        logger.warning(f"⏸️ Pausa FORÇADA até {self.tempo_pausa_ate.strftime('%H:%M:%S')}")
    
    def forcar_retomada(self):
        """
        Força retomada manual do sistema
        """
        self._reativar()
        logger.info("▶️ Retomada FORÇADA pelo usuário")
    
    def obter_status(self) -> Dict:
        """
        Retorna status atual do Risk Manager
        
        Returns:
            Dict: Status completo
        """
        status = {
            "pausado": self.pausado,
            "tempo_pausa_ate": self.tempo_pausa_ate,
            "operacoes_ativas": self.operacoes_ativas,
            "valor_ajustado": self.valor_ajustado,
            "perdas_consecutivas": self.stats_optimizer.obter_perdas_consecutivas(),
        }
        
        if self.pausado and self.tempo_pausa_ate:
            tempo_restante = (self.tempo_pausa_ate - datetime.now()).total_seconds()
            status["tempo_restante_segundos"] = max(0, int(tempo_restante))
        
        return status
    
    def atualizar_config(self, novos_valores: Dict):
        """
        Atualiza configurações do Risk Manager
        
        Args:
            novos_valores: Dicionário com novos valores
        """
        self.config.update(novos_valores)
        logger.info(f"⚙️ Risk Manager config atualizada: {novos_valores}")
    
    def obter_config(self) -> Dict:
        """
        Retorna configuração atual
        
        Returns:
            Dict: Configuração atual
        """
        return self.config.copy()
