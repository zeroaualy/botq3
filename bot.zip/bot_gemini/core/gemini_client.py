"""
Cliente Gemini API
Wrapper simplificado para Google Generative AI
"""
import logging
import google.generativeai as genai

logger = logging.getLogger(__name__)


class GeminiClient:
    """Cliente para Google Gemini API"""
    
    def __init__(self, api_key: str):
        """
        Inicializa cliente Gemini
        
        Args:
            api_key: Chave de API do Google Gemini
        """
        self.api_key = api_key
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-pro')
        logger.info("✅ Cliente Gemini inicializado")
    
    class ChatCompletions:
        """Classe para compatibilidade com interface Groq"""
        
        def __init__(self, model):
            self.model = model
        
        def create(self, model, messages, temperature=0.7, max_tokens=None):
            """
            Cria completion compatível com interface Groq
            
            Args:
                model: Nome do modelo (ignorado, usa gemini-pro)
                messages: Lista de mensagens
                temperature: Temperatura de geração
                max_tokens: Máximo de tokens (ignorado no Gemini)
            
            Returns:
                Objeto com choices[0].message.content
            """
            # Extrair prompt da última mensagem do usuário
            prompt = ""
            for msg in messages:
                if msg["role"] == "user":
                    prompt = msg["content"]
            
            # Gerar resposta
            response = self.model.generate_content(
                prompt,
                generation_config=genai.types.GenerationConfig(
                    temperature=temperature,
                )
            )
            
            # Criar objeto de resposta compatível
            class Choice:
                def __init__(self, text):
                    self.message = type('obj', (object,), {'content': text})()
            
            class Response:
                def __init__(self, text):
                    self.choices = [Choice(text)]
            
            return Response(response.text)
    
    @property
    def chat(self):
        """Retorna objeto chat para compatibilidade"""
        class Chat:
            def __init__(self, model):
                self.completions = GeminiClient.ChatCompletions(model)
        
        return Chat(self.model)
