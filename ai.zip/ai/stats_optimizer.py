"""
Stats Optimizer - Otimizador Estatístico

OBJETIVO:
- Armazenar histórico detalhado das operações
- Calcular performance por ativo
- Calcular performance por horário
- Identificar melhores janelas operacionais
- Ajustar prioridade de ativos dinamicamente
"""
import logging
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from collections import defaultdict

logger = logging.getLogger(__name__)


class StatsOptimizer:
    """
    Otimizador Estatístico de Performance
    
    Armazena e analisa dados históricos para:
    - Melhorar decisões futuras
    - Identificar padrões de sucesso
    - Otimizar horários de operação
    - Priorizar ativos rentáveis
    """
    
    def __init__(self, arquivo_historico: str = "historico_operacoes.json"):
        """
        Inicializa Stats Optimizer
        
        Args:
            arquivo_historico: Caminho do arquivo de histórico
        """
        self.arquivo_historico = arquivo_historico
        self.historico: List[Dict] = []
        self.stats_cache = {
            "ativos": {},
            "horarios": {},
            "geral": {}
        }
        
        self._carregar_historico()
        self._atualizar_cache()
        
        logger.info(f"✅ Stats Optimizer inicializado ({len(self.historico)} operações)")
    
    def registrar_operacao(
        self,
        par: str,
        direcao: str,
        resultado: str,
        valor_operacao: float,
        valor_lucro: float,
        payout: float,
        score_q3: int = None,
        contexto: Dict = None
    ):
        """
        Registra uma operação no histórico
        
        Args:
            par: Par operado
            direcao: CALL ou PUT
            resultado: WIN, LOSS ou EMPATE
            valor_operacao: Valor investido
            valor_lucro: Lucro/prejuízo
            payout: Payout da operação
            score_q3: Score da Q3 IA Beta
            contexto: Contexto adicional
        """
        operacao = {
            "timestamp": datetime.now().isoformat(),
            "par": par,
            "direcao": direcao,
            "resultado": resultado,
            "valor_operacao": valor_operacao,
            "valor_lucro": valor_lucro,
            "payout": payout,
            "hora": datetime.now().hour,
            "dia_semana": datetime.now().weekday(),
            "score_q3": score_q3,
            "contexto": contexto or {}
        }
        
        self.historico.append(operacao)
        self._salvar_historico()
        self._atualizar_cache()
        
        logger.info(f"📝 Operação registrada: {par} {resultado}")
    
    def obter_stats_ativo(self, par: str) -> Optional[Dict]:
        """
        Retorna estatísticas de um ativo específico
        
        Args:
            par: Par a ser analisado
        
        Returns:
            Dict: Estatísticas do ativo ou None
        """
        if par in self.stats_cache["ativos"]:
            return self.stats_cache["ativos"][par]
        return None
    
    def obter_stats_horario(self, hora: int) -> Optional[Dict]:
        """
        Retorna estatísticas de um horário específico
        
        Args:
            hora: Hora a ser analisada (0-23)
        
        Returns:
            Dict: Estatísticas do horário ou None
        """
        if hora in self.stats_cache["horarios"]:
            return self.stats_cache["horarios"][hora]
        return None
    
    def obter_perdas_consecutivas(self) -> int:
        """
        Retorna número de perdas consecutivas atuais
        
        Returns:
            int: Número de perdas consecutivas
        """
        if not self.historico:
            return 0
        
        perdas = 0
        for op in reversed(self.historico):
            if op["resultado"] == "LOSS":
                perdas += 1
            else:
                break
        
        return perdas
    
    def obter_ultimas_operacoes(self, quantidade: int = 5) -> List[Dict]:
        """
        Retorna as últimas N operações
        
        Args:
            quantidade: Número de operações
        
        Returns:
            List[Dict]: Lista de operações
        """
        return self.historico[-quantidade:] if self.historico else []
    
    def obter_melhores_ativos(self, top: int = 5) -> List[Dict]:
        """
        Retorna os ativos com melhor performance
        
        Args:
            top: Número de ativos a retornar
        
        Returns:
            List[Dict]: Lista de ativos ordenados por winrate
        """
        ativos_stats = []
        
        for par, stats in self.stats_cache["ativos"].items():
            if stats["total_operacoes"] >= 10:  # Mínimo de operações
                ativos_stats.append({
                    "par": par,
                    "winrate": stats["winrate"],
                    "total_operacoes": stats["total_operacoes"],
                    "lucro_total": stats["lucro_total"]
                })
        
        # Ordenar por winrate
        ativos_stats.sort(key=lambda x: x["winrate"], reverse=True)
        return ativos_stats[:top]
    
    def obter_melhores_horarios(self, top: int = 5) -> List[Dict]:
        """
        Retorna os horários com melhor performance
        
        Args:
            top: Número de horários a retornar
        
        Returns:
            List[Dict]: Lista de horários ordenados por winrate
        """
        horarios_stats = []
        
        for hora, stats in self.stats_cache["horarios"].items():
            if stats["total_operacoes"] >= 5:  # Mínimo de operações
                horarios_stats.append({
                    "hora": hora,
                    "winrate": stats["winrate"],
                    "total_operacoes": stats["total_operacoes"],
                    "lucro_total": stats["lucro_total"]
                })
        
        # Ordenar por winrate
        horarios_stats.sort(key=lambda x: x["winrate"], reverse=True)
        return horarios_stats[:top]
    
    def obter_stats_gerais(self) -> Dict:
        """
        Retorna estatísticas gerais
        
        Returns:
            Dict: Estatísticas gerais
        """
        return self.stats_cache["geral"]
    
    def obter_relatorio_completo(self) -> Dict:
        """
        Gera relatório completo de performance
        
        Returns:
            Dict: Relatório completo
        """
        return {
            "geral": self.stats_cache["geral"],
            "melhores_ativos": self.obter_melhores_ativos(5),
            "piores_ativos": self.obter_piores_ativos(5),
            "melhores_horarios": self.obter_melhores_horarios(5),
            "piores_horarios": self.obter_piores_horarios(5),
            "ultimas_operacoes": self.obter_ultimas_operacoes(10),
            "perdas_consecutivas": self.obter_perdas_consecutivas()
        }
    
    def obter_piores_ativos(self, top: int = 5) -> List[Dict]:
        """
        Retorna os ativos com pior performance
        
        Args:
            top: Número de ativos a retornar
        
        Returns:
            List[Dict]: Lista de ativos ordenados por winrate (crescente)
        """
        ativos_stats = []
        
        for par, stats in self.stats_cache["ativos"].items():
            if stats["total_operacoes"] >= 10:
                ativos_stats.append({
                    "par": par,
                    "winrate": stats["winrate"],
                    "total_operacoes": stats["total_operacoes"],
                    "lucro_total": stats["lucro_total"]
                })
        
        ativos_stats.sort(key=lambda x: x["winrate"])
        return ativos_stats[:top]
    
    def obter_piores_horarios(self, top: int = 5) -> List[Dict]:
        """
        Retorna os horários com pior performance
        
        Args:
            top: Número de horários a retornar
        
        Returns:
            List[Dict]: Lista de horários ordenados por winrate (crescente)
        """
        horarios_stats = []
        
        for hora, stats in self.stats_cache["horarios"].items():
            if stats["total_operacoes"] >= 5:
                horarios_stats.append({
                    "hora": hora,
                    "winrate": stats["winrate"],
                    "total_operacoes": stats["total_operacoes"],
                    "lucro_total": stats["lucro_total"]
                })
        
        horarios_stats.sort(key=lambda x: x["winrate"])
        return horarios_stats[:top]
    
    def limpar_historico_antigo(self, dias: int = 30):
        """
        Remove operações mais antigas que X dias
        
        Args:
            dias: Número de dias a manter
        """
        limite = datetime.now() - timedelta(days=dias)
        
        historico_novo = [
            op for op in self.historico
            if datetime.fromisoformat(op["timestamp"]) > limite
        ]
        
        removidos = len(self.historico) - len(historico_novo)
        self.historico = historico_novo
        
        self._salvar_historico()
        self._atualizar_cache()
        
        logger.info(f"🗑️ {removidos} operações antigas removidas (>{dias} dias)")
    
    def _carregar_historico(self):
        """
        Carrega histórico do arquivo JSON
        """
        if os.path.exists(self.arquivo_historico):
            try:
                with open(self.arquivo_historico, 'r') as f:
                    self.historico = json.load(f)
                logger.info(f"📂 Histórico carregado: {len(self.historico)} operações")
            except Exception as e:
                logger.error(f"❌ Erro ao carregar histórico: {e}")
                self.historico = []
        else:
            logger.info("📂 Novo histórico criado")
            self.historico = []
    
    def _salvar_historico(self):
        """
        Salva histórico no arquivo JSON
        """
        try:
            with open(self.arquivo_historico, 'w') as f:
                json.dump(self.historico, f, indent=2)
        except Exception as e:
            logger.error(f"❌ Erro ao salvar histórico: {e}")
    
    def _atualizar_cache(self):
        """
        Atualiza cache de estatísticas
        """
        # Resetar cache
        self.stats_cache = {
            "ativos": defaultdict(lambda: {
                "total_operacoes": 0,
                "wins": 0,
                "losses": 0,
                "empates": 0,
                "lucro_total": 0.0,
                "winrate": 0.0
            }),
            "horarios": defaultdict(lambda: {
                "total_operacoes": 0,
                "wins": 0,
                "losses": 0,
                "empates": 0,
                "lucro_total": 0.0,
                "winrate": 0.0
            }),
            "geral": {
                "total_operacoes": 0,
                "wins": 0,
                "losses": 0,
                "empates": 0,
                "lucro_total": 0.0,
                "winrate": 0.0
            }
        }
        
        # Processar histórico
        for op in self.historico:
            # Stats por ativo
            par = op["par"]
            self.stats_cache["ativos"][par]["total_operacoes"] += 1
            if op["resultado"] == "WIN":
                self.stats_cache["ativos"][par]["wins"] += 1
            elif op["resultado"] == "LOSS":
                self.stats_cache["ativos"][par]["losses"] += 1
            else:
                self.stats_cache["ativos"][par]["empates"] += 1
            self.stats_cache["ativos"][par]["lucro_total"] += op["valor_lucro"]
            
            # Stats por horário
            hora = op["hora"]
            self.stats_cache["horarios"][hora]["total_operacoes"] += 1
            if op["resultado"] == "WIN":
                self.stats_cache["horarios"][hora]["wins"] += 1
            elif op["resultado"] == "LOSS":
                self.stats_cache["horarios"][hora]["losses"] += 1
            else:
                self.stats_cache["horarios"][hora]["empates"] += 1
            self.stats_cache["horarios"][hora]["lucro_total"] += op["valor_lucro"]
            
            # Stats gerais
            self.stats_cache["geral"]["total_operacoes"] += 1
            if op["resultado"] == "WIN":
                self.stats_cache["geral"]["wins"] += 1
            elif op["resultado"] == "LOSS":
                self.stats_cache["geral"]["losses"] += 1
            else:
                self.stats_cache["geral"]["empates"] += 1
            self.stats_cache["geral"]["lucro_total"] += op["valor_lucro"]
        
        # Calcular winrates
        for par, stats in self.stats_cache["ativos"].items():
            if stats["total_operacoes"] > 0:
                stats["winrate"] = (stats["wins"] / stats["total_operacoes"]) * 100
        
        for hora, stats in self.stats_cache["horarios"].items():
            if stats["total_operacoes"] > 0:
                stats["winrate"] = (stats["wins"] / stats["total_operacoes"]) * 100
        
        if self.stats_cache["geral"]["total_operacoes"] > 0:
            total = self.stats_cache["geral"]["total_operacoes"]
            self.stats_cache["geral"]["winrate"] = (
                self.stats_cache["geral"]["wins"] / total
            ) * 100
