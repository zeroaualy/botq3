"""
Monte Carlo Simulation Engine
Estimates worst-case drawdown and risk of ruin
"""
import logging
from typing import Dict, List
import numpy as np

logger = logging.getLogger(__name__)


class MonteCarloEngine:
    """
    Monte Carlo simulation for risk estimation
    
    Features:
    - Worst-case drawdown estimation
    - Risk of ruin calculation
    - Expected variance
    """
    
    def __init__(self, num_simulations: int = 10000):
        self.num_simulations = num_simulations
    
    def simulate(self, trade_history: List[Dict], num_future_trades: int = 100) -> Dict:
        """
        Run Monte Carlo simulation on trade history
        
        Args:
            trade_history: List of past trades with PNL
            num_future_trades: Number of future trades to simulate
            
        Returns:
            Dict with simulation results
        """
        try:
            if not trade_history or len(trade_history) < 20:
                return {
                    "status": "INSUFFICIENT_DATA",
                    "trades_needed": 20 - len(trade_history) if trade_history else 20,
                    "worst_drawdown": 0,
                    "risk_of_ruin": 0,
                    "details": "Need at least 20 trades for simulation"
                }
            
            # Extract PNL values
            pnl_values = [t.get("pnl", 0) for t in trade_history]
            
            # Run simulations
            max_drawdowns = []
            final_balances = []
            
            for _ in range(self.num_simulations):
                sequence = np.random.choice(pnl_values, num_future_trades, replace=True)
                
                # Calculate drawdown for this sequence
                cumsum = np.cumsum(sequence)
                running_max = np.maximum.accumulate(cumsum)
                drawdown = running_max - cumsum
                max_dd = np.max(drawdown)
                
                max_drawdowns.append(max_dd)
                final_balances.append(cumsum[-1])
            
            # Calculate statistics
            worst_drawdown = np.percentile(max_drawdowns, 95)  # 95th percentile
            avg_drawdown = np.mean(max_drawdowns)
            
            # Risk of ruin (% of simulations ending negative)
            ruin_count = sum(1 for b in final_balances if b < 0)
            risk_of_ruin = (ruin_count / self.num_simulations) * 100
            
            # Expected variance
            variance = np.var(final_balances)
            
            return {
                "status": "SUCCESS",
                "worst_drawdown": round(worst_drawdown, 2),
                "avg_drawdown": round(avg_drawdown, 2),
                "risk_of_ruin": round(risk_of_ruin, 2),
                "expected_variance": round(variance, 2),
                "simulations": self.num_simulations,
                "trades_simulated": num_future_trades,
                "details": f"95th percentile drawdown: ${worst_drawdown:.2f}"
            }
            
        except Exception as e:
            logger.error(f"Error in Monte Carlo simulation: {e}")
            return {
                "status": "ERROR",
                "details": str(e)
            }
    
    def get_recommended_risk_adjustment(self, simulation_result: Dict) -> Dict:
        """
        Recommend risk adjustment based on simulation
        
        Returns:
            Dict with risk recommendations
        """
        if simulation_result.get("status") != "SUCCESS":
            return {"action": "MAINTAIN", "modifier": 1.0}
        
        worst_dd = simulation_result.get("worst_drawdown", 0)
        risk_of_ruin = simulation_result.get("risk_of_ruin", 0)
        
        # High risk scenario
        if worst_dd > 100 or risk_of_ruin > 10:
            return {
                "action": "REDUCE",
                "modifier": 0.6,
                "reason": f"High risk: DD=${worst_dd:.2f}, RoR={risk_of_ruin:.1f}%"
            }
        
        # Moderate risk
        elif worst_dd > 50 or risk_of_ruin > 5:
            return {
                "action": "REDUCE",
                "modifier": 0.8,
                "reason": f"Moderate risk: DD=${worst_dd:.2f}, RoR={risk_of_ruin:.1f}%"
            }
        
        # Low risk - can be more aggressive
        else:
            return {
                "action": "MAINTAIN",
                "modifier": 1.0,
                "reason": "Risk levels acceptable"
            }
