"""
Capital Intelligence Engine
Dynamic lot sizing based on multiple factors
"""
import logging
from typing import Dict
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class CapitalEngine:
    """
    Dynamic capital management system
    
    Features:
    - Confidence-based sizing
    - Drawdown protection
    - Consecutive loss reduction
    - Expectancy-based adjustment
    - Hard daily stop
    """
    
    def __init__(self, base_amount: float = 10.0):
        self.base_amount = base_amount
        self.daily_loss = 0.0
        self.daily_reset_time = None
        self.max_daily_loss = base_amount * 5  # Max 5x base per day
        self.consecutive_losses = 0
    
    def calculate_position_size(
        self,
        confidence_level: str,
        score: int,
        current_drawdown: float,
        expectancy: float = None
    ) -> Dict:
        """
        Calculate optimal position size
        
        Args:
            confidence_level: "HIGH" | "MEDIUM" | "LOW"
            score: Total confluence score (0-100)
            current_drawdown: Current session drawdown %
            expectancy: Asset expectancy (optional)
            
        Returns:
            Dict with position size and modifiers
        """
        try:
            # Reset daily tracking if needed
            self._check_daily_reset()
            
            # Check daily stop
            if abs(self.daily_loss) >= self.max_daily_loss:
                return {
                    "position_size": 0,
                    "approved": False,
                    "reason": "Daily loss limit reached",
                    "modifiers": {}
                }
            
            # Start with base amount
            size = self.base_amount
            modifiers = {}
            
            # 1. Confidence modifier
            conf_mod = self._get_confidence_modifier(confidence_level, score)
            size *= conf_mod
            modifiers["confidence"] = conf_mod
            
            # 2. Drawdown modifier
            dd_mod = self._get_drawdown_modifier(current_drawdown)
            size *= dd_mod
            modifiers["drawdown"] = dd_mod
            
            # 3. Consecutive loss modifier
            loss_mod = self._get_consecutive_loss_modifier()
            size *= loss_mod
            modifiers["consecutive_losses"] = loss_mod
            
            # 4. Expectancy modifier (if available)
            if expectancy is not None:
                exp_mod = self._get_expectancy_modifier(expectancy)
                size *= exp_mod
                modifiers["expectancy"] = exp_mod
            
            # Floor at minimum
            size = max(2.0, size)
            
            return {
                "position_size": round(size, 2),
                "approved": True,
                "reason": "Position sized calculated",
                "modifiers": modifiers,
                "base_amount": self.base_amount
            }
            
        except Exception as e:
            logger.error(f"Error calculating position size: {e}")
            return {
                "position_size": self.base_amount,
                "approved": True,
                "reason": "Default sizing (error)",
                "modifiers": {}
            }
    
    def record_result(self, result: str, pnl: float):
        """Record trade result for tracking"""
        self.daily_loss += pnl
        
        if result == "LOSS":
            self.consecutive_losses += 1
        else:
            self.consecutive_losses = 0
    
    def _get_confidence_modifier(self, confidence: str, score: int) -> float:
        """Get multiplier based on confidence"""
        if confidence == "HIGH" and score >= 85:
            return 1.3
        elif confidence == "HIGH":
            return 1.2
        elif confidence == "MEDIUM":
            return 1.0
        else:
            return 0.7
    
    def _get_drawdown_modifier(self, drawdown: float) -> float:
        """Reduce size during drawdown"""
        if drawdown < 5:
            return 1.0
        elif drawdown < 10:
            return 0.8
        elif drawdown < 15:
            return 0.6
        else:
            return 0.4
    
    def _get_consecutive_loss_modifier(self) -> float:
        """Reduce size after consecutive losses"""
        if self.consecutive_losses == 0:
            return 1.0
        elif self.consecutive_losses == 1:
            return 0.9
        elif self.consecutive_losses == 2:
            return 0.7
        elif self.consecutive_losses >= 3:
            return 0.5
        return 1.0
    
    def _get_expectancy_modifier(self, expectancy: float) -> float:
        """Adjust based on expectancy"""
        if expectancy > 2.0:
            return 1.2
        elif expectancy > 0.5:
            return 1.0
        elif expectancy > -0.5:
            return 0.8
        else:
            return 0.6
    
    def _check_daily_reset(self):
        """Reset daily tracking at start of new day"""
        now = datetime.now(TZ)
        
        if self.daily_reset_time is None:
            self.daily_reset_time = now
            return
        
        # Reset if it's a new day
        if now.date() > self.daily_reset_time.date():
            self.daily_loss = 0.0
            self.consecutive_losses = 0
            self.daily_reset_time = now
            logger.info("📅 Daily capital tracking reset")
