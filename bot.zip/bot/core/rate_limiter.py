"""
Rate Limiter - Q3 IA Beta
Controle de taxa de operações para evitar sobrecarga
"""
import asyncio
import logging
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
from collections import deque

logger = logging.getLogger(__name__)


class RateLimiter:
    """
    Rate Limiter com janela deslizante
    
    Características:
    - Janela deslizante para controle preciso
    - Suporte a múltiplos limitadores nomeados
    - Backoff exponencial opcional
    - Métricas de uso
    """
    
    def __init__(self, max_calls: int, time_window: float, name: str = "default"):
        """
        Inicializa o rate limiter
        
        Args:
            max_calls: Número máximo de chamadas permitidas
            time_window: Janela de tempo em segundos
            name: Nome do limitador
        """
        self.name = name
        self.max_calls = max_calls
        self.time_window = time_window
        
        # Histórico de chamadas (janela deslizante)
        self._calls: deque[datetime] = deque()
        
        # Métricas
        self._total_calls = 0
        self._total_blocked = 0
        self._total_waited = 0
        
        logger.info(
            f"✅ Rate Limiter '{name}' inicializado "
            f"(max_calls={max_calls}, window={time_window}s)"
        )
    
    async def acquire(self, wait: bool = True) -> bool:
        """
        Tenta adquirir permissão para executar
        
        Args:
            wait: Se True, aguarda até ter permissão; Se False, retorna imediatamente
        
        Returns:
            True se pode executar, False se bloqueado (apenas quando wait=False)
        """
        self._total_calls += 1
        
        while True:
            # Limpar chamadas antigas
            self._cleanup_old_calls()
            
            # Verificar se pode executar
            if len(self._calls) < self.max_calls:
                # Pode executar - registrar chamada
                self._calls.append(datetime.now())
                return True
            
            # Limite atingido
            if not wait:
                self._total_blocked += 1
                return False
            
            # Calcular quanto tempo esperar
            oldest_call = self._calls[0]
            wait_until = oldest_call + timedelta(seconds=self.time_window)
            wait_seconds = (wait_until - datetime.now()).total_seconds()
            
            if wait_seconds > 0:
                logger.debug(
                    f"⏳ Rate Limiter '{self.name}': Aguardando {wait_seconds:.2f}s"
                )
                self._total_waited += 1
                await asyncio.sleep(wait_seconds)
            
            # Tentar novamente
            self._cleanup_old_calls()
    
    def _cleanup_old_calls(self) -> None:
        """Remove chamadas antigas da janela"""
        cutoff = datetime.now() - timedelta(seconds=self.time_window)
        
        while self._calls and self._calls[0] < cutoff:
            self._calls.popleft()
    
    def can_proceed(self) -> bool:
        """
        Verifica se pode proceder sem bloquear
        
        Returns:
            True se pode executar imediatamente
        """
        self._cleanup_old_calls()
        return len(self._calls) < self.max_calls
    
    def get_remaining_calls(self) -> int:
        """
        Retorna o número de chamadas restantes na janela atual
        
        Returns:
            Número de chamadas disponíveis
        """
        self._cleanup_old_calls()
        return max(0, self.max_calls - len(self._calls))
    
    def get_reset_time(self) -> Optional[datetime]:
        """
        Retorna quando o limitador será resetado
        
        Returns:
            Datetime do próximo reset ou None se não há chamadas
        """
        if not self._calls:
            return None
        
        oldest_call = self._calls[0]
        return oldest_call + timedelta(seconds=self.time_window)
    
    def reset(self) -> None:
        """Reseta o limitador"""
        self._calls.clear()
        logger.info(f"🔄 Rate Limiter '{self.name}' resetado")
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas do limitador
        
        Returns:
            Dicionário com métricas
        """
        self._cleanup_old_calls()
        
        blocked_rate = (
            (self._total_blocked / self._total_calls * 100)
            if self._total_calls > 0 else 0
        )
        
        return {
            'name': self.name,
            'max_calls': self.max_calls,
            'time_window': self.time_window,
            'current_calls': len(self._calls),
            'remaining_calls': self.get_remaining_calls(),
            'can_proceed': self.can_proceed(),
            'total_calls': self._total_calls,
            'total_blocked': self._total_blocked,
            'total_waited': self._total_waited,
            'blocked_rate': blocked_rate,
            'reset_at': self.get_reset_time().isoformat() if self.get_reset_time() else None
        }
    
    def __repr__(self) -> str:
        """Representação string do limitador"""
        return (
            f"RateLimiter('{self.name}', "
            f"{len(self._calls)}/{self.max_calls})"
        )


class RateLimiterManager:
    """Gerenciador de múltiplos Rate Limiters"""
    
    def __init__(self):
        """Inicializa o gerenciador"""
        self._limiters: Dict[str, RateLimiter] = {}
        logger.info("✅ Rate Limiter Manager inicializado")
    
    def get_or_create(self, name: str, max_calls: int, 
                     time_window: float) -> RateLimiter:
        """
        Obtém ou cria um Rate Limiter
        
        Args:
            name: Nome do limitador
            max_calls: Número máximo de chamadas
            time_window: Janela de tempo em segundos
        
        Returns:
            Instância do RateLimiter
        """
        if name not in self._limiters:
            self._limiters[name] = RateLimiter(max_calls, time_window, name)
        
        return self._limiters[name]
    
    def get(self, name: str) -> Optional[RateLimiter]:
        """
        Obtém um Rate Limiter existente
        
        Args:
            name: Nome do limitador
        
        Returns:
            Instância ou None se não existir
        """
        return self._limiters.get(name)
    
    def reset_all(self) -> None:
        """Reseta todos os Rate Limiters"""
        for limiter in self._limiters.values():
            limiter.reset()
        logger.info("🔄 Todos os Rate Limiters resetados")
    
    def get_all_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas de todos os Rate Limiters
        
        Returns:
            Dicionário com métricas
        """
        return {
            name: limiter.get_metrics()
            for name, limiter in self._limiters.items()
        }
    
    def __len__(self) -> int:
        """Retorna o número de Rate Limiters"""
        return len(self._limiters)


# Instância global do gerenciador
_manager_instance: Optional[RateLimiterManager] = None


def get_rate_limiter_manager() -> RateLimiterManager:
    """
    Retorna a instância global do gerenciador (singleton)
    
    Returns:
        Instância do RateLimiterManager
    """
    global _manager_instance
    
    if _manager_instance is None:
        _manager_instance = RateLimiterManager()
    
    return _manager_instance
