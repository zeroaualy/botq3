"""
Estado de runtime do bot
Variáveis mutáveis durante execução
"""

# Lista de sinais agendados
sinais_agendados = []

# Flag de captura de sinais
captura_sinais_ativa = False

# Instância da conexão IQ Option (será preenchida em runtime)
iq_connection = None

# Cliente IA (será preenchido em runtime)
gemini_client = None

# ======================================
# AUTO TRADER
# Controle do modo de trading automatizado
# ======================================

# Instância do AutoTrader (será preenchida em runtime)
auto_trader = None

# Flag do modo automático
modo_automatico_ativo = False

# ======================================
# AUTOMAÇÃO DE SINAIS
# Motor interno de geração inteligente
# ======================================

# Instância do SignalEngine (será preenchida em runtime)
signal_engine = None

# Instância do Enhanced Signal Engine (será preenchida em runtime)
enhanced_signal_engine = None

# Flag da automação de sinais
automacao_sinais_ativa = False

# Instância do AutoSignalGenerator (será preenchida em runtime)
auto_signal_generator = None

# ======================================
# ESTADO DE EDIÇÃO DE VALORES
# Controla quando usuário está editando valores
# ======================================

# Armazena qual valor está sendo editado por usuário
# Formato: {user_id: "valor_entrada" | "stop_loss" | "stop_gain" | None}
editing_state = {}


def adicionar_sinal(sinal):
    """Adiciona sinal à fila de agendamento"""
    sinais_agendados.append(sinal)


def remover_sinal(sinal):
    """Remove sinal da fila"""
    if sinal in sinais_agendados:
        sinais_agendados.remove(sinal)


def limpar_sinais():
    """Limpa todos os sinais agendados"""
    sinais_agendados.clear()


def obter_sinais_pendentes():
    """Retorna lista de sinais agendados"""
    return sinais_agendados.copy()


def quantidade_sinais():
    """Retorna quantidade de sinais agendados"""
    return len(sinais_agendados)
