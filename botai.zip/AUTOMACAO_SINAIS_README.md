# 🧠 AUTOMAÇÃO DE SINAIS - Q3 IA Beta

## 📋 VISÃO GERAL

A **Automação de Sinais** é um motor interno inteligente que analisa o mercado em tempo real e gera sinais de trading baseados em análise estatística.

### ✨ Características

- ✅ **Análise em Tempo Real**: Monitora múltiplos ativos simultaneamente
- ✅ **Análise Estatística**: Combina tendência, momentum e volume
- ✅ **Filtros de Qualidade**: Apenas sinais com confiança ≥ 65%
- ✅ **Integração Total**: Funciona em conjunto com IA Guard e Risk Manager
- ✅ **Segurança PRACTICE**: Opera APENAS em conta de treinamento
- ✅ **Controle via Telegram**: Ative/desative com um clique

---

## 🔄 COMO FUNCIONA

### Fluxo de Execução

```
Motor de Automação
        ↓
Análise Estatística (Tendência + Momentum + Volume)
        ↓
Filtro de Confiança (mín. 65%)
        ↓
Geração de Sinal Interno
        ↓
Parser Interno
        ↓
Scheduler (Agendamento)
        ↓
IA Guard (se ativado)
        ↓
Verificação PRACTICE
        ↓
Trade Executor
```

### Análise Realizada

O motor analisa cada ativo considerando:

1. **Tendência** (35% do score)
   - Analisa últimas 20 velas
   - Identifica direção dominante (CALL/PUT)
   
2. **Momentum** (35% do score)
   - Compara últimas 5 velas com anteriores
   - Detecta aceleração/desaceleração
   
3. **Volume** (15% do score)
   - Analisa volume relativo
   - Identifica confirmação de movimento
   
4. **Winrate por Horário** (15% do score)
   - Considera histórico estatístico
   - Ajusta score por performance temporal

---

## 🎮 COMO USAR

### Pré-requisitos

Antes de ativar a Automação de Sinais, certifique-se que:

1. ✅ **IQ Option está conectado**
2. ✅ **Modo Automático está ATIVO**
3. ✅ **Conta está em PRACTICE**

### Passo a Passo

1. **Abra o bot no Telegram**
   ```
   /start
   ```

2. **Ative o Modo Automático**
   - Clique em: `🔄 Automático: ⚪ PAUSADO`
   - Confirme que está ATIVO (🟢)

3. **Ative a Automação de Sinais**
   - Clique em: `🧠 Automação de Sinais: ⚪ DESATIVADO`
   - Confirme a ativação

4. **Monitore os Sinais**
   - O bot começará a analisar o mercado
   - Sinais serão gerados e executados automaticamente
   - Você receberá notificações de cada operação

### Para Desativar

- Clique novamente em: `🧠 Automação de Sinais: 🟢 ATIVADO`
- O motor pausará imediatamente
- Sinais manuais continuam funcionando normalmente

---

## ⚙️ CONFIGURAÇÕES

As configurações padrão da Automação de Sinais são:

| Parâmetro | Valor Padrão | Descrição |
|-----------|--------------|-----------|
| **Confiança Mínima** | 65% | Score mínimo para gerar sinal |
| **Intervalo de Análise** | 30 segundos | Tempo entre análises |
| **Máx. Sinais/Hora** | 10 | Limite de sinais por hora |

Estas configurações podem ser ajustadas em `state/config.py`:

```python
"automacao_confianca_minima": 65,
"automacao_intervalo_analise": 30,
"automacao_max_sinais_hora": 10,
```

---

## 🛡️ PROTEÇÕES ATIVAS

A Automação de Sinais **RESPEITA** todas as proteções existentes:

### ✅ IA Guard
- Valida contexto operacional
- Pode bloquear sinais em condições desfavoráveis

### ✅ Risk Manager
- Controla exposição de risco
- Monitora drawdown
- Aplica stop loss e stop gain

### ✅ PRACTICE Obrigatório
- **NUNCA** opera em conta real
- Verifica conta a cada operação
- Pausa automaticamente se detectar conta real

### ✅ Limites de Segurança
- Máximo de sinais por hora
- Confiança mínima obrigatória
- Análise contínua de mercado

---

## 📊 ESTATÍSTICAS

Para visualizar estatísticas da Automação:

```python
# No código
from state import runtime

stats = runtime.signal_engine.obter_estatisticas()
print(stats)
```

Retorna:
```python
{
    "ativo": True/False,
    "sinais_ultima_hora": 5,
    "confianca_minima": 65,
    "intervalo_analise": 30,
    "max_sinais_hora": 10
}
```

---

## ⚠️ IMPORTANTE

### O que a Automação FAZ

✅ Analisa dados reais da API IQ Option
✅ Identifica padrões estatísticos
✅ Gera sinais com base em probabilidade
✅ Executa através do fluxo normal do bot
✅ Respeita TODAS as proteções

### O que a Automação NÃO FAZ

❌ **NÃO** prevê o mercado com certeza
❌ **NÃO** garante lucros
❌ **NÃO** ignora proteções de segurança
❌ **NÃO** opera fora de PRACTICE
❌ **NÃO** substitui análise profissional

---

## 🔍 LOGS

Quando a Automação está ativa, você verá logs como:

```
INFO - 🧠 Automação de Sinais ATIVADA
INFO - 🔄 Iniciando loop do Motor de Automação...
INFO - 📡 Sinal interno gerado: EURUSD CALL (72% confiança)
INFO - 🚀 Enviado para modo Automático: EURUSD CALL às 14:32:15
INFO - ⛔ Automação de Sinais DESATIVADA
```

---

## 🆘 SOLUÇÃO DE PROBLEMAS

### "AutoTrader não inicializado"
- **Causa**: Sistema não foi iniciado corretamente
- **Solução**: Reinicie o bot com `/start`

### "IQ Option não conectado"
- **Causa**: Conexão com IQ perdida
- **Solução**: Verifique credenciais e conexão

### "Modo Automático precisa estar ATIVO"
- **Causa**: Tentou ativar Automação sem Modo Automático
- **Solução**: Ative primeiro o Modo Automático (🔄)

### "Limite de sinais/hora atingido"
- **Causa**: Sistema gerou 10 sinais na última hora
- **Solução**: Aguarde ou ajuste `max_sinais_hora` no config

---

## 🔧 DESENVOLVIMENTO

### Arquitetura

A Automação de Sinais foi implementada de forma **modular**:

```
/core/signal_engine.py       → Motor principal
/state/runtime.py            → Estado (signal_engine, automacao_sinais_ativa)
/state/config.py             → Configurações
/bot/telegram_bot.py         → Interface Telegram
/main.py                     → Inicialização
```

### Compatibilidade

✅ Python 3.10+
✅ Asyncio
✅ API IQ Option (myiq)
✅ Telegram Bot API

---

## 📝 CHANGELOG

### v1.0.0 - Lançamento Inicial
- ✅ Motor de análise estatística
- ✅ Geração automática de sinais
- ✅ Integração com Modo Automático
- ✅ Interface Telegram
- ✅ Proteções de segurança
- ✅ Logs estruturados

---

## 👨‍💻 SUPORTE

Para dúvidas ou problemas:

1. Verifique os logs do sistema
2. Consulte esta documentação
3. Teste em conta PRACTICE primeiro
4. Use o botão de feedback no Telegram

---

## ⚖️ DISCLAIMER

**AVISO IMPORTANTE**: 

Este sistema é uma ferramenta de **análise técnica automatizada** que:
- Utiliza dados históricos e em tempo real
- Aplica análise estatística
- **NÃO garante resultados**
- **NÃO substitui conhecimento profissional**

Trading envolve risco. Use apenas capital que você pode perder.
Sempre opere primeiro em conta PRACTICE.

---

## 📜 LICENÇA

Parte integrante do Bot Q3 IA Beta v3.0
Todos os direitos reservados.
