# Bot Q3 VIP Beta - Enhanced Professional Trading System

## Overview

The Enhanced Professional Trading System transforms the Bot Q3 VIP Beta into a sophisticated, adaptive trading platform while preserving 100% of the original architecture.

## Architecture

### Core Principles
- **Manual Priority**: Manual signals ALWAYS have priority
- **Non-Destructive**: All original systems remain intact and functional
- **Gemini Secondary**: Gemini acts ONLY as probabilistic confirmation, never overrides scoring
- **Adaptive Intelligence**: System learns and adapts from performance

### System Components

#### 1. Analysis Engines (`/analysis/`)

**Trend Engine** (`trend_engine.py`)
- EMA 9, 21, 50 alignment analysis
- Trend strength measurement
- Directional confirmation

**Structure Engine** (`structure_engine.py`)
- Higher Highs / Higher Lows detection
- Lower Highs / Lower Lows detection
- Break of Structure (BOS) identification

**Pattern Engine** (`pattern_engine.py`)
- Bullish/Bearish Engulfing patterns
- Inside Bar detection
- False breakout identification (liquidity sweeps)

**Liquidity Engine** (`liquidity_engine.py`)
- Support/Resistance level detection
- Liquidity sweep approximation
- Stop hunt identification

**Volatility Engine** (`volatility_engine.py`)
- ATR (Average True Range) calculation
- Volatility state classification
- Market condition assessment

**Filters Engine** (`filters_engine.py`)
- OTC session detection
- Time-based filters
- Session quality assessment
- Low liquidity filtering

**Scoring Engine** (`scoring_engine.py`)
- Weighted confluence scoring
- Confidence level classification
- Adaptive threshold management
- Direction determination via majority vote

**Regime Engine** (`regime_engine.py`)
- Market regime classification:
  - TRENDING: Clear directional movement
  - RANGING: Sideways consolidation  
  - HIGH_VOLATILITY: Erratic price action
  - MANIPULATIVE: Fake moves and sweeps
  - DEAD: Extremely low activity
- Automatic parameter adjustment per regime

**Expectancy Engine** (`expectancy_engine.py`)
- Tracks expectancy by:
  - Asset
  - Score range
  - Trading session
  - Strategy type
- Automatic asset filtering (negative expectancy)
- Performance-based adaptation

**Capital Engine** (`capital_engine.py`)
- Dynamic position sizing based on:
  - Confidence level
  - Current drawdown
  - Consecutive losses
  - Asset expectancy
- Hard daily stop loss
- Progressive risk reduction

**Monte Carlo Engine** (`monte_carlo_engine.py`)
- 10,000 sequence simulations
- Worst-case drawdown estimation (95th percentile)
- Risk of ruin calculation
- Expected variance analysis
- Risk adjustment recommendations

**Shadow Engine** (`shadow_engine.py`)
- Parallel simulation with alternative thresholds
- Performance comparison vs live
- Non-intrusive testing
- Strategy optimization recommendations

**Watchdog Engine** (`watchdog_engine.py`)
- System health monitoring:
  - MyIQ connectivity
  - Gemini API failures
  - Loop health checks
  - Error rate tracking
- Auto-recovery protocols
- Critical alert system

**Telemetry Engine** (`telemetry_engine.py`)
- Structured JSON logging
- Event tracking:
  - Signal generation
  - Gemini responses
  - Trade execution
  - Risk state changes
  - Regime transitions
  - Expectancy updates
  - Capital adjustments

#### 2. Enhanced Signal Engine (`core/signal_engine_enhanced.py`)

The master orchestrator that:
- Coordinates all analysis engines
- Implements comprehensive market analysis workflow
- Manages signal generation with confluence requirements
- Integrates with existing queue system
- Implements cooldown mechanism (5 minutes per asset)
- Respects hourly trade limits
- Logs all events via telemetry

### Workflow

```
1. Market Scan (every 30 seconds)
   ↓
2. Asset Selection (from configured list)
   ↓
3. Cooldown Check (per asset)
   ↓
4. Data Fetching (100 candles via MyIQ)
   ↓
5. Regime Detection
   ↓
6. Comprehensive Technical Analysis
   ├── Trend Analysis (EMA)
   ├── Structure Analysis (BOS)
   ├── Pattern Detection
   ├── Liquidity Analysis
   ├── Volatility Check (ATR)
   └── Session Filters
   ↓
7. Confluence Scoring
   ↓
8. Threshold Check (adaptive)
   ↓
9. Expectancy Filter
   ↓
10. Capital Management (position sizing)
    ↓
11. [Optional] Gemini Confirmation
    ↓
12. Signal Queue Addition
    ↓
13. Trade Execution (via existing pipeline)
    ↓
14. Result Tracking & Learning
    ├── Expectancy Update
    ├── Threshold Adaptation
    ├── Shadow Mode Recording
    └── Monte Carlo Update
```

### Configuration

#### Config File (`state/config.py`)

```python
CONFIG = {
    # Enhanced Analysis Engine
    "usar_enhanced_engine": True,        # Enable professional system
    "scoring_threshold": 65,             # Base threshold
    "adaptive_threshold": True,          # Enable adaptation
    "cooldown_seconds": 300,             # 5 minutes cooldown
    "shadow_mode_enabled": True,         # Enable shadow testing
    "monte_carlo_enabled": True,         # Enable MC simulation
    "telemetry_enabled": True,           # Enable structured logging
    "gemini_confirmation": True,         # Use Gemini secondary
    
    # Trade Limits
    "automacao_max_sinais_hora": 10,     # Max signals per hour
    "automacao_intervalo_analise": 30,   # Analysis interval (seconds)
}
```

### Usage

#### Activation

1. Connect to IQ Option (PRACTICE account verified)
2. Activate "Modo Automático" first
3. Toggle "Automação de Sinais" button

When enabled, you'll see:
```
🚀 Professional Analysis System ATIVADO

📊 Análises Ativas:
   ✓ Trend (EMA 9/21/50)
   ✓ Structure (BOS detection)
   ✓ Patterns (Engulfing, Inside Bar)
   ✓ Liquidity Sweeps
   ✓ Volatility (ATR)
   ✓ Session Filters

🎯 Smart Features:
   ✓ Adaptive Scoring
   ✓ Expectancy Tracking
   ✓ Dynamic Capital Management
   ✓ Regime Detection
   ✓ Monte Carlo Risk Simulation
   ✓ Shadow Mode Testing
   ✓ Watchdog Monitoring
```

#### Monitoring

The system logs comprehensive telemetry:
- Signal generation with full score breakdown
- Gemini API interactions
- Trade executions and results
- Risk manager states
- Regime changes
- Expectancy updates
- Capital adjustments

### Safety Features

1. **Manual Priority**: Manual signals ALWAYS processed first
2. **Practice Only**: PRACTICE account verification mandatory
3. **Cooldown**: Prevents overtrading same asset (5 min)
4. **Hourly Limits**: Max 10 signals per hour
5. **Daily Stop**: Hard daily loss limit via capital engine
6. **Regime Awareness**: Reduces activity in adverse conditions
7. **Expectancy Filtering**: Skips assets with negative expectancy
8. **Adaptive Thresholds**: Increases requirements when performance drops
9. **Watchdog**: Monitors system health, alerts on critical issues
10. **Circuit Breaker**: Existing circuit breaker integration maintained

### Performance Tracking

The system automatically tracks:
- Win rate by asset
- Win rate by score range
- Win rate by trading session
- Expectancy metrics
- Drawdown statistics
- Risk of ruin
- Shadow mode comparison

### Risk Management Integration

The Enhanced Engine integrates seamlessly with existing Risk Manager:
- Respects consecutive loss limits
- Honors pause states
- Uses adjusted position sizing
- Maintains volatility checks
- Preserves all existing safety mechanisms

### Backward Compatibility

- All existing commands work unchanged
- Manual signal parsing unchanged
- Telegram bot interface preserved
- Original auto_trader logic intact
- Can switch back to legacy system via config flag

### Technical Requirements

```bash
# Additional dependency
numpy>=1.24.0
```

All other dependencies remain unchanged.

### Testing Recommendations

1. **Start Conservative**: Begin with higher threshold (70-75)
2. **Monitor Shadow Mode**: Compare performance after 20+ trades
3. **Review Telemetry**: Analyze JSON logs for insights
4. **Check Expectancy**: Review per-asset performance weekly
5. **Adjust Thresholds**: Let adaptive system work, but monitor
6. **Respect Regimes**: Pay attention to regime classifications

### Future Enhancements

Potential areas for improvement:
- Additional technical indicators (RSI, MACD, Bollinger Bands)
- Machine learning model integration
- Multi-timeframe analysis
- Order book depth analysis (if API available)
- Sentiment analysis integration
- Advanced position management (trailing stops, partial closes)

### Support

For issues or questions:
1. Check telemetry logs for error details
2. Verify PRACTICE account connection
3. Review watchdog health status
4. Check console output for detailed logging
5. Confirm all engines initialized successfully

---

**Remember**: This is a sophisticated professional system. Start with conservative settings and let the adaptive mechanisms optimize over time. The system learns from every trade.
