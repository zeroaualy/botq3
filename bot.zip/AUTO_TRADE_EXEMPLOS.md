# 📚 Exemplos Práticos - Auto Trade

## 🎯 Cenários de Uso Real

### **Cenário 1: Trader Iniciante**

**Situação:** João acabou de criar sua conta na IQ Option e quer testar trading automatizado de forma segura.

**Solução com Auto Trade:**

```python
# Passo 1: Configurar valores conservadores
Valor de entrada: $2.00
Stop Loss: $20.00
Stop Gain: $40.00

# Passo 2: Ativar modo automático
/start → Clicar em "Automático"

# Resultado esperado:
- Máximo de 10 trades antes de atingir stop loss
- Proteção contra perdas excessivas
- Aprendizado através das notificações
```

**Resultados de João em 1 semana:**

```
📊 Estatísticas - Semana 1
Total de operações: 67
├─ Wins: 41 (61.2%)
├─ Losses: 26 (38.8%)
└─ Lucro total: $38.50

💡 Lições aprendidas:
- Horários com mais volatilidade: 14h-17h
- Pares mais lucrativos: EURUSD, GBPUSD
- Evitar horários de notícias econômicas
```

---

### **Cenário 2: Trader Experiente**

**Situação:** Maria tem experiência em trading manual e quer automatizar sua estratégia.

**Solução com Auto Trade:**

```python
# Passo 1: Ajustar estratégia no código
# Editar auto_trader.py para incluir RSI, MACD

# Passo 2: Configurar valores agressivos
Valor de entrada: $10.00
Stop Loss: $100.00
Stop Gain: $200.00
Nível mínimo de confiança: 70%

# Passo 3: Monitorar e ajustar
- Acompanhar resultados diariamente
- Ajustar parâmetros com base em performance
- Testar diferentes horários
```

**Resultados de Maria em 1 mês:**

```
📊 Estatísticas - Mês 1
Total de operações: 243
├─ Wins: 156 (64.2%)
├─ Losses: 87 (35.8%)
└─ Lucro total: $548.00

🎯 Estratégia otimizada:
- Operar apenas entre 9h-12h e 14h-18h
- Focar em EURUSD e USDJPY
- Aumentar confiança mínima para 75%
- Resultado: Taxa de acerto subiu para 67%
```

---

### **Cenário 3: Gestor de Múltiplas Contas**

**Situação:** Pedro gerencia contas de 5 clientes e precisa escalar suas operações.

**Solução com Auto Trade:**

```python
# Estratégia: Um bot por conta

# Bot 1 - Conta Conservadora
Valor: $3.00
Stop Loss: $30.00
Confiança: 75%

# Bot 2 - Conta Moderada
Valor: $5.00
Stop Loss: $50.00
Confiança: 65%

# Bot 3 - Conta Agressiva
Valor: $10.00
Stop Loss: $100.00
Confiança: 60%

# ... e assim por diante
```

**Gestão de Pedro:**

```
📊 Dashboard de 5 Contas

Conta 1 (Conservadora):
├─ 45 operações
├─ 67% taxa de acerto
└─ +$67.50

Conta 2 (Moderada):
├─ 78 operações
├─ 63% taxa de acerto
└─ +$124.00

Conta 3 (Agressiva):
├─ 112 operações
├─ 61% taxa de acerto
└─ +$201.50

Conta 4 (Moderada):
├─ 65 operações
├─ 64% taxa de acerto
└─ +$98.00

Conta 5 (Conservadora):
├─ 52 operações
├─ 68% taxa de acerto
└─ +$78.50

Total geral: +$569.50
```

---

## 🔧 Casos de Uso Técnicos

### **Uso 1: Backtesting de Estratégias**

```python
# Objetivo: Testar estratégia com dados históricos

# Modificar auto_trader.py:
def captura_sinal_historico(self, timestamp):
    """Usar dados históricos ao invés de tempo real"""
    candles = self.iq_client.iq.get_candles(
        par="EURUSD",
        intervalo=60,
        quantidade=60,
        timestamp=timestamp  # Timestamp histórico
    )
    return self._analisar_tendencia(candles, "EURUSD")

# Executar backtesting:
for dia in range(30):  # Últimos 30 dias
    timestamp = time.time() - (dia * 86400)
    sinal = captura_sinal_historico(timestamp)
    # Processar resultado...
```

---

### **Uso 2: Integração com IA Personalizada**

```python
# Objetivo: Usar modelo de ML próprio

# Modificar _analisar_tendencia():
def _analisar_tendencia_ml(self, candles, par):
    """Usar modelo treinado ao invés de lógica simples"""
    
    # Preparar features
    features = self._preparar_features(candles)
    
    # Prever com modelo
    predicao = self.modelo_ml.predict(features)
    confianca = self.modelo_ml.predict_proba(features)
    
    return {
        "direcao": "CALL" if predicao == 1 else "PUT",
        "confianca": int(confianca * 100),
        "descricao": f"Predição ML: {confianca:.2f}"
    }
```

---

### **Uso 3: Notificações Avançadas**

```python
# Objetivo: Enviar notificações mais ricas

# Modificar _enviar_notificacao():
async def _enviar_notificacao_avancada(self, tipo, dados):
    """Notificações com gráficos e análises"""
    
    if tipo == "sinal_detectado":
        # Gerar gráfico de candles
        grafico = self._gerar_grafico_candles(dados['candles'])
        
        # Enviar imagem + texto
        await self.telegram_bot_instance.send_photo(
            chat_id=self.chat_id,
            photo=grafico,
            caption=f"📊 Sinal: {dados['par']} {dados['acao']}"
        )
    
    elif tipo == "resultado":
        # Gerar gráfico de evolução
        grafico = self._gerar_grafico_evolucao()
        
        await self.telegram_bot_instance.send_photo(
            chat_id=self.chat_id,
            photo=grafico,
            caption=f"✅ Resultado: {dados['resultado']}"
        )
```

---

## 📊 Exemplos de Análise de Dados

### **Análise 1: Melhor Horário para Operar**

```python
# Coletar dados por 1 mês
# Agrupar por horário

Resultados por horário:

08:00 - 10:00: 58% taxa de acerto
10:00 - 12:00: 62% taxa de acerto ✅ MELHOR
12:00 - 14:00: 54% taxa de acerto
14:00 - 16:00: 61% taxa de acerto ✅ BOM
16:00 - 18:00: 59% taxa de acerto
18:00 - 20:00: 52% taxa de acerto

Conclusão: Operar entre 10h-12h e 14h-16h
```

---

### **Análise 2: Melhor Par de Moedas**

```python
# Coletar dados por 1 mês
# Agrupar por par

Resultados por par:

EURUSD: 64% (156/243) ✅ MELHOR
GBPUSD: 62% (98/158)
USDJPY: 61% (87/143)
AUDUSD: 58% (76/131)
EURJPY: 57% (65/114)

Conclusão: Focar em EURUSD e GBPUSD
```

---

### **Análise 3: Correlação Confiança vs Resultado**

```python
# Analisar se maior confiança = melhor resultado

Confiança 60-65%: 58% taxa de acerto
Confiança 65-70%: 62% taxa de acerto
Confiança 70-75%: 67% taxa de acerto ✅
Confiança 75-80%: 71% taxa de acerto ✅
Confiança 80%+:   68% taxa de acerto

Conclusão: Aumentar confiança mínima para 70%
```

---

## 🎮 Simulações Práticas

### **Simulação 1: Dia Típico**

```
09:00 - Bot ativado
09:05 - Primeiro sinal (EURUSD CALL 72%) → WIN +$8.50
09:12 - Segundo sinal (GBPUSD PUT 68%) → WIN +$8.50
09:25 - Mercado lateral, sem sinais
09:42 - Terceiro sinal (USDJPY CALL 75%) → LOSS -$5.00
10:15 - Quarto sinal (EURUSD PUT 70%) → WIN +$8.50
10:30 - Quinto sinal (GBPUSD CALL 66%) → WIN +$8.50
11:00 - Sexto sinal (EURUSD CALL 73%) → LOSS -$5.00

Resultado do período (2 horas):
- 6 operações
- 4 wins, 2 losses (66.7%)
- Lucro: $24.00
```

---

### **Simulação 2: Semana Completa**

```
Segunda-feira: 12 ops, 8 wins → +$24.00
Terça-feira:   15 ops, 9 wins → +$21.00
Quarta-feira:  10 ops, 7 wins → +$19.00
Quinta-feira:  14 ops, 8 wins → +$18.00
Sexta-feira:   11 ops, 7 wins → +$19.00

Total da semana:
- 62 operações
- 39 wins (62.9%)
- Lucro: $101.00
```

---

### **Simulação 3: Mês com Stop Loss**

```
Semana 1: +$101.00
Semana 2: +$87.50
Semana 3: -$45.00 (semana ruim)
Semana 4: +$124.00

Total do mês:
- 248 operações
- 156 wins (62.9%)
- Lucro: $267.50

Observações:
- Stop loss foi ativado 2 vezes na semana 3
- Ajuste de parâmetros melhorou semana 4
- ROI mensal: +2.67%
```

---

## 💡 Dicas e Truques

### **Dica 1: Otimizar Intervalo de Verificação**

```python
# Intervalo muito curto (1s): sobrecarga de API
intervalo_verificacao = 1  # ❌ NÃO RECOMENDADO

# Intervalo ideal (5s): balanço perfeito
intervalo_verificacao = 5  # ✅ RECOMENDADO

# Intervalo longo (30s): pode perder sinais
intervalo_verificacao = 30  # ⚠️ USE COM CAUTELA
```

---

### **Dica 2: Combinar com Sinais Manuais**

```python
# Estratégia híbrida:
# - Auto Trade para operações de rotina
# - Sinais manuais para oportunidades especiais

# Ativar modo automático
🟢 Automático: ATIVO

# Receber sinal manual importante
📱 "EURUSD CALL 15:30 (notícia importante)"

# Desativar temporariamente
⚪ Automático: PAUSADO

# Executar sinal manual
✅ Trade manual executado

# Reativar modo automático
🟢 Automático: ATIVO
```

---

### **Dica 3: Usar Múltiplos Bots**

```python
# Bot 1: Scalping (M1)
- Expiracao: 60s
- Confiança: 70%
- Agressivo

# Bot 2: Swing (M5)
- Expiracao: 300s
- Confiança: 65%
- Moderado

# Bot 3: Position (M15)
- Expiracao: 900s
- Confiança: 75%
- Conservador

Resultado: Diversificação e redução de risco
```

---

## 🚀 Próximos Passos

Após dominar o básico, evolua para:

1. **Implementar indicadores técnicos**
   - RSI (Relative Strength Index)
   - MACD (Moving Average Convergence Divergence)
   - Bollinger Bands
   - Fibonacci Retracements

2. **Integrar Machine Learning**
   - TensorFlow ou PyTorch
   - Treinar modelo com dados históricos
   - Backtesting automatizado

3. **Criar Dashboard Web**
   - Visualização em tempo real
   - Gráficos interativos
   - Controle remoto

4. **Implementar Risk Management Avançado**
   - Kelly Criterion
   - Martingale adaptativo
   - Position sizing dinâmico

5. **Adicionar Mais Estratégias**
   - Breakout
   - Mean reversion
   - Trend following
   - News trading

---

**🎯 Lembre-se: O sucesso em trading vem de disciplina, gestão de risco e aprendizado contínuo!**
