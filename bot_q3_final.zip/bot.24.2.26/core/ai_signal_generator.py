"""
Gerador Automático de Sinais com IA - Bot Q3 Beta
Analisa mercado e gera sinais automaticamente usando IA Gemini
"""
import asyncio
import logging
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from typing import Optional, Dict, List

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class AISignalGenerator:
    """
    Gerador automático de sinais usando IA.
    
    Fluxo:
    1. Busca candles M1 (60 candles)
    2. Analisa tendência e volatilidade
    3. Envia para IA (Gemini)
    4. Se probabilidade >= 60%, gera sinal
    5. Envia sinal no formato padrão para o grupo
    """
    
    def __init__(self, iq_client, gemini_client, notify_callback, config: dict):
        """
        Args:
            iq_client: Cliente IQ Option
            gemini_client: Cliente Gemini AI
            notify_callback: Função para enviar mensagem no Telegram
            config: Configurações do bot
        """
        self.iq = iq_client
        self.gemini = gemini_client
        self.notify = notify_callback
        self.config = config
        
        # Lista de ativos para análise
        self.ativos = config.get("ai_ativos", ["EURUSD", "GBPUSD", "USDJPY"])
        
        # Probabilidade mínima para gerar sinal
        self.prob_minima = config.get("ai_probabilidade_minima", 60)
        
        # Cache para evitar sinais duplicados
        self._sinais_enviados = {}  # {ativo_direcao_minuto: timestamp}
        
        # Estado de execução
        self.active = False
        self._task = None
    
    async def start(self):
        """Inicia o gerador automático"""
        if self.active:
            logger.warning("Gerador já está ativo")
            return False
        
        if not self.gemini:
            logger.error("Gemini client não disponível")
            return False
        
        self.active = True
        self._task = asyncio.create_task(self._loop())
        logger.info("✅ Gerador automático de sinais INICIADO")
        return True
    
    async def stop(self):
        """Para o gerador automático"""
        self.active = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("⏸️ Gerador automático de sinais PAUSADO")
    
    async def _loop(self):
        """Loop principal - executa a cada minuto"""
        while self.active:
            try:
                # Verificar cada ativo na lista
                for ativo in self.ativos:
                    if not self.active:
                        break
                    
                    try:
                        await self.gerar_sinal_se_aprovado(ativo)
                    except Exception as e:
                        logger.error(f"Erro ao gerar sinal para {ativo}: {e}")
                
                # Aguardar 60 segundos
                await asyncio.sleep(60)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Erro no loop do gerador: {e}")
                await asyncio.sleep(60)
    
    async def gerar_previsao(self, ativo: str) -> Optional[Dict]:
        """
        Gera previsão para um ativo usando IA.
        
        Returns:
            {"direcao": "CALL" | "PUT", "probabilidade": int} ou None
        """
        try:
            # 1. Buscar 60 candles M1
            candles = await self._buscar_candles(ativo, timeframe=60, count=60)
            
            if not candles or len(candles) < 30:
                logger.warning(f"Candles insuficientes para {ativo}")
                return None
            
            # 2. Calcular métricas
            tendencia = self._calcular_tendencia(candles)
            volatilidade = self._calcular_volatilidade(candles)
            preco_atual = candles[-1]["close"]
            
            # 3. Preparar prompt para IA
            prompt = self._criar_prompt(ativo, candles, tendencia, volatilidade, preco_atual)
            
            # 4. Enviar para IA com timeout
            try:
                resposta = await asyncio.wait_for(
                    self.gemini.analisar_contexto(prompt),
                    timeout=5.0
                )
            except asyncio.TimeoutError:
                logger.warning(f"Timeout na IA para {ativo}")
                return None
            
            # 5. Parsear resposta
            resultado = self._parsear_resposta_ia(resposta)
            
            if resultado:
                logger.info(
                    f"📊 {ativo}: {resultado['direcao']} "
                    f"({resultado['probabilidade']}%)"
                )
            
            return resultado
            
        except Exception as e:
            logger.error(f"Erro ao gerar previsão para {ativo}: {e}")
            return None
    
    async def gerar_sinal_se_aprovado(self, ativo: str):
        """
        Gera sinal automaticamente se probabilidade >= 60%
        """
        # Obter previsão da IA
        previsao = await self.gerar_previsao(ativo)
        
        if not previsao:
            return
        
        direcao = previsao["direcao"]
        probabilidade = previsao["probabilidade"]
        
        # Verificar probabilidade mínima
        if probabilidade < self.prob_minima:
            logger.debug(
                f"❌ {ativo} {direcao}: {probabilidade}% < {self.prob_minima}%"
            )
            return
        
        # Verificar duplicação
        agora = datetime.now(TZ)
        minuto_atual = agora.strftime("%H:%M")
        cache_key = f"{ativo}_{direcao}_{minuto_atual}"
        
        if cache_key in self._sinais_enviados:
            logger.debug(f"Sinal duplicado ignorado: {cache_key}")
            return
        
        # Registrar sinal
        self._sinais_enviados[cache_key] = agora.timestamp()
        
        # Limpar cache antigo (> 2 minutos)
        self._limpar_cache_antigo()
        
        # Criar sinal no formato padrão
        horario = (agora + timedelta(seconds=30)).strftime("%H:%M")
        sinal_texto = f"{ativo} {direcao} {horario}"
        
        # Enviar no grupo
        if self.notify:
            mensagem = (
                f"🤖 <b>Sinal IA</b>\n"
                f"📊 {sinal_texto}\n"
                f"🎯 Probabilidade: {probabilidade}%"
            )
            await self.notify(mensagem)
        
        logger.info(f"✅ Sinal IA gerado: {sinal_texto} ({probabilidade}%)")
    
    async def _buscar_candles(self, ativo: str, timeframe: int, count: int) -> List[Dict]:
        """Busca candles históricos"""
        try:
            # Remover sufixo -OTC se presente
            ativo_clean = ativo.replace("-OTC", "")
            
            # Buscar candles usando myiq
            candles = await self.iq.iq.get_candles(
                ativo_clean,
                timeframe,
                count,
                datetime.now(TZ)
            )
            
            if not candles:
                return []
            
            # Converter para formato dict
            resultado = []
            for c in candles:
                resultado.append({
                    "open": float(c.open),
                    "high": float(c.max),
                    "low": float(c.min),
                    "close": float(c.close),
                    "time": c.at
                })
            
            return resultado
            
        except Exception as e:
            logger.error(f"Erro ao buscar candles de {ativo}: {e}")
            return []
    
    def _calcular_tendencia(self, candles: List[Dict]) -> str:
        """
        Calcula tendência simples: Alta / Baixa / Lateral
        """
        if len(candles) < 10:
            return "LATERAL"
        
        # Comparar média dos últimos 10 com média dos 10 anteriores
        recentes = candles[-10:]
        anteriores = candles[-20:-10]
        
        media_recente = sum(c["close"] for c in recentes) / len(recentes)
        media_anterior = sum(c["close"] for c in anteriores) / len(anteriores)
        
        diff_percent = ((media_recente - media_anterior) / media_anterior) * 100
        
        if diff_percent > 0.05:
            return "ALTA"
        elif diff_percent < -0.05:
            return "BAIXA"
        else:
            return "LATERAL"
    
    def _calcular_volatilidade(self, candles: List[Dict]) -> str:
        """
        Calcula volatilidade simples: Baixa / Média / Alta
        """
        if len(candles) < 20:
            return "MEDIA"
        
        # Calcular variação média dos últimos 20 candles
        variacoes = []
        for c in candles[-20:]:
            variacao = abs(c["high"] - c["low"]) / c["close"]
            variacoes.append(variacao)
        
        volatilidade_media = sum(variacoes) / len(variacoes)
        
        if volatilidade_media < 0.0005:
            return "BAIXA"
        elif volatilidade_media > 0.002:
            return "ALTA"
        else:
            return "MEDIA"
    
    def _criar_prompt(
        self,
        ativo: str,
        candles: List[Dict],
        tendencia: str,
        volatilidade: str,
        preco_atual: float
    ) -> str:
        """Cria prompt para a IA"""
        
        # Últimos 10 candles
        candles_texto = ""
        for c in candles[-10:]:
            candles_texto += (
                f"open:{c['open']:.5f} high:{c['high']:.5f} "
                f"low:{c['low']:.5f} close:{c['close']:.5f}\n"
            )
        
        agora = datetime.now(TZ)
        
        prompt = f"""Analise este ativo para operação binária de 1 minuto:

Ativo: {ativo}
Timeframe: M1
Hora atual: {agora.strftime('%H:%M')}
Preço atual: {preco_atual:.5f}
Tendência: {tendencia}
Volatilidade: {volatilidade}

Últimos candles:
{candles_texto}

Responda EXATAMENTE neste formato (sem texto extra):
DIRECAO: CALL
PROBABILIDADE: 65

Ou:
DIRECAO: PUT
PROBABILIDADE: 70
"""
        return prompt
    
    def _parsear_resposta_ia(self, resposta: str) -> Optional[Dict]:
        """
        Parseia resposta da IA.
        
        Formato esperado:
        DIRECAO: CALL
        PROBABILIDADE: 65
        """
        try:
            linhas = resposta.strip().split("\n")
            
            direcao = None
            probabilidade = None
            
            for linha in linhas:
                linha = linha.strip()
                
                if "DIRECAO:" in linha.upper():
                    partes = linha.split(":")
                    if len(partes) >= 2:
                        direcao = partes[1].strip().upper()
                
                if "PROBABILIDADE:" in linha.upper():
                    partes = linha.split(":")
                    if len(partes) >= 2:
                        try:
                            probabilidade = int(partes[1].strip())
                        except:
                            pass
            
            if direcao in ("CALL", "PUT") and probabilidade is not None:
                return {
                    "direcao": direcao,
                    "probabilidade": probabilidade
                }
            
            logger.warning(f"Resposta IA inválida: {resposta}")
            return None
            
        except Exception as e:
            logger.error(f"Erro ao parsear resposta IA: {e}")
            return None
    
    def _limpar_cache_antigo(self):
        """Remove sinais do cache com mais de 2 minutos"""
        agora = datetime.now(TZ).timestamp()
        limite = agora - 120  # 2 minutos
        
        keys_remover = [
            k for k, ts in self._sinais_enviados.items()
            if ts < limite
        ]
        
        for key in keys_remover:
            del self._sinais_enviados[key]
