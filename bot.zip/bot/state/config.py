"""
Configurações do bot
Inclui flags de PERMISSÃO (para governança) que NÃO alteram comportamento real
"""
import os
import logging
from dotenv import load_dotenv

# Carregar .env no ponto mais alto
load_dotenv()

logger = logging.getLogger(__name__)

# ======================================
# FUNÇÕES DE VALIDAÇÃO E SANITIZAÇÃO
# ======================================

def _sanitize_api_key(key):
    """Remove espaços, aspas e caracteres invisíveis da API key"""
    if not key:
        return None
    # Remove espaços, aspas simples/duplas, quebras de linha
    key = key.strip().strip('"').strip("'").strip()
    return key if key else None

def _validate_gemini_key(key):
    """Valida formato da chave Gemini"""
    if not key:
        return False, "Chave não encontrada"
    if len(key) < 20:
        return False, f"Chave muito curta (len={len(key)})"
    return True, "OK"

def _load_config():
    """Carrega e valida configurações"""
    # Carregar do .env
    TOKEN = os.getenv('TELEGRAM_TOKEN')
    GRUPO_ID = os.getenv('TELEGRAM_GROUP_ID')
    GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
    EMAIL = os.getenv('IQ_EMAIL')
    SENHA = os.getenv('IQ_PASSWORD')
    
    # Sanitizar chave Gemini
    GEMINI_API_KEY = _sanitize_api_key(GEMINI_API_KEY)
    
    # Validar chave Gemini
    is_valid, msg = _validate_gemini_key(GEMINI_API_KEY)
    if not is_valid:
        logger.error(f"❌ GEMINI_API_KEY inválida: {msg}")
        if GEMINI_API_KEY:
            logger.error(f"   Primeiros 8 chars: {GEMINI_API_KEY[:8]}...")
            logger.error(f"   Comprimento: {len(GEMINI_API_KEY)}")
        else:
            logger.error("   Chave é None ou vazia")
    else:
        logger.info(f"✅ GEMINI_API_KEY válida (inicio: {GEMINI_API_KEY[:8]}..., len: {len(GEMINI_API_KEY)})")
    
    # Converter GRUPO_ID para int
    try:
        GRUPO_ID = int(GRUPO_ID) if GRUPO_ID else None
    except:
        GRUPO_ID = None
    
    # Validação final
    if not TOKEN:
        logger.error("❌ TELEGRAM_TOKEN não encontrado no .env")
    if not GRUPO_ID:
        logger.error("❌ TELEGRAM_GROUP_ID não encontrado no .env")
    if not GEMINI_API_KEY:
        logger.error("❌ GEMINI_API_KEY não encontrado no .env")
    if not EMAIL:
        logger.error("❌ IQ_EMAIL não encontrado no .env")
    if not SENHA:
        logger.error("❌ IQ_PASSWORD não encontrado no .env")
    
    return TOKEN, GRUPO_ID, GEMINI_API_KEY, EMAIL, SENHA

# ======================================
# CREDENCIAIS
# ======================================
TOKEN, GRUPO_ID, GEMINI_API_KEY, EMAIL, SENHA = _load_config()

# ======================================
# CONFIGURAÇÕES OPERACIONAIS
# ======================================
CONFIG = {
    # Operação
    "ativos": ["EURUSD", "GBPUSD", "USDJPY"],
    "timeframe": 60,
    "operar_automatico": False,
    "valor_entrada": 100.0,
    "martingale": False,
    
    # Proteção
    "stop_loss": 20.0,
    "stop_gain": 50.0,
    
    # IA (validação de contexto/risco)
    "ia_validar_contexto": True,
    
    # Agendamento
    "tolerancia_agendamento_ms": 3000,  # 3 segundos
    
    # Automação de Sinais
    "automacao_sinais_habilitada": True,  # Permite usar a funcionalidade
    "automacao_confianca_minima": 65,    # Confiança mínima para gerar sinais
    "automacao_intervalo_analise": 30,   # Segundos entre análises
    "automacao_max_sinais_hora": 10,     # Limite de sinais por hora
    
    # Enhanced Analysis Engine
    "usar_enhanced_engine": True,        # Use professional analysis system
    "scoring_threshold": 65,             # Base scoring threshold
    "adaptive_threshold": True,          # Enable adaptive threshold
    "cooldown_seconds": 300,             # Cooldown between trades (same asset)
    "shadow_mode_enabled": True,         # Enable shadow mode testing
    "monte_carlo_enabled": True,         # Enable Monte Carlo simulation
    "telemetry_enabled": True,           # Enable structured logging
    "gemini_confirmation": True,         # Use Gemini as secondary confirmation
}

# ======================================
# PERMISSÕES DE GOVERNANÇA
# CRÍTICO: Estas flags NÃO habilitam funcionalidade real
# Servem APENAS para auditoria e transparência
# ======================================
PERMISSOES = {
    # Flag visual - IA NÃO cria estratégia mesmo se True
    "ia_pode_criar_estrategia": False,
    
    # Flag visual - IA NÃO prevê mercado mesmo se True
    "ia_pode_prever_mercado": False,
    
    # Flag visual - IA NÃO decide direção mesmo se True
    "ia_pode_decidir_direcao": False,
}

# Mensagem exibida quando permissão é alterada
AVISO_PERMISSAO = """
⚠️ <b>AVISO IMPORTANTE</b>

Esta permissão foi alterada apenas como <b>FLAG DE GOVERNANÇA</b>.

O comportamento REAL do bot permanece inalterado:
• IA NÃO cria estratégias
• IA NÃO prevê mercado
• IA NÃO decide CALL ou PUT
• IA APENAS valida contexto e risco

Esta flag serve para:
✓ Auditoria
✓ Transparência
✓ Trava explícita de poder
"""
