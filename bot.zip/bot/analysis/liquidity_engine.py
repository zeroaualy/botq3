"""
Liquidity Engine - Liquidity Sweep Detection
Approximates liquidity levels and sweep patterns
"""
import logging
from typing import Dict, List

logger = logging.getLogger(__name__)


class LiquidityEngine:
    """Detects potential liquidity sweeps"""
    
    def analyze(self, candles: List[Dict]) -> Dict:
        try:
            if not candles or len(candles) < 20:
                return {"sweep_detected": False, "score": 0, "details": "Insufficient data"}
            
            # Find recent support/resistance levels (highs and lows)
            highs = [c["high"] for c in candles[-20:]]
            lows = [c["low"] for c in candles[-20:]]
            
            recent_resistance = max(highs[:-3])
            recent_support = min(lows[:-3])
            
            last_candle = candles[-1]
            
            # Check for bullish sweep (price dips below support then recovers)
            if (last_candle["low"] <= recent_support * 0.9998 and
                last_candle["close"] > recent_support):
                return {
                    "sweep_detected": True,
                    "sweep_type": "BULLISH",
                    "score": 65,
                    "details": "Bullish liquidity sweep detected"
                }
            
            # Check for bearish sweep (price spikes above resistance then drops)
            if (last_candle["high"] >= recent_resistance * 1.0002 and
                last_candle["close"] < recent_resistance):
                return {
                    "sweep_detected": True,
                    "sweep_type": "BEARISH",
                    "score": 65,
                    "details": "Bearish liquidity sweep detected"
                }
            
            return {
                "sweep_detected": False,
                "score": 40,
                "details": "No liquidity sweep"
            }
            
        except Exception as e:
            logger.error(f"Error in liquidity analysis: {e}")
            return {"sweep_detected": False, "score": 0, "details": str(e)}
