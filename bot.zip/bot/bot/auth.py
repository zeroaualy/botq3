"""
Auth — Bot Q3 Beta
Verifica se usuário é admin do grupo via API do Telegram.
Sem lista fixa de IDs. Cache de 60s para não spammar a API.
"""
import logging
import time
from typing import Optional

logger = logging.getLogger(__name__)

# Cache: {user_id: (is_admin: bool, timestamp: float)}
_cache: dict = {}
CACHE_TTL = 60  # segundos


async def is_admin(bot, user_id: int, chat_id: int) -> bool:
    """
    Retorna True se user_id for admin ou criador do chat_id.
    Usa cache de 60s para evitar chamadas repetidas à API.
    """
    now = time.time()
    cache_key = (user_id, chat_id)

    # Cache hit
    if cache_key in _cache:
        result, ts = _cache[cache_key]
        if now - ts < CACHE_TTL:
            return result

    # API call
    try:
        member = await bot.get_chat_member(chat_id=chat_id, user_id=user_id)
        result = member.status in ("administrator", "creator")
        _cache[cache_key] = (result, now)
        logger.debug(f"Auth: user={user_id} status={member.status} → admin={result}")
        return result
    except Exception as e:
        logger.warning(f"Auth check failed for user={user_id}: {e}")
        # Em caso de erro (ex: bot não é admin do grupo), nega por segurança
        return False


def clear_cache(user_id: int = None, chat_id: int = None):
    """Limpa cache de um usuário específico ou todo o cache."""
    global _cache
    if user_id and chat_id:
        _cache.pop((user_id, chat_id), None)
    else:
        _cache.clear()
