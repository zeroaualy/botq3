"""
IA Guard - Validador de Contexto e Risco Operacional

IMPORTANTE: As funções de IA agora respeitam flags de runtime
definidas em state/runtime.py que são controladas via Telegram:
- CREATE_STRATEGY_ENABLED
- PREDICT_MARKET_ENABLED  
- DECIDE_DIRECTION_ENABLED

Cada função verifica sua flag antes de executar.
"""
import logging
import asyncio

logger = logging.getLogger(__name__)


class IAGuard:
    """
    Validador de Contexto e Risco Operacional
    
    FUNCIONALIDADES CONTROLÁVEIS:
    1. Validar contexto operacional (sempre ativo)
    2. Criar estratégias (controlado por flag)
    3. Prever mercado (controlado por flag)
    4. Decidir direção (controlado por flag)
    """
    
    def __init__(self, gemini_client):
        self.gemini_client = gemini_client
        self._retry_attempts = 2
        self._retry_delay = 1.0
    
    async def _call_gemini_with_retry(self, prompt, temperature=0.1, max_tokens=10):
        """Chama Gemini API com retry automático"""
        for attempt in range(self._retry_attempts + 1):
            try:
                logger.debug(f"🔄 Chamando Gemini API (tentativa {attempt + 1}/{self._retry_attempts + 1})")
                
                response = self.gemini_client.chat.completions.create(
                    model="gemini-pro",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                
                logger.debug("✅ Resposta Gemini API recebida")
                return response.choices[0].message.content.strip()
            
            except Exception as e:
                error_msg = str(e)
                logger.error(f"❌ Erro na chamada Gemini (tentativa {attempt + 1}): {error_msg}")
                
                # Se erro 401, não retry
                if "401" in error_msg or "invalid" in error_msg.lower():
                    logger.error("🔴 Erro 401: API Key inválida - Não será feito retry")
                    raise
                
                # Se última tentativa, propagar erro
                if attempt == self._retry_attempts:
                    raise
                
                # Aguardar antes de retry
                await asyncio.sleep(self._retry_delay * (attempt + 1))
        
        raise Exception("Todas as tentativas falharam")
    
    async def validar_contexto(self, sinal, contexto_operacional=None):
        """
        Valida APENAS contexto operacional
        Esta função está sempre ativa (não depende de flags)
        
        Retorna: "EXECUTAR", "IGNORAR" ou "RISCO"
        """
        if not self.gemini_client:
            logger.warning("⚠️ IA indisponível, executando sem validação")
            return "EXECUTAR"
        
        try:
            prompt = self._criar_prompt_validacao(sinal, contexto_operacional)
            
            resposta = await self._call_gemini_with_retry(
                prompt,
                temperature=0.1,
                max_tokens=10
            )
            
            resposta = resposta.upper()
            
            # Extrair decisão
            if "EXECUTAR" in resposta:
                decisao = "EXECUTAR"
            elif "RISCO" in resposta:
                decisao = "RISCO"
            else:
                decisao = "IGNORAR"
            
            logger.info(f"🤖 IA Guard: {decisao}")
            return decisao
            
        except Exception as e:
            logger.error(f"❌ Erro na IA Guard: {e}")
            logger.warning("⚠️ Usando fallback: EXECUTAR (permitir operação)")
            return "EXECUTAR"  # Fallback: permite execução em caso de erro
    
    async def criar_estrategia(self, ativo, timeframe):
        """
        Cria estratégia de trading
        
        VERIFICA FLAG: state.runtime.CREATE_STRATEGY_ENABLED
        - Se False: Retorna None imediatamente
        - Se True: Executa análise e cria estratégia
        """
        from state import runtime
        
        # Verificar flag de controle
        if not runtime.CREATE_STRATEGY_ENABLED:
            logger.info("⚠️ Criar Estratégia: DESABILITADO (flag=False)")
            return {
                "habilitado": False,
                "mensagem": "Função 'Criar Estratégia' está desabilitada no momento."
            }
        
        logger.info("✅ Criar Estratégia: HABILITADO (flag=True)")
        
        if not self.gemini_client:
            return {
                "habilitado": True,
                "erro": "IA não disponível"
            }
        
        try:
            prompt = f"""Crie uma estratégia de trading para:
Ativo: {ativo}
Timeframe: {timeframe}

Forneça:
1. Análise técnica
2. Pontos de entrada
3. Stop loss e take profit
4. Gestão de risco

Seja breve e objetivo."""

            estrategia = await self._call_gemini_with_retry(
                prompt,
                temperature=0.7,
                max_tokens=300
            )
            
            return {
                "habilitado": True,
                "estrategia": estrategia,
                "ativo": ativo,
                "timeframe": timeframe
            }
            
        except Exception as e:
            logger.error(f"❌ Erro ao criar estratégia: {e}")
            return {
                "habilitado": True,
                "erro": str(e)
            }
    
    async def prever_mercado(self, ativo):
        """
        Prevê tendência de mercado
        
        VERIFICA FLAG: state.runtime.PREDICT_MARKET_ENABLED
        - Se False: Retorna None imediatamente
        - Se True: Executa análise e faz previsão
        """
        from state import runtime
        
        # Verificar flag de controle
        if not runtime.PREDICT_MARKET_ENABLED:
            logger.info("⚠️ Prever Mercado: DESABILITADO (flag=False)")
            return {
                "habilitado": False,
                "mensagem": "Função 'Prever Mercado' está desabilitada no momento."
            }
        
        logger.info("✅ Prever Mercado: HABILITADO (flag=True)")
        
        if not self.gemini_client:
            return {
                "habilitado": True,
                "erro": "IA não disponível"
            }
        
        try:
            prompt = f"""Analise e preveja a tendência de mercado para {ativo}.

Forneça:
1. Tendência esperada (alta/baixa/lateral)
2. Nível de confiança
3. Fatores principais
4. Prazo da previsão

Seja breve e objetivo."""

            previsao = await self._call_gemini_with_retry(
                prompt,
                temperature=0.7,
                max_tokens=200
            )
            
            return {
                "habilitado": True,
                "previsao": previsao,
                "ativo": ativo
            }
            
        except Exception as e:
            logger.error(f"❌ Erro ao prever mercado: {e}")
            return {
                "habilitado": True,
                "erro": str(e)
            }
    
    async def decidir_direcao(self, ativo, contexto=None):
        """
        Decide direção de operação (CALL ou PUT)
        
        VERIFICA FLAG: state.runtime.DECIDE_DIRECTION_ENABLED
        - Se False: Retorna None imediatamente
        - Se True: Analisa e sugere direção
        """
        from state import runtime
        
        # Verificar flag de controle
        if not runtime.DECIDE_DIRECTION_ENABLED:
            logger.info("⚠️ Decidir Direção: DESABILITADO (flag=False)")
            return {
                "habilitado": False,
                "mensagem": "Função 'Decidir Direção' está desabilitada no momento."
            }
        
        logger.info("✅ Decidir Direção: HABILITADO (flag=True)")
        
        if not self.gemini_client:
            return {
                "habilitado": True,
                "erro": "IA não disponível"
            }
        
        try:
            contexto_str = ""
            if contexto:
                contexto_str = f"\nContexto adicional: {contexto}"
            
            prompt = f"""Analise {ativo} e decida a direção da operação.{contexto_str}

Responda em formato JSON:
{{
    "direcao": "CALL" ou "PUT",
    "confianca": "alta/média/baixa",
    "motivo": "breve explicação"
}}"""

            decisao = await self._call_gemini_with_retry(
                prompt,
                temperature=0.5,
                max_tokens=150
            )
            
            return {
                "habilitado": True,
                "decisao": decisao,
                "ativo": ativo
            }
            
        except Exception as e:
            logger.error(f"❌ Erro ao decidir direção: {e}")
            return {
                "habilitado": True,
                "erro": str(e)
            }
    
    def _criar_prompt_validacao(self, sinal, contexto):
        """
        Cria prompt RESTRITO para validação de contexto
        Esta função não é afetada pelas flags
        """
        contexto_str = ""
        if contexto:
            if "ativo_aberto" in contexto:
                contexto_str += f"- Ativo aberto: {'Sim' if contexto['ativo_aberto'] else 'Não'}\n"
            if "atraso_execucao" in contexto:
                contexto_str += f"- Atraso de execução: {contexto['atraso_execucao']}s\n"
        
        prompt = f"""Você é um validador de CONTEXTO OPERACIONAL.

SINAL RECEBIDO:
- Par: {sinal['par']}
- Direção solicitada: {sinal['direcao']}
- Expiração: {sinal['tempo_expiracao']}s

CONTEXTO OPERACIONAL:
{contexto_str if contexto_str else "- Nenhum contexto adicional"}

TAREFA:
Avaliar APENAS se o contexto operacional permite execução segura.

NÃO analise tendência.
NÃO preveja mercado.
NÃO sugira estratégia.

RESPONDA APENAS UMA PALAVRA:
- EXECUTAR (se contexto operacional OK)
- IGNORAR (se condições ruins para operar)
- RISCO (se detectar problema grave)

Resposta:"""
        
        return prompt
    
    def desabilitado(self):
        """Verifica se IA Guard está desabilitada"""
        return self.gemini_client is None
