# 🤖 Guia de Integração - Auto Trade

## 📋 Visão Geral

Este guia mostra como integrar a funcionalidade de **Auto Trade** ao seu bot existente.

O Auto Trade permite:
- ✅ Captura automática de sinais reais da API IQ Option
- ✅ Análise de tendências em tempo real
- ✅ Execução automática de trades na conta PRACTICE
- ✅ Notificações em tempo real via Telegram
- ✅ Segurança garantida (apenas conta PRACTICE)

---

## 📁 Arquivos Necessários

Você receberá 4 arquivos:

1. **`auto_trader.py`** - Módulo principal do Auto Trade
2. **`runtime_updated.py`** - Runtime atualizado com flags do Auto Trade
3. **`telegram_bot_extension.py`** - Extensões para o bot Telegram
4. **`main_extension.py`** - Extensões para o main.py

---

## 🔧 Passo a Passo de Integração

### **Passo 1: Adicionar o módulo auto_trader.py**

```bash
# Copie o arquivo auto_trader.py para a pasta core/
cp auto_trader.py bot/core/
```

**Estrutura esperada:**
```
bot/
├── core/
│   ├── auto_trader.py    ← NOVO ARQUIVO
│   ├── iq_client.py
│   ├── trade_executor.py
│   └── ...
```

---

### **Passo 2: Atualizar state/runtime.py**

Substitua o conteúdo de `bot/state/runtime.py` pelo conteúdo de `runtime_updated.py`

**OU** adicione manualmente estas linhas ao arquivo existente:

```python
# Adicionar após a linha 16 (após groq_client = None)

# ======================================
# AUTO TRADER
# Controle do modo de trading automatizado
# ======================================

# Instância do AutoTrader (será preenchida em runtime)
auto_trader = None

# Flag do modo automático
modo_automatico_ativo = False
```

---

### **Passo 3: Atualizar bot/telegram_bot.py**

Abra `bot/bot/telegram_bot.py` e faça as seguintes modificações:

#### **3.1. Adicionar import no início do arquivo (linha ~15)**

```python
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)
import logging
import time  # Adicionar se não existir
```

#### **3.2. Adicionar auto_trader ao __init__ (linha ~23)**

```python
def __init__(self, config, stats, runtime, signal_parser, 
             trade_executor, ia_guard, permissoes):
    self.config = config
    self.stats = stats
    self.runtime = runtime
    self.signal_parser = signal_parser
    self.trade_executor = trade_executor
    self.ia_guard = ia_guard
    self.permissoes = permissoes
    self.iq_client = None
    self.auto_trader = None  # ← ADICIONAR ESTA LINHA

def set_auto_trader(self, auto_trader):  # ← ADICIONAR ESTE MÉTODO
    """Define instância do AutoTrader"""
    self.auto_trader = auto_trader
```

#### **3.3. Atualizar menu_principal() (linha ~41)**

Substitua o método `menu_principal()` por:

```python
def menu_principal(self):
    # Verificar status do modo automático
    from state import runtime
    
    if runtime.auto_trader and runtime.auto_trader.is_ativo():
        auto_status = "🟢 ATIVO"
        auto_data = "toggle_auto_off"
    else:
        auto_status = "⚪ PAUSADO"
        auto_data = "toggle_auto_on"
    
    keyboard = [
        [
            InlineKeyboardButton("⚙️ Configurações", callback_data="config"),
            InlineKeyboardButton("📊 Estatísticas", callback_data="stats")
        ],
        [
            InlineKeyboardButton("📥 Sinais", callback_data="sinais"),
            InlineKeyboardButton("🤖 IA & Governança", callback_data="ia_menu")
        ],
        [
            InlineKeyboardButton(f"🔄 Automático: {auto_status}", callback_data=auto_data),
        ],
        [
            InlineKeyboardButton("💰 Ver Saldo", callback_data="ver_saldo"),
        ],
        [
            InlineKeyboardButton("▶️ Iniciar Bot", callback_data="start_bot"),
            InlineKeyboardButton("⏸️ Pausar Bot", callback_data="pause_bot")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)
```

#### **3.4. Adicionar handlers no button_callback()**

Localize o método `button_callback()` e adicione estes handlers **ANTES** do último `else`:

```python
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AUTO TRADE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

elif query.data == "toggle_auto_on":
    """Ativa modo automático"""
    from state import runtime
    
    if not runtime.auto_trader:
        await query.answer("❌ AutoTrader não inicializado", show_alert=True)
        return
    
    if not self.iq_client or not self.iq_client.esta_conectado():
        await query.answer(
            "❌ IQ Option não conectado!\n"
            "Conecte-se primeiro antes de ativar o modo automático.",
            show_alert=True
        )
        return
    
    # Ativar modo automático
    sucesso = await runtime.auto_trader.ativar(query.message.chat_id)
    
    if sucesso:
        runtime.modo_automatico_ativo = True
        
        await query.edit_message_text(
            "🟢 <b>Modo Automático ATIVADO</b>\n\n"
            "✅ Captura de sinais reais: <b>ATIVA</b>\n"
            "✅ Execução automática: <b>ATIVA</b>\n"
            "✅ Conta: <b>PRACTICE</b>\n\n"
            "📡 O bot está agora capturando sinais da API IQ Option "
            "e executando trades automaticamente na conta PRACTICE.\n\n"
            "🔔 Você receberá notificações de:\n"
            "   • Sinais detectados\n"
            "   • Trades executados\n"
            "   • Resultados das operações\n\n"
            "⚠️ Para desativar, pressione o botão Automático novamente.",
            parse_mode="HTML",
            reply_markup=self.menu_principal()
        )
        
        logger.info(f"✅ Modo automático ativado pelo usuário {query.from_user.id}")
    else:
        await query.answer("❌ Erro ao ativar modo automático", show_alert=True)

elif query.data == "toggle_auto_off":
    """Desativa modo automático"""
    from state import runtime
    
    if not runtime.auto_trader:
        await query.answer("❌ AutoTrader não inicializado", show_alert=True)
        return
    
    # Desativar modo automático
    sucesso = await runtime.auto_trader.desativar()
    
    if sucesso:
        runtime.modo_automatico_ativo = False
        
        await query.edit_message_text(
            "⚪ <b>Modo Automático DESATIVADO</b>\n\n"
            "🛑 Captura de sinais: <b>PAUSADA</b>\n"
            "🛑 Execução automática: <b>PAUSADA</b>\n\n"
            "💡 O bot parou de capturar e executar trades automaticamente.\n\n"
            "📊 Estatísticas da sessão foram salvas.\n\n"
            "✅ Para reativar, pressione o botão Automático novamente.",
            parse_mode="HTML",
            reply_markup=self.menu_principal()
        )
        
        logger.info(f"🛑 Modo automático desativado pelo usuário {query.from_user.id}")
    else:
        await query.answer("❌ Erro ao desativar modo automático", show_alert=True)
```

---

### **Passo 4: Atualizar main.py**

Abra `bot/main.py` e faça estas modificações:

#### **4.1. Adicionar import (linha ~35)**

```python
# Core
from core.iq_client import IQClient
from core.signal_parser import parsear_sinal, validar_sinal
from core.trade_executor import TradeExecutor
from core.scheduler import Scheduler
from core.auto_trader import AutoTrader  # ← ADICIONAR ESTA LINHA
```

#### **4.2. Atualizar função inicializar_sistema() (linha ~73)**

Localize a função `inicializar_sistema()` e adicione o código do AutoTrader:

```python
def inicializar_sistema():
    """Inicializa todos os componentes"""
    logger.info("🚀 Iniciando Bot Q3 IA v3.0 SÊNIOR...")
    
    # IA
    groq_client = inicializar_ia()
    runtime.groq_client = groq_client
    
    # IQ Option
    iq_client = IQClient(EMAIL, SENHA)
    conectado = iq_client.conectar()
    
    if not conectado:
        logger.warning("⚠️ Bot iniciará sem conexão IQ Option")
    
    runtime.iq_connection = iq_client
    
    # Componentes
    trade_executor = TradeExecutor(iq_client)
    ia_guard = IAGuard(groq_client)
    scheduler = Scheduler(CONFIG["tolerancia_agendamento_ms"])
    
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # AUTO TRADER - ADICIONAR ESTE BLOCO
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    auto_trader = AutoTrader(
        iq_client=iq_client,
        trade_executor=trade_executor,
        config=CONFIG,
        stats=stats.STATS
    )
    runtime.auto_trader = auto_trader
    logger.info("✅ AutoTrader inicializado")
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    
    # Bot Telegram
    telegram_bot = TelegramBot(
        config=CONFIG,
        stats=stats.STATS,
        runtime=runtime,
        signal_parser=type('obj', (object,), {'parsear_sinal': parsear_sinal}),
        trade_executor=trade_executor,
        ia_guard=ia_guard,
        permissoes=PERMISSOES
    )
    
    telegram_bot.set_iq_client(iq_client)
    telegram_bot.set_auto_trader(auto_trader)  # ← ADICIONAR ESTA LINHA
    
    return telegram_bot, scheduler, iq_client
```

#### **4.3. Atualizar função main() (adicionar configuração do bot)**

Localize a função `main()` e adicione após criar a aplicação:

```python
async def main():
    """Loop principal"""
    telegram_bot, scheduler, iq_client = inicializar_sistema()
    
    # Criar aplicação Telegram
    app = Application.builder().token(TOKEN).build()
    
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # CONFIGURAR BOT NO AUTO TRADER - ADICIONAR ESTE BLOCO
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    from state import runtime
    if runtime.auto_trader:
        runtime.auto_trader.set_telegram_bot(app.bot)
        logger.info("✅ Bot Telegram configurado no AutoTrader")
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    
    # ... resto do código ...
    
    # No final do try/except, adicionar desativação do AutoTrader:
    except KeyboardInterrupt:
        logger.info("🛑 Encerrando bot...")
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # DESATIVAR AUTO TRADER AO ENCERRAR
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        if runtime.auto_trader and runtime.auto_trader.is_ativo():
            await runtime.auto_trader.desativar()
            logger.info("✅ AutoTrader desativado")
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        await app.updater.stop()
        await app.stop()
        await app.shutdown()
```

---

## ✅ Verificação da Integração

Após fazer todas as modificações, verifique:

1. **Estrutura de arquivos:**
```
bot/
├── core/
│   ├── auto_trader.py     ✓ Novo
│   ├── iq_client.py        ✓
│   ├── trade_executor.py   ✓
│   └── ...
├── state/
│   ├── runtime.py          ✓ Atualizado
│   └── ...
├── bot/
│   ├── telegram_bot.py     ✓ Atualizado
│   └── ...
└── main.py                 ✓ Atualizado
```

2. **Imports adicionados:**
   - `from core.auto_trader import AutoTrader` em main.py ✓
   - `import time` em telegram_bot.py (se não existir) ✓

3. **Código adicionado:**
   - AutoTrader inicializado em runtime ✓
   - Botão Automático no menu principal ✓
   - Handlers toggle_auto_on e toggle_auto_off ✓
   - set_telegram_bot() no auto_trader ✓

---

## 🚀 Testando a Funcionalidade

1. **Inicie o bot:**
```bash
cd bot
python main.py
```

2. **No Telegram:**
   - Digite `/start`
   - Você verá o botão "🔄 Automático: ⚪ PAUSADO"
   - Clique nele para ativar
   - Você deve ver "🟢 ATIVO"

3. **Verificar logs:**
```
✅ AutoTrader inicializado
✅ Bot Telegram configurado no AutoTrader
✅ Modo automático ativado pelo usuário 123456
🔄 Iniciando loop de auto trade...
```

4. **Esperar notificações:**
   - O bot enviará notificações quando detectar sinais
   - Você verá as operações sendo executadas
   - Resultados serão notificados automaticamente

---

## 📊 Funcionalidades Implementadas

✅ **Captura automática de sinais reais**
- Analisa candles em tempo real da API IQ Option
- Identifica tendências de mercado
- Calcula nível de confiança (0-100%)

✅ **Execução automática**
- Trades executados apenas em conta PRACTICE
- Verificação de segurança antes de cada trade
- Monitoramento de resultados

✅ **Notificações em tempo real**
- Sinal detectado
- Trade executado
- Resultado da operação

✅ **Controle via Telegram**
- Botão ON/OFF no menu principal
- Status visual (🟢 ATIVO / ⚪ PAUSADO)
- Feedback imediato

---

## 🔧 Personalização

### Alterar intervalo de verificação

Em `auto_trader.py`, linha 91:
```python
intervalo_verificacao = 5  # segundos (padrão: 5)
```

### Alterar pares analisados

Em `auto_trader.py`, linha 160:
```python
pares_analisar = [
    "EURUSD", "GBPUSD", "USDJPY",  # Principais
    "AUDUSD", "EURJPY", "GBPJPY",  # Secundários
    # Adicione mais pares aqui
]
```

### Alterar nível mínimo de confiança

Em `auto_trader.py`, linha 205:
```python
if melhor_sinal and melhor_sinal["confianca"] >= 60:  # Padrão: 60%
```

### Alterar tempo de expiração

Em `auto_trader.py`, linha 199:
```python
"expiracao": 60,  # segundos (padrão: 60 = M1)
# Opções: 60 (M1), 300 (M5), 900 (M15)
```

---

## ❗ Troubleshooting

### ❌ "AutoTrader não inicializado"
**Solução:** Verifique se adicionou o código de inicialização em `main.py`

### ❌ "IQ Option não conectado"
**Solução:** Verifique credenciais em `state/config.py` e conexão de internet

### ❌ Botão Automático não aparece
**Solução:** Verifique se atualizou o método `menu_principal()` corretamente

### ❌ Sinais não são detectados
**Solução:** Verifique logs, pode ser mercado lateral ou pares fechados

### ❌ Trades não são executados
**Solução:** Verifique se a conta PRACTICE está ativa e com saldo

---

## 📞 Suporte

Se tiver dúvidas ou problemas:

1. Verifique os logs do bot
2. Confira se todos os passos foram seguidos
3. Teste com `/start` para ver o menu atualizado

---

**✅ Integração Completa!**

Agora seu bot possui trading automatizado com captura de sinais reais da API IQ Option! 🚀
