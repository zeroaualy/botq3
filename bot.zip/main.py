"""
Bot Q3 IA v3.0 - Arquitetura Sênior
Executor de sinais em conta PRACTICE com IA Guard

PRINCÍPIOS:
- Separação de responsabilidades
- Segurança PRACTICE obrigatória
- IA como validadora (NÃO estrategista)
- Governança transparente
"""
import asyncio
import logging
from datetime import datetime
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)

# State
from state.config import TOKEN, GRUPO_ID, GROQ_API_KEY, EMAIL, SENHA, CONFIG, PERMISSOES
from state import stats
from state import runtime

# Core
from core.iq_client import IQClient
from core.signal_parser import parsear_sinal, validar_sinal
from core.trade_executor import TradeExecutor
from core.scheduler import Scheduler
from core.auto_trader import AutoTrader

# AI
from ai.ia_guard import IAGuard

# Bot
from bot.telegram_bot import TelegramBot

# Groq
try:
    from groq import Groq
    GROQ_DISPONIVEL = True
except ImportError:
    GROQ_DISPONIVEL = False

# ======================================
# LOGGING
# ======================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ======================================
# INICIALIZAÇÃO
# ======================================
def inicializar_ia():
    """Inicializa cliente IA"""
    if not GROQ_DISPONIVEL:
        logger.error("❌ Groq não instalado")
        return None
    
    try:
        client = Groq(api_key=GROQ_API_KEY)
        logger.info("✅ IA Guard inicializada")
        return client
    except Exception as e:
        logger.error(f"❌ Erro na IA: {e}")
        return None


def inicializar_sistema():
    """Inicializa todos os componentes"""
    logger.info("🚀 Iniciando Bot Q3 IA v3.0 SÊNIOR...")
    
    # IA
    groq_client = inicializar_ia()
    runtime.groq_client = groq_client
    
    # IQ Option
    iq_client = IQClient(EMAIL, SENHA)
    conectado = iq_client.conectar()
    
    if not conectado:
        logger.warning("⚠️ Bot iniciará sem conexão IQ Option")
    
    runtime.iq_connection = iq_client
    
    # Componentes
    trade_executor = TradeExecutor(iq_client)
    ia_guard = IAGuard(groq_client)
    scheduler = Scheduler(CONFIG["tolerancia_agendamento_ms"])
    
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # AUTO TRADER
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    auto_trader = AutoTrader(
        iq_client=iq_client,
        trade_executor=trade_executor,
        config=CONFIG,
        stats=stats.STATS
    )
    runtime.auto_trader = auto_trader
    logger.info("✅ AutoTrader inicializado")
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    
    # Bot Telegram
    telegram_bot = TelegramBot(
        config=CONFIG,
        stats=stats.STATS,
        runtime=runtime,
        signal_parser=type('obj', (object,), {'parsear_sinal': parsear_sinal}),
        trade_executor=trade_executor,
        ia_guard=ia_guard,
        permissoes=PERMISSOES
    )
    telegram_bot.set_iq_client(iq_client)
    telegram_bot.set_auto_trader(auto_trader)
    
    logger.info("✅ Sistema inicializado")
    logger.info("🏦 Configurado para PRACTICE")
    logger.info("🤖 IA Guard: Validadora de contexto")
    logger.info("🔒 Governança: Flags de auditoria ativas")
    
    return telegram_bot, trade_executor, ia_guard, scheduler, iq_client)
    
    return telegram_bot, trade_executor, ia_guard, scheduler, iq_client


# ======================================
# PROCESSADOR DE OPERAÇÕES
# ======================================
async def processar_operacao(app, sinal, trade_executor, ia_guard, iq_client):
    """
    Processa operação completa
    1. Valida contexto com IA (se habilitado)
    2. Executa operação (PRACTICE)
    3. Aguarda resultado
    4. Registra estatísticas
    """
    
    # 1. VALIDAÇÃO DE CONTEXTO COM IA
    if CONFIG["ia_validar_contexto"] and not ia_guard.desabilitado():
        await app.bot.send_message(GRUPO_ID, "🤖 IA Guard validando contexto...")
        
        # Contexto operacional básico
        contexto = {
            "ativo_aberto": True,  # Simplificado - poderia verificar com iq_client
        }
        
        decisao = await ia_guard.validar_contexto(sinal, contexto)
        stats.registrar_decisao_ia(decisao)
        
        if decisao == "IGNORAR":
            await app.bot.send_message(
                GRUPO_ID,
                f"❌ <b>IA Guard: IGNORAR</b>\n\n"
                f"📊 {sinal['par']} {sinal['direcao']}\n"
                f"Condições operacionais desfavoráveis",
                parse_mode="HTML"
            )
            return
        
        elif decisao == "RISCO":
            await app.bot.send_message(
                GRUPO_ID,
                f"⚠️ <b>IA Guard: RISCO ALTO</b>\n\n"
                f"📊 {sinal['par']} {sinal['direcao']}\n"
                f"Operação cancelada por segurança",
                parse_mode="HTML"
            )
            return
        
        await app.bot.send_message(GRUPO_ID, "✅ IA Guard: Contexto OK")
    
    # 2. EXECUTAR OPERAÇÃO
    valor = CONFIG["valor_entrada"]
    
    saldo_antes = iq_client.obter_saldo()
    tipo_conta = iq_client.obter_tipo_conta()
    
    await app.bot.send_message(
        GRUPO_ID,
        f"💰 <b>PRÉ-OPERAÇÃO</b>\n\n"
        f"🏦 Conta: {tipo_conta}\n"
        f"💵 Saldo: ${saldo_antes:.2f}\n"
        f"📊 Par: {sinal['par']}\n"
        f"📈 Direção: {sinal['direcao']}\n"
        f"⏱️ Expiração: {sinal['tempo_expiracao']}s\n"
        f"🕐 Horário: {datetime.now().strftime('%H:%M:%S')}",
        parse_mode="HTML"
    )
    
    status, order_id = trade_executor.executar(
        sinal["par"],
        sinal["direcao"],
        valor,
        sinal["tempo_expiracao"]
    )
    
    if not status:
        await app.bot.send_message(
            GRUPO_ID,
            "❌ <b>FALHA NA OPERAÇÃO</b>\n\n"
            "Possíveis causas:\n"
            "• Ativo fechado\n"
            "• Horário fora do expediente\n"
            "• Problema de conexão\n"
            "• Tente -OTC",
            parse_mode="HTML"
        )
        return
    
    await app.bot.send_message(
        GRUPO_ID,
        f"🎯 <b>OPERAÇÃO EXECUTADA</b>\n\n"
        f"🏦 Conta: PRACTICE ✅\n"
        f"📊 Par: {sinal['par']}\n"
        f"📈 Direção: {sinal['direcao']}\n"
        f"💰 Valor: ${valor}\n"
        f"⏱️ Expiração: {sinal['tempo_expiracao']}s\n"
        f"🆔 ID: {order_id}\n"
        f"🕐 Executado: {datetime.now().strftime('%H:%M:%S')}",
        parse_mode="HTML"
    )
    
    # 3. AGUARDAR RESULTADO
    await app.bot.send_message(
        GRUPO_ID,
        f"⏳ Aguardando {sinal['tempo_expiracao']}s..."
    )
    
    await asyncio.sleep(sinal["tempo_expiracao"] + 5)
    
    resultado, lucro = trade_executor.verificar_resultado(order_id)
    
    # 4. REGISTRAR ESTATÍSTICAS
    stats.registrar_operacao(resultado, valor, lucro)
    
    if resultado == "WIN":
        emoji = "✅"
    elif resultado == "LOSS":
        emoji = "❌"
    elif resultado == "EMPATE":
        emoji = "⚪"
    else:
        emoji = "⚠️"
    
    winrate = stats.obter_winrate()
    saldo_depois = iq_client.obter_saldo()
    diferenca = saldo_depois - saldo_antes
    
    await app.bot.send_message(
        GRUPO_ID,
        f"{emoji} <b>RESULTADO: {resultado}</b>\n\n"
        f"🏦 Conta: PRACTICE ✅\n"
        f"💰 Lucro op: ${lucro:.2f}\n"
        f"💵 Antes: ${saldo_antes:.2f}\n"
        f"💵 Depois: ${saldo_depois:.2f}\n"
        f"📊 Diferença: ${diferenca:.2f}\n\n"
        f"📈 <b>Resumo:</b>\n"
        f"├ Lucro dia: ${stats.STATS['lucro_dia']:.2f}\n"
        f"├ Win Rate: {winrate:.1f}%\n"
        f"└ Ops: {stats.STATS['vitorias']}W / {stats.STATS['derrotas']}L / {stats.STATS['empates']}E\n\n"
        f"🤖 <b>IA Guard:</b>\n"
        f"└ Exec: {stats.STATS['ia_decisoes']['executar']} | "
        f"Ignor: {stats.STATS['ia_decisoes']['ignorar']} | "
        f"Risco: {stats.STATS['ia_decisoes']['risco']}",
        parse_mode="HTML"
    )


# ======================================
# LOOP AUTOMÁTICO
# ======================================
async def loop_auto(app, scheduler, trade_executor, ia_guard, iq_client):
    """Loop principal - executa sinais e monitora stops"""
    
    while True:
        try:
            # Verificar sinais prontos
            sinais_prontos = scheduler.verificar_sinais_prontos(runtime.sinais_agendados)
            
            for sinal in sinais_prontos:
                runtime.remover_sinal(sinal)
                
                if CONFIG["operar_automatico"]:
                    await app.bot.send_message(
                        GRUPO_ID,
                        f"⏰ <b>Executando sinal agendado</b>\n\n"
                        f"📊 {sinal['par']} {sinal['direcao']}\n"
                        f"🕐 Previsto: {sinal['horario'].strftime('%H:%M:%S')}\n"
                        f"🕐 Real: {datetime.now().strftime('%H:%M:%S')}",
                        parse_mode="HTML"
                    )
                    await processar_operacao(app, sinal, trade_executor, ia_guard, iq_client)
                else:
                    logger.warning(f"⚠️ Bot pausado - sinal {sinal['par']} não executado")
            
            # Verificar Stop Loss
            if stats.STATS["lucro_dia"] <= -CONFIG["stop_loss"]:
                if CONFIG["operar_automatico"]:
                    CONFIG["operar_automatico"] = False
                    await app.bot.send_message(
                        GRUPO_ID,
                        f"🛑 <b>STOP LOSS ATINGIDO!</b>\n\n"
                        f"Perda: ${abs(stats.STATS['lucro_dia']):.2f}\n"
                        f"Limite: ${CONFIG['stop_loss']:.2f}\n"
                        f"Bot pausado automaticamente.\n\n"
                        f"🏦 Conta: PRACTICE ✅",
                        parse_mode="HTML"
                    )
            
            # Verificar Stop Gain
            if stats.STATS["lucro_dia"] >= CONFIG["stop_gain"]:
                if CONFIG["operar_automatico"]:
                    CONFIG["operar_automatico"] = False
                    await app.bot.send_message(
                        GRUPO_ID,
                        f"🎯 <b>STOP GAIN ATINGIDO!</b>\n\n"
                        f"Lucro: ${stats.STATS['lucro_dia']:.2f}\n"
                        f"Meta: ${CONFIG['stop_gain']:.2f}\n"
                        f"Bot pausado automaticamente.\n\n"
                        f"🏦 Conta: PRACTICE ✅",
                        parse_mode="HTML"
                    )
            
            await asyncio.sleep(1)
            
        except asyncio.CancelledError:
            logger.info("Loop automático cancelado")
            break
        except Exception as e:
            logger.error(f"Erro no loop: {e}")
            import traceback
            logger.error(traceback.format_exc())
            await asyncio.sleep(5)


# ======================================
# MAIN
# ======================================
def main():
    """Ponto de entrada"""
    
    # Inicializar componentes
    telegram_bot, trade_executor, ia_guard, scheduler, iq_client = inicializar_sistema()
    
    # Criar aplicação Telegram
    app = Application.builder().token(TOKEN).build()
    
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # CONFIGURAR BOT NO AUTO TRADER
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    from state import runtime
    if runtime.auto_trader:
        runtime.auto_trader.set_telegram_bot(app.bot)
        logger.info("✅ Bot Telegram configurado no AutoTrader")
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    
    # Handlers
    app.add_handler(CommandHandler("start", telegram_bot.start))
    app.add_handler(CallbackQueryHandler(telegram_bot.button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, telegram_bot.mensagem))
    
    # Post-init e shutdown
    async def post_init(application):
        task = asyncio.create_task(loop_auto(application, scheduler, trade_executor, ia_guard, iq_client))
        application.bot_data['loop_task'] = task
        logger.info("🤖 Bot rodando - Sistema autônomo ativo")
    
    async def post_shutdown(application):
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # DESATIVAR AUTO TRADER AO ENCERRAR
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        from state import runtime
        if runtime.auto_trader and runtime.auto_trader.is_ativo():
            await runtime.auto_trader.desativar()
            logger.info("✅ AutoTrader desativado")
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        if 'loop_task' in application.bot_data:
            application.bot_data['loop_task'].cancel()
            try:
                await application.bot_data['loop_task']
            except asyncio.CancelledError:
                pass
    
    app.post_init = post_init
    app.post_shutdown = post_shutdown
    
    logger.info("=" * 50)
    logger.info("🚀 Bot Q3 IA v3.0 SÊNIOR pronto!")
    logger.info("🏗️ Arquitetura modular implementada")
    logger.info("🔒 Segurança PRACTICE obrigatória")
    logger.info("🤖 IA Guard: Validadora (NÃO estrategista)")
    logger.info("📊 Governança transparente")
    logger.info("=" * 50)
    
    app.run_polling()


if __name__ == "__main__":
    main()
