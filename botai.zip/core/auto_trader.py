"""
Módulo de Auto Trade
Captura automática de sinais reais e execução de trades
"""
import asyncio
import logging
from datetime import datetime
from telegram import Bot

logger = logging.getLogger(__name__)


class AutoTrader:
    """
    Gerenciador de trading automatizado
    Captura sinais reais da API e executa trades automaticamente
    """
    
    def __init__(self, iq_client, trade_executor, config, stats):
        """
        Inicializa o AutoTrader
        
        Args:
            iq_client: Cliente IQ Option para capturar dados do mercado
            trade_executor: Executor de trades
            config: Configurações do bot
            stats: Estatísticas de operações
        """
        self.iq_client = iq_client
        self.trade_executor = trade_executor
        self.config = config
        self.stats = stats
        self.modo_auto_ativo = False
        self.task_auto_trade = None
        self.telegram_bot_instance = None
        self.chat_id = None
        
    def set_telegram_bot(self, bot_instance):
        """Define instância do bot Telegram para notificações"""
        self.telegram_bot_instance = bot_instance
    
    def is_ativo(self):
        """Verifica se o modo automático está ativo"""
        return self.modo_auto_ativo
    
    async def ativar(self, chat_id):
        """
        Ativa o modo automático
        
        Args:
            chat_id: ID do chat para enviar notificações
            
        Returns:
            bool: True se ativado com sucesso
        """
        if self.modo_auto_ativo:
            logger.warning("⚠️ Modo automático já está ativo")
            return False
        
        if not self.iq_client or not self.iq_client.esta_conectado():
            logger.error("❌ IQ Option não está conectado")
            return False
        
        self.modo_auto_ativo = True
        self.chat_id = chat_id
        logger.info("✅ Modo automático ATIVADO")
        
        # Iniciar task de captura e execução
        self.task_auto_trade = asyncio.create_task(
            self._loop_auto_trade()
        )
        
        return True
    
    async def desativar(self):
        """
        Desativa o modo automático
        
        Returns:
            bool: True se desativado com sucesso
        """
        if not self.modo_auto_ativo:
            logger.warning("⚠️ Modo automático já está desativado")
            return False
        
        self.modo_auto_ativo = False
        logger.info("🛑 Modo automático DESATIVADO")
        
        # Cancelar task
        if self.task_auto_trade and not self.task_auto_trade.done():
            self.task_auto_trade.cancel()
            try:
                await self.task_auto_trade
            except asyncio.CancelledError:
                logger.info("✅ Task de auto trade cancelada com sucesso")
        
        return True
    
    async def _loop_auto_trade(self):
        """
        Loop principal de auto trade
        Captura sinais reais da API e executa trades automaticamente
        """
        logger.info("🔄 Iniciando loop de auto trade...")
        
        # Intervalo de verificação (em segundos)
        intervalo_verificacao = 5
        
        try:
            while self.modo_auto_ativo:
                try:
                    # Garantir que está em conta PRACTICE
                    if not self.iq_client.garantir_practice():
                        logger.error("❌ Falha na verificação PRACTICE - pausando auto trade")
                        await self._enviar_notificacao(
                            "⚠️ <b>Auto Trade Pausado</b>\n\n"
                            "Falha na verificação da conta PRACTICE.\n"
                            "Verifique a conexão e reative o modo automático."
                        )
                        break
                    
                    # Capturar sinal real da API
                    sinal = await self._captura_sinal_real()
                    
                    if sinal and sinal.get("valido"):
                        logger.info(f"📡 Sinal capturado: {sinal['par']} {sinal['acao']} ({sinal['confianca']}% confiança)")
                        
                        # Executar trade automaticamente
                        await self._executar_trade_auto(sinal)
                    
                    # Aguardar antes da próxima verificação
                    await asyncio.sleep(intervalo_verificacao)
                    
                except asyncio.CancelledError:
                    logger.info("⏹️ Loop de auto trade cancelado")
                    break
                    
                except Exception as e:
                    logger.error(f"❌ Erro no loop de auto trade: {e}")
                    import traceback
                    logger.error(traceback.format_exc())
                    
                    # Aguardar um pouco antes de tentar novamente
                    await asyncio.sleep(intervalo_verificacao)
        
        finally:
            logger.info("🏁 Loop de auto trade finalizado")
    
    async def _captura_sinal_real(self):
        """
        Captura sinais reais da API IQ Option
        
        Analisa:
        - Candles em tempo real
        - Volume de negociação
        - Tendências de mercado
        - Indicadores técnicos
        
        Returns:
            dict ou None: Sinal capturado com formato:
                {
                    "valido": bool,
                    "par": str,
                    "acao": str,  # "CALL" ou "PUT"
                    "expiracao": int,
                    "confianca": int,  # 0-100
                    "analise": str
                }
        """
        try:
            # Lista de pares principais para análise
            pares_analisar = [
                "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", 
                "EURJPY", "GBPJPY", "USDCAD", "NZDUSD"
            ]
            
            melhor_sinal = None
            maior_confianca = 0
            
            for par in pares_analisar:
                try:
                    # Verificar se ativo está disponível
                    disponivel, par_final = self.iq_client.verificar_ativo_disponivel(par)
                    if not disponivel:
                        continue
                    
                    # Obter candles recentes (últimos 60 segundos, velas de 1 segundo)
                    candles = self.iq_client.iq.get_candles(par_final, 1, 60, time.time())
                    
                    if not candles or len(candles) < 10:
                        continue
                    
                    # Analisar tendência com base nos candles
                    analise = self._analisar_tendencia(candles, par_final)
                    
                    if analise["confianca"] > maior_confianca:
                        maior_confianca = analise["confianca"]
                        melhor_sinal = {
                            "valido": True,
                            "par": par_final,
                            "acao": analise["direcao"],
                            "expiracao": 60,  # 1 minuto (M1)
                            "confianca": analise["confianca"],
                            "analise": analise["descricao"]
                        }
                
                except Exception as e:
                    logger.debug(f"Erro ao analisar {par}: {e}")
                    continue
            
            # Retornar apenas sinais com confiança mínima de 60%
            if melhor_sinal and melhor_sinal["confianca"] >= 60:
                return melhor_sinal
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Erro na captura de sinais: {e}")
            return None
    
    def _analisar_tendencia(self, candles, par):
        """
        Analisa tendência do mercado com base nos candles
        
        Estratégia simples baseada em:
        - Direção das últimas velas
        - Força da tendência
        - Volume relativo
        
        Args:
            candles: Lista de candles da API
            par: Nome do par analisado
            
        Returns:
            dict: {
                "direcao": "CALL" ou "PUT",
                "confianca": int (0-100),
                "descricao": str
            }
        """
        try:
            # Analisar as últimas 10 velas
            ultimas_10 = candles[-10:]
            
            # Contar velas de alta (CALL) e baixa (PUT)
            velas_call = 0
            velas_put = 0
            
            for candle in ultimas_10:
                if candle["close"] > candle["open"]:
                    velas_call += 1
                elif candle["close"] < candle["open"]:
                    velas_put += 1
            
            # Calcular força da tendência
            total_velas = len(ultimas_10)
            
            if velas_call > velas_put:
                # Tendência de alta
                confianca = int((velas_call / total_velas) * 100)
                return {
                    "direcao": "CALL",
                    "confianca": confianca,
                    "descricao": f"Tendência de alta detectada ({velas_call}/{total_velas} velas)"
                }
            elif velas_put > velas_call:
                # Tendência de baixa
                confianca = int((velas_put / total_velas) * 100)
                return {
                    "direcao": "PUT",
                    "confianca": confianca,
                    "descricao": f"Tendência de baixa detectada ({velas_put}/{total_velas} velas)"
                }
            else:
                # Mercado lateral - sem sinal
                return {
                    "direcao": "NEUTRO",
                    "confianca": 0,
                    "descricao": "Mercado lateral, sem tendência clara"
                }
        
        except Exception as e:
            logger.error(f"Erro na análise de tendência: {e}")
            return {
                "direcao": "ERRO",
                "confianca": 0,
                "descricao": f"Erro na análise: {e}"
            }
    
    async def _executar_trade_auto(self, sinal):
        """
        Executa trade automaticamente com base no sinal capturado
        
        Args:
            sinal: Dicionário com dados do sinal
        """
        try:
            # Notificar sobre o sinal
            await self._enviar_notificacao(
                f"🎯 <b>Sinal Detectado - Auto Trade</b>\n\n"
                f"📊 Par: <b>{sinal['par']}</b>\n"
                f"📈 Direção: <b>{sinal['acao']}</b>\n"
                f"⏱️ Expiração: <b>{sinal['expiracao']}s</b>\n"
                f"🎲 Confiança: <b>{sinal['confianca']}%</b>\n"
                f"💡 Análise: {sinal['analise']}\n\n"
                f"⚡ Executando trade automaticamente..."
            )
            
            # Executar trade
            par = sinal["par"]
            acao = sinal["acao"]
            expiracao = sinal["expiracao"]
            valor = self.config["valor_entrada"]
            
            logger.info(f"💰 Executando: {par} {acao} ${valor} {expiracao}s")
            
            sucesso, order_id = self.trade_executor.executar(
                par=par,
                direcao=acao,
                valor=valor,
                expiracao=expiracao
            )
            
            if sucesso:
                # Atualizar estatísticas
                self.stats["total_operacoes"] += 1
                
                # Aguardar resultado
                await asyncio.sleep(expiracao + 3)
                
                resultado, valor_resultado = self.trade_executor.verificar_resultado(order_id)
                
                # Atualizar estatísticas com resultado
                if resultado == "WIN":
                    self.stats["wins"] += 1
                    self.stats["lucro_total"] += valor_resultado
                    emoji = "✅"
                    mensagem_resultado = f"WIN - Lucro: ${valor_resultado:.2f}"
                elif resultado == "LOSS":
                    self.stats["losses"] += 1
                    self.stats["lucro_total"] -= valor_resultado
                    emoji = "❌"
                    mensagem_resultado = f"LOSS - Perda: ${valor_resultado:.2f}"
                else:
                    emoji = "⚪"
                    mensagem_resultado = resultado
                
                # Notificar resultado
                await self._enviar_notificacao(
                    f"{emoji} <b>Resultado - Auto Trade</b>\n\n"
                    f"📊 {par} {acao}\n"
                    f"🎲 {mensagem_resultado}\n"
                    f"💰 Saldo: ${self.iq_client.obter_saldo():.2f}\n"
                    f"📈 Total operações: {self.stats['total_operacoes']}"
                )
            else:
                logger.error(f"❌ Falha ao executar trade")
                await self._enviar_notificacao(
                    f"❌ <b>Erro na Execução</b>\n\n"
                    f"Não foi possível executar o trade.\n"
                    f"Verifique o log para mais detalhes."
                )
        
        except Exception as e:
            logger.error(f"❌ Erro ao executar trade auto: {e}")
            import traceback
            logger.error(traceback.format_exc())
    
    async def _enviar_notificacao(self, mensagem):
        """
        Envia notificação para o usuário via Telegram
        
        Args:
            mensagem: Texto da mensagem em HTML
        """
        if not self.telegram_bot_instance or not self.chat_id:
            logger.warning("⚠️ Bot Telegram não configurado para notificações")
            return
        
        try:
            await self.telegram_bot_instance.send_message(
                chat_id=self.chat_id,
                text=mensagem,
                parse_mode="HTML"
            )
        except Exception as e:
            logger.error(f"❌ Erro ao enviar notificação: {e}")
