"""
Q3 IA Beta - Camada de Inteligência Estratégica

OBJETIVO:
- Filtro Estratégico Inteligente
- Controlador Adaptativo de Risco
- Otimizador Estatístico de Performance
- Camada de Proteção Avançada

IMPORTANTE:
- NÃO transforma IA em geradora de sinais
- NÃO permite que IA decida CALL ou PUT diretamente
- NÃO cria previsão mística de mercado
- Mantém obrigatoriamente conta PRACTICE
"""
import logging
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple
import json
import os

logger = logging.getLogger(__name__)


class Q3IABeta:
    """
    Q3 IA Beta - Sistema de Filtro Estratégico e Score Inteligente
    
    Fluxo:
    Sinal → Motor Determinístico → Q3 IA Beta (Score) → Risk Manager → Executor
    """
    
    def __init__(self, stats_optimizer):
        """
        Inicializa Q3 IA Beta
        
        Args:
            stats_optimizer: Instância do otimizador estatístico
        """
        self.stats_optimizer = stats_optimizer
        self.config = {
            "score_minimo": 5,  # Score mínimo para aprovar trade
            "score_alto_risco": 2,  # Score abaixo disso é alto risco
            "payout_minimo": 75,  # Payout mínimo aceitável (%)
            "winrate_minimo": 55,  # Winrate mínimo do ativo (%)
            "max_perdas_consecutivas": 3,  # Máximo de perdas seguidas
            "volatilidade_maxima": 2.0,  # Volatilidade máxima aceitável
        }
        logger.info("✅ Q3 IA Beta inicializada")
    
    async def avaliar_sinal(
        self,
        sinal: Dict,
        contexto: Dict,
        payout: float = 80.0
    ) -> Tuple[str, int, Dict]:
        """
        Avalia um sinal e retorna decisão baseada em score
        
        Args:
            sinal: Sinal a ser avaliado
            contexto: Contexto operacional
            payout: Payout oferecido (%)
        
        Returns:
            Tuple[str, int, Dict]: (decisao, score, analise_detalhada)
                - decisao: "APROVAR", "REJEITAR", "ALTO_RISCO"
                - score: Pontuação final
                - analise_detalhada: Breakdown do score
        """
        logger.info(f"🔍 Q3 IA Beta avaliando sinal: {sinal['par']} {sinal['direcao']}")
        
        # Calcular score
        score = 0
        analise = {
            "componentes": {},
            "fatores_positivos": [],
            "fatores_negativos": [],
            "recomendacoes": []
        }
        
        # ═══════════════════════════════════════════════════════════
        # 1. ANÁLISE DE TENDÊNCIA MULTI-TIMEFRAME
        # ═══════════════════════════════════════════════════════════
        tendencia_score, tendencia_info = await self._avaliar_tendencia(
            sinal, contexto
        )
        score += tendencia_score
        analise["componentes"]["tendencia"] = tendencia_score
        if tendencia_score > 0:
            analise["fatores_positivos"].append(tendencia_info)
        else:
            analise["fatores_negativos"].append(tendencia_info)
        
        # ═══════════════════════════════════════════════════════════
        # 2. ANÁLISE DE VOLATILIDADE
        # ═══════════════════════════════════════════════════════════
        volatilidade_score, volatilidade_info = await self._avaliar_volatilidade(
            sinal, contexto
        )
        score += volatilidade_score
        analise["componentes"]["volatilidade"] = volatilidade_score
        if volatilidade_score > 0:
            analise["fatores_positivos"].append(volatilidade_info)
        elif volatilidade_score < 0:
            analise["fatores_negativos"].append(volatilidade_info)
        
        # ═══════════════════════════════════════════════════════════
        # 3. SEQUÊNCIA DE PERDAS RECENTES
        # ═══════════════════════════════════════════════════════════
        perdas_score, perdas_info = await self._avaliar_sequencia_perdas()
        score += perdas_score
        analise["componentes"]["sequencia_perdas"] = perdas_score
        if perdas_score < 0:
            analise["fatores_negativos"].append(perdas_info)
        
        # ═══════════════════════════════════════════════════════════
        # 4. HORÁRIO DO DIA
        # ═══════════════════════════════════════════════════════════
        horario_score, horario_info = await self._avaliar_horario()
        score += horario_score
        analise["componentes"]["horario"] = horario_score
        if horario_score > 0:
            analise["fatores_positivos"].append(horario_info)
        else:
            analise["fatores_negativos"].append(horario_info)
        
        # ═══════════════════════════════════════════════════════════
        # 5. PAYOUT
        # ═══════════════════════════════════════════════════════════
        payout_score, payout_info = self._avaliar_payout(payout)
        score += payout_score
        analise["componentes"]["payout"] = payout_score
        if payout_score > 0:
            analise["fatores_positivos"].append(payout_info)
        else:
            analise["fatores_negativos"].append(payout_info)
        
        # ═══════════════════════════════════════════════════════════
        # 6. PERFORMANCE HISTÓRICA DO ATIVO
        # ═══════════════════════════════════════════════════════════
        performance_score, performance_info = await self._avaliar_performance_ativo(
            sinal['par']
        )
        score += performance_score
        analise["componentes"]["performance_ativo"] = performance_score
        if performance_score > 0:
            analise["fatores_positivos"].append(performance_info)
        elif performance_score < 0:
            analise["fatores_negativos"].append(performance_info)
        
        # ═══════════════════════════════════════════════════════════
        # 7. WINRATE POR HORÁRIO
        # ═══════════════════════════════════════════════════════════
        winrate_horario_score, winrate_info = await self._avaliar_winrate_horario()
        score += winrate_horario_score
        analise["componentes"]["winrate_horario"] = winrate_horario_score
        if winrate_horario_score > 0:
            analise["fatores_positivos"].append(winrate_info)
        elif winrate_horario_score < 0:
            analise["fatores_negativos"].append(winrate_info)
        
        # ═══════════════════════════════════════════════════════════
        # 8. ÚLTIMAS 5 OPERAÇÕES
        # ═══════════════════════════════════════════════════════════
        ultimas_ops_score, ultimas_info = await self._avaliar_ultimas_operacoes()
        score += ultimas_ops_score
        analise["componentes"]["ultimas_operacoes"] = ultimas_ops_score
        if ultimas_ops_score > 0:
            analise["fatores_positivos"].append(ultimas_info)
        elif ultimas_ops_score < 0:
            analise["fatores_negativos"].append(ultimas_info)
        
        # ═══════════════════════════════════════════════════════════
        # DECISÃO FINAL
        # ═══════════════════════════════════════════════════════════
        analise["score_total"] = score
        
        if score >= self.config["score_minimo"]:
            decisao = "APROVAR"
            logger.info(f"✅ Q3 IA Beta: APROVAR (score: {score})")
        elif score <= self.config["score_alto_risco"]:
            decisao = "ALTO_RISCO"
            analise["recomendacoes"].append(
                "Score muito baixo - condições desfavoráveis"
            )
            logger.warning(f"⚠️ Q3 IA Beta: ALTO_RISCO (score: {score})")
        else:
            decisao = "REJEITAR"
            analise["recomendacoes"].append(
                f"Score insuficiente (mínimo: {self.config['score_minimo']})"
            )
            logger.info(f"❌ Q3 IA Beta: REJEITAR (score: {score})")
        
        return decisao, score, analise
    
    async def _avaliar_tendencia(
        self, sinal: Dict, contexto: Dict
    ) -> Tuple[int, str]:
        """
        Avalia alinhamento de tendência
        
        Returns:
            Tuple[int, str]: (score, info)
        """
        # Verificar se há dados de tendência no contexto
        if "tendencia_alinhada" in contexto:
            if contexto["tendencia_alinhada"]:
                return 2, "Tendência multi-timeframe alinhada"
            else:
                return -1, "Tendências conflitantes detectadas"
        
        # Se não houver dados, score neutro
        return 0, "Sem dados de tendência disponíveis"
    
    async def _avaliar_volatilidade(
        self, sinal: Dict, contexto: Dict
    ) -> Tuple[int, str]:
        """
        Avalia volatilidade do ativo
        
        Returns:
            Tuple[int, str]: (score, info)
        """
        if "volatilidade" in contexto:
            volatilidade = contexto["volatilidade"]
            
            if volatilidade < 0.5:
                return 1, f"Volatilidade baixa ideal ({volatilidade:.2f})"
            elif volatilidade < self.config["volatilidade_maxima"]:
                return 0, f"Volatilidade moderada ({volatilidade:.2f})"
            else:
                return -2, f"Volatilidade extrema detectada ({volatilidade:.2f})"
        
        return 0, "Volatilidade não disponível"
    
    async def _avaliar_sequencia_perdas(self) -> Tuple[int, str]:
        """
        Avalia sequência de perdas consecutivas
        
        Returns:
            Tuple[int, str]: (score, info)
        """
        perdas_consecutivas = self.stats_optimizer.obter_perdas_consecutivas()
        
        if perdas_consecutivas == 0:
            return 1, "Sem perdas consecutivas"
        elif perdas_consecutivas < self.config["max_perdas_consecutivas"]:
            return 0, f"{perdas_consecutivas} perdas consecutivas (dentro do limite)"
        else:
            penalidade = -perdas_consecutivas
            return penalidade, f"⚠️ {perdas_consecutivas} perdas consecutivas - alto risco"
    
    async def _avaliar_horario(self) -> Tuple[int, str]:
        """
        Avalia se é bom horário para operar
        
        Returns:
            Tuple[int, str]: (score, info)
        """
        agora = datetime.now()
        hora = agora.hour
        
        # Horários fortes: 8h-11h, 13h-16h, 19h-22h (horários de maior liquidez)
        horarios_fortes = [
            (8, 11), (13, 16), (19, 22)
        ]
        
        for inicio, fim in horarios_fortes:
            if inicio <= hora <= fim:
                return 1, f"Horário de alta liquidez ({hora}h)"
        
        # Horários fracos
        return -1, f"Horário de baixa liquidez ({hora}h)"
    
    def _avaliar_payout(self, payout: float) -> Tuple[int, str]:
        """
        Avalia payout oferecido
        
        Returns:
            Tuple[int, str]: (score, info)
        """
        if payout >= 85:
            return 2, f"Payout excelente ({payout}%)"
        elif payout >= self.config["payout_minimo"]:
            return 1, f"Payout bom ({payout}%)"
        else:
            return -1, f"Payout baixo ({payout}%)"
    
    async def _avaliar_performance_ativo(self, par: str) -> Tuple[int, str]:
        """
        Avalia performance histórica do ativo
        
        Returns:
            Tuple[int, str]: (score, info)
        """
        stats = self.stats_optimizer.obter_stats_ativo(par)
        
        if stats and stats["total_operacoes"] >= 10:
            winrate = stats["winrate"]
            
            if winrate >= 65:
                return 2, f"Winrate excelente no ativo ({winrate:.1f}%)"
            elif winrate >= self.config["winrate_minimo"]:
                return 1, f"Winrate bom no ativo ({winrate:.1f}%)"
            else:
                return -1, f"Winrate baixo no ativo ({winrate:.1f}%)"
        
        return 0, "Sem histórico suficiente do ativo"
    
    async def _avaliar_winrate_horario(self) -> Tuple[int, str]:
        """
        Avalia winrate no horário atual
        
        Returns:
            Tuple[int, str]: (score, info)
        """
        hora = datetime.now().hour
        stats = self.stats_optimizer.obter_stats_horario(hora)
        
        if stats and stats["total_operacoes"] >= 5:
            winrate = stats["winrate"]
            
            if winrate >= 65:
                return 1, f"Winrate excelente neste horário ({winrate:.1f}%)"
            elif winrate >= self.config["winrate_minimo"]:
                return 0, f"Winrate médio neste horário ({winrate:.1f}%)"
            else:
                return -1, f"Winrate baixo neste horário ({winrate:.1f}%)"
        
        return 0, "Sem histórico suficiente neste horário"
    
    async def _avaliar_ultimas_operacoes(self) -> Tuple[int, str]:
        """
        Avalia resultado das últimas 5 operações
        
        Returns:
            Tuple[int, str]: (score, info)
        """
        ultimas = self.stats_optimizer.obter_ultimas_operacoes(5)
        
        if not ultimas:
            return 0, "Sem operações recentes"
        
        wins = sum(1 for op in ultimas if op.get("resultado") == "WIN")
        total = len(ultimas)
        
        if wins >= 4:
            return 1, f"Excelente performance recente ({wins}/{total} wins)"
        elif wins >= 3:
            return 0, f"Performance média recente ({wins}/{total} wins)"
        else:
            return -1, f"Performance ruim recente ({wins}/{total} wins)"
    
    def atualizar_config(self, novos_valores: Dict):
        """
        Atualiza configurações do Q3 IA Beta
        
        Args:
            novos_valores: Dicionário com novos valores
        """
        self.config.update(novos_valores)
        logger.info(f"⚙️ Q3 IA Beta config atualizada: {novos_valores}")
    
    def obter_config(self) -> Dict:
        """
        Retorna configuração atual
        
        Returns:
            Dict: Configuração atual
        """
        return self.config.copy()
