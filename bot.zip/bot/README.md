# Bot Q3 IA v3.0 - Arquitetura Sênior

## 🎯 Propósito

Executor de sinais de trading em conta **PRACTICE** (demo) com validação de contexto por IA.

**O BOT NÃO É:**
- ❌ Robô estrategista
- ❌ Prevedor de mercado
- ❌ Tomador de decisões de CALL/PUT
- ❌ Gerador autônomo de sinais

**O BOT É:**
- ✅ Executor de sinais externos
- ✅ Agendador preciso de operações
- ✅ Validador de contexto operacional
- ✅ Sistema de governança transparente

---

## 🏗️ Arquitetura

```
/bot_refatorado
├── main.py                    # Ponto de entrada
├── state/                     # Estado e configurações
│   ├── config.py             # Configurações e permissões
│   ├── stats.py              # Estatísticas e métricas
│   └── runtime.py            # Estado mutável (sinais, flags)
├── core/                      # Lógica de negócio
│   ├── iq_client.py          # Cliente IQ Option + segurança PRACTICE
│   ├── signal_parser.py      # Parser de múltiplos formatos
│   ├── trade_executor.py     # Executor seguro de operações
│   └── scheduler.py          # Agendamento preciso
├── ai/                        # Inteligência Artificial
│   └── ia_guard.py           # Validador de contexto (NÃO estrategista)
└── bot/                       # Interface Telegram
    └── telegram_bot.py        # Menus e handlers
```

---

## 🔒 Segurança PRACTICE

### Múltiplas Camadas de Proteção

1. **Conexão Inicial**: Força PRACTICE ao conectar
2. **Verificação Pré-Operação**: `garantir_practice()` antes de TODA operação
3. **Logs Claros**: Registra tipo de conta em cada etapa
4. **Aborto Automático**: Cancela operação se não confirmar PRACTICE

```python
# Exemplo de fluxo seguro
def executar_operacao():
    if not garantir_practice():
        logger.error("OPERAÇÃO ABORTADA")
        return False
    # ... executa apenas se PRACTICE confirmado
```

---

## 🤖 Papel da IA

### IA Guard - Validador de Contexto

**O QUE FAZ:**
- Valida se contexto operacional permite execução segura
- Bloqueia operações em condições extremas
- Avalia risco operacional (não direcional)

**O QUE NÃO FAZ:**
- ❌ Criar estratégias
- ❌ Prever movimentos de mercado
- ❌ Decidir CALL ou PUT
- ❌ Gerar sinais sozinha

**Respostas Possíveis:**
- `EXECUTAR`: Contexto OK
- `IGNORAR`: Condições ruins
- `RISCO`: Problema grave detectado

---

## 🔐 Sistema de Governança

### Flags de Permissão (Auditoria)

O bot possui flags de governança que **NÃO habilitam funcionalidade**:

```python
PERMISSOES = {
    "ia_pode_criar_estrategia": False,   # Flag visual apenas
    "ia_pode_prever_mercado": False,     # Flag visual apenas
    "ia_pode_decidir_direcao": False,    # Flag visual apenas
}
```

**Propósito:**
- ✓ Transparência
- ✓ Auditoria
- ✓ Documentação de travas

**CRÍTICO:**
Mesmo com permissão `True`, o código **BLOQUEIA** comportamento proibido.

---

## 📋 Formatos de Sinais Aceitos

### 1. Formato Estruturado
```
ATIVO: EURUSD
DIREÇÃO: CALL
TIMEFRAME: 1M
HORÁRIO: 14:32
```

### 2. Formato com Horário
```
M5 EURUSD CALL 14:30
```

### 3. Formato Imediato
```
M5 EURUSD CALL
EURUSD PUT
```

---

## ⚙️ Configurações

### Operacionais
- `operar_automatico`: Execução automática de sinais
- `valor_entrada`: Valor por operação ($)
- `martingale`: Progressão de valor (desabilitado)

### Proteção
- `stop_loss`: Limite de perda diária ($)
- `stop_gain`: Meta de lucro diária ($)

### IA
- `ia_validar_contexto`: Ativar IA Guard

### Agendamento
- `tolerancia_agendamento_ms`: Tolerância para execução (ms)

---

## 📊 Estatísticas Rastreadas

- Total de operações
- Vitórias / Derrotas / Empates
- Lucro acumulado do dia
- Win Rate
- Decisões da IA (Executar/Ignorar/Risco)

---

## 🚀 Como Usar

### 1. Instalação
```bash
pip install python-telegram-bot iqoptionapi groq
```

### 2. Execução
```bash
python main.py
```

### 3. Telegram
- Envie `/start` no bot
- Use os menus para configurar
- Envie sinais no formato aceito

---

## 🔍 Fluxo de Operação

```
Sinal Recebido
    ↓
Parser (valida formato)
    ↓
Agendamento (se horário futuro)
    ↓
Scheduler (verifica hora exata)
    ↓
IA Guard (valida contexto) [opcional]
    ↓
Garantir PRACTICE (CRÍTICO)
    ↓
Executar Operação
    ↓
Aguardar Expiração
    ↓
Verificar Resultado
    ↓
Registrar Estatísticas
```

---

## 🛡️ Proteções Implementadas

1. **Conta PRACTICE**: Verificação obrigatória
2. **Stop Loss**: Pausa automática
3. **Stop Gain**: Pausa automática
4. **Validação de Sinais**: Formato e campos obrigatórios
5. **IA Guard**: Bloqueio de condições extremas
6. **Logs Auditáveis**: Rastreamento completo

---

## 📝 Princípios de Design

### Separação de Responsabilidades
Cada módulo tem papel único e bem definido.

### Segurança em Camadas
Múltiplas verificações de PRACTICE.

### Governança Transparente
Flags explícitas de permissão.

### Manutenibilidade
Código modular e documentado.

### Previsibilidade
Comportamento consistente e auditável.

---

## ⚠️ Avisos Importantes

1. **IA Limitada**: A IA NÃO cria estratégias nem prevê mercado
2. **Apenas PRACTICE**: Bot configurado para conta demo
3. **Sinais Externos**: Bot não gera sinais sozinho
4. **Permissões são Flags**: Não habilitam funcionalidade real
5. **Responsabilidade**: Use por sua conta e risco

---

## 📞 Suporte

Este é um projeto educacional de arquitetura de software.

**Não oferecemos:**
- ❌ Sinais de trading
- ❌ Consultoria financeira
- ❌ Garantias de lucro

**Oferecemos:**
- ✅ Código bem estruturado
- ✅ Documentação clara
- ✅ Exemplos de boas práticas

---

## 📄 Licença

Código fornecido como exemplo educacional.
Uso por conta e risco do usuário.

---

## 🎓 Aprendizados

Este projeto demonstra:
- Arquitetura modular em Python
- Separação de responsabilidades
- Segurança em camadas
- Governança de sistemas autônomos
- Uso responsável de IA
- Documentação de código sênior
