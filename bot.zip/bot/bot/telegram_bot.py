"""
Bot Telegram
Interface de controle e governança
"""
import asyncio
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)
import logging

logger = logging.getLogger(__name__)


class TelegramBot:
    """Bot Telegram com controle de governança"""
    
    def __init__(self, config, stats, runtime, signal_parser, 
                 trade_executor, ia_guard, permissoes):
        self.config = config
        self.stats = stats
        self.runtime = runtime
        self.signal_parser = signal_parser
        self.trade_executor = trade_executor
        self.ia_guard = ia_guard
        self.permissoes = permissoes
        self.iq_client = None
        self.auto_trader = None
        
    def set_iq_client(self, iq_client):
        """Define cliente IQ Option"""
        self.iq_client = iq_client
    
    def set_auto_trader(self, auto_trader):
        """Define instância do AutoTrader"""
        self.auto_trader = auto_trader
    
    # ======================================
    # MENUS
    # ======================================
    def menu_principal(self):
        # Verificar status do modo automático
        from state import runtime
        
        if runtime.auto_trader and runtime.auto_trader.is_ativo():
            auto_status = "🟢 ATIVO"
            auto_data = "toggle_auto_off"
        else:
            auto_status = "⚪ PAUSADO"
            auto_data = "toggle_auto_on"
        
        # Verificar status da Automação de Sinais
        if runtime.signal_engine and runtime.signal_engine.is_ativo():
            automacao_status = "🟢 ATIVADO"
            automacao_data = "toggle_automacao_off"
        else:
            automacao_status = "⚪ DESATIVADO"
            automacao_data = "toggle_automacao_on"
        
        keyboard = [
            [
                InlineKeyboardButton("⚙️ Configurações", callback_data="config"),
                InlineKeyboardButton("📊 Estatísticas", callback_data="stats")
            ],
            [
                InlineKeyboardButton("📥 Sinais", callback_data="sinais"),
                InlineKeyboardButton("🤖 IA & Governança", callback_data="ia_menu")
            ],
            [
                InlineKeyboardButton(f"🔄 Automático: {auto_status}", callback_data=auto_data),
            ],
            [
                InlineKeyboardButton(f"🧠 Automação de Sinais: {automacao_status}", callback_data=automacao_data),
            ],
            [
                InlineKeyboardButton("💰 Ver Saldo", callback_data="ver_saldo"),
            ],
            [
                InlineKeyboardButton("▶️ Iniciar Bot", callback_data="start_bot"),
                InlineKeyboardButton("⏸️ Pausar Bot", callback_data="pause_bot")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def menu_config(self):
        """
        Menu de Configurações
        Permite ajustar todos os parâmetros operacionais
        """
        auto = "✅ ATIVO" if self.config["operar_automatico"] else "❌ INATIVO"
        martingale = "✅ ATIVO" if self.config["martingale"] else "❌ INATIVO"
        
        keyboard = [
            [InlineKeyboardButton("━━━ OPERAÇÃO ━━━", callback_data="info_config")],
            [InlineKeyboardButton(f"{auto} Operação Automática", callback_data="toggle_auto")],
            [InlineKeyboardButton(f"{martingale} Martingale", callback_data="toggle_martingale")],
            [InlineKeyboardButton("━━━ VALORES ━━━", callback_data="info_valores")],
            [InlineKeyboardButton(f"💰 Valor Entrada: ${self.config['valor_entrada']}", callback_data="edit_valor_entrada")],
            [InlineKeyboardButton(f"🛑 Stop Loss: ${self.config['stop_loss']}", callback_data="edit_stop_loss")],
            [InlineKeyboardButton(f"🎯 Stop Gain: ${self.config['stop_gain']}", callback_data="edit_stop_gain")],
            [InlineKeyboardButton("━━━━━━━━━━━━━━━━", callback_data="info_sep")],
            [InlineKeyboardButton("❓ Explicar Configurações", callback_data="explicar_config")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def menu_ia_governanca(self):
        """
        Menu IA com controle REAL de funcionalidades
        
        As flags em state/runtime.py controlam o comportamento real:
        - CREATE_STRATEGY_ENABLED: Permite IA criar estratégias
        - PREDICT_MARKET_ENABLED: Permite IA prever mercado
        - DECIDE_DIRECTION_ENABLED: Permite IA decidir CALL/PUT
        
        Os botões alteram essas flags em tempo real.
        """
        validar = "✅" if self.config["ia_validar_contexto"] else "❌"
        
        # Importar flags de runtime
        from state import runtime
        
        # Indicadores de estado (✅ ativado / ❌ desativado)
        criar_estrategia = "✅" if runtime.CREATE_STRATEGY_ENABLED else "❌"
        prever_mercado = "✅" if runtime.PREDICT_MARKET_ENABLED else "❌"
        decidir_direcao = "✅" if runtime.DECIDE_DIRECTION_ENABLED else "❌"
        
        keyboard = [
            [InlineKeyboardButton("━━━ VALIDAÇÃO BÁSICA ━━━", callback_data="info_validacao")],
            [InlineKeyboardButton(f"{validar} Validar Contexto (IA Guard)", callback_data="toggle_ia_validar")],
            [InlineKeyboardButton("━━━ FUNÇÕES AVANÇADAS DA IA ━━━", callback_data="info_funcoes")],
            [InlineKeyboardButton(f"{criar_estrategia} Criar Estratégia", callback_data="toggle_criar_estrategia")],
            [InlineKeyboardButton(f"{prever_mercado} Prever Mercado", callback_data="toggle_prever_mercado")],
            [InlineKeyboardButton(f"{decidir_direcao} Decidir Direção", callback_data="toggle_decidir_direcao")],
            [InlineKeyboardButton("━━━━━━━━━━━━━━━━━━━━━━", callback_data="info_separador")],
            [InlineKeyboardButton("🧪 Testar Criar Estratégia", callback_data="test_criar_estrategia")],
            [InlineKeyboardButton("🔮 Testar Prever Mercado", callback_data="test_prever_mercado")],
            [InlineKeyboardButton("🎯 Testar Decidir Direção", callback_data="test_decidir_direcao")],
            [InlineKeyboardButton("❓ Sobre as Funções", callback_data="info_sobre_funcoes")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def menu_sinais(self):
        """
        Menu de Gerenciamento de Sinais
        Controla captura, lista e formatos aceitos
        """
        captura = "✅ ATIVA" if self.runtime.captura_sinais_ativa else "❌ PAUSADA"
        qtd_sinais = self.runtime.quantidade_sinais()
        
        keyboard = [
            [InlineKeyboardButton(f"📡 Captura: {captura}", callback_data="toggle_captura")],
            [InlineKeyboardButton(f"📋 Sinais Agendados ({qtd_sinais})", callback_data="listar_sinais")],
            [InlineKeyboardButton("🗑️ Limpar Todos os Sinais", callback_data="limpar_sinais")],
            [InlineKeyboardButton("━━━━━━━━━━━━━━━━", callback_data="info_sep2")],
            [InlineKeyboardButton("📝 Formatos Aceitos", callback_data="formatos_sinal")],
            [InlineKeyboardButton("💡 Como Enviar Sinais", callback_data="tutorial_sinais")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    # ======================================
    # HANDLERS
    # ======================================
    async def start(self, update: Update, context):
        """
        Comando /start - Apresentação completa do bot
        Mostra status do sistema e explicação de cada menu
        """
        status_iq = "✅ Conectado" if self.iq_client and self.iq_client.esta_conectado() else "❌ Desconectado"
        status_ia = "✅ Ativa" if not self.ia_guard.desabilitado() else "❌ Inativa"
        
        saldo_msg = ""
        if self.iq_client and self.iq_client.esta_conectado():
            try:
                saldo = await self.iq_client.obter_saldo()
                tipo = self.iq_client.obter_tipo_conta()
                saldo_msg = f"└ 💰 Saldo {tipo}: ${saldo:.2f}"
            except:
                pass
        
        mensagem = f"""
🤖 <b>Bot Q3 IA v3.0 - Trading Automatizado</b>

Bem-vindo ao seu assistente de trading com Inteligência Artificial!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 <b>STATUS DO SISTEMA</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

├ 🔌 IQ Option: {status_iq}
├ 🤖 IA Guard: {status_ia}
├ 📥 Sinais agendados: {self.runtime.quantidade_sinais()}
{saldo_msg}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📖 <b>MENU PRINCIPAL</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚙️ <b>Configurações</b>
   Configure valores de entrada, stop loss/gain,
   martingale e outros parâmetros operacionais.

📊 <b>Estatísticas</b>
   Acompanhe seu desempenho: operações,
   win rate, lucro/prejuízo acumulado.

📥 <b>Sinais</b>
   Gerencie sinais de entrada: agende operações,
   veja pendências e aprenda os formatos aceitos.

🤖 <b>IA & Funções Avançadas</b>
   Controle as capacidades da IA: validação
   de contexto, criação de estratégias, previsões
   e decisões de direção.

💰 <b>Ver Saldo</b>
   Consulte saldo atual e tipo de conta
   (PRACTICE ou REAL).

▶️ <b>Iniciar Bot</b> / ⏸️ <b>Pausar Bot</b>
   Ative/desative a execução automática
   de operações agendadas.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 <b>COMO USAR</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣ Configure seus parâmetros em ⚙️ Configurações
2️⃣ Envie sinais no formato aceito ou use 📥 Sinais
3️⃣ Ative o bot com ▶️ Iniciar Bot
4️⃣ Acompanhe resultados em 📊 Estatísticas

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 <b>FORMATOS DE SINAL</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

<code>M5 EURUSD CALL 14:30</code> → Agendado
<code>EURUSD PUT</code> → Imediato
<code>ATIVO: EURUSD
DIREÇÃO: CALL
TIMEFRAME: 1M
HORÁRIO: 14:30</code> → Estruturado

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️ <b>IMPORTANTE</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• Este bot opera em conta <b>PRACTICE</b> (demo)
• Sinais devem ser enviados manualmente
• IA valida contexto, não cria sinais sozinha
• Use stop loss/gain para proteção

━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👇 <b>Use os botões abaixo para começar</b>
        """
        
        await update.message.reply_text(
            mensagem,
            parse_mode="HTML",
            reply_markup=self.menu_principal()
        )
    
    async def button_handler(self, update: Update, context):
        """Handler de botões"""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        
        # Menu principal
        if data == "menu":
            await query.edit_message_text(
                "🤖 <b>Menu Principal</b>",
                parse_mode="HTML",
                reply_markup=self.menu_principal()
            )
        
        # Ver saldo
        elif data == "ver_saldo":
            if not self.iq_client or not self.iq_client.esta_conectado():
                await query.edit_message_text(
                    "❌ Sem conexão IQ Option",
                    reply_markup=self.menu_principal()
                )
                return
            
            saldo = await self.iq_client.obter_saldo()
            tipo = self.iq_client.obter_tipo_conta()
            
            await query.edit_message_text(
                f"💰 <b>Informações da Conta</b>\n\n"
                f"Tipo: {tipo}\n"
                f"Saldo: ${saldo:.2f}\n\n"
                f"{'✅ PRACTICE (seguro)' if tipo == 'PRACTICE' else '⚠️ ATENÇÃO: REAL!'}",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("◀️ Voltar", callback_data="menu")
                ]])
            )
        
        # Configurações
        elif data == "config":
            await query.edit_message_text(
                "⚙️ <b>Configurações do Bot</b>\n\n"
                "Ajuste os parâmetros operacionais para\n"
                "otimizar seu trading automatizado.\n\n"
                "💡 Clique em cada item para editar.",
                parse_mode="HTML",
                reply_markup=self.menu_config()
            )
        
        elif data == "toggle_auto":
            self.config["operar_automatico"] = not self.config["operar_automatico"]
            status = "✅ ATIVADA" if self.config["operar_automatico"] else "❌ DESATIVADA"
            await query.edit_message_text(
                f"🤖 <b>Operação Automática: {status}</b>\n\n"
                f"{'O bot agora executará sinais automaticamente quando agendados.' if self.config['operar_automatico'] else 'O bot não executará sinais automaticamente. Você precisa confirmar cada operação manualmente.'}\n\n"
                "<b>O que é Operação Automática?</b>\n"
                "Quando ativa, o bot executa sinais agendados\n"
                "automaticamente no horário programado.\n\n"
                "Quando inativa, você precisa aprovar\n"
                "cada operação manualmente.",
                parse_mode="HTML",
                reply_markup=self.menu_config()
            )
        
        elif data == "toggle_martingale":
            self.config["martingale"] = not self.config["martingale"]
            status = "✅ ATIVADO" if self.config["martingale"] else "❌ DESATIVADO"
            await query.edit_message_text(
                f"📊 <b>Martingale: {status}</b>\n\n"
                f"{'⚠️ ATENÇÃO: Martingale aumenta o valor após perdas!' if self.config['martingale'] else 'Martingale desativado. Valor fixo em todas operações.'}\n\n"
                "<b>O que é Martingale?</b>\n"
                "Estratégia que dobra o valor de entrada\n"
                "após cada perda, visando recuperar\n"
                "prejuízos com uma vitória.\n\n"
                "⚠️ <b>Risco:</b> Pode esgotar saldo rapidamente\n"
                "em sequências de perdas.",
                parse_mode="HTML",
                reply_markup=self.menu_config()
            )
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # EDIÇÃO DE VALORES
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        elif data == "edit_valor_entrada":
            from state import runtime
            user_id = query.from_user.id
            runtime.editing_state[user_id] = "valor_entrada"
            
            await query.edit_message_text(
                f"💰 <b>Editar Valor de Entrada</b>\n\n"
                f"Valor atual: <b>${self.config['valor_entrada']}</b>\n\n"
                "Digite o novo valor desejado (apenas o número).\n"
                "Exemplo: <code>5</code> ou <code>10.50</code>\n\n"
                "💡 Valor mínimo recomendado: $2\n"
                "💡 Valor máximo recomendado: $100\n\n"
                "⚠️ Certifique-se de ter saldo suficiente!",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("❌ Cancelar", callback_data="config")
                ]])
            )
        
        elif data == "edit_stop_loss":
            from state import runtime
            user_id = query.from_user.id
            runtime.editing_state[user_id] = "stop_loss"
            
            await query.edit_message_text(
                f"🛑 <b>Editar Stop Loss</b>\n\n"
                f"Valor atual: <b>${self.config['stop_loss']}</b>\n\n"
                "Digite o novo limite de perda diária.\n"
                "Exemplo: <code>20</code> ou <code>50.00</code>\n\n"
                "💡 Stop Loss protege seu saldo de perdas excessivas.\n"
                "Quando atingido, o bot pausa automaticamente.\n\n"
                "⚠️ Defina um valor compatível com seu saldo!",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("❌ Cancelar", callback_data="config")
                ]])
            )
        
        elif data == "edit_stop_gain":
            from state import runtime
            user_id = query.from_user.id
            runtime.editing_state[user_id] = "stop_gain"
            
            await query.edit_message_text(
                f"🎯 <b>Editar Stop Gain</b>\n\n"
                f"Valor atual: <b>${self.config['stop_gain']}</b>\n\n"
                "Digite a nova meta de lucro diária.\n"
                "Exemplo: <code>50</code> ou <code>100.00</code>\n\n"
                "💡 Stop Gain garante que você realize lucros.\n"
                "Quando atingido, o bot pausa automaticamente.\n\n"
                "⚠️ Seja realista com suas metas!",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("❌ Cancelar", callback_data="config")
                ]])
            )
        
        elif data == "explicar_config":
            await query.edit_message_text(
                "📚 <b>Explicação das Configurações</b>\n\n"
                "<b>💰 Valor de Entrada</b>\n"
                "Quantia investida em cada operação.\n"
                "Ex: $5 por trade.\n\n"
                "<b>🛑 Stop Loss</b>\n"
                "Limite de perda diária. Ao atingir,\n"
                "bot pausa para proteger seu capital.\n"
                "Ex: Parar ao perder $20.\n\n"
                "<b>🎯 Stop Gain</b>\n"
                "Meta de lucro diária. Ao atingir,\n"
                "bot pausa para garantir ganhos.\n"
                "Ex: Parar ao lucrar $50.\n\n"
                "<b>🤖 Operação Automática</b>\n"
                "Executa sinais agendados automaticamente\n"
                "sem necessidade de confirmação manual.\n\n"
                "<b>📊 Martingale</b>\n"
                "Dobra valor após perdas para recuperar.\n"
                "⚠️ Alto risco! Use com cautela.",
                parse_mode="HTML",
                reply_markup=self.menu_config()
            )
        
        # IA e Governança
        elif data == "ia_menu":
            await query.edit_message_text(
                "🤖 <b>IA Guard & Funções Avançadas</b>\n\n"
                "<b>Validação Básica:</b>\n"
                "• Validar Contexto: Verifica condições operacionais\n\n"
                "<b>Funções Avançadas (controláveis):</b>\n"
                "• Criar Estratégia: IA analisa e sugere estratégias\n"
                "• Prever Mercado: IA prevê tendências\n"
                "• Decidir Direção: IA sugere CALL ou PUT\n\n"
                "💡 Use os botões para ativar/desativar cada função.",
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        elif data == "toggle_ia_validar":
            self.config["ia_validar_contexto"] = not self.config["ia_validar_contexto"]
            status = "ativada" if self.config["ia_validar_contexto"] else "desativada"
            await query.edit_message_text(
                f"✅ Validação de contexto {status}",
                reply_markup=self.menu_ia_governanca()
            )
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # CONTROLE REAL DAS FUNÇÕES DA IA
        # Estes handlers alteram as flags em state/runtime.py
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        elif data == "toggle_criar_estrategia":
            """
            Altera flag CREATE_STRATEGY_ENABLED em runtime.py
            Controla se IA pode criar estratégias de trading
            """
            from state import runtime
            
            runtime.CREATE_STRATEGY_ENABLED = not runtime.CREATE_STRATEGY_ENABLED
            status = "✅ ATIVADA" if runtime.CREATE_STRATEGY_ENABLED else "❌ DESATIVADA"
            
            await query.edit_message_text(
                f"🤖 <b>Criar Estratégia: {status}</b>\n\n"
                f"{'A IA agora PODE criar estratégias de trading.' if runtime.CREATE_STRATEGY_ENABLED else 'A IA NÃO PODE criar estratégias de trading.'}\n\n"
                "<b>O que esta função faz:</b>\n"
                "• Analisa ativos e timeframes\n"
                "• Sugere pontos de entrada/saída\n"
                "• Define stop loss e take profit\n"
                "• Cria plano de gestão de risco\n\n"
                f"<b>Estado atual:</b> {status}\n\n"
                "Use 'Testar Criar Estratégia' para experimentar.",
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        elif data == "toggle_prever_mercado":
            """
            Altera flag PREDICT_MARKET_ENABLED em runtime.py
            Controla se IA pode fazer previsões de mercado
            """
            from state import runtime
            
            runtime.PREDICT_MARKET_ENABLED = not runtime.PREDICT_MARKET_ENABLED
            status = "✅ ATIVADA" if runtime.PREDICT_MARKET_ENABLED else "❌ DESATIVADA"
            
            await query.edit_message_text(
                f"🔮 <b>Prever Mercado: {status}</b>\n\n"
                f"{'A IA agora PODE prever tendências de mercado.' if runtime.PREDICT_MARKET_ENABLED else 'A IA NÃO PODE prever tendências de mercado.'}\n\n"
                "<b>O que esta função faz:</b>\n"
                "• Analisa tendências (alta/baixa/lateral)\n"
                "• Avalia nível de confiança\n"
                "• Identifica fatores principais\n"
                "• Estima prazo da previsão\n\n"
                f"<b>Estado atual:</b> {status}\n\n"
                "Use 'Testar Prever Mercado' para experimentar.",
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        elif data == "toggle_decidir_direcao":
            """
            Altera flag DECIDE_DIRECTION_ENABLED em runtime.py
            Controla se IA pode decidir direção (CALL/PUT)
            """
            from state import runtime
            
            runtime.DECIDE_DIRECTION_ENABLED = not runtime.DECIDE_DIRECTION_ENABLED
            status = "✅ ATIVADA" if runtime.DECIDE_DIRECTION_ENABLED else "❌ DESATIVADA"
            
            await query.edit_message_text(
                f"🎯 <b>Decidir Direção: {status}</b>\n\n"
                f"{'A IA agora PODE decidir entre CALL ou PUT.' if runtime.DECIDE_DIRECTION_ENABLED else 'A IA NÃO PODE decidir entre CALL ou PUT.'}\n\n"
                "<b>O que esta função faz:</b>\n"
                "• Analisa ativo atual\n"
                "• Decide CALL (compra) ou PUT (venda)\n"
                "• Informa nível de confiança\n"
                "• Explica motivo da decisão\n\n"
                f"<b>Estado atual:</b> {status}\n\n"
                "Use 'Testar Decidir Direção' para experimentar.",
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # TESTES DAS FUNÇÕES DA IA
        # Permitem testar cada função individualmente
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        elif data == "test_criar_estrategia":
            """
            Testa função criar_estrategia() da IA
            Respeita flag CREATE_STRATEGY_ENABLED
            """
            await query.edit_message_text("🧪 Testando Criar Estratégia...")
            
            resultado = await self.ia_guard.criar_estrategia("EURUSD", "M5")
            
            if not resultado.get("habilitado"):
                await query.edit_message_text(
                    f"❌ <b>Função Desabilitada</b>\n\n"
                    f"{resultado.get('mensagem')}\n\n"
                    "Para ativar, clique em:\n"
                    "✅ Criar Estratégia",
                    parse_mode="HTML",
                    reply_markup=self.menu_ia_governanca()
                )
            elif "erro" in resultado:
                await query.edit_message_text(
                    f"❌ <b>Erro</b>\n\n{resultado['erro']}",
                    parse_mode="HTML",
                    reply_markup=self.menu_ia_governanca()
                )
            else:
                await query.edit_message_text(
                    f"✅ <b>Estratégia Criada</b>\n\n"
                    f"<b>Ativo:</b> {resultado['ativo']}\n"
                    f"<b>Timeframe:</b> {resultado['timeframe']}\n\n"
                    f"{resultado['estrategia'][:500]}...",
                    parse_mode="HTML",
                    reply_markup=self.menu_ia_governanca()
                )
        
        elif data == "test_prever_mercado":
            """
            Testa função prever_mercado() da IA
            Respeita flag PREDICT_MARKET_ENABLED
            """
            await query.edit_message_text("🔮 Testando Prever Mercado...")
            
            resultado = await self.ia_guard.prever_mercado("EURUSD")
            
            if not resultado.get("habilitado"):
                await query.edit_message_text(
                    f"❌ <b>Função Desabilitada</b>\n\n"
                    f"{resultado.get('mensagem')}\n\n"
                    "Para ativar, clique em:\n"
                    "✅ Prever Mercado",
                    parse_mode="HTML",
                    reply_markup=self.menu_ia_governanca()
                )
            elif "erro" in resultado:
                await query.edit_message_text(
                    f"❌ <b>Erro</b>\n\n{resultado['erro']}",
                    parse_mode="HTML",
                    reply_markup=self.menu_ia_governanca()
                )
            else:
                await query.edit_message_text(
                    f"✅ <b>Previsão de Mercado</b>\n\n"
                    f"<b>Ativo:</b> {resultado['ativo']}\n\n"
                    f"{resultado['previsao'][:500]}",
                    parse_mode="HTML",
                    reply_markup=self.menu_ia_governanca()
                )
        
        elif data == "test_decidir_direcao":
            """
            Testa função decidir_direcao() da IA
            Respeita flag DECIDE_DIRECTION_ENABLED
            """
            await query.edit_message_text("🎯 Testando Decidir Direção...")
            
            resultado = await self.ia_guard.decidir_direcao("EURUSD")
            
            if not resultado.get("habilitado"):
                await query.edit_message_text(
                    f"❌ <b>Função Desabilitada</b>\n\n"
                    f"{resultado.get('mensagem')}\n\n"
                    "Para ativar, clique em:\n"
                    "✅ Decidir Direção",
                    parse_mode="HTML",
                    reply_markup=self.menu_ia_governanca()
                )
            elif "erro" in resultado:
                await query.edit_message_text(
                    f"❌ <b>Erro</b>\n\n{resultado['erro']}",
                    parse_mode="HTML",
                    reply_markup=self.menu_ia_governanca()
                )
            else:
                await query.edit_message_text(
                    f"✅ <b>Decisão de Direção</b>\n\n"
                    f"<b>Ativo:</b> {resultado['ativo']}\n\n"
                    f"{resultado['decisao'][:500]}",
                    parse_mode="HTML",
                    reply_markup=self.menu_ia_governanca()
                )
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # INFORMAÇÕES SOBRE AS FUNÇÕES
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        elif data == "info_sobre_funcoes":
            from state import runtime
            
            criar = "✅ ATIVA" if runtime.CREATE_STRATEGY_ENABLED else "❌ INATIVA"
            prever = "✅ ATIVA" if runtime.PREDICT_MARKET_ENABLED else "❌ INATIVA"
            decidir = "✅ ATIVA" if runtime.DECIDE_DIRECTION_ENABLED else "❌ INATIVA"
            
            await query.edit_message_text(
                "📚 <b>Sobre as Funções da IA</b>\n\n"
                "<b>1️⃣ Criar Estratégia</b> " + criar + "\n"
                "Analisa mercado e cria planos completos de trading.\n\n"
                "<b>2️⃣ Prever Mercado</b> " + prever + "\n"
                "Prevê tendências futuras com base em análise.\n\n"
                "<b>3️⃣ Decidir Direção</b> " + decidir + "\n"
                "Decide se deve comprar (CALL) ou vender (PUT).\n\n"
                "━━━━━━━━━━━━━━━━━━━━\n\n"
                "<b>Como funciona:</b>\n"
                "• Clique no botão para ativar/desativar\n"
                "• Use 'Testar' para experimentar\n"
                "• Funções desabilitadas retornam mensagem informativa\n\n"
                "<b>⚠️ Importante:</b>\n"
                "As funções são controladas por flags em <code>state/runtime.py</code>\n"
                "Cada função verifica sua flag antes de executar.",
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        # Sinais
        elif data == "sinais":
            await query.edit_message_text(
                "📡 <b>Gerenciamento de Sinais</b>\n\n"
                "Configure e gerencie seus sinais de trading.\n\n"
                "<b>📡 Captura:</b> Ativa/desativa recepção de sinais\n"
                "<b>📋 Agendados:</b> Lista sinais na fila\n"
                "<b>📝 Formatos:</b> Veja formatos aceitos\n"
                "<b>💡 Tutorial:</b> Aprenda a enviar sinais\n\n"
                f"Sinais atuais: <b>{self.runtime.quantidade_sinais()}</b>",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "toggle_captura":
            self.runtime.captura_sinais_ativa = not self.runtime.captura_sinais_ativa
            status = "✅ ATIVADA" if self.runtime.captura_sinais_ativa else "❌ PAUSADA"
            await query.edit_message_text(
                f"📡 <b>Captura de Sinais: {status}</b>\n\n"
                f"{'O bot agora aceita novos sinais enviados.' if self.runtime.captura_sinais_ativa else 'O bot NÃO aceita novos sinais no momento.'}\n\n"
                "<b>O que é Captura de Sinais?</b>\n"
                "Quando ativa, o bot reconhece e agenda\n"
                "sinais que você enviar no chat.\n\n"
                "Quando pausada, sinais enviados são ignorados.",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "listar_sinais":
            from zoneinfo import ZoneInfo
            FUSO_SP = ZoneInfo("America/Sao_Paulo")
            
            sinais = self.runtime.obter_sinais_pendentes()
            if not sinais:
                await query.edit_message_text(
                    "📭 <b>Nenhum sinal agendado</b>\n\n"
                    "Você ainda não tem sinais na fila de execução.\n\n"
                    "💡 Envie um sinal no formato aceito para agendar.",
                    parse_mode="HTML",
                    reply_markup=self.menu_sinais()
                )
                return
            
            agora_sp = datetime.now(FUSO_SP)
            
            lista = f"📋 <b>Sinais Agendados</b>\n\n"
            lista += f"🕐 Horário atual SP: {agora_sp.strftime('%H:%M:%S')}\n\n"
            
            for i, s in enumerate(sinais[:10], 1):
                # Garantir que horário está em SP
                if s['horario'].tzinfo is None:
                    horario_sinal = s['horario'].replace(tzinfo=FUSO_SP)
                else:
                    horario_sinal = s['horario'].astimezone(FUSO_SP)
                
                tempo_restante = (horario_sinal - agora_sp).total_seconds()
                
                if tempo_restante < 0:
                    tempo_str = "⚠️ ATRASADO"
                elif tempo_restante < 60:
                    tempo_str = f"{int(tempo_restante)}s"
                elif tempo_restante < 3600:
                    tempo_str = f"{int(tempo_restante/60)}min"
                else:
                    tempo_str = f"{int(tempo_restante/3600)}h{int((tempo_restante%3600)/60)}min"
                
                lista += f"{i}. <b>{s['par']}</b> {s['direcao']} "
                lista += f"• {horario_sinal.strftime('%H:%M:%S')} "
                lista += f"<code>({tempo_str})</code>\n"
            
            if len(sinais) > 10:
                lista += f"\n... e mais <b>{len(sinais) - 10}</b> sinais"
            
            lista += f"\n\n<b>Total:</b> {len(sinais)} sinal(is) agendado(s)"
            
            await query.edit_message_text(
                lista,
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "limpar_sinais":
            qtd = self.runtime.quantidade_sinais()
            self.runtime.limpar_sinais()
            await query.edit_message_text(
                f"🗑️ <b>Sinais Removidos</b>\n\n"
                f"Foram removidos <b>{qtd}</b> sinal(is) da fila.\n\n"
                "A fila está agora vazia.",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "formatos_sinal":
            await query.edit_message_text(
                "📝 <b>Formatos de Sinal Aceitos</b>\n\n"
                "<b>1️⃣ Formato Estruturado:</b>\n"
                "<code>ATIVO: EURUSD\n"
                "DIREÇÃO: CALL\n"
                "TIMEFRAME: 1M\n"
                "HORÁRIO: 14:30</code>\n\n"
                "<b>2️⃣ Formato com Horário:</b>\n"
                "<code>M5 EURUSD CALL 14:30</code>\n\n"
                "<b>3️⃣ Formato Imediato:</b>\n"
                "<code>M5 EURUSD CALL</code>\n"
                "<code>EURUSD PUT</code>\n\n"
                "━━━━━━━━━━━━━━━━━━━━\n\n"
                "<b>📌 Dicas:</b>\n"
                "• Use CALL para compra, PUT para venda\n"
                "• M1, M5, M15 = timeframe em minutos\n"
                "• Sem horário = execução imediata\n"
                "• Com horário = execução agendada",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "tutorial_sinais":
            await query.edit_message_text(
                "💡 <b>Tutorial: Como Enviar Sinais</b>\n\n"
                "<b>Passo 1:</b> Ative a captura de sinais\n"
                "Menu → Sinais → 📡 Captura\n\n"
                "<b>Passo 2:</b> Envie o sinal no formato aceito\n"
                "Exemplo: <code>EURUSD CALL 14:30</code>\n\n"
                "<b>Passo 3:</b> Confirme o agendamento\n"
                "O bot mostrará tempo até execução\n\n"
                "<b>Passo 4:</b> Aguarde a execução automática\n"
                "Bot executará no horário programado\n\n"
                "━━━━━━━━━━━━━━━━━━━━\n\n"
                "<b>📌 Exemplos Práticos:</b>\n\n"
                "✅ <code>M5 EURUSD CALL 14:30</code>\n"
                "   → Executa às 14:30, expira em 5 min\n\n"
                "✅ <code>GBPUSD PUT</code>\n"
                "   → Executa imediatamente\n\n"
                "✅ <code>ATIVO: USDJPY\n"
                "DIREÇÃO: CALL\n"
                "TIMEFRAME: 15M\n"
                "HORÁRIO: 16:00</code>\n"
                "   → Executa às 16:00, expira em 15 min",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        # Estatísticas
        elif data == "stats":
            from state.stats import obter_winrate
            winrate = obter_winrate()
            
            # Calcular taxa de empate
            empate_rate = 0
            if self.stats['total_operacoes'] > 0:
                empate_rate = (self.stats['empates'] / self.stats['total_operacoes']) * 100
            
            # Calcular lucro médio por operação
            lucro_medio = 0
            if self.stats['total_operacoes'] > 0:
                lucro_medio = self.stats['lucro_dia'] / self.stats['total_operacoes']
            
            # Emoji de status
            if self.stats['lucro_dia'] > 0:
                status_emoji = "📈"
                status_text = "POSITIVO"
            elif self.stats['lucro_dia'] < 0:
                status_emoji = "📉"
                status_text = "NEGATIVO"
            else:
                status_emoji = "➖"
                status_text = "NEUTRO"
            
            mensagem = f"""
📊 <b>Estatísticas de Performance</b>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📈 <b>OPERAÇÕES</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

├ 🎯 Total: <b>{self.stats['total_operacoes']}</b>
├ ✅ Vitórias: <b>{self.stats['vitorias']}</b>
├ ❌ Derrotas: <b>{self.stats['derrotas']}</b>
└ ⚪ Empates: <b>{self.stats['empates']}</b>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 <b>FINANCEIRO</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

├ {status_emoji} Status: <b>{status_text}</b>
├ 💵 Lucro/Prejuízo: <b>${self.stats['lucro_dia']:.2f}</b>
├ 📊 Lucro médio/op: <b>${lucro_medio:.2f}</b>
├ 🎯 Win Rate: <b>{winrate:.1f}%</b>
└ ⚪ Taxa Empate: <b>{empate_rate:.1f}%</b>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🤖 <b>IA GUARD (Decisões)</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

├ ✅ Executar: <b>{self.stats['ia_decisoes']['executar']}</b>
├ ❌ Ignorar: <b>{self.stats['ia_decisoes']['ignorar']}</b>
└ ⚠️ Risco: <b>{self.stats['ia_decisoes']['risco']}</b>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 <b>ANÁLISE</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{'✅ Bom desempenho! Continue assim.' if winrate >= 60 else '📊 Desempenho neutro. Analise suas operações.' if winrate >= 45 else '⚠️ Win rate abaixo do ideal. Revise sua estratégia.'}

{f'⚠️ Atenção ao Stop Loss: ${abs(self.stats["lucro_dia"]):.2f} / ${self.config["stop_loss"]:.2f}' if self.stats["lucro_dia"] < 0 else f'✅ Progresso ao Stop Gain: ${self.stats["lucro_dia"]:.2f} / ${self.config["stop_gain"]:.2f}' if self.stats["lucro_dia"] > 0 else ''}
            """
            
            await query.edit_message_text(
                mensagem,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🔄 Atualizar", callback_data="stats"),
                    InlineKeyboardButton("◀️ Voltar", callback_data="menu")
                ]])
            )
        
        # Controles
        elif data == "start_bot":
            self.config["operar_automatico"] = True
            await query.edit_message_text(
                "✅ Bot iniciado!",
                reply_markup=self.menu_principal()
            )
        
        elif data == "pause_bot":
            self.config["operar_automatico"] = False
            await query.edit_message_text(
                "⏸️ Bot pausado!",
                reply_markup=self.menu_principal()
            )
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # AUTO TRADE
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        elif data == "toggle_auto_on":
            """Ativa modo automático"""
            from state import runtime
            
            if not runtime.auto_trader:
                await query.answer("❌ AutoTrader não inicializado", show_alert=True)
                return
            
            if not self.iq_client or not self.iq_client.esta_conectado():
                await query.answer(
                    "❌ IQ Option não conectado!\n"
                    "Conecte-se primeiro antes de ativar o modo automático.",
                    show_alert=True
                )
                return
            
            # Ativar modo automático
            sucesso = await runtime.auto_trader.ativar(query.message.chat_id)
            
            if sucesso:
                runtime.modo_automatico_ativo = True
                
                await query.edit_message_text(
                    "🟢 <b>Modo Automático ATIVADO</b>\n\n"
                    "✅ Captura de sinais reais: <b>ATIVA</b>\n"
                    "✅ Execução automática: <b>ATIVA</b>\n"
                    "✅ Conta: <b>PRACTICE</b>\n\n"
                    "📡 O bot está agora capturando sinais da API IQ Option "
                    "e executando trades automaticamente na conta PRACTICE.\n\n"
                    "🔔 Você receberá notificações de:\n"
                    "   • Sinais detectados\n"
                    "   • Trades executados\n"
                    "   • Resultados das operações\n\n"
                    "⚠️ Para desativar, pressione o botão Automático novamente.",
                    parse_mode="HTML",
                    reply_markup=self.menu_principal()
                )
                
                logger.info(f"✅ Modo automático ativado pelo usuário {query.from_user.id}")
            else:
                await query.answer("❌ Erro ao ativar modo automático", show_alert=True)
        
        elif data == "toggle_auto_off":
            """Desativa modo automático"""
            from state import runtime
            
            if not runtime.auto_trader:
                await query.answer("❌ AutoTrader não inicializado", show_alert=True)
                return
            
            # Desativar modo automático
            sucesso = await runtime.auto_trader.desativar()
            
            if sucesso:
                runtime.modo_automatico_ativo = False
                
                await query.edit_message_text(
                    "⚪ <b>Modo Automático DESATIVADO</b>\n\n"
                    "🛑 Captura de sinais: <b>PAUSADA</b>\n"
                    "🛑 Execução automática: <b>PAUSADA</b>\n\n"
                    "💡 O bot parou de capturar e executar trades automaticamente.\n\n"
                    "📊 Estatísticas da sessão foram salvas.\n\n"
                    "✅ Para reativar, pressione o botão Automático novamente.",
                    parse_mode="HTML",
                    reply_markup=self.menu_principal()
                )
                
                logger.info(f"🛑 Modo automático desativado pelo usuário {query.from_user.id}")
            else:
                await query.answer("❌ Erro ao desativar modo automático", show_alert=True)
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # AUTOMAÇÃO DE SINAIS
        # Motor interno de geração inteligente
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        elif data == "toggle_automacao_on":
            """Ativa Motor de Automação de Sinais"""
            from state import runtime
            
            if not runtime.signal_engine:
                await query.answer("❌ SignalEngine não inicializado", show_alert=True)
                return
            
            if not self.iq_client or not self.iq_client.esta_conectado():
                await query.answer(
                    "❌ IQ Option não conectado!\n"
                    "Conecte-se primeiro.",
                    show_alert=True
                )
                return
            
            # Verificar se modo automático está ativo
            if not runtime.modo_automatico_ativo:
                await query.answer(
                    "⚠️ O Modo Automático precisa estar ATIVO!\n\n"
                    "A Automação de Sinais funciona JUNTO com o Modo Automático.\n"
                    "Ative o Modo Automático primeiro.",
                    show_alert=True
                )
                return
            
            # Ativar motor de automação
            sucesso = await runtime.signal_engine.ativar()
            
            if sucesso:
                runtime.automacao_sinais_ativa = True
                
                await query.edit_message_text(
                    "🧠 <b>Automação de Sinais ATIVADA</b>\n\n"
                    "✅ Motor de análise: <b>ATIVO</b>\n"
                    "✅ Geração de sinais: <b>ATIVA</b>\n"
                    "✅ Integração: <b>Modo Automático</b>\n"
                    "✅ Conta: <b>PRACTICE</b>\n\n"
                    "🔍 <b>O que o motor faz:</b>\n"
                    "   • Analisa mercado em tempo real\n"
                    "   • Identifica oportunidades estatísticas\n"
                    "   • Gera sinais com base em dados da API\n"
                    "   • Envia sinais para execução automática\n\n"
                    "⚙️ <b>Proteções ativas:</b>\n"
                    "   ✓ IA Guard (validação)\n"
                    "   ✓ Risk Manager\n"
                    "   ✓ Conta PRACTICE obrigatória\n"
                    "   ✓ Stop Loss e Stop Gain\n\n"
                    "📊 <b>Configurações:</b>\n"
                    f"   • Confiança mínima: {runtime.signal_engine.confianca_minima}%\n"
                    f"   • Intervalo de análise: {runtime.signal_engine.intervalo_analise}s\n"
                    f"   • Máx. sinais/hora: {runtime.signal_engine.max_sinais_por_hora}\n\n"
                    "⚠️ Para desativar, pressione o botão novamente.",
                    parse_mode="HTML",
                    reply_markup=self.menu_principal()
                )
                
                logger.info(f"🧠 Automação de Sinais ativada pelo usuário {query.from_user.id}")
            else:
                await query.answer("❌ Erro ao ativar automação de sinais", show_alert=True)
        
        elif data == "toggle_automacao_off":
            """Desativa Motor de Automação de Sinais"""
            from state import runtime
            
            if not runtime.signal_engine:
                await query.answer("❌ SignalEngine não inicializado", show_alert=True)
                return
            
            # Desativar motor de automação
            sucesso = await runtime.signal_engine.desativar()
            
            if sucesso:
                runtime.automacao_sinais_ativa = False
                
                # Obter estatísticas finais
                stats = runtime.signal_engine.obter_estatisticas()
                
                await query.edit_message_text(
                    "⚪ <b>Automação de Sinais DESATIVADA</b>\n\n"
                    "🛑 Motor de análise: <b>PAUSADO</b>\n"
                    "🛑 Geração de sinais: <b>PAUSADA</b>\n\n"
                    "📊 <b>Estatísticas da sessão:</b>\n"
                    f"   • Sinais gerados na última hora: {stats['sinais_ultima_hora']}\n\n"
                    "💡 O motor parou de gerar sinais internamente.\n"
                    "   Sinais manuais continuam funcionando normalmente.\n\n"
                    "✅ Para reativar, pressione o botão novamente.",
                    parse_mode="HTML",
                    reply_markup=self.menu_principal()
                )
                
                logger.info(f"⛔ Automação de Sinais desativada pelo usuário {query.from_user.id}")
            else:
                await query.answer("❌ Erro ao desativar automação de sinais", show_alert=True)
    
    async def mensagem(self, update: Update, context):
        """
        Handler de mensagens de texto
        Processa sinais E edição de valores
        SUPORTA MÚLTIPLOS SINAIS SIMULTANEAMENTE
        """
        from state import runtime
        from datetime import datetime
        from zoneinfo import ZoneInfo
        
        user_id = update.message.from_user.id
        texto = update.message.text
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # VERIFICAR SE ESTÁ EDITANDO VALORES
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        if user_id in runtime.editing_state and runtime.editing_state[user_id]:
            campo = runtime.editing_state[user_id]
            
            try:
                # Tentar converter para float
                valor = float(texto.replace(',', '.').strip())
                
                # Validar valor
                if valor <= 0:
                    await update.message.reply_text(
                        "❌ Valor deve ser maior que zero!\n"
                        "Tente novamente ou use /start para cancelar."
                    )
                    return
                
                if valor > 10000:
                    await update.message.reply_text(
                        "❌ Valor muito alto!\n"
                        "Use um valor razoável (máximo $10.000).\n"
                        "Tente novamente ou use /start para cancelar."
                    )
                    return
                
                # Atualizar configuração
                if campo == "valor_entrada":
                    self.config["valor_entrada"] = valor
                    nome_campo = "Valor de Entrada"
                    emoji = "💰"
                elif campo == "stop_loss":
                    self.config["stop_loss"] = valor
                    nome_campo = "Stop Loss"
                    emoji = "🛑"
                elif campo == "stop_gain":
                    self.config["stop_gain"] = valor
                    nome_campo = "Stop Gain"
                    emoji = "🎯"
                else:
                    nome_campo = "Valor"
                    emoji = "✅"
                
                # Limpar estado de edição
                runtime.editing_state[user_id] = None
                
                await update.message.reply_text(
                    f"{emoji} <b>{nome_campo} Atualizado!</b>\n\n"
                    f"Novo valor: <b>${valor:.2f}</b>\n\n"
                    f"Use /start para voltar ao menu principal.",
                    parse_mode="HTML"
                )
                return
                
            except ValueError:
                await update.message.reply_text(
                    "❌ Valor inválido!\n\n"
                    "Digite apenas números.\n"
                    "Exemplos válidos: <code>5</code>, <code>10.50</code>, <code>25</code>\n\n"
                    "Tente novamente ou use /start para cancelar.",
                    parse_mode="HTML"
                )
                return
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # PROCESSAR SINAIS (AGORA SUPORTA MÚLTIPLOS)
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        sinais = self.signal_parser.parsear_sinal(texto)
        
        if not sinais:
            return
        
        # Fuso horário de São Paulo para cálculos
        FUSO_SP = ZoneInfo("America/Sao_Paulo")
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # PROCESSAR CADA SINAL DA LISTA
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        sinais_agendados_count = 0
        sinais_imediatos_count = 0
        
        for sinal in sinais:
            if sinal["imediato"] and self.config["operar_automatico"]:
                sinais_imediatos_count += 1
                await update.message.reply_text(
                    f"⚡ <b>Sinal Imediato #{sinais_imediatos_count}</b>\n\n"
                    f"📊 {sinal['par']} {sinal['direcao']}\n"
                    f"⏱️ {sinal['tempo_expiracao']}s\n"
                    f"🕐 Executando agora...",
                    parse_mode="HTML"
                )
                # Processar será implementado no main
            
            elif not sinal["imediato"]:
                if self.runtime.captura_sinais_ativa or self.config["operar_automatico"]:
                    self.runtime.adicionar_sinal(sinal)
                    sinais_agendados_count += 1
                    
                    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                    # CÁLCULO CORRETO DO TEMPO (SÃO PAULO)
                    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                    
                    agora_sp = datetime.now(FUSO_SP)
                    
                    # Garantir que horário do sinal está no fuso de SP
                    if sinal['horario'].tzinfo is None:
                        horario_sinal = sinal['horario'].replace(tzinfo=FUSO_SP)
                    else:
                        horario_sinal = sinal['horario'].astimezone(FUSO_SP)
                    
                    # Calcular diferença
                    tempo_restante = (horario_sinal - agora_sp).total_seconds()
                    
                    # Formatar tempo de forma legível
                    if tempo_restante < 0:
                        tempo_str = "ERRO: horário já passou!"
                        logger.warning(f"⚠️ Sinal com horário passado: {horario_sinal}")
                    elif tempo_restante < 60:
                        tempo_str = f"{int(tempo_restante)}s"
                    elif tempo_restante < 3600:
                        minutos = int(tempo_restante / 60)
                        segundos = int(tempo_restante % 60)
                        tempo_str = f"{minutos}min {segundos}s"
                    else:
                        horas = int(tempo_restante / 3600)
                        minutos = int((tempo_restante % 3600) / 60)
                        tempo_str = f"{horas}h {minutos}min"
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # ENVIAR CONFIRMAÇÃO CONSOLIDADA
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        if sinais_agendados_count > 0:
            # Mostrar último sinal agendado como exemplo
            ultimo_sinal = sinais[-1] if not sinais[-1]["imediato"] else None
            
            if ultimo_sinal:
                agora_sp = datetime.now(FUSO_SP)
                if ultimo_sinal['horario'].tzinfo is None:
                    horario_sinal = ultimo_sinal['horario'].replace(tzinfo=FUSO_SP)
                else:
                    horario_sinal = ultimo_sinal['horario'].astimezone(FUSO_SP)
                
                tempo_restante = (horario_sinal - agora_sp).total_seconds()
                
                if tempo_restante < 60:
                    tempo_str = f"{int(tempo_restante)}s"
                elif tempo_restante < 3600:
                    minutos = int(tempo_restante / 60)
                    segundos = int(tempo_restante % 60)
                    tempo_str = f"{minutos}min {segundos}s"
                else:
                    horas = int(tempo_restante / 3600)
                    minutos = int((tempo_restante % 3600) / 60)
                    tempo_str = f"{horas}h {minutos}min"
                
                mensagem = f"✅ <b>{sinais_agendados_count} Sinal(is) Agendado(s)!</b>\n\n"
                
                if sinais_agendados_count == 1:
                    mensagem += (
                        f"📊 Par: <b>{ultimo_sinal['par']}</b>\n"
                        f"📈 Direção: <b>{ultimo_sinal['direcao']}</b>\n"
                        f"🕐 Horário: <b>{horario_sinal.strftime('%H:%M:%S')}</b>\n"
                        f"⏱️ Expiração: <b>{ultimo_sinal['tempo_expiracao']}s</b>\n"
                        f"⏳ Tempo restante: <b>{tempo_str}</b>\n"
                        f"📝 Formato: {ultimo_sinal.get('formato', 'PADRÃO')}\n\n"
                        f"🕐 Horário atual SP: {agora_sp.strftime('%H:%M:%S')}\n\n"
                        f"💡 Execução automática no horário programado.\n"
                        f"🔔 Você receberá notificação antes."
                    )
                else:
                    mensagem += (
                        f"📋 Total de sinais na fila: <b>{self.runtime.quantidade_sinais()}</b>\n\n"
                        f"<b>Último sinal adicionado:</b>\n"
                        f"📊 {ultimo_sinal['par']} {ultimo_sinal['direcao']}\n"
                        f"🕐 {horario_sinal.strftime('%H:%M:%S')} ({tempo_str})\n\n"
                        f"💡 Use /start → 📥 Sinais → 📋 Listar\n"
                        f"para ver todos os sinais agendados."
                    )
                
                await update.message.reply_text(mensagem, parse_mode="HTML")
