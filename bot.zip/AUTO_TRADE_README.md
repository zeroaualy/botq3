# 🤖 Bot de Trading Automatizado - Auto Trade

## 📖 Descrição

Sistema de trading automatizado que **captura sinais reais da API IQ Option** e executa trades automaticamente na **conta PRACTICE**.

### ✨ Principais Características

- ✅ **Captura automática de sinais reais** da API IQ Option
- ✅ **Análise de tendências** em tempo real usando candles
- ✅ **Execução automática** de trades na conta PRACTICE
- ✅ **Segurança total**: apenas conta PRACTICE, nunca REAL
- ✅ **Notificações em tempo real** via Telegram
- ✅ **Controle fácil**: botão ON/OFF no menu
- ✅ **Estatísticas completas**: wins, losses, lucro/prejuízo

---

## 🎯 Funcionalidades

### 1. **Captura de Sinais Reais**

O bot analisa o mercado em tempo real:

```python
# Estratégia de análise:
- Obtém candles da API IQ Option (últimos 60 segundos)
- Analisa as últimas 10 velas
- Identifica tendências (alta/baixa)
- Calcula nível de confiança (0-100%)
- Retorna apenas sinais com confiança >= 60%
```

**Pares analisados:**
- EURUSD, GBPUSD, USDJPY
- AUDUSD, EURJPY, GBPJPY
- USDCAD, NZDUSD

### 2. **Execução Automática**

Quando um sinal válido é detectado:

1. ✅ Verifica conta PRACTICE
2. ✅ Valida saldo disponível
3. ✅ Executa trade automaticamente
4. ✅ Aguarda resultado
5. ✅ Atualiza estatísticas
6. ✅ Notifica usuário

### 3. **Notificações Telegram**

Você recebe notificações de:

```
🎯 Sinal Detectado
📊 Par: EURUSD
📈 Direção: CALL
🎲 Confiança: 75%
⚡ Executando trade...

✅ Resultado
📊 EURUSD CALL
🎲 WIN - Lucro: $8.50
💰 Saldo: $10,245.00
```

### 4. **Controle Via Telegram**

Interface simples e intuitiva:

```
🏠 Menu Principal
├─ 🔄 Automático: 🟢 ATIVO    ← Clique para ON/OFF
├─ ⚙️ Configurações
├─ 📊 Estatísticas
├─ 📥 Sinais
└─ 🤖 IA & Governança
```

---

## 🚀 Como Usar

### **Passo 1: Ativar o Modo Automático**

1. Abra o bot no Telegram
2. Digite `/start`
3. Clique no botão "🔄 Automático: ⚪ PAUSADO"
4. Aguarde a confirmação:

```
🟢 Modo Automático ATIVADO

✅ Captura de sinais reais: ATIVA
✅ Execução automática: ATIVA
✅ Conta: PRACTICE

📡 O bot está agora capturando sinais da API IQ Option
e executando trades automaticamente.
```

### **Passo 2: Monitorar Operações**

O bot enviará notificações automaticamente:

- 📡 Quando um sinal for detectado
- ⚡ Quando um trade for executado
- ✅ Quando um resultado for confirmado

### **Passo 3: Desativar (quando quiser)**

Clique novamente no botão "🔄 Automático: 🟢 ATIVO"

```
⚪ Modo Automático DESATIVADO

🛑 Captura de sinais: PAUSADA
🛑 Execução automática: PAUSADA

📊 Estatísticas da sessão foram salvas.
```

---

## ⚙️ Configuração

### **Parâmetros Ajustáveis**

Todos os parâmetros podem ser configurados via menu "⚙️ Configurações":

| Parâmetro | Padrão | Descrição |
|-----------|--------|-----------|
| Valor de Entrada | $5.00 | Valor de cada trade |
| Stop Loss | $50.00 | Perda máxima acumulada |
| Stop Gain | $100.00 | Ganho máximo acumulado |
| Tempo de Expiração | 60s | M1 (1 minuto) |
| Nível de Confiança Mínimo | 60% | Sinais abaixo são ignorados |
| Intervalo de Verificação | 5s | Tempo entre análises |

### **Personalização Avançada**

Para desenvolvedores, edite `core/auto_trader.py`:

```python
# Alterar intervalo de verificação (linha 91)
intervalo_verificacao = 5  # segundos

# Alterar pares analisados (linha 160)
pares_analisar = [
    "EURUSD", "GBPUSD", "USDJPY",
    # Adicione mais pares aqui
]

# Alterar nível mínimo de confiança (linha 205)
if melhor_sinal and melhor_sinal["confianca"] >= 60:  # %

# Alterar tempo de expiração (linha 199)
"expiracao": 60,  # segundos (60=M1, 300=M5, 900=M15)
```

---

## 📊 Como Funciona a Análise

### **Estratégia de Detecção de Tendências**

```python
1. Obter candles recentes (últimos 60 segundos)
   ├─ Fonte: API IQ Option
   └─ Velas de 1 segundo cada

2. Analisar as últimas 10 velas
   ├─ Vela verde (close > open) → indicador CALL
   └─ Vela vermelha (close < open) → indicador PUT

3. Calcular força da tendência
   ├─ Se 7+ velas verdes → CALL (70% confiança)
   ├─ Se 7+ velas vermelhas → PUT (70% confiança)
   └─ Se 5/5 → mercado lateral (0% confiança)

4. Retornar apenas sinais >= 60% confiança
```

### **Exemplo de Análise Real**

```
Par: EURUSD
Últimas 10 velas: 🟢🟢🟢🔴🟢🟢🟢🟢🔴🟢

Análise:
- Velas verdes: 8
- Velas vermelhas: 2
- Tendência: ALTA (CALL)
- Confiança: 80%

Resultado: ✅ SINAL VÁLIDO
Ação: Executar CALL em EURUSD
```

---

## 🔒 Segurança

### **Garantias Implementadas**

1. ✅ **Verificação de conta antes de cada trade**
   ```python
   if not self.iq_client.garantir_practice():
       logger.error("❌ OPERAÇÃO ABORTADA")
       return False
   ```

2. ✅ **Validação de saldo**
   ```python
   if saldo < valor:
       logger.error("❌ Saldo insuficiente")
       return False
   ```

3. ✅ **Controle de Stop Loss/Gain**
   - Bot para automaticamente ao atingir limites
   - Estatísticas são salvas antes de parar

4. ✅ **Tratamento de erros robusto**
   - Todos os erros são capturados e logados
   - Bot continua funcionando mesmo com erros pontuais

5. ✅ **Desligamento seguro**
   - Ao pressionar Ctrl+C, o bot:
     - Desativa o auto trade
     - Cancela tasks pendentes
     - Salva estatísticas
     - Fecha conexões

---

## 📈 Estatísticas

O bot mantém estatísticas em tempo real:

```python
📊 Estatísticas

Total de operações: 45
├─ ✅ Wins: 28 (62.2%)
├─ ❌ Losses: 17 (37.8%)
└─ 💰 Lucro Total: $127.50

Melhor sequência: 5 wins consecutivos
Pior sequência: 3 losses consecutivos

Taxa de acerto: 62.2%
Retorno médio: $2.83/trade
```

Acesse via menu "📊 Estatísticas"

---

## 🛠️ Requisitos Técnicos

### **Dependências Python**

```txt
python-telegram-bot>=20.0
iqoptionapi
asyncio
logging
```

### **Conta IQ Option**

- ✅ Conta PRACTICE ativada
- ✅ Credenciais configuradas em `state/config.py`
- ✅ Conexão estável com internet

### **Bot Telegram**

- ✅ Token do bot configurado
- ✅ ID do grupo/chat permitido

---

## 📁 Estrutura de Arquivos

```
bot/
├── core/
│   ├── auto_trader.py       ← Módulo principal do Auto Trade
│   ├── iq_client.py         ← Cliente IQ Option
│   ├── trade_executor.py    ← Executor de trades
│   ├── signal_parser.py     ← Parser de sinais
│   └── scheduler.py         ← Agendador
├── state/
│   ├── runtime.py           ← Estado em runtime (+ auto_trader)
│   ├── config.py            ← Configurações
│   └── stats.py             ← Estatísticas
├── bot/
│   └── telegram_bot.py      ← Bot Telegram (+ handlers auto trade)
├── ai/
│   └── ia_guard.py          ← IA de validação
└── main.py                  ← Inicialização (+ auto trader)
```

---

## 🎓 Exemplos de Uso

### **Exemplo 1: Operação Básica**

```python
# Usuário ativa o modo automático
/start
→ Clica em "🔄 Automático"

# Bot começa a analisar
🔄 Analisando EURUSD... tendência alta detectada (75%)
🔄 Analisando GBPUSD... mercado lateral (40%)
🔄 Analisando USDJPY... tendência baixa detectada (82%)

# Bot detecta sinal válido
🎯 Sinal: USDJPY PUT (82% confiança)
⚡ Executando trade de $5.00...

# Aguarda resultado (60s)
✅ WIN! Lucro: $8.50
💰 Saldo atualizado: $10,245.00
```

### **Exemplo 2: Stop Loss Ativado**

```python
# Bot operando automaticamente
📊 Total operações: 15
├─ Wins: 7
├─ Losses: 8
└─ Prejuízo acumulado: $48.50

# Próximo trade resulta em loss
❌ LOSS! Perda: $5.00
💰 Prejuízo total: $53.50

# Stop Loss atingido ($50.00)
🛑 STOP LOSS ATINGIDO!

⚪ Modo Automático DESATIVADO automaticamente
📊 Revise suas configurações antes de reativar
```

### **Exemplo 3: Sessão Completa**

```python
# Início da sessão
🟢 Modo Automático ATIVADO
💰 Saldo inicial: $10,000.00

# Durante a sessão (2 horas)
📡 45 sinais analisados
├─ 12 sinais válidos (>= 60% confiança)
├─ 33 sinais ignorados (< 60% confiança)
└─ 12 trades executados

# Resultados
✅ Wins: 8 (66.7%)
❌ Losses: 4 (33.3%)
💰 Lucro final: $67.00

# Final da sessão
⚪ Modo Automático DESATIVADO
💰 Saldo final: $10,067.00
📈 Retorno: +0.67%
```

---

## ⚠️ Avisos Importantes

1. **Sempre use conta PRACTICE para testes**
   - Nunca ative em conta REAL sem validação completa
   - O bot força conta PRACTICE por segurança

2. **Mercado pode ter períodos sem sinais**
   - Nem sempre haverá sinais com confiança >= 60%
   - Isso é normal e esperado

3. **Taxa de acerto varia**
   - Estratégia simples não garante lucro constante
   - Use como base para desenvolver estratégias melhores

4. **Monitore regularmente**
   - Verifique notificações e estatísticas
   - Ajuste parâmetros conforme necessário

5. **Trading envolve riscos**
   - Nunca opere com dinheiro que não pode perder
   - Este bot é educacional, não garantia de lucro

---

## 📚 Documentação Adicional

- 📄 **[INTEGRACAO.md](INTEGRACAO.md)** - Guia completo de integração
- 📄 **[telegram_bot_extension.py](telegram_bot_extension.py)** - Código dos handlers
- 📄 **[main_extension.py](main_extension.py)** - Código de inicialização
- 📄 **[auto_trader.py](auto_trader.py)** - Módulo principal comentado

---

## 🤝 Contribuindo

Para melhorar este projeto:

1. Implemente estratégias de análise mais sofisticadas
2. Adicione mais indicadores técnicos (RSI, MACD, Bollinger)
3. Integre machine learning para previsões
4. Adicione backtesting com dados históricos
5. Crie dashboard web para visualização

---

## 📞 Suporte

Dúvidas ou problemas? Consulte:

1. 📖 [Guia de Integração](INTEGRACAO.md)
2. 📊 Logs do bot (`bot.log`)
3. 🔍 Seção de Troubleshooting no guia

---

## 📄 Licença

Este projeto é fornecido "como está" para fins educacionais.

---

**Desenvolvido com ❤️ para traders que querem automatizar suas estratégias de forma segura e eficiente.**

🚀 **Bons trades!**
