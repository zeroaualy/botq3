"""
Cliente IQ Option
Responsável por conexão e garantia de conta PRACTICE
"""
import logging
import time
from iqoptionapi.stable_api import IQ_Option

logger = logging.getLogger(__name__)


class IQClient:
    """Cliente IQ Option com garantia de conta PRACTICE"""
    
    def __init__(self, email, senha):
        self.email = email
        self.senha = senha
        self.iq = None
        # Cache para status de ativos (evita sobrecarga da API)
        self._cache_ativos = None
        self._cache_timestamp = 0
        self._cache_duracao = 30  # segundos
        
    def conectar(self, max_tentativas=3):
        """Conecta à IQ Option e força conta PRACTICE"""
        for tentativa in range(max_tentativas):
            try:
                logger.info(f"🔄 Conectando IQ Option ({tentativa + 1}/{max_tentativas})...")
                self.iq = IQ_Option(self.email, self.senha)
                check, reason = self.iq.connect()
                
                if check:
                    # CRÍTICO: Forçar conta PRACTICE
                    self.iq.change_balance("PRACTICE")
                    time.sleep(2)
                    
                    saldo = self.iq.get_balance()
                    tipo_conta = self.iq.get_balance_mode()
                    
                    logger.info(f"✅ Conectado!")
                    logger.info(f"📊 Tipo de conta: {tipo_conta}")
                    logger.info(f"💰 Saldo PRACTICE: ${saldo:.2f}")
                    
                    return True
                else:
                    logger.error(f"❌ Falha: {reason}")
                
                time.sleep(5)
            except Exception as e:
                logger.error(f"❌ Erro: {e}")
        
        return False
    
    def garantir_practice(self):
        """
        SEGURANÇA CRÍTICA: Garante que está em PRACTICE
        Retorna True se confirmado, False se falhou
        """
        try:
            if not self.iq:
                logger.error("❌ Sem conexão IQ Option")
                return False
            
            tipo_conta = self.iq.get_balance_mode()
            
            if tipo_conta != "PRACTICE":
                logger.warning(f"⚠️ Conta não é PRACTICE (atual: {tipo_conta})")
                logger.info("🔄 Forçando mudança para PRACTICE...")
                
                self.iq.change_balance("PRACTICE")
                time.sleep(2)
                
                # Verificar novamente
                tipo_conta = self.iq.get_balance_mode()
                
                if tipo_conta != "PRACTICE":
                    logger.error(f"❌ FALHA CRÍTICA: Não conseguiu mudar para PRACTICE")
                    return False
            
            logger.info("✅ Confirmado: Operando em conta PRACTICE")
            return True
            
        except Exception as e:
            logger.error(f"❌ Erro ao verificar conta: {e}")
            return False
    
    def verificar_ativo_disponivel(self, par):
        """Verifica se ativo está aberto (com cache)"""
        try:
            par_limpo = par.replace("-OTC", "")
            
            # Verificar cache
            tempo_atual = time.time()
            
            # Usar cache se ainda estiver válido
            if self._cache_ativos and (tempo_atual - self._cache_timestamp) < self._cache_duracao:
                all_assets = self._cache_ativos
                logger.debug("📦 Usando cache de ativos")
            else:
                # Tentar obter status dos ativos
                try:
                    logger.debug("🔄 Obtendo status de ativos da API...")
                    all_assets = self.iq.get_all_open_time()
                    # Atualizar cache se obteve dados
                    if all_assets:
                        self._cache_ativos = all_assets
                        self._cache_timestamp = tempo_atual
                except Exception as e:
                    logger.warning(f"⚠️ Erro ao obter status de ativos: {str(e)}")
                    # Usar cache antigo se disponível
                    if self._cache_ativos:
                        logger.info("📦 Usando cache antigo de ativos")
                        all_assets = self._cache_ativos
                    else:
                        all_assets = None
            
            # Verificar se recebemos dados válidos
            if not all_assets:
                logger.warning(f"⚠️ Sem dados de ativos, tentando {par_limpo} mesmo assim...")
                return True, par_limpo
            
            # Verificar se tem a estrutura esperada
            if not isinstance(all_assets, dict) or "binary" not in all_assets:
                logger.warning(f"⚠️ Estrutura de dados inesperada, tentando {par_limpo} mesmo assim...")
                return True, par_limpo
            
            # Verificar disponibilidade do ativo
            binary_assets = all_assets.get("binary", {})
            if not isinstance(binary_assets, dict):
                logger.warning(f"⚠️ Dados binary inválidos, tentando {par_limpo} mesmo assim...")
                return True, par_limpo
            
            # Procurar pelo ativo
            for ativo_id, dados in binary_assets.items():
                if not isinstance(dados, dict):
                    continue
                    
                if par_limpo.upper() in str(ativo_id).upper():
                    is_open = dados.get("open", False)
                    if is_open:
                        logger.info(f"✅ Ativo {par_limpo} disponível")
                        return True, par_limpo
                    else:
                        # Tentar versão OTC
                        par_otc = f"{par_limpo}-OTC"
                        for ativo_otc_id, dados_otc in binary_assets.items():
                            if not isinstance(dados_otc, dict):
                                continue
                            if par_otc.upper() in str(ativo_otc_id).upper():
                                is_open_otc = dados_otc.get("open", False)
                                if is_open_otc:
                                    logger.info(f"✅ Usando OTC: {par_otc}")
                                    return True, par_otc
                        
                        logger.warning(f"⚠️ {par_limpo} fechado e OTC não disponível")
                        return False, None
            
            # Não encontrou o ativo nos dados
            logger.warning(f"⚠️ {par_limpo} não encontrado na lista, tentando mesmo assim...")
            return True, par_limpo
            
        except Exception as e:
            logger.error(f"❌ Erro inesperado ao verificar ativo: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            # Em caso de erro, permite tentar operar
            return True, par.replace("-OTC", "")
    
    def obter_saldo(self):
        """Retorna saldo atual"""
        if not self.iq:
            return 0.0
        return self.iq.get_balance()
    
    def obter_tipo_conta(self):
        """Retorna tipo de conta"""
        if not self.iq:
            return "DESCONECTADO"
        return self.iq.get_balance_mode()
    
    def esta_conectado(self):
        """Verifica se está conectado"""
        return self.iq is not None
