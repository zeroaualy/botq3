# 🚀 GUIA DE INSTALAÇÃO - AUTOMAÇÃO DE SINAIS

## Q3 IA Beta v3.1 - Atualização com Motor de Automação de Sinais

---

## 📦 CONTEÚDO DO PACOTE

Este pacote contém a implementação completa da funcionalidade **Automação de Sinais**:

### Arquivos Novos:
- ✅ `/core/signal_engine.py` - Motor de Automação de Sinais
- ✅ `AUTOMACAO_SINAIS_README.md` - Documentação completa
- ✅ `CHANGELOG_AUTOMACAO_SINAIS.md` - Registro de mudanças
- ✅ `test_signal_engine.py` - Testes automatizados
- ✅ `GUIA_INSTALACAO_AUTOMACAO.md` - Este arquivo

### Arquivos Modificados:
- ✅ `/state/runtime.py` - Adicionadas flags de estado
- ✅ `/state/config.py` - Adicionadas configurações
- ✅ `/bot/telegram_bot.py` - Adicionado botão e handlers
- ✅ `/main.py` - Adicionada inicialização do motor

---

## 🔧 OPÇÃO 1: INSTALAÇÃO COMPLETA (RECOMENDADO)

Se você está começando do zero ou quer substituir tudo:

### Passo 1: Backup
```bash
# Faça backup do projeto atual
cp -r bot_atual bot_backup_$(date +%Y%m%d)
```

### Passo 2: Substituir
```bash
# Substitua o projeto pelo novo
rm -rf bot_atual
mv bot_atualizado bot_atual
cd bot_atual
```

### Passo 3: Instalar dependências
```bash
pip install -r requirements.txt --break-system-packages
```

### Passo 4: Configurar credenciais
```bash
# Edite state/config.py com suas credenciais
nano state/config.py
```

### Passo 5: Executar
```bash
python main.py
```

---

## 🔄 OPÇÃO 2: ATUALIZAÇÃO INCREMENTAL (AVANÇADO)

Se você tem um projeto existente e quer apenas adicionar a funcionalidade:

### Passo 1: Backup
```bash
cp -r meu_bot meu_bot_backup_$(date +%Y%m%d)
```

### Passo 2: Adicionar arquivo novo
```bash
# Copiar o novo motor
cp bot_atualizado/core/signal_engine.py meu_bot/core/
```

### Passo 3: Atualizar state/runtime.py
Adicione no final do arquivo:
```python
# ======================================
# AUTOMAÇÃO DE SINAIS
# Motor interno de geração inteligente
# ======================================

# Instância do SignalEngine (será preenchida em runtime)
signal_engine = None

# Flag da automação de sinais
automacao_sinais_ativa = False
```

### Passo 4: Atualizar state/config.py
Adicione dentro do dicionário CONFIG:
```python
# Automação de Sinais
"automacao_sinais_habilitada": True,
"automacao_confianca_minima": 65,
"automacao_intervalo_analise": 30,
"automacao_max_sinais_hora": 10,
```

### Passo 5: Atualizar bot/telegram_bot.py

**5.1** No método `menu_principal()`, adicione:
```python
# Verificar status da Automação de Sinais
if runtime.signal_engine and runtime.signal_engine.is_ativo():
    automacao_status = "🟢 ATIVADO"
    automacao_data = "toggle_automacao_off"
else:
    automacao_status = "⚪ DESATIVADO"
    automacao_data = "toggle_automacao_on"
```

E adicione o botão no keyboard:
```python
[
    InlineKeyboardButton(f"🧠 Automação de Sinais: {automacao_status}", 
                        callback_data=automacao_data),
],
```

**5.2** Adicione os handlers (veja arquivo completo em bot_atualizado/bot/telegram_bot.py)

### Passo 6: Atualizar main.py
Adicione após a inicialização do AutoTrader:
```python
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SIGNAL ENGINE - Motor de Automação de Sinais
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
from core.signal_engine import SignalEngine

signal_engine = SignalEngine(
    iq_client=iq_client,
    runtime=runtime,
    config=CONFIG
)
runtime.signal_engine = signal_engine
logger.info("✅ SignalEngine (Automação de Sinais) inicializado")
```

---

## ✅ VERIFICAÇÃO DA INSTALAÇÃO

### Teste 1: Verificar importações
```bash
python -c "from core.signal_engine import SignalEngine; print('✅ SignalEngine OK')"
```

### Teste 2: Executar testes
```bash
python test_signal_engine.py
```

### Teste 3: Iniciar bot
```bash
python main.py
```

Você deve ver no log:
```
✅ SignalEngine (Automação de Sinais) inicializado
🧠 SignalEngine: Motor de Automação de Sinais pronto
```

### Teste 4: Verificar Telegram
1. Abra o bot no Telegram
2. Envie `/start`
3. Verifique se há um botão: `🧠 Automação de Sinais: ⚪ DESATIVADO`

---

## 🎮 COMO USAR

1. **Conecte-se à IQ Option**
2. **Ative o Modo Automático** (botão 🔄)
3. **Ative a Automação de Sinais** (botão 🧠)
4. **Monitore as notificações**

O bot começará a:
- Analisar o mercado a cada 30 segundos
- Gerar sinais com confiança ≥ 65%
- Executar trades automaticamente
- Enviar notificações de cada operação

Para desativar, basta clicar novamente no botão 🧠.

---

## 🔍 SOLUÇÃO DE PROBLEMAS

### Erro: "ModuleNotFoundError: No module named 'core.signal_engine'"
**Solução**: Certifique-se que o arquivo `core/signal_engine.py` existe

### Erro: "AttributeError: module 'runtime' has no attribute 'signal_engine'"
**Solução**: Verifique se adicionou as linhas em `state/runtime.py`

### Erro: "SignalEngine não inicializado"
**Solução**: Verifique se adicionou a inicialização em `main.py`

### Botão não aparece no Telegram
**Solução**: Verifique se modificou `bot/telegram_bot.py` corretamente

### Bot pausa imediatamente
**Solução**: Verifique se está em conta PRACTICE e se o Modo Automático está ativo

---

## 📚 DOCUMENTAÇÃO

### Leia os arquivos de documentação:
1. **AUTOMACAO_SINAIS_README.md** - Guia completo de uso
2. **CHANGELOG_AUTOMACAO_SINAIS.md** - Detalhes técnicos da implementação

### Código-fonte:
- **core/signal_engine.py** - Motor principal (bem documentado)
- **test_signal_engine.py** - Exemplos de uso e testes

---

## 🛡️ SEGURANÇA

### Proteções Ativas:
- ✅ Opera APENAS em conta PRACTICE
- ✅ Respeita IA Guard
- ✅ Respeita Risk Manager
- ✅ Limites de sinais por hora
- ✅ Confiança mínima obrigatória
- ✅ Stop Loss e Stop Gain

### Recomendações:
1. **Sempre teste em PRACTICE primeiro**
2. **Monitore as primeiras horas de operação**
3. **Ajuste as configurações conforme necessário**
4. **Mantenha stop loss/gain configurados**

---

## 📞 SUPORTE

### Em caso de problemas:
1. Verifique os logs do sistema
2. Consulte a documentação
3. Execute os testes (`test_signal_engine.py`)
4. Verifique se todas as modificações foram aplicadas

### Logs importantes:
```bash
# Verificar logs em tempo real
tail -f logs/bot.log

# Buscar erros
grep "ERROR" logs/bot.log

# Buscar atividade da Automação
grep "Automação" logs/bot.log
```

---

## ✨ NOVIDADES DESTA VERSÃO

### v3.1 - Automação de Sinais
- ✅ Motor interno de análise estatística
- ✅ Geração automática de sinais
- ✅ Análise de tendência, momentum e volume
- ✅ Filtros de qualidade
- ✅ Integração total com sistema existente
- ✅ Interface Telegram completa
- ✅ Documentação extensiva
- ✅ Suite de testes

---

## 🎯 PRÓXIMOS PASSOS

Após a instalação:

1. **Configure suas preferências** em `state/config.py`
2. **Leia a documentação completa** em `AUTOMACAO_SINAIS_README.md`
3. **Execute os testes** com `test_signal_engine.py`
4. **Inicie em PRACTICE** e monitore
5. **Ajuste parâmetros** conforme necessário

---

## 📝 NOTAS FINAIS

### Sobre a Implementação:
- ✅ 100% modular e não-invasiva
- ✅ Não quebra funcionalidades existentes
- ✅ Totalmente compatível com código anterior
- ✅ Pode ser desativada sem afetar o sistema

### Sobre o Uso:
- ⚠️ Esta é uma ferramenta de análise técnica
- ⚠️ Não garante lucros
- ⚠️ Trading envolve riscos
- ⚠️ Use com responsabilidade

---

**Desenvolvido com atenção aos detalhes** ✨  
**Q3 IA Beta v3.1** - Fevereiro 2026
