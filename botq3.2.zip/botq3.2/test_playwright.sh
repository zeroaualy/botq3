#!/bin/bash

###############################################################################
# Script de Teste - Playwright
# Testa se Playwright está instalado e funcionando
###############################################################################

echo "=========================================="
echo "🧪 Testando Playwright..."
echo "=========================================="

# Ativar ambiente virtual
if [ -d "venv" ]; then
    source venv/bin/activate
else
    echo "❌ Ambiente virtual não encontrado!"
    echo "Execute: python3 -m venv venv"
    exit 1
fi

# Verificar se Playwright está instalado
if ! python3 -c "import playwright" 2>/dev/null; then
    echo "❌ Playwright não instalado!"
    echo "Execute: pip install playwright"
    exit 1
fi

echo "✅ Playwright está instalado"

# Testar navegador
python3 << 'EOF'
import asyncio
from playwright.async_api import async_playwright

async def test_playwright():
    print("\n🌐 Testando navegador Chromium...")
    
    try:
        async with async_playwright() as p:
            # Iniciar navegador
            browser = await p.chromium.launch(
                headless=True,
                args=['--no-sandbox', '--disable-setuid-sandbox']
            )
            print("✅ Chromium iniciado com sucesso")
            
            # Criar página
            page = await browser.new_page()
            print("✅ Página criada")
            
            # Navegar para Google
            await page.goto('https://www.google.com', timeout=15000)
            print("✅ Navegação para Google bem-sucedida")
            
            # Pegar título
            title = await page.title()
            print(f"✅ Título da página: {title}")
            
            # Fechar
            await browser.close()
            print("✅ Navegador fechado")
            
            print("\n🎉 Playwright está funcionando perfeitamente!")
            return True
            
    except Exception as e:
        print(f"\n❌ Erro ao testar Playwright: {e}")
        import traceback
        traceback.print_exc()
        return False

# Executar teste
success = asyncio.run(test_playwright())

if success:
    exit(0)
else:
    print("\n⚠️  Se o erro for sobre chromium não instalado:")
    print("Execute: playwright install chromium")
    print("         playwright install-deps chromium")
    exit(1)
EOF

TEST_RESULT=$?

if [ $TEST_RESULT -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "✅ TESTE CONCLUÍDO COM SUCESSO!"
    echo "=========================================="
    echo ""
    echo "🚀 Você pode agora executar o bot:"
    echo "   python3 main_playwright.py"
    echo ""
else
    echo ""
    echo "=========================================="
    echo "❌ TESTE FALHOU"
    echo "=========================================="
    echo ""
    echo "Soluções:"
    echo "1. Instalar Playwright:"
    echo "   pip install playwright"
    echo ""
    echo "2. Instalar Chromium:"
    echo "   playwright install chromium"
    echo "   playwright install-deps chromium"
    echo ""
    echo "3. Verificar logs acima para detalhes"
    echo ""
fi

exit $TEST_RESULT
