"""
Executor de trades
Responsável pela execução segura de operações
"""
import logging
import time

logger = logging.getLogger(__name__)


class TradeExecutor:
    """Executor de operações com segurança"""
    
    def __init__(self, iq_client, settlement_engine=None):
        self.iq_client = iq_client
        self.settlement_engine = settlement_engine
        self._last_result = {}  # Cache do último resultado
    
    async def executar(self, par, direcao, valor, expiracao):
        """
        Executa operação COM SEGURANÇA usando myiq (async)
        Retorna: (sucesso, order_id)
        
        IMPORTANT: Returns success IMMEDIATELY after execution confirmation (ACK)
        Does NOT wait for settlement - that's handled by SettlementEngine
        """
        # SEGURANÇA CRÍTICA: Garantir PRACTICE
        if not await self.iq_client.garantir_practice():
            logger.error("❌ OPERAÇÃO ABORTADA: Falha na verificação PRACTICE")
            return False, None
        
        try:
            # Verificar saldo
            saldo = await self.iq_client.obter_saldo()
            if saldo < valor:
                logger.error(f"❌ Saldo insuficiente: ${saldo:.2f} < ${valor:.2f}")
                return False, None
            
            logger.info(f"📊 Executando: {par} {direcao.upper()} ${valor} {expiracao}s")
            logger.info(f"🏦 Conta: PRACTICE | Saldo: ${saldo:.2f}")
            
            # Execute order - returns immediately after ACK
            status, order_id = await self.iq_client.executar_ordem(par, direcao, valor, expiracao)
            
            if status:
                logger.info(f"✅ Ordem executada! ID: {order_id}")
                
                # Register with settlement engine if available
                if self.settlement_engine:
                    self.settlement_engine.register_trade(
                        order_id=order_id,
                        asset=par,
                        direction=direcao,
                        amount=valor,
                        expiration_seconds=expiracao
                    )
                    logger.info(f"📋 Trade registered for settlement monitoring")
                
                return True, order_id
            else:
                logger.error(f"❌ Falha ao executar ordem")
                return False, None
                
        except Exception as e:
            logger.error(f"❌ Erro ao executar operação: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False, None
    
    async def verificar_resultado(self, order_id, aguardar_segundos=None):
        """
        Verifica resultado da operação
        
        ARCHITECTURAL CHANGE:
        - Now queries settlement engine for result
        - If not available, waits up to aguardar_segundos
        
        Retorna: (resultado_str, valor_lucro)
        """
        try:
            if not self.settlement_engine:
                logger.warning("⚠️ Settlement Engine not available - cannot get result")
                return "DESCONHECIDO", 0
            
            # Check if result is already available
            result = self.settlement_engine.get_result(order_id)
            
            if result:
                return self._parse_result(result)
            
            # If aguardar_segundos specified, wait for result
            if aguardar_segundos:
                logger.info(f"⏳ Waiting up to {aguardar_segundos}s for result...")
                result = await self.settlement_engine.wait_for_result(
                    order_id,
                    timeout=aguardar_segundos
                )
                
                if result:
                    return self._parse_result(result)
            
            # Still no result
            logger.warning(f"⚠️ Result not available for order {order_id}")
            return "DESCONHECIDO", 0
                
        except Exception as e:
            logger.error(f"❌ Erro ao verificar resultado: {e}")
            return "ERRO", 0
    
    def _parse_result(self, result: dict) -> tuple:
        """
        Parse settlement result to (resultado_str, valor_lucro)
        
        Args:
            result: Dict from settlement engine
        
        Returns:
            ("WIN" | "LOSS" | "EMPATE" | "DESCONHECIDO", lucro_float)
        """
        result_type = result.get("result", "").lower()
        pnl = result.get("pnl", 0)
        
        if result_type == "win":
            logger.info(f"✅ WIN - Lucro: ${pnl:.2f}")
            return "WIN", pnl
        elif result_type in ["loose", "loss"]:
            logger.info(f"❌ LOSS - Perda: ${abs(pnl):.2f}")
            return "LOSS", abs(pnl)
        elif result_type == "equal":
            logger.info("⚪ EMPATE")
            return "EMPATE", 0
        else:
            logger.warning(f"⚠️ Unknown result type: {result_type}")
            return "DESCONHECIDO", 0
    
    def _cache_result(self, order_id, result_data):
        """Armazena resultado no cache interno (deprecated)"""
        self._last_result[order_id] = result_data
