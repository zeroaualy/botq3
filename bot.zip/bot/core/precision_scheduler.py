"""
Precision Scheduler - Q3 IA Beta
Scheduler de alta precisão usando event loop callbacks
"""
import asyncio
import logging
from typing import Callable, Optional, Dict, Any
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from uuid import uuid4

logger = logging.getLogger(__name__)


@dataclass
class ScheduledTask:
    """Representa uma tarefa agendada"""
    id: str
    callback: Callable
    scheduled_at: datetime
    args: tuple = field(default_factory=tuple)
    kwargs: dict = field(default_factory=dict)
    repeat_interval: Optional[float] = None
    created_at: datetime = field(default_factory=datetime.now)
    executed_count: int = 0
    last_execution: Optional[datetime] = None
    handle: Optional[asyncio.TimerHandle] = None
    
    @property
    def delay_seconds(self) -> float:
        """Calcula o delay em segundos até a execução"""
        now = datetime.now()
        if self.scheduled_at <= now:
            return 0.0
        return (self.scheduled_at - now).total_seconds()


class PrecisionScheduler:
    """
    Scheduler de alta precisão usando event loop callbacks
    
    Características:
    - Usa loop.call_later() para precisão
    - Suporte a tarefas recorrentes
    - Cancelamento seguro
    - Tratamento de exceções por tarefa
    - Métricas detalhadas
    - Não usa polling (evita while True com sleep)
    """
    
    def __init__(self):
        """Inicializa o scheduler"""
        self._tasks: Dict[str, ScheduledTask] = {}
        self._running = False
        
        # Métricas
        self._total_scheduled = 0
        self._total_executed = 0
        self._total_failed = 0
        self._total_cancelled = 0
        
        logger.info("✅ Precision Scheduler inicializado")
    
    def start(self) -> None:
        """Inicia o scheduler"""
        if self._running:
            logger.warning("⚠️ Scheduler já está rodando")
            return
        
        self._running = True
        logger.info("🚀 Precision Scheduler iniciado")
    
    def stop(self) -> None:
        """Para o scheduler e cancela todas as tarefas"""
        if not self._running:
            logger.warning("⚠️ Scheduler já está parado")
            return
        
        self._running = False
        
        # Cancelar todas as tarefas
        for task_id in list(self._tasks.keys()):
            self.cancel(task_id)
        
        logger.info("⛔ Precision Scheduler parado")
    
    def schedule(self, callback: Callable, delay_seconds: Optional[float] = None,
                at_time: Optional[datetime] = None, repeat_interval: Optional[float] = None,
                *args, **kwargs) -> str:
        """
        Agenda uma tarefa para execução
        
        Args:
            callback: Função a executar (pode ser async)
            delay_seconds: Delay em segundos (alternativa a at_time)
            at_time: Momento exato de execução (alternativa a delay_seconds)
            repeat_interval: Se fornecido, repetir a cada N segundos
            *args: Argumentos posicionais para o callback
            **kwargs: Argumentos nomeados para o callback
        
        Returns:
            ID da tarefa agendada
        
        Example:
            # Executar em 5 segundos
            task_id = scheduler.schedule(my_func, delay_seconds=5)
            
            # Executar em horário específico
            task_id = scheduler.schedule(my_func, at_time=datetime(2024, 1, 1, 12, 0))
            
            # Repetir a cada 10 segundos
            task_id = scheduler.schedule(my_func, delay_seconds=10, repeat_interval=10)
        """
        if not self._running:
            raise RuntimeError("Scheduler não está rodando")
        
        # Calcular quando executar
        if at_time is not None:
            scheduled_at = at_time
        elif delay_seconds is not None:
            scheduled_at = datetime.now() + timedelta(seconds=delay_seconds)
        else:
            raise ValueError("Forneça delay_seconds ou at_time")
        
        # Criar tarefa
        task = ScheduledTask(
            id=str(uuid4()),
            callback=callback,
            scheduled_at=scheduled_at,
            args=args,
            kwargs=kwargs,
            repeat_interval=repeat_interval
        )
        
        # Agendar usando loop.call_later
        delay = task.delay_seconds
        if delay < 0:
            delay = 0
        
        loop = asyncio.get_event_loop()
        handle = loop.call_later(
            delay,
            lambda: asyncio.create_task(self._execute_task(task.id))
        )
        
        task.handle = handle
        self._tasks[task.id] = task
        self._total_scheduled += 1
        
        logger.debug(
            f"📅 Tarefa agendada: {task.id[:8]} "
            f"(delay={delay:.2f}s, repeat={repeat_interval})"
        )
        
        return task.id
    
    def schedule_at(self, callback: Callable, at_time: datetime, 
                   repeat_interval: Optional[float] = None,
                   *args, **kwargs) -> str:
        """
        Agenda uma tarefa para horário específico
        
        Args:
            callback: Função a executar
            at_time: Momento exato de execução
            repeat_interval: Se fornecido, repetir a cada N segundos
            *args: Argumentos posicionais
            **kwargs: Argumentos nomeados
        
        Returns:
            ID da tarefa
        """
        return self.schedule(
            callback, at_time=at_time, repeat_interval=repeat_interval,
            *args, **kwargs
        )
    
    def schedule_in(self, callback: Callable, seconds: float,
                   repeat_interval: Optional[float] = None,
                   *args, **kwargs) -> str:
        """
        Agenda uma tarefa para daqui X segundos
        
        Args:
            callback: Função a executar
            seconds: Segundos no futuro
            repeat_interval: Se fornecido, repetir a cada N segundos
            *args: Argumentos posicionais
            **kwargs: Argumentos nomeados
        
        Returns:
            ID da tarefa
        """
        return self.schedule(
            callback, delay_seconds=seconds, repeat_interval=repeat_interval,
            *args, **kwargs
        )
    
    def cancel(self, task_id: str) -> bool:
        """
        Cancela uma tarefa agendada
        
        Args:
            task_id: ID da tarefa
        
        Returns:
            True se cancelada, False se não existia
        """
        task = self._tasks.get(task_id)
        
        if task is None:
            return False
        
        # Cancelar handle se existir
        if task.handle and not task.handle.cancelled():
            task.handle.cancel()
        
        # Remover tarefa
        del self._tasks[task_id]
        self._total_cancelled += 1
        
        logger.debug(f"🚫 Tarefa cancelada: {task_id[:8]}")
        return True
    
    async def _execute_task(self, task_id: str) -> None:
        """
        Executa uma tarefa agendada
        
        Args:
            task_id: ID da tarefa
        """
        task = self._tasks.get(task_id)
        
        if task is None:
            return
        
        try:
            # Executar callback
            if asyncio.iscoroutinefunction(task.callback):
                await task.callback(*task.args, **task.kwargs)
            else:
                await asyncio.get_event_loop().run_in_executor(
                    None, lambda: task.callback(*task.args, **task.kwargs)
                )
            
            # Atualizar métricas
            task.executed_count += 1
            task.last_execution = datetime.now()
            self._total_executed += 1
            
            logger.debug(f"✅ Tarefa executada: {task_id[:8]}")
            
            # Se for recorrente, reagendar
            if task.repeat_interval is not None and self._running:
                next_execution = datetime.now() + timedelta(seconds=task.repeat_interval)
                
                loop = asyncio.get_event_loop()
                handle = loop.call_later(
                    task.repeat_interval,
                    lambda: asyncio.create_task(self._execute_task(task_id))
                )
                
                task.handle = handle
                task.scheduled_at = next_execution
                
                logger.debug(
                    f"🔄 Tarefa reagendada: {task_id[:8]} "
                    f"(próxima em {task.repeat_interval}s)"
                )
            else:
                # Remover tarefa não-recorrente
                if task_id in self._tasks:
                    del self._tasks[task_id]
        
        except Exception as e:
            logger.error(
                f"❌ Erro ao executar tarefa {task_id[:8]}: {e}",
                exc_info=True
            )
            self._total_failed += 1
            
            # Remover tarefa com erro
            if task_id in self._tasks:
                del self._tasks[task_id]
    
    def get_task(self, task_id: str) -> Optional[ScheduledTask]:
        """
        Obtém informações de uma tarefa
        
        Args:
            task_id: ID da tarefa
        
        Returns:
            ScheduledTask ou None se não existir
        """
        return self._tasks.get(task_id)
    
    def get_pending_tasks(self) -> list[ScheduledTask]:
        """
        Retorna lista de tarefas pendentes
        
        Returns:
            Lista de ScheduledTask
        """
        return list(self._tasks.values())
    
    def get_task_count(self) -> int:
        """
        Retorna o número de tarefas pendentes
        
        Returns:
            Número de tarefas
        """
        return len(self._tasks)
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas do scheduler
        
        Returns:
            Dicionário com métricas
        """
        return {
            'running': self._running,
            'pending_tasks': len(self._tasks),
            'total_scheduled': self._total_scheduled,
            'total_executed': self._total_executed,
            'total_failed': self._total_failed,
            'total_cancelled': self._total_cancelled,
            'tasks': [
                {
                    'id': task.id,
                    'scheduled_at': task.scheduled_at.isoformat(),
                    'delay_seconds': task.delay_seconds,
                    'executed_count': task.executed_count,
                    'is_recurring': task.repeat_interval is not None,
                    'repeat_interval': task.repeat_interval
                }
                for task in self._tasks.values()
            ]
        }
    
    def __len__(self) -> int:
        """Retorna o número de tarefas pendentes"""
        return len(self._tasks)
    
    def __repr__(self) -> str:
        """Representação string do scheduler"""
        return f"PrecisionScheduler(pending={len(self._tasks)})"


# Instância global do scheduler
_scheduler_instance: Optional[PrecisionScheduler] = None


def get_precision_scheduler() -> PrecisionScheduler:
    """
    Retorna a instância global do scheduler (singleton)
    
    Returns:
        Instância do PrecisionScheduler
    """
    global _scheduler_instance
    
    if _scheduler_instance is None:
        _scheduler_instance = PrecisionScheduler()
    
    return _scheduler_instance
