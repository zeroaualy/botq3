"""
Signal Queue - Q3 IA Beta
Fila central assíncrona para gerenciamento de sinais
"""
import asyncio
import logging
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
from collections import deque

logger = logging.getLogger(__name__)


class SignalQueue:
    """
    Fila central de sinais com controle de backpressure
    
    Características:
    - Limite configurável de capacidade
    - Timeout de inserção para evitar bloqueio
    - Controle de backpressure
    - Métricas de performance
    - Priorização opcional de sinais
    """
    
    def __init__(self, max_size: int = 100, timeout_seconds: float = 5.0):
        """
        Inicializa a fila de sinais
        
        Args:
            max_size: Tamanho máximo da fila
            timeout_seconds: Timeout para operações de inserção
        """
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=max_size)
        self._max_size = max_size
        self._timeout = timeout_seconds
        
        # Métricas
        self._signals_added = 0
        self._signals_removed = 0
        self._signals_dropped = 0
        self._signals_timeout = 0
        
        # Histórico de latência
        self._latency_history = deque(maxlen=100)
        
        logger.info(f"✅ Signal Queue inicializada (max_size={max_size})")
    
    async def put(self, signal: Dict[str, Any], priority: int = 0, 
                  metadata: Optional[Dict[str, Any]] = None) -> bool:
        """
        Adiciona um sinal à fila com timeout
        
        Args:
            signal: Dados do sinal
            priority: Prioridade (maior = mais prioritário) - não implementado ainda
            metadata: Metadados adicionais
        
        Returns:
            bool: True se adicionado com sucesso, False se falhou
        """
        # Verificar se fila está cheia
        if self._queue.full():
            logger.warning(
                f"⚠️ Fila de sinais CHEIA ({self._queue.qsize()}/{self._max_size}) - "
                f"sinal será descartado"
            )
            self._signals_dropped += 1
            return False
        
        # Adicionar timestamp de entrada
        signal_wrapper = {
            'signal': signal,
            'priority': priority,
            'metadata': metadata or {},
            'queued_at': datetime.now(),
            'queue_entry_time': datetime.now().timestamp()
        }
        
        try:
            # Tentar adicionar com timeout
            await asyncio.wait_for(
                self._queue.put(signal_wrapper),
                timeout=self._timeout
            )
            
            self._signals_added += 1
            logger.debug(
                f"📥 Sinal adicionado à fila "
                f"(size={self._queue.qsize()}/{self._max_size})"
            )
            return True
        
        except asyncio.TimeoutError:
            logger.error(
                f"⏱️ Timeout ao adicionar sinal à fila "
                f"(timeout={self._timeout}s)"
            )
            self._signals_timeout += 1
            return False
        
        except Exception as e:
            logger.error(f"❌ Erro ao adicionar sinal à fila: {e}")
            return False
    
    async def get(self, timeout: Optional[float] = None) -> Optional[Dict[str, Any]]:
        """
        Remove e retorna o próximo sinal da fila
        
        Args:
            timeout: Timeout opcional em segundos (None = aguarda indefinidamente)
        
        Returns:
            Dicionário com o sinal ou None se timeout/erro
        """
        try:
            if timeout is not None:
                signal_wrapper = await asyncio.wait_for(
                    self._queue.get(),
                    timeout=timeout
                )
            else:
                signal_wrapper = await self._queue.get()
            
            self._signals_removed += 1
            
            # Calcular latência (tempo na fila)
            queue_time = datetime.now().timestamp() - signal_wrapper['queue_entry_time']
            self._latency_history.append(queue_time)
            
            logger.debug(
                f"📤 Sinal removido da fila "
                f"(latency={queue_time:.3f}s, remaining={self._queue.qsize()})"
            )
            
            # Retornar apenas o sinal original (sem wrapper)
            return signal_wrapper['signal']
        
        except asyncio.TimeoutError:
            logger.debug(f"⏱️ Timeout ao aguardar sinal (timeout={timeout}s)")
            return None
        
        except Exception as e:
            logger.error(f"❌ Erro ao remover sinal da fila: {e}")
            return None
    
    async def peek(self) -> Optional[Dict[str, Any]]:
        """
        Retorna o próximo sinal sem removê-lo da fila
        
        Returns:
            Dicionário com o sinal ou None se vazio
        """
        if self._queue.empty():
            return None
        
        # Não há método peek nativo, então fazemos get/put
        try:
            signal_wrapper = await asyncio.wait_for(
                self._queue.get(),
                timeout=0.1
            )
            await self._queue.put(signal_wrapper)
            return signal_wrapper['signal']
        except:
            return None
    
    def size(self) -> int:
        """
        Retorna o número atual de sinais na fila
        
        Returns:
            Número de sinais
        """
        return self._queue.qsize()
    
    def is_empty(self) -> bool:
        """
        Verifica se a fila está vazia
        
        Returns:
            bool: True se vazia
        """
        return self._queue.empty()
    
    def is_full(self) -> bool:
        """
        Verifica se a fila está cheia
        
        Returns:
            bool: True se cheia
        """
        return self._queue.full()
    
    def get_fill_percentage(self) -> float:
        """
        Retorna a porcentagem de ocupação da fila
        
        Returns:
            Porcentagem (0-100)
        """
        return (self._queue.qsize() / self._max_size) * 100
    
    def get_avg_latency(self) -> float:
        """
        Retorna a latência média (tempo na fila) em segundos
        
        Returns:
            Latência média ou 0 se sem histórico
        """
        if not self._latency_history:
            return 0.0
        return sum(self._latency_history) / len(self._latency_history)
    
    def get_max_latency(self) -> float:
        """
        Retorna a latência máxima registrada
        
        Returns:
            Latência máxima ou 0 se sem histórico
        """
        if not self._latency_history:
            return 0.0
        return max(self._latency_history)
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas da fila
        
        Returns:
            Dicionário com métricas
        """
        return {
            'current_size': self._queue.qsize(),
            'max_size': self._max_size,
            'fill_percentage': self.get_fill_percentage(),
            'signals_added': self._signals_added,
            'signals_removed': self._signals_removed,
            'signals_dropped': self._signals_dropped,
            'signals_timeout': self._signals_timeout,
            'avg_latency_ms': self.get_avg_latency() * 1000,
            'max_latency_ms': self.get_max_latency() * 1000,
            'is_backpressure': self.get_fill_percentage() > 80,
        }
    
    def reset_metrics(self) -> None:
        """Reseta as métricas da fila"""
        self._signals_added = 0
        self._signals_removed = 0
        self._signals_dropped = 0
        self._signals_timeout = 0
        self._latency_history.clear()
        logger.info("📊 Métricas da fila resetadas")
    
    async def clear(self) -> int:
        """
        Limpa todos os sinais da fila
        
        Returns:
            Número de sinais removidos
        """
        count = 0
        while not self._queue.empty():
            try:
                await asyncio.wait_for(self._queue.get(), timeout=0.1)
                count += 1
            except:
                break
        
        logger.info(f"🗑️ Fila limpa ({count} sinais removidos)")
        return count
    
    def __len__(self) -> int:
        """Retorna o tamanho da fila"""
        return self._queue.qsize()
    
    def __repr__(self) -> str:
        """Representação string da fila"""
        return (
            f"SignalQueue(size={self._queue.qsize()}/{self._max_size}, "
            f"fill={self.get_fill_percentage():.1f}%)"
        )


# Instância global da fila
_signal_queue_instance: Optional[SignalQueue] = None


def get_signal_queue() -> SignalQueue:
    """
    Retorna a instância global da fila de sinais (singleton)
    
    Returns:
        Instância do SignalQueue
    """
    global _signal_queue_instance
    
    if _signal_queue_instance is None:
        _signal_queue_instance = SignalQueue()
    
    return _signal_queue_instance
