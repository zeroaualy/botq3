# ✅ VERIFICAÇÃO DE INSTALAÇÃO

Use este guia para verificar se tudo está correto antes de executar o bot.

---

## 📋 CHECKLIST DE VERIFICAÇÃO

### 1. Estrutura de Diretórios
```bash
# Execute este comando:
ls -la

# Deve mostrar:
# - ai/
# - bot/
# - core/
# - myiq/         ← IMPORTANTE!
# - state/
# - main.py
# - requirements.txt
```

### 2. Biblioteca myiq
```bash
# Verifique se myiq está presente:
ls -la myiq/

# Deve mostrar:
# - core/
# - http/
# - models/
# - __init__.py
```

### 3. Módulo signal_engine
```bash
# Verifique se o novo módulo está presente:
ls -la core/signal_engine.py

# Deve existir e ter ~15KB
```

### 4. Teste de Importação
```bash
python3 -c "from core.signal_engine import SignalEngine; print('✅ SignalEngine OK')"
python3 -c "from myiq.core.client import IQOption; print('✅ myiq OK')"
python3 -c "from bot.telegram_bot import TelegramBot; print('✅ TelegramBot OK')"
```

Se todos os testes passarem, você está pronto para executar!

---

## 🚀 INSTALAÇÃO COMPLETA

### Passo 1: Ambiente Virtual
```bash
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
```

### Passo 2: Instalar Dependências
```bash
pip install --upgrade pip
pip install -r requirements.txt --break-system-packages
```

### Passo 3: Configurar Credenciais
```bash
nano state/config.py
# ou
vim state/config.py
```

Edite:
```python
TOKEN = "seu_token_telegram"
GRUPO_ID = seu_id_do_grupo
GROQ_API_KEY = "sua_chave_groq"
EMAIL = "seu_email_iqoption"
SENHA = "sua_senha"
```

### Passo 4: Executar
```bash
python main.py
```

---

## ❌ PROBLEMAS COMUNS

### Erro: "No module named 'myiq'"
**Causa**: Biblioteca myiq não está presente
**Solução**: Certifique-se que a pasta `myiq/` existe no diretório

### Erro: "No module named 'telegram'"
**Causa**: Dependências não instaladas
**Solução**: 
```bash
pip install python-telegram-bot --break-system-packages
```

### Erro: "No module named 'groq'"
**Causa**: Biblioteca Groq não instalada
**Solução**:
```bash
pip install groq --break-system-packages
```

### Erro: "No module named 'websockets'"
**Causa**: WebSockets não instalado
**Solução**:
```bash
pip install websockets --break-system-packages
```

---

## 🧪 TESTES FINAIS

Depois de instalar, execute os testes:

```bash
# Teste 1: Importações
python3 << EOF
from core.signal_engine import SignalEngine
from myiq.core.client import IQOption
from bot.telegram_bot import TelegramBot
print("✅ Todas as importações funcionando!")
