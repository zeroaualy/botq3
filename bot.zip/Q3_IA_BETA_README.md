# 🧠 Q3 IA Beta - Sistema de Inteligência Estratégica

## 🎯 VISÃO GERAL

A **Q3 IA Beta** é uma camada de inteligência estratégica que atua como:
- ✅ Filtro Estratégico Inteligente
- ✅ Controlador Adaptativo de Risco
- ✅ Otimizador Estatístico de Performance
- ✅ Camada de Proteção Avançada

## 🚀 PRINCÍPIOS FUNDAMENTAIS

### ❌ O QUE A Q3 IA BETA **NÃO FAZ**:
- ❌ NÃO transforma IA em geradora de sinais
- ❌ NÃO permite que IA decida CALL ou PUT diretamente
- ❌ NÃO cria previsão mística de mercado
- ❌ NÃO quebra a arquitetura modular existente

### ✅ O QUE A Q3 IA BETA **FAZ**:
- ✅ Decide se um sinal deve ou não ser executado
- ✅ Baseada em contexto ampliado e score inteligente
- ✅ Ajusta valores de operação dinamicamente
- ✅ Protege contra perdas consecutivas
- ✅ Analisa performance histórica

---

## 🏗️ ARQUITETURA

### Fluxo Completo:

```
Captura de Sinal
        ↓
Motor Determinístico de Análise Técnica
        ↓
Q3 IA Beta (Filtro Estratégico + Score)
        ↓
Risk Manager Adaptativo
        ↓
Executor de Trade
```

---

## 📊 COMPONENTES

### 1️⃣ Q3 IA Beta (`ai/q3_ia_beta.py`)

**Sistema de Score Inteligente** baseado em:
- 🔄 Tendência multi-timeframe (±2 pontos)
- 📉 Volatilidade atual (±2 pontos)
- 🔴 Sequência de perdas recente (-X pontos)
- ⏰ Horário do dia (±1 ponto)
- 💰 Payout mínimo aceitável (±2 pontos)
- 📈 Performance histórica do ativo (±2 pontos)
- 🕐 Winrate por horário (±1 ponto)
- 📊 Resultado das últimas 5 operações (±1 ponto)

**Decisões possíveis:**
- ✅ `APROVAR` - Score >= 5 (configurável)
- ❌ `REJEITAR` - Score abaixo do mínimo
- ⚠️ `ALTO_RISCO` - Score <= 2 (configurável)

**Exemplo de configuração:**
```python
{
    "score_minimo": 5,              # Score mínimo para aprovar
    "score_alto_risco": 2,          # Score de alto risco
    "payout_minimo": 75,            # Payout mínimo (%)
    "winrate_minimo": 55,           # Winrate mínimo (%)
    "max_perdas_consecutivas": 3,   # Máximo de perdas
    "volatilidade_maxima": 2.0,     # Volatilidade máxima
}
```

---

### 2️⃣ Risk Manager (`core/risk_manager.py`)

**Controle Adaptativo de Risco:**

- 📉 **Redução automática de valor** após perdas
  - 20% de redução por perda consecutiva
  - Mínimo: 30% do valor base

- ⏸️ **Pausa automática** após X perdas seguidas
  - Padrão: 5 perdas consecutivas
  - Tempo de pausa: 30 minutos (configurável)

- ⏰ **Ajuste de agressividade por horário**
  - Horários fortes (8-11h, 13-16h, 19-22h): 100%
  - Horários fracos: 70%

- 🔢 **Limite de operações simultâneas**
  - Padrão: máximo 3 operações paralelas

- 🌪️ **Bloqueio em volatilidade extrema**
  - Limite: 2.5 (configurável)

**Exemplo de uso:**
```python
pode_executar, motivo, valor_ajustado = await risk_manager.validar_operacao(
    sinal=sinal,
    contexto=contexto
)
```

---

### 3️⃣ Stats Optimizer (`ai/stats_optimizer.py`)

**Otimizador Estatístico de Performance:**

- 💾 **Armazena histórico detalhado** em JSON
- 📊 **Calcula performance por ativo**
- ⏰ **Calcula performance por horário**
- 🎯 **Identifica melhores janelas operacionais**
- 📈 **Ajusta prioridade de ativos dinamicamente**

**Métricas armazenadas:**
- Timestamp completo
- Par, direção, resultado
- Valor da operação e lucro
- Payout e score Q3
- Hora e dia da semana
- Contexto operacional

**Funções principais:**
```python
# Obter estatísticas de ativo
stats_optimizer.obter_stats_ativo("EURUSD")

# Obter estatísticas de horário
stats_optimizer.obter_stats_horario(14)  # 14h

# Obter perdas consecutivas
stats_optimizer.obter_perdas_consecutivas()

# Obter melhores ativos
stats_optimizer.obter_melhores_ativos(top=5)

# Obter melhores horários
stats_optimizer.obter_melhores_horarios(top=5)
```

---

## 📈 EXEMPLO DE FLUXO

```python
# 1. Sinal recebido
sinal = {
    "par": "EURUSD",
    "direcao": "CALL",
    "tempo_expiracao": 60
}

# 2. Q3 IA Beta avalia
decisao, score, analise = await q3_ia_beta.avaliar_sinal(
    sinal=sinal,
    contexto=contexto,
    payout=80.0
)
# → Score: 7
# → Decisão: APROVAR

# 3. Risk Manager valida
pode, motivo, valor = await risk_manager.validar_operacao(
    sinal=sinal,
    contexto=contexto
)
# → Pode executar: True
# → Valor ajustado: $8.00 (reduzido por 1 perda recente)

# 4. Trade executado
status, order_id = trade_executor.executar(
    sinal["par"],
    sinal["direcao"],
    valor,  # Valor ajustado pelo Risk Manager
    sinal["tempo_expiracao"]
)

# 5. Resultado registrado
stats_optimizer.registrar_operacao(
    par=sinal["par"],
    direcao=sinal["direcao"],
    resultado="WIN",
    valor_operacao=valor,
    valor_lucro=6.80,
    payout=80.0,
    score_q3=score
)
```

---

## 🔧 CONFIGURAÇÃO

### Configurar Q3 IA Beta:
```python
q3_ia_beta.atualizar_config({
    "score_minimo": 6,           # Mais conservador
    "payout_minimo": 80,         # Exigir payout maior
    "winrate_minimo": 60         # Exigir winrate maior
})
```

### Configurar Risk Manager:
```python
risk_manager.atualizar_config({
    "valor_base": 15.0,          # Aumentar valor base
    "max_perdas_pausa": 3,       # Pausar após 3 perdas
    "reducao_por_perda": 0.25    # Reduzir 25% por perda
})
```

---

## 📊 MENSAGENS DO BOT

### Análise Q3 IA Beta:
```
🧠 Q3 IA Beta - Análise

📊 Score: 7
🎯 Decisão: APROVAR

✅ Fatores Positivos:
  • Tendência multi-timeframe alinhada
  • Payout excelente (85%)
  • Winrate excelente no ativo (68.5%)

❌ Fatores Negativos:
  • Horário de baixa liquidez (23h)
```

### Validação Risk Manager:
```
🛡️ Risk Manager: Operação aprovada
💰 Valor ajustado: $8.00
```

### Resultado com estatísticas:
```
✅ RESULTADO: WIN

🏦 Conta: PRACTICE ✅
💰 Lucro op: $6.80
💵 Antes: $10,000.00
💵 Depois: $10,006.80
📊 Diferença: $6.80

📈 Resumo:
├ Lucro dia: $127.50
├ Win Rate: 64.2%
└ Ops: 32W / 18L / 0E

🤖 IA Guard:
└ Exec: 45 | Ignor: 3 | Risco: 2

🧠 Q3 IA Beta:
└ Score: 7 | Decisão: APROVAR

🛡️ Risk Manager:
└ Perdas consecutivas: 0 | Ops ativas: 0
```

---

## 🎯 BENEFÍCIOS

### 1. Filtragem Inteligente
- Rejeita sinais com baixa probabilidade
- Score baseado em múltiplos fatores
- Reduz operações de baixa qualidade

### 2. Proteção de Capital
- Ajusta valores automaticamente
- Pausa após perdas consecutivas
- Bloqueia em condições extremas

### 3. Otimização Contínua
- Aprende com histórico
- Identifica melhores ativos
- Identifica melhores horários

### 4. Transparência Total
- Score detalhado em cada operação
- Fatores positivos e negativos claros
- Histórico completo armazenado

---

## ⚠️ AVISOS IMPORTANTES

1. **Conta PRACTICE obrigatória**
   - Validação em múltiplas camadas
   - Sistema aborta se detectar conta REAL

2. **IA NÃO prevê mercado**
   - Sistema baseado em estatística
   - Não há previsão mágica
   - Apenas filtragem inteligente

3. **Não garante lucros**
   - Trading envolve riscos
   - Sistema reduz riscos, não elimina
   - Use sempre gestão de risco adequada

4. **Histórico é fundamental**
   - Sistema melhora com dados
   - Mínimo 10 ops por ativo para stats
   - Mínimo 5 ops por horário para stats

---

## 📚 ARQUIVOS ADICIONADOS

```
ai/
├── q3_ia_beta.py          # Sistema de score inteligente
└── stats_optimizer.py      # Otimizador estatístico

core/
└── risk_manager.py        # Gerenciador de risco adaptativo

historico_operacoes.json   # Banco de dados de histórico (gerado automaticamente)
```

---

## 🚀 INSTALAÇÃO

1. **Extrair o projeto:**
   ```bash
   unzip bot_q3_ia_beta.zip
   cd bot_q3_ia_v3
   ```

2. **Executar setup:**
   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```

3. **Configurar credenciais:**
   - Editar `state/config.py`
   - Adicionar TOKEN, GRUPO_ID, EMAIL, SENHA, GROQ_API_KEY

4. **Executar bot:**
   ```bash
   python3 main.py
   ```

---

## 📞 SUPORTE

Este é um projeto educacional focado em:
- ✅ Arquitetura de software de qualidade
- ✅ Boas práticas de desenvolvimento
- ✅ Sistemas de controle de risco
- ✅ Análise estatística

**NÃO oferece:**
- ❌ Sinais de trading
- ❌ Consultoria financeira
- ❌ Garantias de lucro
- ❌ Estratégias vencedoras mágicas

---

**Desenvolvido com foco em segurança, estatística e controle de risco profissional.**
