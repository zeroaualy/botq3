"""
Wrapper de compatibilidade
Permite que o telegram_bot.py use o cliente Playwright
sem modificações massivas no código
"""
import asyncio
import logging

logger = logging.getLogger(__name__)


class PlaywrightClientWrapper:
    """
    Wrapper que faz o cliente Playwright parecer síncrono
    para compatibilidade com código existente
    """
    
    def __init__(self, async_client):
        self.async_client = async_client
        self._loop = None
    
    def _get_loop(self):
        """Obtém ou cria event loop"""
        if self._loop is None or self._loop.is_closed():
            try:
                self._loop = asyncio.get_event_loop()
            except RuntimeError:
                self._loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self._loop)
        return self._loop
    
    def _run_async(self, coro):
        """Executa coroutine de forma síncrona"""
        loop = self._get_loop()
        if loop.is_running():
            # Se loop já está rodando, criar task
            return asyncio.create_task(coro)
        else:
            return loop.run_until_complete(coro)
    
    def garantir_practice(self):
        """Versão síncrona - sempre retorna True pois já foi garantido no login"""
        return self.async_client.esta_logado
    
    def verificar_ativo_disponivel(self, par):
        """
        Versão simplificada - sempre retorna disponível
        A verificação real acontece durante execução
        """
        par_limpo = par.replace("-OTC", "")
        return True, par_limpo
    
    def obter_saldo(self):
        """Retorna saldo atual"""
        return self.async_client.obter_saldo()
    
    def obter_tipo_conta(self):
        """Retorna tipo de conta"""
        return self.async_client.obter_tipo_conta()
    
    def esta_conectado(self):
        """Verifica se está conectado"""
        return self.async_client.esta_conectado()


class PlaywrightExecutorWrapper:
    """
    Wrapper que faz o executor Playwright parecer síncrono
    """
    
    def __init__(self, async_executor):
        self.async_executor = async_executor
        self._loop = None
    
    def _get_loop(self):
        """Obtém ou cria event loop"""
        if self._loop is None or self._loop.is_closed():
            try:
                self._loop = asyncio.get_event_loop()
            except RuntimeError:
                self._loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self._loop)
        return self._loop
    
    def _run_async(self, coro):
        """Executa coroutine de forma síncrona"""
        loop = self._get_loop()
        if loop.is_running():
            # Se loop já está rodando, usar run_coroutine_threadsafe
            import concurrent.futures
            future = asyncio.run_coroutine_threadsafe(coro, loop)
            return future.result(timeout=60)
        else:
            return loop.run_until_complete(coro)
    
    def executar(self, par, direcao, valor, expiracao):
        """
        Versão síncrona de executar
        NOTA: Deve ser chamado em contexto assíncrono para funcionar corretamente
        """
        # No contexto do main_playwright.py, isso será chamado
        # dentro de funções async, então não precisa wrapper
        # Esta versão é para compatibilidade apenas
        logger.warning("⚠️ Método síncrono executar() chamado - use await executor.executar() em contexto async")
        return False, None
    
    def verificar_resultado(self, order_id, aguardar_segundos=3):
        """
        Versão síncrona de verificar_resultado
        """
        logger.warning("⚠️ Método síncrono verificar_resultado() chamado - use await em contexto async")
        return "ERRO", 0
