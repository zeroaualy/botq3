"""
Cliente IQ Option usando biblioteca myiq
Responsável por conexão e garantia de conta PRACTICE
"""
import logging
import asyncio
import time
from typing import Tuple, Optional

logger = logging.getLogger(__name__)

# Flag global para instância
_iq_instance = None


class IQClient:
    """Cliente IQ Option com garantia de conta PRACTICE usando myiq"""
    
    def __init__(self, email, senha):
        self.email = email
        self.senha = senha
        self.iq = None
        self._connected = False
        self._practice_balance_id = None
        
    async def conectar(self, max_tentativas=3):
        """Conecta à IQ Option e força conta PRACTICE (async)"""
        global _iq_instance
        
        for tentativa in range(max_tentativas):
            try:
                logger.info(f"🔄 Conectando IQ Option ({tentativa + 1}/{max_tentativas})...")
                
                # Importar aqui para evitar problemas de circular import
                from myiq.core.client import IQOption
                
                # Criar nova instância
                self.iq = IQOption(self.email, self.senha)
                
                try:
                    # Start conecta e autentica
                    await self.iq.start()
                    
                    # Verificar conexão
                    if not self.iq.check_connect():
                        logger.error("❌ Falha na autenticação")
                        continue
                    
                    # Obter balances e selecionar PRACTICE
                    balances = await self.iq.get_balances()
                    
                    if not balances:
                        logger.error("❌ Não foi possível obter balances")
                        continue
                    
                    # Procurar balance PRACTICE (tipo 4)
                    practice_balance = None
                    for b in balances:
                        if b.type == 4:  # PRACTICE
                            practice_balance = b
                            break
                    
                    if not practice_balance:
                        logger.error("❌ Conta PRACTICE não encontrada")
                        continue
                    
                    # Selecionar PRACTICE
                    await self.iq.change_balance(practice_balance.id)
                    self._practice_balance_id = practice_balance.id
                    
                    logger.info(f"✅ Conectado!")
                    logger.info(f"📊 Tipo de conta: PRACTICE")
                    logger.info(f"💰 Saldo PRACTICE: ${practice_balance.amount:.2f}")
                    
                    self._connected = True
                    _iq_instance = self.iq
                    
                    # Inicializar lock e contadores para refresh
                    self._refresh_lock = asyncio.Lock()
                    self._refresh_fail_count = 0
                    self._last_refresh_log = 0
                    
                    # Refresh inicial do cache de ativos (assíncrono)
                    try:
                        await self.refresh_open_assets()
                    except Exception as e:
                        logger.warning(f"⚠️ Refresh inicial de ativos falhou: {e}")
                    
                    return True
                    
                except Exception as e:
                    logger.error(f"❌ Erro na conexão assíncrona: {e}")
                    import traceback
                    logger.error(traceback.format_exc())
                
                await asyncio.sleep(5)
                
            except Exception as e:
                logger.error(f"❌ Erro: {e}")
                import traceback
                logger.error(traceback.format_exc())
        
        return False
    
    async def refresh_open_assets(self) -> dict:
        """
        Atualiza cache de ativos abertos (binary + digital + turbo).
        Implementação VERSION-AGNOSTIC com detecção dinâmica de métodos.
        Usa async lock para evitar múltiplos refreshes simultâneos.

        Returns:
            dict: Ativos abertos organizados por tipo
        """
        # ── Lock para prevenir refreshes simultâneos ──────────────────
        if not hasattr(self, "_refresh_lock"):
            self._refresh_lock = asyncio.Lock()
        if not hasattr(self, "_refresh_fail_count"):
            self._refresh_fail_count = 0
        if not hasattr(self, "_last_refresh_log"):
            self._last_refresh_log = 0

        if self._refresh_lock.locked():
            # Refresh já em andamento — retorna cache atual
            return self.iq.actives_cache if self.iq else {}

        async with self._refresh_lock:
            try:
                if not self.iq or not self._connected:
                    return {}

                logger.info("🔄 Atualizando cache de ativos abertos...")

                binary_assets: dict = {}
                digital_assets: dict = {}
                turbo_assets: dict = {}

                # ── Estratégia 1: get_actives (myiq nativo async) ────────
                if hasattr(self.iq, "get_actives"):
                    try:
                        for instrument in ("binary", "digital", "turbo"):
                            try:
                                result = await asyncio.wait_for(
                                    self.iq.get_actives(instrument),
                                    timeout=15.0
                                )
                                if result and isinstance(result, dict):
                                    if instrument == "binary":
                                        binary_assets = result
                                    elif instrument == "digital":
                                        digital_assets = result
                                    elif instrument == "turbo":
                                        turbo_assets = result
                            except asyncio.TimeoutError:
                                logger.warning(f"⚠️ Timeout ao obter {instrument} actives")
                            except Exception as e:
                                logger.debug(f"⚠️ Erro em get_actives({instrument}): {e}")
                    except Exception as e:
                        logger.debug(f"⚠️ get_actives falhou: {e}")

                # ── Estratégia 2: get_all_open_time (versões antigas) ────
                if not binary_assets and not digital_assets:
                    method_names = [
                        "get_all_open_time",
                        "get_all_open_time_v2",
                        "get_all_ACTIVES_OPCODE",
                    ]
                    for method_name in method_names:
                        if hasattr(self.iq, method_name):
                            try:
                                fn = getattr(self.iq, method_name)
                                if asyncio.iscoroutinefunction(fn):
                                    raw = await asyncio.wait_for(fn(), timeout=15.0)
                                else:
                                    raw = fn()
                                if raw:
                                    binary_assets = raw.get("binary", raw.get("turbo-option", {}))
                                    digital_assets = raw.get("digital", raw.get("digital-option", {}))
                                    logger.info(f"✅ Usou {method_name} para obter ativos")
                                    break
                            except Exception as e:
                                logger.debug(f"⚠️ {method_name} falhou: {e}")

                # ── Estratégia 3: get_binary_option_detail / fallback ───
                if not binary_assets and not digital_assets:
                    for method_name in ("get_binary_option_detail", "get_digital_underlying_list"):
                        if hasattr(self.iq, method_name):
                            try:
                                fn = getattr(self.iq, method_name)
                                if asyncio.iscoroutinefunction(fn):
                                    raw = await asyncio.wait_for(fn(), timeout=15.0)
                                else:
                                    raw = fn()
                                if raw and isinstance(raw, dict):
                                    binary_assets = raw
                                    logger.info(f"✅ Usou {method_name} como fallback")
                                    break
                            except Exception as e:
                                logger.debug(f"⚠️ {method_name} falhou: {e}")

                # ── Consolidar all_assets ────────────────────────────────
                all_assets: dict = {}
                for aid, data in binary_assets.items():
                    if isinstance(data, dict):
                        all_assets[str(aid)] = {**data, "option_type": "binary"}
                for aid, data in digital_assets.items():
                    if isinstance(data, dict):
                        key = str(aid)
                        if key in all_assets:
                            all_assets[key]["has_digital"] = True
                        else:
                            all_assets[key] = {**data, "option_type": "digital"}
                for aid, data in turbo_assets.items():
                    if isinstance(data, dict):
                        key = str(aid)
                        if key not in all_assets:
                            all_assets[key] = {**data, "option_type": "turbo"}

                # ── Persistir no cache interno da instância IQ ──────────
                if binary_assets:
                    self.iq.actives_cache["binary-option"] = binary_assets
                    self.iq.actives_cache["binary"] = binary_assets
                if digital_assets:
                    self.iq.actives_cache["digital-option"] = digital_assets
                    self.iq.actives_cache["digital"] = digital_assets
                if turbo_assets:
                    self.iq.actives_cache["turbo"] = turbo_assets
                if all_assets:
                    self.iq.actives_cache["all-assets"] = all_assets

                # ── Contar abertos ────────────────────────────────────────
                def count_open(assets: dict) -> int:
                    return sum(
                        1 for a in assets.values()
                        if isinstance(a, dict) and (
                            a.get("is_open") or
                            (a.get("enabled") and not a.get("is_suspended", True))
                        )
                    )

                binary_open  = count_open(binary_assets)
                digital_open = count_open(digital_assets)
                total_open   = count_open(all_assets)

                if all_assets:
                    self._refresh_fail_count = 0
                    logger.info(
                        f"✅ Assets loaded: {total_open} open "
                        f"(binary: {binary_open}, digital: {digital_open}, "
                        f"total: {len(all_assets)})"
                    )
                else:
                    self._refresh_fail_count += 1
                    import time as _time
                    now = _time.time()
                    if now - self._last_refresh_log > 60:
                        logger.warning(
                            f"⚠️ Cache de ativos vazio após refresh "
                            f"(tentativas: {self._refresh_fail_count})"
                        )
                        self._last_refresh_log = now

                    if self._refresh_fail_count >= 3:
                        logger.critical(
                            "🚨 Cache vazio após 3 tentativas — trading pausado até próximo refresh"
                        )

                return {
                    "binary":  binary_assets,
                    "digital": digital_assets,
                    "turbo":   turbo_assets,
                    "all":     all_assets,
                    "stats": {
                        "binary_total":  len(binary_assets),
                        "binary_open":   binary_open,
                        "digital_total": len(digital_assets),
                        "digital_open":  digital_open,
                        "total_open":    total_open,
                    },
                }

            except Exception as e:
                logger.error(f"❌ Erro ao atualizar ativos: {e}")
                import traceback
                logger.error(traceback.format_exc())
                return {}
    
    async def garantir_practice(self):
        """
        SEGURANÇA CRÍTICA: Garante que está em PRACTICE (async)
        Retorna True se confirmado, False se falhou
        """
        try:
            if not self.iq or not self._connected:
                logger.error("❌ Sem conexão IQ Option")
                return False
            
            # Verificar se balance ativo é PRACTICE
            if not self._practice_balance_id:
                logger.error("❌ Balance PRACTICE não definido")
                return False
            
            if self.iq.active_balance_id != self._practice_balance_id:
                logger.warning(f"⚠️ Balance ativo não é PRACTICE")
                logger.info("🔄 Forçando mudança para PRACTICE...")
                
                # Reselecionar PRACTICE
                await self.iq.change_balance(self._practice_balance_id)
                
                # Verificar novamente
                if self.iq.active_balance_id != self._practice_balance_id:
                    logger.error(f"❌ FALHA CRÍTICA: Não conseguiu mudar para PRACTICE")
                    return False
            
            logger.info("✅ Confirmado: Operando em conta PRACTICE")
            return True
            
        except Exception as e:
            logger.error(f"❌ Erro ao verificar conta: {e}")
            return False
    
    def verificar_ativo_disponivel(self, par: str) -> Tuple[bool, Optional[str]]:
        """
        Verifica se ativo está aberto para binary/digital/turbo options.
        Suporta ambas as estruturas de dados (explorer.py e legacy).
        Tenta market open, depois OTC como fallback.
        """
        try:
            if not self.iq or not self._connected:
                logger.warning("⚠️ Conexão não estabelecida, permitindo tentativa")
                return True, par.replace("-OTC", "")

            par_limpo = par.replace("-OTC", "").replace("-otc", "").upper()
            is_otc_request = "-OTC" in par.upper()

            # ── Coletar todos os caches disponíveis ────────────────────
            caches_to_check = []
            for key in ("binary-option", "binary", "turbo", "digital-option", "digital"):
                cache = self.iq.actives_cache.get(key, {})
                if cache and isinstance(cache, dict):
                    caches_to_check.append((key, cache))

            if not caches_to_check:
                logger.warning("⚠️ Cache vazio — agendando refresh assíncrono")
                # Disparar refresh em background sem bloquear
                asyncio.ensure_future(self.refresh_open_assets())
                return True, par_limpo  # Permite a tentativa

            def _is_asset_open(data: dict) -> bool:
                """Verifica se ativo está aberto em qualquer estrutura de dados."""
                # Estrutura explorer.py: enabled + not suspended + market_open
                if data.get("enabled") is not None:
                    return (
                        data.get("enabled", False) and
                        not data.get("is_suspended", False) and
                        data.get("is_open", data.get("market_open", False))
                    )
                # Estrutura legacy
                return data.get("is_open", False)

            def _asset_matches(data: dict, name_upper: str, otc: bool = False) -> bool:
                """Verifica se ativo corresponde ao nome buscado."""
                for field in ("name", "ticker", "underlying"):
                    v = data.get(field, "")
                    if not v:
                        continue
                    v_up = str(v).upper()
                    if otc:
                        if (name_upper + "-OTC") in v_up or (name_upper in v_up and "OTC" in v_up):
                            return True
                    else:
                        if v_up == name_upper or v_up == name_upper + "-OTC":
                            return False  # exact non-OTC only
                        if v_up == name_upper:
                            return True
                        if name_upper in v_up and "OTC" not in v_up:
                            return True
                return False

            # ── Procurar: non-OTC aberto primeiro ─────────────────────
            for cache_key, cache in caches_to_check:
                for active_id, data in cache.items():
                    if not isinstance(data, dict):
                        continue
                    if _asset_matches(data, par_limpo, otc=False):
                        if _is_asset_open(data):
                            logger.info(f"✅ {par_limpo} disponível [{cache_key}] (ID: {active_id})")
                            return True, par_limpo

            # ── Fallback: OTC ──────────────────────────────────────────
            for cache_key, cache in caches_to_check:
                for active_id, data in cache.items():
                    if not isinstance(data, dict):
                        continue
                    if _asset_matches(data, par_limpo, otc=True):
                        if _is_asset_open(data):
                            par_otc = f"{par_limpo}-OTC"
                            logger.info(f"✅ Usando OTC: {par_otc} [{cache_key}] (ID: {active_id})")
                            return True, par_otc

            # ── Se solicitou OTC explicitamente mas não achou ─────────
            if is_otc_request:
                logger.warning(f"⚠️ {par} (OTC) não disponível ou fechado")
            else:
                logger.warning(f"⚠️ {par_limpo} não disponível (nem market, nem OTC)")

            return False, None

        except Exception as e:
            logger.error(f"❌ Erro ao verificar ativo: {e}")
            return True, par.replace("-OTC", "")
    
    async def obter_saldo(self) -> float:
        """Retorna saldo atual (async)"""
        try:
            if not self.iq or not self._connected:
                return 0.0
            
            # Obter balances novamente
            balances = await self.iq.get_balances()
            
            for b in balances:
                if b.id == self._practice_balance_id:
                    return float(b.amount)
            
            return 0.0
        except Exception as e:
            logger.error(f"❌ Erro ao obter saldo: {e}")
            return 0.0
    
    def obter_tipo_conta(self) -> str:
        """Retorna tipo de conta"""
        if not self.iq or not self._connected:
            return "DESCONECTADO"
        
        if self.iq.active_balance_id == self._practice_balance_id:
            return "PRACTICE"
        else:
            return "REAL"  # WARNING!
    
    def esta_conectado(self) -> bool:
        """Verifica se está conectado"""
        return self._connected and self.iq is not None and self.iq.check_connect()
    
    async def executar_ordem(self, par: str, direcao: str, valor: float, expiracao: int) -> Tuple[bool, Optional[str]]:
        """
        Executa ordem binary usando myiq (async)
        
        Args:
            par: Par a operar
            direcao: CALL ou PUT
            valor: Valor a investir
            expiracao: Tempo de expiração em segundos
        
        Returns:
            Tuple[bool, Optional[str]]: (sucesso, order_id)
        """
        try:
            if not await self.garantir_practice():
                logger.error("❌ Falha na verificação PRACTICE")
                return False, None
            
            # Verificar disponibilidade
            disponivel, par_final = self.verificar_ativo_disponivel(par)
            
            if not disponivel:
                logger.error(f"❌ Ativo {par} não disponível")
                return False, None
            
            # Converter direção
            direction = direcao.lower()  # "call" ou "put"
            
            # myiq usa buy_blitz, mas vamos adaptar para binary
            # Precisamos encontrar o active_id do par
            active_id = self._encontrar_active_id(par_final)
            
            if not active_id:
                logger.error(f"❌ Não foi possível encontrar ID do ativo {par_final}")
                return False, None
            
            # Executar compra usando método adaptado
            logger.info(f"🎯 Executando ordem: {par_final} {direcao} ${valor} {expiracao}s")
            
            result = await self._buy_binary(active_id, direction, valor, expiracao)
            
            if result and result.get("status") != "error":
                order_id = result.get("order_id")
                logger.info(f"✅ Ordem executada: ID {order_id}")
                return True, str(order_id)
            else:
                logger.error(f"❌ Falha na execução da ordem: {result}")
                return False, None
            
        except Exception as e:
            logger.error(f"❌ Erro ao executar ordem: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False, None
    
    def _encontrar_active_id(self, par: str) -> Optional[int]:
        """Encontra o active_id de um par buscando em todos os caches disponíveis"""
        try:
            par_upper = par.upper().replace("-OTC", "")
            is_otc = "-OTC" in par.upper()
            cache = self.iq.actives_cache

            # Prioridades de busca
            priority_keys = ["binary-option", "binary", "turbo", "digital-option", "digital"]
            all_keys = list(cache.keys())
            search_keys = priority_keys + [k for k in all_keys if k not in priority_keys]

            for cat_key in search_keys:
                cat_data = cache.get(cat_key, {})
                if not isinstance(cat_data, dict):
                    continue

                for active_id, active_data in cat_data.items():
                    if not isinstance(active_data, dict):
                        continue

                    name = str(active_data.get("name", "") or active_data.get("ticker", "")).upper()
                    underlying = str(active_data.get("underlying", "")).upper()

                    if is_otc:
                        # Busca OTC explícita
                        if (par_upper + "-OTC") in name or (par_upper in name and "OTC" in name):
                            return int(active_id)
                    else:
                        # Busca sem OTC
                        name_clean = name.replace("-OTC", "")
                        underlying_clean = underlying.replace("-OTC", "")
                        if par_upper == name_clean or par_upper in name_clean or par_upper in underlying_clean:
                            return int(active_id)

            return None

        except Exception as e:
            logger.error(f"❌ Erro ao encontrar active_id: {e}")
            return None
    
    async def _buy_binary(self, active_id: int, direction: str, amount: float, duration: int) -> dict:
        """
        Compra opção binária (adaptado do buy_blitz)
        
        Esta função é uma adaptação do método buy_blitz da myiq
        para funcionar com opções binárias (binary options).
        """
        try:
            from myiq.core.constants import OPTION_TYPE_BINARY, OP_OPEN_OPTION, EV_POSITION_CHANGED, OP_SUBSCRIBE_POSITIONS
            from myiq.core.utils import get_req_id
        except ImportError:
            # Fallback - definir constantes localmente
            OPTION_TYPE_BINARY = 1  # Binary options
            OP_OPEN_OPTION = "binary-options.open-option"
            EV_POSITION_CHANGED = "portfolio.position-changed"
            OP_SUBSCRIBE_POSITIONS = "subscribeMessage"
            
            def get_req_id():
                import random
                return f"req_{int(time.time())}_{random.randint(1000, 9999)}"
        
        if not self.iq.active_balance_id:
            raise ValueError("Saldo não selecionado. Use change_balance() primeiro.")

        # Obter payout
        profit_percent = self.iq.get_profit_percent(active_id)
        if profit_percent == 0:
            logger.warning(f"⚠️ Payout não encontrado para ativo {active_id}, usando 80%")
            profit_percent = 80
        
        req_id = get_req_id()
        server_time = self.iq.get_server_timestamp()
        if server_time == 0:
            server_time = int(time.time())

        # Calcular expiração (alinhar com próximo minuto + margem)
        expired = (server_time - (server_time % 60)) + 120
        
        body = {
            "user_balance_id": self.iq.active_balance_id,
            "active_id": active_id,
            "option_type_id": OPTION_TYPE_BINARY,
            "direction": direction.lower(),
            "expired": expired,
            "expiration_size": duration,
            "refund_value": 0,
            "price": float(amount),
            "value": 0, 
            "profit_percent": profit_percent
        }

        # Future para resposta imediata
        ack_future = self.iq.dispatcher.create_future(req_id)
        
        # Future para o ID da ordem
        order_id_future = asyncio.get_running_loop().create_future()
        
        def on_order_created(msg):
            if msg.get("name") == EV_POSITION_CHANGED:
                raw = msg.get("msg", {})
                evt = raw.get("raw_event", {}).get("binary_options_option_changed1", {})
                
                if (str(evt.get("active_id")) == str(active_id) and 
                    evt.get("direction") == direction.lower() and
                    evt.get("result") == "opened"):
                    
                    if not order_id_future.done():
                        order_id_future.set_result(raw.get("external_id") or raw.get("id"))

        self.iq.dispatcher.add_listener(EV_POSITION_CHANGED, on_order_created)
        
        logger.info(f"📤 Enviando ordem binary: {active_id} {direction} ${amount}")
        
        try:
            # Enviar Request
            await self.iq.ws.send({
                "name": "sendMessage",
                "request_id": req_id,
                "msg": {
                    "name": OP_OPEN_OPTION,
                    "version": "2.0",
                    "body": body
                }
            })
            
            # Esperar ACK
            ack = await asyncio.wait_for(ack_future, timeout=10.0)
            
            # Validar ACK
            ack_status = ack.get("status")
            if ack_status not in [0, 2000]:
                msg_err = ack.get("msg")
                if isinstance(msg_err, dict):
                    msg_err = msg_err.get("message")
                raise RuntimeError(f"Erro na abertura da ordem: {msg_err}")

            # ID da ordem
            created_order_id = ack.get("msg", {}).get("id")
            logger.info(f"✅ Ordem ACK recebido: ID {created_order_id}")

            order_id = created_order_id
            
            self.iq.dispatcher.remove_listener(EV_POSITION_CHANGED, on_order_created)

            # Subscrever para resultados
            await self.iq.ws.send({
                "name": "subscribeMessage",
                "request_id": get_req_id(),
                "msg": {
                    "name": "portfolio.position-changed",
                    "version": "3.0",
                    "params": {
                        "routingFilters": {
                            "ids": [order_id]
                        }
                    }
                }
            })

            result_future = asyncio.get_running_loop().create_future()
            
            def on_result(msg):
                if msg.get("name") == EV_POSITION_CHANGED:
                    raw = msg.get("msg", {})
                    msg_id = raw.get("id")
                    external_id = raw.get("external_id")
                    
                    is_same_id = (str(msg_id) == str(order_id) or str(external_id) == str(order_id))
                    
                    if is_same_id:
                        status = raw.get("status")
                        evt = raw.get("raw_event", {}).get("binary_options_option_changed1", {})
                        
                        is_closed = (status == "closed")
                        has_result = (evt.get("result") in ["win", "loose", "equal"])
                        
                        if is_closed or has_result:
                            if not result_future.done():
                                pnl = raw.get("pnl", 0)
                                if pnl == 0 and "profit_amount" in evt:
                                    net = evt.get("profit_amount", 0) - evt.get("amount", 0)
                                    pnl = net
                                
                                outcome = evt.get("result") or raw.get("close_reason")
                                
                                result_data = {
                                    "status": "closed",
                                    "result": outcome,
                                    "profit": pnl, 
                                    "pnl": pnl,
                                    "order_id": order_id
                                }
                                result_future.set_result(result_data)

            self.iq.dispatcher.add_listener(EV_POSITION_CHANGED, on_result)
            
            # Esperar resultado
            wait_time = max(duration, 60) + 30
            logger.info(f"⏳ Aguardando resultado (timeout: {wait_time}s)")
            
            trade_result = await asyncio.wait_for(result_future, timeout=wait_time)
            return trade_result

        except asyncio.TimeoutError:
            logger.error("❌ Timeout aguardando resultado")
            return {"status": "error", "result": "timeout", "pnl": 0}
        except Exception as e:
            logger.error(f"❌ Erro na ordem: {e}")
            raise
        finally:
            if 'on_order_created' in locals():
                self.iq.dispatcher.remove_listener(EV_POSITION_CHANGED, on_order_created)
            if 'on_result' in locals():
                self.iq.dispatcher.remove_listener(EV_POSITION_CHANGED, on_result)
    
    def verificar_resultado_ordem(self, order_id: str) -> Tuple[str, float]:
        """
        Verifica resultado de uma ordem
        
        Args:
            order_id: ID da ordem
        
        Returns:
            Tuple[str, float]: (resultado, lucro)
                resultado: "WIN", "LOSS", "EMPATE", ou "DESCONHECIDO"
                lucro: Valor de lucro/prejuízo
        """
        # Esta função não é mais necessária pois buy_binary já retorna o resultado
        # Mas vamos manter para compatibilidade
        logger.warning("⚠️ verificar_resultado_ordem não é mais necessário com myiq")
        return "DESCONHECIDO", 0.0
