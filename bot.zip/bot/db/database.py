"""
Database Layer — Bot Q3 Beta
SQLite via stdlib (no aiosqlite dependency).
All async via asyncio.to_thread for compatibility.
"""
import sqlite3
import asyncio
import logging
from datetime import datetime, date
from typing import Optional, Dict, List
import os

logger = logging.getLogger(__name__)
DB_PATH = os.path.join(os.path.dirname(__file__), "bot_q3.db")


def _connect():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _init_sync():
    conn = _connect()
    c = conn.cursor()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS trades (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_id       TEXT,
            timestamp       TEXT NOT NULL,
            asset           TEXT NOT NULL,
            direction       TEXT NOT NULL,
            amount          REAL NOT NULL,
            payout          REAL NOT NULL DEFAULT 0,
            result          TEXT,
            pnl             REAL NOT NULL DEFAULT 0,
            martingale_level INTEGER NOT NULL DEFAULT 0,
            slippage_ms     INTEGER NOT NULL DEFAULT 0,
            signal_source   TEXT NOT NULL DEFAULT 'manual',
            order_id        TEXT
        );
        CREATE TABLE IF NOT EXISTS martingale_state (
            id                  INTEGER PRIMARY KEY CHECK (id = 1),
            current_level       INTEGER NOT NULL DEFAULT 0,
            consecutive_losses  INTEGER NOT NULL DEFAULT 0,
            base_value          REAL NOT NULL DEFAULT 10.0,
            last_result         TEXT,
            last_update         TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS performance_daily (
            date    TEXT PRIMARY KEY,
            total   INTEGER NOT NULL DEFAULT 0,
            wins    INTEGER NOT NULL DEFAULT 0,
            losses  INTEGER NOT NULL DEFAULT 0,
            draws   INTEGER NOT NULL DEFAULT 0,
            pnl     REAL NOT NULL DEFAULT 0.0
        );
    """)
    # Ensure martingale singleton
    c.execute("""
        INSERT OR IGNORE INTO martingale_state
        (id, current_level, consecutive_losses, base_value, last_result, last_update)
        VALUES (1, 0, 0, 10.0, NULL, datetime('now'))
    """)
    conn.commit()
    conn.close()
    logger.info(f"✅ Database ready: {DB_PATH}")


async def init_db():
    await asyncio.to_thread(_init_sync)


# ─────────────────────────────────────────────────────────────
# TRADES
# ─────────────────────────────────────────────────────────────

def _insert_trade_sync(signal_id, ts, asset, direction, amount, payout,
                        martingale_level, slippage_ms, signal_source, order_id):
    conn = _connect()
    c = conn.cursor()
    c.execute("""
        INSERT INTO trades
        (signal_id, timestamp, asset, direction, amount, payout,
         martingale_level, slippage_ms, signal_source, order_id)
        VALUES (?,?,?,?,?,?,?,?,?,?)
    """, (signal_id, ts, asset, direction, amount, payout,
          martingale_level, slippage_ms, signal_source, order_id))
    row_id = c.lastrowid
    conn.commit()
    conn.close()
    return row_id


async def insert_trade(asset, direction, amount, payout, martingale_level,
                       slippage_ms, signal_source, signal_id=None, order_id=None) -> int:
    ts = datetime.now().isoformat()
    return await asyncio.to_thread(
        _insert_trade_sync, signal_id, ts, asset, direction, amount, payout,
        martingale_level, slippage_ms, signal_source, order_id
    )


def _update_result_sync(trade_id, result, pnl, order_id):
    conn = _connect()
    if order_id:
        conn.execute("UPDATE trades SET result=?, pnl=?, order_id=? WHERE id=?",
                     (result, pnl, order_id, trade_id))
    else:
        conn.execute("UPDATE trades SET result=?, pnl=? WHERE id=?",
                     (result, pnl, trade_id))
    conn.commit()
    conn.close()


async def update_trade_result(trade_id: int, result: str, pnl: float, order_id: str = None):
    await asyncio.to_thread(_update_result_sync, trade_id, result, pnl, order_id)


def _recent_trades_sync(limit):
    conn = _connect()
    rows = conn.execute("SELECT * FROM trades ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


async def get_recent_trades(limit=20) -> List[Dict]:
    return await asyncio.to_thread(_recent_trades_sync, limit)


# ─────────────────────────────────────────────────────────────
# DAILY PERFORMANCE
# ─────────────────────────────────────────────────────────────

def _upsert_daily_sync(result, pnl):
    today = date.today().isoformat()
    wins = 1 if result == "WIN" else 0
    losses = 1 if result == "LOSS" else 0
    draws = 1 if result == "EMPATE" else 0
    conn = _connect()
    conn.execute("""
        INSERT INTO performance_daily (date, total, wins, losses, draws, pnl)
        VALUES (?, 1, ?, ?, ?, ?)
        ON CONFLICT(date) DO UPDATE SET
            total  = total + 1,
            wins   = wins + excluded.wins,
            losses = losses + excluded.losses,
            draws  = draws + excluded.draws,
            pnl    = pnl + excluded.pnl
    """, (today, wins, losses, draws, pnl))
    conn.commit()
    conn.close()


async def upsert_daily(result: str, pnl: float):
    await asyncio.to_thread(_upsert_daily_sync, result, pnl)


def _today_sync():
    today = date.today().isoformat()
    conn = _connect()
    row = conn.execute("SELECT * FROM performance_daily WHERE date=?", (today,)).fetchone()
    conn.close()
    if row:
        d = dict(row)
        d["winrate"] = round((d["wins"] / d["total"] * 100), 1) if d["total"] > 0 else 0.0
        return d
    return {"date": today, "total": 0, "wins": 0, "losses": 0, "draws": 0, "pnl": 0.0, "winrate": 0.0}


async def get_today_stats() -> Dict:
    return await asyncio.to_thread(_today_sync)


def _all_time_sync():
    conn = _connect()
    row = conn.execute("""
        SELECT COUNT(*) as total,
               SUM(CASE WHEN result='WIN' THEN 1 ELSE 0 END) as wins,
               SUM(CASE WHEN result='LOSS' THEN 1 ELSE 0 END) as losses,
               SUM(CASE WHEN result='EMPATE' THEN 1 ELSE 0 END) as draws,
               SUM(pnl) as pnl
        FROM trades WHERE result IS NOT NULL
    """).fetchone()
    conn.close()
    if row:
        total = row["total"] or 0
        wins = row["wins"] or 0
        pnl = row["pnl"] or 0.0
        return {
            "total": total, "wins": wins,
            "losses": row["losses"] or 0, "draws": row["draws"] or 0,
            "pnl": round(pnl, 2),
            "winrate": round((wins / total * 100), 1) if total > 0 else 0.0,
        }
    return {"total": 0, "wins": 0, "losses": 0, "draws": 0, "pnl": 0.0, "winrate": 0.0}


async def get_all_time_stats() -> Dict:
    return await asyncio.to_thread(_all_time_sync)


def _consecutive_losses_sync():
    conn = _connect()
    rows = conn.execute(
        "SELECT result FROM trades WHERE result IS NOT NULL ORDER BY id DESC LIMIT 20"
    ).fetchall()
    conn.close()
    count = 0
    for row in rows:
        if row["result"] == "LOSS":
            count += 1
        else:
            break
    return count


async def get_consecutive_losses() -> int:
    return await asyncio.to_thread(_consecutive_losses_sync)


# ─────────────────────────────────────────────────────────────
# MARTINGALE STATE
# ─────────────────────────────────────────────────────────────

def _load_mg_sync():
    conn = _connect()
    row = conn.execute("SELECT * FROM martingale_state WHERE id=1").fetchone()
    conn.close()
    if row:
        return dict(row)
    return {"current_level": 0, "consecutive_losses": 0, "base_value": 10.0, "last_result": None}


async def load_martingale_state() -> Dict:
    return await asyncio.to_thread(_load_mg_sync)


def _save_mg_sync(level, consecutive_losses, base_value, last_result):
    conn = _connect()
    conn.execute("""
        UPDATE martingale_state
        SET current_level=?, consecutive_losses=?, base_value=?,
            last_result=?, last_update=datetime('now')
        WHERE id=1
    """, (level, consecutive_losses, base_value, last_result))
    conn.commit()
    conn.close()


async def save_martingale_state(level: int, consecutive_losses: int, base_value: float, last_result: Optional[str]):
    await asyncio.to_thread(_save_mg_sync, level, consecutive_losses, base_value, last_result)
