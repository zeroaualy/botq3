# 🔧 TROUBLESHOOTING - SOLUÇÕES PARA ERROS COMUNS

## ⚠️ IMPORTANTE: CREDENCIAIS

O código **NÃO contém suas credenciais**. Você precisa criar o arquivo `.env`:

```bash
cd /root/bot_playwright_v3.1
nano .env
```

Cole isto e edite com suas credenciais REAIS:

```env
EMAIL=seu_email@iqoption.com
SENHA=sua_senha_aqui
TOKEN=seu_token_telegram_bot
GRUPO_ID=-1001234567890
GROQ_API_KEY=
```

Salvar: `Ctrl+O`, `Enter`, `Ctrl+X`

---

## 🐛 ERROS E SOLUÇÕES

### 1. ❌ "Timeout ao carregar formulário de login"

**Erro:**
```
TimeoutError: Timeout 20000ms exceeded
waiting for selector "input[name='email']"
```

**Causas:**
- Internet lenta
- IQ Option bloqueou IP do VPS
- Página mudou estrutura

**Soluções:**

**A) Aumentar timeout (já implementado)**
```python
await self.page.wait_for_selector('input[name="email"]', timeout=30000)
```

**B) Verificar se página carregou**
```bash
# Executar bot em modo NÃO headless para ver o que acontece
# Editar temporariamente main_playwright.py:
await iq_client.iniciar(headless=False)  # Mudar True para False
```

**C) Testar manualmente**
```bash
python3 << 'EOF'
import asyncio
from playwright.async_api import async_playwright

async def test():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        page = await browser.new_page()
        await page.goto('https://login.iqoption.com/pt/login')
        await asyncio.sleep(30)  # Ver se carrega
        await browser.close()

asyncio.run(test())
EOF
```

---

### 2. ❌ "Botão de login não encontrado"

**Erro:**
```
⚠️ Botão não encontrado, pressionando Enter...
```

**Causas:**
- IQ Option mudou classe CSS do botão
- Botão não está visível

**Soluções:**

**A) Inspecionar página real**
```bash
# Rodar em modo visual (headless=False)
# Ver qual é o seletor real do botão
```

**B) Usar JavaScript para forçar clique**

Editar `core/iq_playwright_client.py`:

```python
# Substituir bloco de clique por:
await self.page.evaluate('''
    const btn = document.querySelector('button[type="submit"]');
    if (btn) btn.click();
''')
```

**C) O bot já tem fallback** - pressiona Enter automaticamente

---

### 3. ❌ "Login failed" ou "Credenciais inválidas"

**Erro:**
```
❌ Erro de login: Invalid credentials
```

**Soluções:**

**A) Verificar email/senha no .env**
```bash
cat .env
# Confirmar que EMAIL e SENHA estão corretos
```

**B) Testar login manual**
- Abrir `https://login.iqoption.com/pt/login`
- Tentar fazer login com mesmas credenciais
- Se falhar, resetar senha

**C) Verificar se conta está bloqueada**
- IQ Option pode ter bloqueado temporariamente
- Aguardar 1-2 horas e tentar novamente

**D) Usar CAPTCHA solver (avançado)**
- IQ Option pode estar pedindo CAPTCHA
- Considerar usar serviço como 2captcha

---

### 4. ❌ "Conta REAL detectada" 

**Erro:**
```
⚠️ Conta REAL detectada! Mudando para PRACTICE...
❌ FALHA CRÍTICA: Não conseguiu mudar para PRACTICE
```

**Soluções:**

**A) Verificar seletores de conta**

Inspecionar elemento do botão de conta na interface real e atualizar seletores:

```python
seletores_conta = [
    '[data-test="account-type"]',  # Adicionar se existir
    'button[class*="account"]',
    '[class*="balance-type"]',
    # ... adicionar novos seletores
]
```

**B) Usar JavaScript para forçar mudança**

```python
await self.page.evaluate('''
    // Procurar elemento de conta
    const accountBtn = document.querySelector('[class*="account"]');
    if (accountBtn) accountBtn.click();
    
    // Esperar 1s
    setTimeout(() => {
        // Clicar em PRACTICE
        const practiceOpt = document.querySelector('[data-value="PRACTICE"]');
        if (practiceOpt) practiceOpt.click();
    }, 1000);
''')
```

**C) Screenshot para debug**

```python
await self.page.screenshot(path='/tmp/conta_debug.png')
logger.info("📸 Screenshot salvo para debug")
```

---

### 5. ❌ "Saldo não detectado"

**Erro:**
```
⚠️ Não foi possível ler saldo, usando valor padrão
💰 Saldo atualizado: $10000.00
```

**Solução:**

**A) Não é crítico** - bot assume saldo de $10000 (padrão conta PRACTICE)

**B) Para ler saldo real**, atualizar seletores:

```python
seletores_saldo = [
    '[data-test="balance"]',
    'span[class*="balance"]',
    'div[class*="balance-value"]',
    # Adicionar após inspecionar elemento
]
```

**C) Usar OCR (avançado)**

```python
from PIL import Image
import pytesseract

# Capturar screenshot da área do saldo
await self.page.locator('[class*="balance"]').screenshot(path='saldo.png')

# Ler com OCR
img = Image.open('saldo.png')
saldo_text = pytesseract.image_to_string(img)
saldo = float(re.findall(r'[\d\.]+', saldo_text)[0])
```

---

### 6. ❌ "Trade falhou ao clicar em CALL/PUT"

**Erro:**
```
❌ Não encontrou botão CALL clicável
```

**Causas:**
- Botão não carregou
- Botão está desabilitado
- Mercado fechado

**Soluções:**

**A) Aguardar carregamento**

```python
# Esperar botão estar visível E habilitado
await self.page.wait_for_selector(
    'button:has-text("CALL")',
    state='visible',
    timeout=15000
)
```

**B) Scroll até botão**

```python
botao = await self.page.query_selector('button:has-text("CALL")')
if botao:
    await botao.scroll_into_view_if_needed()
    await asyncio.sleep(1)
    await botao.click()
```

**C) Forçar clique via JavaScript**

```python
await self.page.evaluate('''
    const callBtn = document.querySelector('button[class*="call"]');
    if (callBtn) callBtn.click();
''')
```

**D) Verificar se mercado está aberto**

```bash
# Executar trade apenas em horário de mercado
# Segunda a Sexta: 9h - 18h (horário do ativo)
```

---

### 7. ❌ "Ordem não confirmada na interface"

**Erro:**
```
⚠️ Não encontrou confirmação visual, assumindo sucesso
```

**Solução:**

**A) Aumentar delay de verificação**

```python
# Em _verificar_ordem_aberta()
await asyncio.sleep(5)  # Aumentar de 2 para 5 segundos
```

**B) Adicionar mais seletores de confirmação**

```python
seletores_confirmacao = [
    '[data-test="order-opened"]',
    'div[class*="trade-open"]',
    'span:has-text("Order opened")',
    'span:has-text("Ordem aberta")',
    # ... adicionar novos
]
```

**C) Screenshot da confirmação**

```python
await self.page.screenshot(path='/tmp/ordem_confirmada.png')
```

---

### 8. ❌ "Reconectar falhou"

**Erro:**
```
❌ Erro ao reconectar: ...
```

**Soluções:**

**A) Aumentar delay entre reconexões**

```python
async def reconectar(self):
    await self.fechar()
    await asyncio.sleep(10)  # Aumentar de 5 para 10
    return await self.iniciar()
```

**B) Limpar cache/cookies**

```python
async def reconectar(self):
    await self.fechar()
    
    # Limpar dados
    if os.path.exists('/tmp/playwright-cache'):
        import shutil
        shutil.rmtree('/tmp/playwright-cache')
    
    await asyncio.sleep(10)
    return await self.iniciar()
```

**C) Verificar credenciais**

```python
# Antes de reconectar, verificar se .env está correto
if not self.email or not self.senha:
    logger.error("❌ Credenciais vazias no .env!")
    return False
```

---

## 📸 DEBUG COM SCREENSHOTS

Para facilitar debug, adicione screenshots em pontos críticos:

```python
# Após login
await self.page.screenshot(path='/tmp/apos_login.png')

# Antes de executar trade
await self.page.screenshot(path='/tmp/antes_trade.png')

# Após clicar CALL/PUT
await self.page.screenshot(path='/tmp/apos_click.png')

# Ver screenshots:
ls -lh /tmp/*.png
```

---

## 🔍 MODO DEBUG VISUAL

Para ver o que está acontecendo:

**1. Editar `main_playwright.py`:**

```python
# Linha ~90
conectado = await iq_client.iniciar(headless=False)  # Mudar True para False
```

**2. Executar localmente (não no VPS)**

```bash
python3 main_playwright.py
```

**3. Você verá o navegador abrindo e executando ações**

---

## 📝 LOGS DETALHADOS

Ativar logs mais verbosos:

```python
# No início de main_playwright.py
logging.basicConfig(
    level=logging.DEBUG,  # Mudar INFO para DEBUG
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
```

---

## ⚡ CHECKLIST DE VERIFICAÇÃO

Antes de reportar erro, verificar:

- [ ] Arquivo `.env` existe e está configurado
- [ ] Credenciais IQ Option estão corretas
- [ ] Playwright e Chromium instalados: `playwright install chromium`
- [ ] Bot consegue acessar internet: `curl https://login.iqoption.com`
- [ ] Logs mostram onde está falhando
- [ ] Tentou executar em modo visual (headless=False)
- [ ] Tirou screenshots dos pontos de falha

---

## 🆘 SUPORTE

Se mesmo após seguir este guia o erro persistir:

1. **Copiar logs completos:**
```bash
sudo journalctl -u botq3 -n 100 > logs.txt
```

2. **Tirar screenshots:**
```bash
ls /tmp/*.png
```

3. **Informar:**
- Qual erro exato
- O que já tentou
- Logs e screenshots

---

**Lembre-se:** A IQ Option muda a interface frequentemente. Seletores CSS podem precisar atualização.
