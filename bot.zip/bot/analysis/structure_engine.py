"""
Structure Engine - Market Structure Analysis
Identifies Higher Highs, Higher Lows, Lower Highs, Lower Lows
Break of Structure (BOS) detection
"""
import logging
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class StructureEngine:
    """
    Analyzes market structure and Break of Structure
    
    Features:
    - HH/HL/LH/LL identification
    - BOS detection
    - Structure trend confirmation
    """
    
    def __init__(self):
        self.lookback = 10  # Candles to look back for swing points
    
    def analyze(self, candles: List[Dict]) -> Dict:
        """
        Analyze market structure
        
        Args:
            candles: List of candle dicts with OHLC data
            
        Returns:
            Dict with structure analysis:
            {
                "structure": "BULLISH" | "BEARISH" | "NEUTRAL",
                "bos_detected": bool,
                "bos_direction": "UP" | "DOWN" | None,
                "score": 0-100,
                "details": str
            }
        """
        try:
            if not candles or len(candles) < 30:
                return self._neutral_result("Insufficient candles for structure")
            
            # Find swing highs and lows
            swing_highs = self._find_swing_highs(candles)
            swing_lows = self._find_swing_lows(candles)
            
            if len(swing_highs) < 2 or len(swing_lows) < 2:
                return self._neutral_result("Insufficient swings")
            
            # Analyze structure progression
            structure_type = self._analyze_structure_progression(
                swing_highs, swing_lows
            )
            
            # Check for Break of Structure
            bos_info = self._check_bos(candles, swing_highs, swing_lows)
            
            # Calculate score
            score = self._calculate_structure_score(
                structure_type, bos_info["detected"]
            )
            
            details = f"Structure: {structure_type}"
            if bos_info["detected"]:
                details += f", BOS {bos_info['direction']}"
            
            return {
                "structure": structure_type,
                "bos_detected": bos_info["detected"],
                "bos_direction": bos_info["direction"],
                "score": score,
                "details": details
            }
            
        except Exception as e:
            logger.error(f"Error in structure analysis: {e}")
            return self._neutral_result(f"Analysis error: {e}")
    
    def _find_swing_highs(self, candles: List[Dict]) -> List[Tuple[int, float]]:
        """Find swing high points (index, price)"""
        swing_highs = []
        
        for i in range(self.lookback, len(candles) - self.lookback):
            high = candles[i]["high"]
            
            # Check if it's a local maximum
            is_swing_high = True
            for j in range(i - self.lookback, i + self.lookback + 1):
                if j != i and candles[j]["high"] >= high:
                    is_swing_high = False
                    break
            
            if is_swing_high:
                swing_highs.append((i, high))
        
        return swing_highs
    
    def _find_swing_lows(self, candles: List[Dict]) -> List[Tuple[int, float]]:
        """Find swing low points (index, price)"""
        swing_lows = []
        
        for i in range(self.lookback, len(candles) - self.lookback):
            low = candles[i]["low"]
            
            # Check if it's a local minimum
            is_swing_low = True
            for j in range(i - self.lookback, i + self.lookback + 1):
                if j != i and candles[j]["low"] <= low:
                    is_swing_low = False
                    break
            
            if is_swing_low:
                swing_lows.append((i, low))
        
        return swing_lows
    
    def _analyze_structure_progression(
        self,
        swing_highs: List[Tuple[int, float]],
        swing_lows: List[Tuple[int, float]]
    ) -> str:
        """
        Analyze if making HH/HL (bullish) or LH/LL (bearish)
        
        Returns:
            "BULLISH" | "BEARISH" | "NEUTRAL"
        """
        # Check last 2 highs
        if len(swing_highs) >= 2:
            last_high = swing_highs[-1][1]
            prev_high = swing_highs[-2][1]
            higher_high = last_high > prev_high
        else:
            higher_high = None
        
        # Check last 2 lows
        if len(swing_lows) >= 2:
            last_low = swing_lows[-1][1]
            prev_low = swing_lows[-2][1]
            higher_low = last_low > prev_low
        else:
            higher_low = None
        
        # Determine structure
        if higher_high and higher_low:
            return "BULLISH"  # HH + HL
        elif higher_high is False and higher_low is False:
            return "BEARISH"  # LH + LL
        else:
            return "NEUTRAL"
    
    def _check_bos(
        self,
        candles: List[Dict],
        swing_highs: List[Tuple[int, float]],
        swing_lows: List[Tuple[int, float]]
    ) -> Dict:
        """
        Check for Break of Structure in recent candles
        
        Returns:
            Dict: {"detected": bool, "direction": "UP" | "DOWN" | None}
        """
        if not swing_highs or not swing_lows:
            return {"detected": False, "direction": None}
        
        # Get last swing high/low
        last_swing_high = swing_highs[-1][1]
        last_swing_low = swing_lows[-1][1]
        
        # Check last 5 candles
        recent_candles = candles[-5:]
        
        # Check if broke above last swing high
        for candle in recent_candles:
            if candle["close"] > last_swing_high:
                return {"detected": True, "direction": "UP"}
        
        # Check if broke below last swing low
        for candle in recent_candles:
            if candle["close"] < last_swing_low:
                return {"detected": True, "direction": "DOWN"}
        
        return {"detected": False, "direction": None}
    
    def _calculate_structure_score(
        self,
        structure_type: str,
        bos_detected: bool
    ) -> int:
        """Calculate score based on structure analysis"""
        base_score = 0
        
        if structure_type == "BULLISH":
            base_score = 60
        elif structure_type == "BEARISH":
            base_score = 60
        else:
            base_score = 30
        
        # Bonus for BOS confirmation
        if bos_detected:
            base_score += 20
        
        return min(100, base_score)
    
    def _neutral_result(self, reason: str) -> Dict:
        """Return neutral result"""
        return {
            "structure": "NEUTRAL",
            "bos_detected": False,
            "bos_direction": None,
            "score": 0,
            "details": reason
        }
