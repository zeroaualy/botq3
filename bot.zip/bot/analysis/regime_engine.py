"""
Regime Engine - Market Regime Detection
Classifies market state and adapts strategy
"""
import logging
from typing import Dict, List
import numpy as np

logger = logging.getLogger(__name__)


class RegimeEngine:
    """
    Detects market regime and adapts parameters
    
    Regimes:
    - TRENDING: Clear directional movement
    - RANGING: Sideways consolidation
    - HIGH_VOLATILITY: Erratic price action
    - MANIPULATIVE: Fake moves and sweeps
    - DEAD: Extremely low activity
    """
    
    def __init__(self):
        self.regime_adjustments = {
            "TRENDING": {"score_modifier": 1.1, "risk_modifier": 1.0},
            "RANGING": {"score_modifier": 0.9, "risk_modifier": 0.8},
            "HIGH_VOLATILITY": {"score_modifier": 0.7, "risk_modifier": 0.6},
            "MANIPULATIVE": {"score_modifier": 0.8, "risk_modifier": 0.7},
            "DEAD": {"score_modifier": 0.5, "risk_modifier": 0.5}
        }
    
    def detect_regime(self, candles: List[Dict]) -> Dict:
        """
        Detect current market regime
        
        Returns:
            Dict with regime info and modifiers
        """
        try:
            if not candles or len(candles) < 30:
                return self._default_regime("Insufficient data")
            
            # Calculate metrics
            closes = np.array([c["close"] for c in candles])
            highs = np.array([c["high"] for c in candles])
            lows = np.array([c["low"] for c in candles])
            
            # Directional movement
            price_range = highs.max() - lows.min()
            net_movement = abs(closes[-1] - closes[0])
            directional_ratio = net_movement / price_range if price_range > 0 else 0
            
            # Volatility
            returns = np.diff(closes) / closes[:-1]
            volatility = np.std(returns) * 100
            
            # Range compression
            recent_range = highs[-10:].max() - lows[-10:].min()
            overall_range = highs.max() - lows.min()
            range_compression = recent_range / overall_range if overall_range > 0 else 0
            
            # Classify regime
            regime = self._classify_regime(
                directional_ratio,
                volatility,
                range_compression
            )
            
            adjustments = self.regime_adjustments.get(regime, {})
            
            return {
                "regime": regime,
                "score_modifier": adjustments.get("score_modifier", 1.0),
                "risk_modifier": adjustments.get("risk_modifier", 1.0),
                "directional_ratio": round(directional_ratio, 3),
                "volatility": round(volatility, 3),
                "range_compression": round(range_compression, 3),
                "details": f"Market regime: {regime}"
            }
            
        except Exception as e:
            logger.error(f"Error detecting regime: {e}")
            return self._default_regime(f"Error: {e}")
    
    def _classify_regime(
        self,
        directional_ratio: float,
        volatility: float,
        range_compression: float
    ) -> str:
        """Classify regime based on metrics"""
        
        # Dead market
        if volatility < 0.05:
            return "DEAD"
        
        # High volatility
        if volatility > 0.3:
            return "HIGH_VOLATILITY"
        
        # Trending
        if directional_ratio > 0.6:
            return "TRENDING"
        
        # Ranging (consolidated)
        if range_compression < 0.3:
            return "RANGING"
        
        # Manipulative (wide swings, no clear direction)
        if directional_ratio < 0.3 and volatility > 0.15:
            return "MANIPULATIVE"
        
        # Default to ranging
        return "RANGING"
    
    def _default_regime(self, reason: str) -> Dict:
        """Return default regime"""
        return {
            "regime": "UNKNOWN",
            "score_modifier": 0.8,
            "risk_modifier": 0.8,
            "details": reason
        }
