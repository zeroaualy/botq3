"""
Telemetry Engine
Structured logging for observability
"""
import logging
import json
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Dict, Any

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class TelemetryEngine:
    """
    Structured logging system for observability
    
    Logs events in JSON format for analysis
    """
    
    def __init__(self, log_file: str = None):
        self.log_file = log_file
        self.telemetry_logger = self._setup_telemetry_logger()
    
    def _setup_telemetry_logger(self):
        """Setup dedicated telemetry logger"""
        telemetry = logging.getLogger("bot_telemetry")
        telemetry.setLevel(logging.INFO)
        
        if self.log_file:
            handler = logging.FileHandler(self.log_file)
            handler.setFormatter(logging.Formatter('%(message)s'))
            telemetry.addHandler(handler)
        
        return telemetry
    
    def log_signal_generation(self, signal: Dict, analysis: Dict):
        """Log signal generation event"""
        event = {
            "event": "SIGNAL_GENERATED",
            "timestamp": datetime.now(TZ).isoformat(),
            "asset": signal.get("asset"),
            "direction": signal.get("direction"),
            "score": analysis.get("total_score"),
            "confluence_count": analysis.get("confluence_count"),
            "confidence_level": analysis.get("confidence_level"),
            "breakdown": analysis.get("breakdown")
        }
        self._log_event(event)
    
    def log_gemini_response(self, request: Dict, response: Dict, duration_ms: float):
        """Log Gemini API interaction"""
        event = {
            "event": "GEMINI_RESPONSE",
            "timestamp": datetime.now(TZ).isoformat(),
            "asset": request.get("asset"),
            "response": response.get("action"),
            "duration_ms": duration_ms,
            "success": response.get("success", False)
        }
        self._log_event(event)
    
    def log_trade_execution(self, trade: Dict, result: Dict):
        """Log trade execution"""
        event = {
            "event": "TRADE_EXECUTED",
            "timestamp": datetime.now(TZ).isoformat(),
            "asset": trade.get("asset"),
            "direction": trade.get("direction"),
            "amount": trade.get("amount"),
            "result": result.get("result"),
            "pnl": result.get("pnl")
        }
        self._log_event(event)
    
    def log_risk_state(self, risk_status: Dict):
        """Log risk manager state"""
        event = {
            "event": "RISK_STATE",
            "timestamp": datetime.now(TZ).isoformat(),
            "pausado": risk_status.get("pausado"),
            "consecutive_losses": risk_status.get("perdas_consecutivas"),
            "valor_ajustado": risk_status.get("valor_ajustado")
        }
        self._log_event(event)
    
    def log_regime_change(self, old_regime: str, new_regime: str, metrics: Dict):
        """Log market regime change"""
        event = {
            "event": "REGIME_CHANGE",
            "timestamp": datetime.now(TZ).isoformat(),
            "old_regime": old_regime,
            "new_regime": new_regime,
            "metrics": metrics
        }
        self._log_event(event)
    
    def log_expectancy_update(self, category: str, key: str, expectancy: float):
        """Log expectancy update"""
        event = {
            "event": "EXPECTANCY_UPDATE",
            "timestamp": datetime.now(TZ).isoformat(),
            "category": category,
            "key": key,
            "expectancy": expectancy
        }
        self._log_event(event)
    
    def log_capital_adjustment(self, adjustment: Dict):
        """Log capital sizing adjustment"""
        event = {
            "event": "CAPITAL_ADJUSTMENT",
            "timestamp": datetime.now(TZ).isoformat(),
            "position_size": adjustment.get("position_size"),
            "modifiers": adjustment.get("modifiers"),
            "reason": adjustment.get("reason")
        }
        self._log_event(event)
    
    def _log_event(self, event: Dict):
        """Write event to log"""
        try:
            log_line = json.dumps(event, ensure_ascii=False)
            self.telemetry_logger.info(log_line)
        except Exception as e:
            logger.error(f"Failed to log telemetry event: {e}")
