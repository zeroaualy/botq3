"""
Gemini Client — Bot Q3 Beta
REST API com X-goog-api-key header. Modelo: gemini-2.0-flash.
"""
import logging
import requests
from typing import Optional, List, Dict

logger = logging.getLogger(__name__)

MODEL = "gemini-2.0-flash"
BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"


class GeminiClient:

    def __init__(self, api_key: str, project_id: str = None):
        if not api_key:
            raise ValueError("GEMINI_API_KEY é obrigatória")
        self.api_key = api_key.strip()
        self.model_name = MODEL
        logger.info(f"✅ GeminiClient pronto — {self.model_name}")

    def generate(self, prompt: str, temperature: float = 0.7, max_output_tokens: int = 512) -> str:
        url = f"{BASE_URL}/{self.model_name}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "X-goog-api-key": self.api_key,
        }
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_output_tokens,
            }
        }
        resp = requests.post(url, json=payload, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        return data["candidates"][0]["content"]["parts"][0]["text"]

    class ChatCompletions:
        def __init__(self, client):
            self.client = client

        def create(self, model: str, messages: List[Dict],
                   temperature: float = 0.7, max_tokens: Optional[int] = None):
            prompt = next(
                (m.get("content", "") for m in messages if m.get("role") == "user"), ""
            )
            text = self.client.generate(prompt, temperature=temperature,
                                        max_output_tokens=max_tokens or 512)

            class Choice:
                def __init__(self, t):
                    self.message = type("M", (), {"content": t})()

            class Response:
                def __init__(self, t):
                    self.choices = [Choice(t)]

            return Response(text)

    @property
    def chat(self):
        client = self
        class Chat:
            def __init__(self):
                self.completions = GeminiClient.ChatCompletions(client)
        return Chat()
