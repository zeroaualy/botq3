"""
Cliente IQ Option
Responsável por conexão e garantia de conta PRACTICE
"""
import logging
import time
from iqoptionapi.stable_api import IQ_Option

logger = logging.getLogger(__name__)


class IQClient:
    """Cliente IQ Option com garantia de conta PRACTICE"""
    
    def __init__(self, email, senha):
        self.email = email
        self.senha = senha
        self.iq = None
        
    def conectar(self, max_tentativas=3):
        """Conecta à IQ Option e força conta PRACTICE"""
        for tentativa in range(max_tentativas):
            try:
                logger.info(f"🔄 Conectando IQ Option ({tentativa + 1}/{max_tentativas})...")
                self.iq = IQ_Option(self.email, self.senha)
                check, reason = self.iq.connect()
                
                if check:
                    # CRÍTICO: Forçar conta PRACTICE
                    self.iq.change_balance("PRACTICE")
                    time.sleep(2)
                    
                    saldo = self.iq.get_balance()
                    tipo_conta = self.iq.get_balance_mode()
                    
                    logger.info(f"✅ Conectado!")
                    logger.info(f"📊 Tipo de conta: {tipo_conta}")
                    logger.info(f"💰 Saldo PRACTICE: ${saldo:.2f}")
                    
                    return True
                else:
                    logger.error(f"❌ Falha: {reason}")
                
                time.sleep(5)
            except Exception as e:
                logger.error(f"❌ Erro: {e}")
        
        return False
    
    def garantir_practice(self):
        """
        SEGURANÇA CRÍTICA: Garante que está em PRACTICE
        Retorna True se confirmado, False se falhou
        """
        try:
            if not self.iq:
                logger.error("❌ Sem conexão IQ Option")
                return False
            
            tipo_conta = self.iq.get_balance_mode()
            
            if tipo_conta != "PRACTICE":
                logger.warning(f"⚠️ Conta não é PRACTICE (atual: {tipo_conta})")
                logger.info("🔄 Forçando mudança para PRACTICE...")
                
                self.iq.change_balance("PRACTICE")
                time.sleep(2)
                
                # Verificar novamente
                tipo_conta = self.iq.get_balance_mode()
                
                if tipo_conta != "PRACTICE":
                    logger.error(f"❌ FALHA CRÍTICA: Não conseguiu mudar para PRACTICE")
                    return False
            
            logger.info("✅ Confirmado: Operando em conta PRACTICE")
            return True
            
        except Exception as e:
            logger.error(f"❌ Erro ao verificar conta: {e}")
            return False
    
    def verificar_ativo_disponivel(self, par):
        """Verifica se ativo está aberto"""
        try:
            par_limpo = par.replace("-OTC", "")
            all_assets = self.iq.get_all_open_time()
            
            if all_assets and "binary" in all_assets:
                for ativo_id, dados in all_assets["binary"].items():
                    if par_limpo.upper() in ativo_id.upper():
                        if dados.get("open", False):
                            logger.info(f"✅ Ativo {par_limpo} disponível")
                            return True, par_limpo
                        else:
                            # Tentar OTC
                            par_otc = f"{par_limpo}-OTC"
                            for ativo_otc_id, dados_otc in all_assets["binary"].items():
                                if par_otc.upper() in ativo_otc_id.upper():
                                    if dados_otc.get("open", False):
                                        logger.info(f"✅ Usando OTC: {par_otc}")
                                        return True, par_otc
                            return False, None
            
            logger.warning(f"⚠️ Status de {par_limpo} desconhecido, tentando...")
            return True, par_limpo
            
        except Exception as e:
            logger.error(f"Erro ao verificar ativo: {e}")
            return True, par.replace("-OTC", "")
    
    def obter_saldo(self):
        """Retorna saldo atual"""
        if not self.iq:
            return 0.0
        return self.iq.get_balance()
    
    def obter_tipo_conta(self):
        """Retorna tipo de conta"""
        if not self.iq:
            return "DESCONECTADO"
        return self.iq.get_balance_mode()
    
    def esta_conectado(self):
        """Verifica se está conectado"""
        return self.iq is not None
