"""
Volatility Engine - ATR and Range Analysis
"""
import logging
from typing import Dict, List
import numpy as np

logger = logging.getLogger(__name__)


class VolatilityEngine:
    """Analyzes market volatility using ATR"""
    
    def analyze(self, candles: List[Dict]) -> Dict:
        try:
            if not candles or len(candles) < 20:
                return {"volatility_state": "UNKNOWN", "atr_score": 0, "details": "Insufficient data"}
            
            # Calculate ATR (14 period)
            atr = self._calculate_atr(candles, 14)
            
            # Get average price for context
            avg_price = np.mean([c["close"] for c in candles[-20:]])
            atr_percentage = (atr / avg_price) * 100
            
            # Classify volatility
            if atr_percentage < 0.05:
                state = "VERY_LOW"
                score = 30
                details = "Very low volatility (dead market)"
            elif atr_percentage < 0.1:
                state = "LOW"
                score = 60
                details = "Low volatility (stable)"
            elif atr_percentage < 0.2:
                state = "NORMAL"
                score = 80
                details = "Normal volatility (optimal)"
            elif atr_percentage < 0.4:
                state = "HIGH"
                score = 50
                details = "High volatility (caution)"
            else:
                state = "EXTREME"
                score = 20
                details = "Extreme volatility (dangerous)"
            
            return {
                "volatility_state": state,
                "atr": round(atr, 5),
                "atr_percentage": round(atr_percentage, 3),
                "atr_score": score,
                "details": details
            }
            
        except Exception as e:
            logger.error(f"Error in volatility analysis: {e}")
            return {"volatility_state": "ERROR", "atr_score": 0, "details": str(e)}
    
    def _calculate_atr(self, candles: List[Dict], period: int = 14) -> float:
        """Calculate Average True Range"""
        true_ranges = []
        
        for i in range(1, len(candles)):
            high = candles[i]["high"]
            low = candles[i]["low"]
            prev_close = candles[i-1]["close"]
            
            tr = max(
                high - low,
                abs(high - prev_close),
                abs(low - prev_close)
            )
            true_ranges.append(tr)
        
        if len(true_ranges) < period:
            period = len(true_ranges)
        
        return np.mean(true_ranges[-period:])
