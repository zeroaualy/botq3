"""
Circuit Breaker - Q3 IA Beta
Proteção contra falhas consecutivas e retry infinito
"""
import asyncio
import logging
from typing import Callable, Any, Optional
from datetime import datetime, timedelta
from enum import Enum

logger = logging.getLogger(__name__)


class CircuitState(str, Enum):
    """Estados do Circuit Breaker"""
    CLOSED = "closed"      # Funcionando normalmente
    OPEN = "open"          # Bloqueando chamadas (muitas falhas)
    HALF_OPEN = "half_open"  # Testando recuperação


class CircuitBreaker:
    """
    Circuit Breaker para proteção contra falhas consecutivas
    
    Estados:
    - CLOSED: Funcionando normalmente
    - OPEN: Bloqueando chamadas após muitas falhas
    - HALF_OPEN: Permitindo algumas chamadas de teste
    
    Características:
    - Bloqueio automático após N falhas consecutivas
    - Timeout de recuperação configurável
    - Tentativas de teste em estado HALF_OPEN
    - Métricas detalhadas
    """
    
    def __init__(self, failure_threshold: int = 5, recovery_timeout: float = 60.0,
                 half_open_max_calls: int = 3, name: str = "circuit_breaker"):
        """
        Inicializa o Circuit Breaker
        
        Args:
            failure_threshold: Número de falhas consecutivas para abrir
            recovery_timeout: Segundos antes de tentar recuperação
            half_open_max_calls: Chamadas de teste em HALF_OPEN
            name: Nome do circuit breaker (para logs)
        """
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max_calls = half_open_max_calls
        
        # Estado
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._opened_at: Optional[datetime] = None
        self._half_open_calls = 0
        
        # Métricas
        self._total_calls = 0
        self._total_failures = 0
        self._total_successes = 0
        self._total_blocked = 0
        self._times_opened = 0
        
        logger.info(
            f"✅ Circuit Breaker '{name}' inicializado "
            f"(threshold={failure_threshold}, timeout={recovery_timeout}s)"
        )
    
    async def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Executa uma função através do Circuit Breaker
        
        Args:
            func: Função a executar
            *args: Argumentos posicionais
            **kwargs: Argumentos nomeados
        
        Returns:
            Resultado da função
        
        Raises:
            Exception: Se circuit estiver OPEN ou função falhar
        """
        self._total_calls += 1
        
        # Verificar estado
        if self._state == CircuitState.OPEN:
            # Verificar se já passou o timeout de recuperação
            if self._should_attempt_reset():
                self._transition_to_half_open()
            else:
                self._total_blocked += 1
                raise Exception(
                    f"Circuit Breaker '{self.name}' está OPEN - "
                    f"bloqueando chamadas"
                )
        
        # Se HALF_OPEN, verificar limite de chamadas de teste
        if self._state == CircuitState.HALF_OPEN:
            if self._half_open_calls >= self.half_open_max_calls:
                self._total_blocked += 1
                raise Exception(
                    f"Circuit Breaker '{self.name}' em HALF_OPEN - "
                    f"limite de testes atingido"
                )
            self._half_open_calls += 1
        
        # Executar função
        try:
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = await asyncio.get_event_loop().run_in_executor(
                    None, lambda: func(*args, **kwargs)
                )
            
            # Sucesso!
            self._on_success()
            return result
        
        except Exception as e:
            # Falha
            self._on_failure()
            raise
    
    def _on_success(self) -> None:
        """Processa uma execução bem-sucedida"""
        self._success_count += 1
        self._total_successes += 1
        
        if self._state == CircuitState.HALF_OPEN:
            # Se em HALF_OPEN, verificar se pode fechar
            if self._success_count >= self.half_open_max_calls:
                self._transition_to_closed()
        else:
            # Resetar contador de falhas
            self._failure_count = 0
    
    def _on_failure(self) -> None:
        """Processa uma execução com falha"""
        self._failure_count += 1
        self._total_failures += 1
        self._success_count = 0
        
        logger.warning(
            f"⚠️ Circuit Breaker '{self.name}': Falha "
            f"({self._failure_count}/{self.failure_threshold})"
        )
        
        if self._state == CircuitState.HALF_OPEN:
            # Falha em HALF_OPEN = voltar para OPEN
            self._transition_to_open()
        elif self._failure_count >= self.failure_threshold:
            # Atingiu threshold = abrir
            self._transition_to_open()
    
    def _should_attempt_reset(self) -> bool:
        """
        Verifica se deve tentar resetar (passar de OPEN para HALF_OPEN)
        
        Returns:
            True se passou o timeout de recuperação
        """
        if self._state != CircuitState.OPEN or self._opened_at is None:
            return False
        
        elapsed = (datetime.now() - self._opened_at).total_seconds()
        return elapsed >= self.recovery_timeout
    
    def _transition_to_open(self) -> None:
        """Transição para estado OPEN"""
        old_state = self._state
        self._state = CircuitState.OPEN
        self._opened_at = datetime.now()
        self._failure_count = 0
        self._success_count = 0
        self._half_open_calls = 0
        self._times_opened += 1
        
        logger.error(
            f"🔴 Circuit Breaker '{self.name}' ABERTO "
            f"(transição: {old_state.value} → OPEN)"
        )
    
    def _transition_to_half_open(self) -> None:
        """Transição para estado HALF_OPEN"""
        old_state = self._state
        self._state = CircuitState.HALF_OPEN
        self._half_open_calls = 0
        self._success_count = 0
        
        logger.warning(
            f"🟡 Circuit Breaker '{self.name}' em HALF_OPEN "
            f"(transição: {old_state.value} → HALF_OPEN)"
        )
    
    def _transition_to_closed(self) -> None:
        """Transição para estado CLOSED"""
        old_state = self._state
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._half_open_calls = 0
        self._opened_at = None
        
        logger.info(
            f"🟢 Circuit Breaker '{self.name}' FECHADO "
            f"(transição: {old_state.value} → CLOSED)"
        )
    
    def reset(self) -> None:
        """Força reset do Circuit Breaker para CLOSED"""
        logger.info(f"🔄 Circuit Breaker '{self.name}' resetado manualmente")
        self._transition_to_closed()
    
    @property
    def state(self) -> CircuitState:
        """Retorna o estado atual"""
        return self._state
    
    @property
    def is_open(self) -> bool:
        """Verifica se está OPEN"""
        return self._state == CircuitState.OPEN
    
    @property
    def is_closed(self) -> bool:
        """Verifica se está CLOSED"""
        return self._state == CircuitState.CLOSED
    
    @property
    def is_half_open(self) -> bool:
        """Verifica se está HALF_OPEN"""
        return self._state == CircuitState.HALF_OPEN
    
    def get_metrics(self) -> dict:
        """
        Retorna métricas do Circuit Breaker
        
        Returns:
            Dicionário com métricas
        """
        failure_rate = (
            (self._total_failures / self._total_calls * 100)
            if self._total_calls > 0 else 0
        )
        
        return {
            'name': self.name,
            'state': self._state.value,
            'consecutive_failures': self._failure_count,
            'consecutive_successes': self._success_count,
            'total_calls': self._total_calls,
            'total_successes': self._total_successes,
            'total_failures': self._total_failures,
            'total_blocked': self._total_blocked,
            'failure_rate': failure_rate,
            'times_opened': self._times_opened,
            'opened_at': self._opened_at.isoformat() if self._opened_at else None,
        }
    
    def __repr__(self) -> str:
        """Representação string do Circuit Breaker"""
        return f"CircuitBreaker('{self.name}', state={self._state.value})"


class CircuitBreakerManager:
    """Gerenciador de múltiplos Circuit Breakers"""
    
    def __init__(self):
        """Inicializa o gerenciador"""
        self._breakers: dict[str, CircuitBreaker] = {}
        logger.info("✅ Circuit Breaker Manager inicializado")
    
    def get_or_create(self, name: str, **kwargs) -> CircuitBreaker:
        """
        Obtém ou cria um Circuit Breaker
        
        Args:
            name: Nome do circuit breaker
            **kwargs: Argumentos para CircuitBreaker()
        
        Returns:
            Instância do CircuitBreaker
        """
        if name not in self._breakers:
            self._breakers[name] = CircuitBreaker(name=name, **kwargs)
        
        return self._breakers[name]
    
    def get(self, name: str) -> Optional[CircuitBreaker]:
        """
        Obtém um Circuit Breaker existente
        
        Args:
            name: Nome do circuit breaker
        
        Returns:
            Instância ou None se não existir
        """
        return self._breakers.get(name)
    
    def reset_all(self) -> None:
        """Reseta todos os Circuit Breakers"""
        for breaker in self._breakers.values():
            breaker.reset()
        logger.info("🔄 Todos os Circuit Breakers resetados")
    
    def get_all_metrics(self) -> dict:
        """
        Retorna métricas de todos os Circuit Breakers
        
        Returns:
            Dicionário com métricas
        """
        return {
            name: breaker.get_metrics()
            for name, breaker in self._breakers.items()
        }
    
    def __len__(self) -> int:
        """Retorna o número de Circuit Breakers"""
        return len(self._breakers)


# Instância global do gerenciador
_manager_instance: Optional[CircuitBreakerManager] = None


def get_circuit_breaker_manager() -> CircuitBreakerManager:
    """
    Retorna a instância global do gerenciador (singleton)
    
    Returns:
        Instância do CircuitBreakerManager
    """
    global _manager_instance
    
    if _manager_instance is None:
        _manager_instance = CircuitBreakerManager()
    
    return _manager_instance
