"""
Configurações do Bot Q3 Beta
Fonte única de verdade para todos os parâmetros operacionais.
"""
import os
import logging
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)


def _sanitize(key):
    if not key:
        return None
    return key.strip().strip('"').strip("'").strip() or None


def _load():
    TOKEN = os.getenv("TELEGRAM_TOKEN")
    GRUPO_ID = os.getenv("TELEGRAM_GROUP_ID")
    GEMINI_API_KEY = _sanitize(os.getenv("GEMINI_API_KEY"))
    EMAIL = os.getenv("IQ_EMAIL")
    SENHA = os.getenv("IQ_PASSWORD")

    try:
        GRUPO_ID = int(GRUPO_ID) if GRUPO_ID else None
    except Exception:
        GRUPO_ID = None

    for name, val in [("TELEGRAM_TOKEN", TOKEN), ("TELEGRAM_GROUP_ID", GRUPO_ID),
                      ("IQ_EMAIL", EMAIL), ("IQ_PASSWORD", SENHA)]:
        if not val:
            logger.error(f"❌ {name} não encontrado no .env")

    return TOKEN, GRUPO_ID, GEMINI_API_KEY, EMAIL, SENHA


TOKEN, GRUPO_ID, GEMINI_API_KEY, EMAIL, SENHA = _load()

CONFIG = {
    "ativos": ["EURUSD", "GBPUSD", "USDJPY"],
    "timeframe": 60,
    "operar_automatico": False,
    "valor_entrada": 10.0,
    "martingale": False,
    "martingale_multiplier": 2.0,
    "martingale_max_levels": 3,
    "stop_loss": 20.0,
    "stop_gain": 50.0,
    "risco_max_perdas_pausa": 5,
    "max_operacoes_simultaneas": 3,
    "max_slippage_ms": 4000,
    "slippage_filter_enabled": False,
    "bypass_schedule_check": True,       # ignora verificação de horário (IQ Option gerencia disponibilidade)
    "min_payout_percent": 70,
    "ia_validar_contexto": False,
    "tolerancia_agendamento_ms": 3000,
    "automacao_sinais_habilitada": True,
    "automacao_confianca_minima": 65,
    "automacao_intervalo_analise": 120,
    "automacao_max_sinais_hora": 10,
    "auto_score_threshold": 65,
    "auto_cooldown_seconds": 120,
    "max_auto_trades_per_hour": 8,
    "show_signals_in_chat": False,
    "debug_trade_validation": False,
}

PERMISSOES = {
    "ia_pode_criar_estrategia": False,
    "ia_pode_prever_mercado": False,
    "ia_pode_decidir_direcao": False,
}
