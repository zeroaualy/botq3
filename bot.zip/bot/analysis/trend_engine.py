"""
Trend Engine - EMA Trend Alignment Analysis
Analyzes market trend using multiple EMAs
"""
import logging
from typing import Dict, List, Optional
import numpy as np

logger = logging.getLogger(__name__)


class TrendEngine:
    """
    Analyzes market trend using EMA alignment
    
    Features:
    - EMA 9, 21, 50 alignment
    - Trend strength measurement
    - Trend confirmation
    """
    
    def __init__(self):
        self.ema_periods = [9, 21, 50]
    
    def analyze(self, candles: List[Dict]) -> Dict:
        """
        Analyze trend using EMA alignment
        
        Args:
            candles: List of candle dicts with OHLC data
            
        Returns:
            Dict with trend analysis:
            {
                "trend": "BULLISH" | "BEARISH" | "NEUTRAL",
                "strength": 0-100,
                "ema_aligned": bool,
                "score": 0-100,
                "details": str
            }
        """
        try:
            if not candles or len(candles) < 50:
                return self._neutral_result("Insufficient candles")
            
            closes = np.array([c["close"] for c in candles])
            
            # Calculate EMAs
            ema9 = self._calculate_ema(closes, 9)
            ema21 = self._calculate_ema(closes, 21)
            ema50 = self._calculate_ema(closes, 50)
            
            current_price = closes[-1]
            
            # Check alignment
            bullish_aligned = ema9 > ema21 > ema50
            bearish_aligned = ema9 < ema21 < ema50
            
            # Calculate trend strength
            if bullish_aligned:
                # Distance between EMAs as % of price
                strength_9_21 = abs((ema9 - ema21) / current_price) * 100
                strength_21_50 = abs((ema21 - ema50) / current_price) * 100
                strength = min(100, (strength_9_21 + strength_21_50) * 10)
                
                # Score based on alignment and strength
                score = min(100, 60 + strength * 0.4)
                
                return {
                    "trend": "BULLISH",
                    "strength": int(strength),
                    "ema_aligned": True,
                    "score": int(score),
                    "details": f"EMAs aligned bullish, strength {int(strength)}%"
                }
                
            elif bearish_aligned:
                strength_9_21 = abs((ema21 - ema9) / current_price) * 100
                strength_21_50 = abs((ema50 - ema21) / current_price) * 100
                strength = min(100, (strength_9_21 + strength_21_50) * 10)
                
                score = min(100, 60 + strength * 0.4)
                
                return {
                    "trend": "BEARISH",
                    "strength": int(strength),
                    "ema_aligned": True,
                    "score": int(score),
                    "details": f"EMAs aligned bearish, strength {int(strength)}%"
                }
            
            else:
                # Not aligned - check which direction price is relative to EMAs
                above_count = sum([current_price > ema9, current_price > ema21, current_price > ema50])
                
                if above_count >= 2:
                    trend = "BULLISH"
                    score = 45
                elif above_count <= 1:
                    trend = "BEARISH"
                    score = 45
                else:
                    trend = "NEUTRAL"
                    score = 30
                
                return {
                    "trend": trend,
                    "strength": 30,
                    "ema_aligned": False,
                    "score": score,
                    "details": f"EMAs not fully aligned, {trend.lower()} bias"
                }
                
        except Exception as e:
            logger.error(f"Error in trend analysis: {e}")
            return self._neutral_result(f"Analysis error: {e}")
    
    def _calculate_ema(self, data: np.ndarray, period: int) -> float:
        """Calculate Exponential Moving Average"""
        multiplier = 2 / (period + 1)
        ema = data[0]  # Start with first value
        
        for price in data[1:]:
            ema = (price * multiplier) + (ema * (1 - multiplier))
        
        return ema
    
    def _neutral_result(self, reason: str) -> Dict:
        """Return neutral result"""
        return {
            "trend": "NEUTRAL",
            "strength": 0,
            "ema_aligned": False,
            "score": 0,
            "details": reason
        }
