"""
Enhanced Signal Engine - Bot Q3 VIP Beta
Professional Technical Analysis Integration
Combines all analysis engines into unified signal generation
"""
import asyncio
import logging
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from typing import Optional, Dict, List

# Import all analysis engines
import sys
sys.path.append('/home/claude/bot_gemini')
from analysis.trend_engine import TrendEngine
from analysis.structure_engine import StructureEngine
from analysis.pattern_engine import PatternEngine
from analysis.liquidity_engine import LiquidityEngine
from analysis.volatility_engine import VolatilityEngine
from analysis.filters_engine import FiltersEngine
from analysis.scoring_engine import ScoringEngine
from analysis.regime_engine import RegimeEngine
from analysis.expectancy_engine import ExpectancyEngine
from analysis.capital_engine import CapitalEngine
from analysis.monte_carlo_engine import MonteCarloEngine
from analysis.shadow_engine import ShadowEngine
from analysis.watchdog_engine import WatchdogEngine
from analysis.telemetry_engine import TelemetryEngine

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class EnhancedSignalEngine:
    """
    Enhanced Signal Engine with Professional Analysis
    
    Integrates:
    - Technical analysis (trend, structure, patterns)
    - Liquidity and volatility analysis
    - Time/session filters
    - Adaptive scoring with confluence
    - Regime detection
    - Expectancy tracking
    - Dynamic capital management
    - Monte Carlo risk simulation
    - Shadow mode testing
    - Watchdog monitoring
    - Structured telemetry
    """
    
    def __init__(self, iq_client, runtime, config):
        self.iq_client = iq_client
        self.runtime = runtime
        self.config = config
        self.ativo = False
        self.task_engine = None
        
        # Initialize all analysis engines
        self.trend_engine = TrendEngine()
        self.structure_engine = StructureEngine()
        self.pattern_engine = PatternEngine()
        self.liquidity_engine = LiquidityEngine()
        self.volatility_engine = VolatilityEngine()
        self.filters_engine = FiltersEngine()
        self.scoring_engine = ScoringEngine()
        self.regime_engine = RegimeEngine()
        self.expectancy_engine = ExpectancyEngine()
        self.capital_engine = CapitalEngine(base_amount=config.get("valor_entrada", 10.0))
        self.monte_carlo_engine = MonteCarloEngine()
        self.shadow_engine = ShadowEngine()
        self.watchdog = WatchdogEngine()
        self.telemetry = TelemetryEngine()
        
        # Configuration
        self.intervalo_analise = config.get("automacao_intervalo_analise", 30)
        self.max_sinais_por_hora = config.get("automacao_max_sinais_hora", 10)
        
        # Trade tracking
        self.sinais_gerados_hora = []
        self.trade_history = []
        self.current_regime = "UNKNOWN"
        
        # Cooldown mechanism
        self.last_trade_time = {}  # per asset
        self.cooldown_seconds = 300  # 5 minutes between trades on same asset
        
        # Assets to analyze
        self.ativos_analise = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "EURJPY", "GBPJPY"]
        
        logger.info("✅ Enhanced Signal Engine initialized with all analysis modules")
    
    def is_ativo(self) -> bool:
        return self.ativo
    
    async def ativar(self):
        if self.ativo:
            logger.warning("⚠️ Enhanced Signal Engine already active")
            return False
        
        if not self.iq_client or not self.iq_client.esta_conectado():
            logger.error("❌ IQ Option not connected")
            return False
        
        if not self.runtime.modo_automatico_ativo:
            logger.error("❌ Automatic mode must be active")
            return False
        
        self.ativo = True
        logger.info("🧠 Enhanced Signal Engine ACTIVATED")
        
        self.task_engine = asyncio.create_task(self._loop_signal_engine())
        return True
    
    async def desativar(self):
        if not self.ativo:
            return False
        
        self.ativo = False
        logger.info("⛔ Enhanced Signal Engine DEACTIVATED")
        
        if self.task_engine and not self.task_engine.done():
            self.task_engine.cancel()
            try:
                await self.task_engine
            except asyncio.CancelledError:
                logger.info("✅ Engine task cancelled successfully")
        
        return True
    
    async def _loop_signal_engine(self):
        """Main analysis and signal generation loop"""
        logger.info("🔄 Starting Enhanced Signal Engine loop...")
        
        try:
            while self.ativo:
                try:
                    # Update watchdog heartbeat
                    self.watchdog.update_heartbeat()
                    
                    # Check system health
                    health = self.watchdog.check_health()
                    if health["status"] == "CRITICAL":
                        logger.error(f"❌ Critical health issues: {health['issues']}")
                        await self._handle_critical_health()
                        continue
                    
                    # Verify PRACTICE account
                    if not self.iq_client.garantir_practice():
                        logger.error("❌ PRACTICE verification failed")
                        break
                    
                    # Check if automatic mode still active
                    if not self.runtime.modo_automatico_ativo:
                        logger.warning("⚠️ Automatic mode deactivated")
                        await self.desativar()
                        break
                    
                    # Clean old signals
                    self._limpar_sinais_antigos()
                    
                    # Check hourly limit
                    if len(self.sinais_gerados_hora) >= self.max_sinais_por_hora:
                        logger.debug(f"⏸️ Hourly limit reached ({self.max_sinais_por_hora})")
                        await asyncio.sleep(self.intervalo_analise)
                        continue
                    
                    # Generate and analyze signal
                    sinal = await self._analisar_e_gerar_sinal()
                    
                    if sinal and sinal.get("approved"):
                        await self._enviar_sinal_para_pipeline(sinal)
                    
                    await asyncio.sleep(self.intervalo_analise)
                    
                except asyncio.CancelledError:
                    logger.info("⏹️ Engine loop cancelled")
                    break
                except Exception as e:
                    logger.error(f"❌ Error in engine loop: {e}")
                    self.watchdog.record_error()
                    import traceback
                    logger.error(traceback.format_exc())
                    await asyncio.sleep(self.intervalo_analise)
        
        finally:
            logger.info("🏁 Enhanced Signal Engine loop finalized")
    
    async def _analisar_e_gerar_sinal(self) -> Optional[Dict]:
        """
        Comprehensive market analysis and signal generation
        """
        try:
            best_signal = None
            highest_score = 0
            
            for ativo in self.ativos_analise:
                try:
                    # Check cooldown
                    if not self._check_cooldown(ativo):
                        continue
                    
                    # Verify asset available
                    disponivel, ativo_final = self.iq_client.verificar_ativo_disponivel(ativo)
                    if not disponivel:
                        continue
                    
                    # Get candles (100 for comprehensive analysis)
                    candles = self.iq_client.iq.get_candles(ativo_final, 1, 100, time.time())
                    if not candles or len(candles) < 50:
                        continue
                    
                    # === COMPREHENSIVE ANALYSIS ===
                    analysis_results = await self._run_comprehensive_analysis(ativo_final, candles)
                    
                    # Calculate unified score
                    score_result = self.scoring_engine.calculate_score(analysis_results)
                    
                    # Check if passes threshold
                    if not score_result["passes_threshold"]:
                        continue
                    
                    # Check expectancy filter
                    if self.expectancy_engine.should_skip_asset(ativo_final):
                        logger.info(f"⏭️ Skipping {ativo_final} (negative expectancy)")
                        continue
                    
                    # Get expectancy for capital sizing
                    asset_expectancy = self.expectancy_engine.get_expectancy("asset", ativo_final)
                    
                    # Calculate position size
                    capital_decision = self.capital_engine.calculate_position_size(
                        confidence_level=score_result["confidence_level"],
                        score=score_result["total_score"],
                        current_drawdown=0,  # Can be enhanced with session tracking
                        expectancy=asset_expectancy
                    )
                    
                    if not capital_decision["approved"]:
                        logger.info(f"❌ Capital manager rejected: {capital_decision['reason']}")
                        continue
                    
                    # Track best signal
                    if score_result["total_score"] > highest_score:
                        highest_score = score_result["total_score"]
                        best_signal = {
                            "asset": ativo_final,
                            "direction": score_result["direction"],
                            "score": score_result["total_score"],
                            "confidence": score_result["confidence_level"],
                            "confluence_count": score_result["confluence_count"],
                            "position_size": capital_decision["position_size"],
                            "analysis": analysis_results,
                            "approved": True,
                            "timestamp": datetime.now(TZ)
                        }
                        
                        # Log to telemetry
                        self.telemetry.log_signal_generation(best_signal, score_result)
                
                except Exception as e:
                    logger.debug(f"Error analyzing {ativo}: {e}")
                    continue
            
            if best_signal:
                logger.info(
                    f"🎯 Best signal: {best_signal['asset']} {best_signal['direction']} "
                    f"(Score: {best_signal['score']}, Confidence: {best_signal['confidence']})"
                )
            
            return best_signal
            
        except Exception as e:
            logger.error(f"❌ Error generating signal: {e}")
            return None
    
    async def _run_comprehensive_analysis(self, asset: str, candles: List[Dict]) -> Dict:
        """Run all analysis engines on the asset"""
        
        # Detect market regime first
        regime = self.regime_engine.detect_regime(candles)
        if regime["regime"] != self.current_regime:
            self.telemetry.log_regime_change(self.current_regime, regime["regime"], regime)
            self.current_regime = regime["regime"]
        
        # Run technical analysis
        trend = self.trend_engine.analyze(candles)
        structure = self.structure_engine.analyze(candles)
        pattern = self.pattern_engine.analyze(candles)
        liquidity = self.liquidity_engine.analyze(candles)
        volatility = self.volatility_engine.analyze(candles)
        filters = self.filters_engine.analyze(asset, datetime.now(TZ))
        
        return {
            "regime": regime,
            "trend": trend,
            "structure": structure,
            "pattern": pattern,
            "liquidity": liquidity,
            "volatility": volatility,
            "filters": filters
        }
    
    async def _enviar_sinal_para_pipeline(self, sinal: Dict):
        """Send approved signal to execution pipeline"""
        try:
            # Create formatted signal
            sinal_formatado = {
                "par": sinal["asset"],
                "direcao": sinal["direction"],
                "tempo_expiracao": 60,
                "horario": datetime.now(TZ) + timedelta(seconds=5),
                "imediato": False,
                "formato": "ENHANCED_ENGINE",
                "origem": "PROFESSIONAL_ANALYSIS",
                "confianca": sinal["score"],
                "confluencia": sinal["confluence_count"],
                "valor": sinal["position_size"],
                "motivo": f"{sinal['confluence_count']} confluences, {sinal['confidence']} confidence"
            }
            
            # Add to signal queue
            self.runtime.adicionar_sinal(sinal_formatado)
            
            # Record signal generated
            self.sinais_gerados_hora.append({
                "timestamp": datetime.now(TZ),
                "asset": sinal["asset"],
                "direction": sinal["direction"],
                "score": sinal["score"]
            })
            
            # Update cooldown
            self.last_trade_time[sinal["asset"]] = datetime.now(TZ)
            
            logger.info(
                f"🚀 Signal sent to pipeline: {sinal_formatado['par']} "
                f"{sinal_formatado['direcao']} @ "
                f"{sinal_formatado['horario'].strftime('%H:%M:%S')}"
            )
            
        except Exception as e:
            logger.error(f"❌ Error sending signal to pipeline: {e}")
            import traceback
            logger.error(traceback.format_exc())
    
    def record_trade_result(self, trade: Dict, result: str, pnl: float):
        """Record trade result for tracking and learning"""
        try:
            # Record in expectancy engine
            trade_record = {
                "asset": trade.get("asset"),
                "result": result,
                "pnl": pnl,
                "score": trade.get("score", 0),
                "session": self._get_current_session()
            }
            self.expectancy_engine.record_trade(trade_record)
            
            # Record in capital engine
            self.capital_engine.record_result(result, pnl)
            
            # Record in shadow engine
            self.shadow_engine.record_shadow_outcome(trade, result, pnl)
            
            # Record in watchdog
            self.watchdog.record_trade()
            
            # Add to trade history
            self.trade_history.append(trade_record)
            
            # Log to telemetry
            self.telemetry.log_trade_execution(trade, {"result": result, "pnl": pnl})
            
            # Adapt scoring threshold based on performance
            performance = self.expectancy_engine.get_performance_summary()
            self.scoring_engine.adapt_threshold(performance)
            
            # Run Monte Carlo if enough trades
            if len(self.trade_history) >= 20 and len(self.trade_history) % 10 == 0:
                mc_result = self.monte_carlo_engine.simulate(self.trade_history)
                logger.info(f"📊 Monte Carlo: Worst DD ${mc_result.get('worst_drawdown', 0):.2f}")
            
        except Exception as e:
            logger.error(f"Error recording trade result: {e}")
    
    def _check_cooldown(self, asset: str) -> bool:
        """Check if asset is in cooldown period"""
        if asset not in self.last_trade_time:
            return True
        
        time_since_last = (datetime.now(TZ) - self.last_trade_time[asset]).total_seconds()
        return time_since_last >= self.cooldown_seconds
    
    def _get_current_session(self) -> str:
        """Determine current trading session"""
        hour = datetime.now(TZ).hour
        
        if 2 <= hour < 8:
            return "ASIAN"
        elif 8 <= hour < 12:
            return "LONDON"
        elif 13 <= hour < 17:
            return "NY"
        elif 19 <= hour < 23:
            return "EVENING"
        else:
            return "OFF_HOURS"
    
    def _limpar_sinais_antigos(self):
        """Remove signals older than 1 hour"""
        agora = datetime.now(TZ)
        self.sinais_gerados_hora = [
            s for s in self.sinais_gerados_hora
            if (agora - s["timestamp"]).total_seconds() < 3600
        ]
    
    async def _handle_critical_health(self):
        """Handle critical system health issues"""
        logger.error("🚨 Handling critical health issue...")
        await asyncio.sleep(60)  # Wait 1 minute before retrying
    
    def obter_estatisticas(self) -> Dict:
        """Get engine statistics"""
        performance = self.expectancy_engine.get_performance_summary()
        shadow_perf = self.shadow_engine.get_shadow_performance()
        health = self.watchdog.check_health()
        
        return {
            "active": self.ativo,
            "signals_last_hour": len(self.sinais_gerados_hora),
            "current_threshold": self.scoring_engine.get_threshold(),
            "performance": performance,
            "shadow_performance": shadow_perf,
            "health_status": health["status"],
            "current_regime": self.current_regime,
            "total_trades": len(self.trade_history)
        }
