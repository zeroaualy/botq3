"""
Trade Executor com Playwright
Executor de trades via automação de navegador
"""
import logging

logger = logging.getLogger(__name__)


class PlaywrightTradeExecutor:
    """Executor de operações com Playwright"""
    
    def __init__(self, playwright_client):
        self.client = playwright_client
    
    async def executar(self, par, direcao, valor, expiracao):
        """
        Executa operação COM SEGURANÇA via navegador
        Retorna: (sucesso, order_id)
        """
        try:
            # Verificar se está conectado
            if not self.client.esta_conectado():
                logger.error("❌ Cliente não está conectado")
                # Tentar reconectar
                logger.info("🔄 Tentando reconectar...")
                if not await self.client.reconectar():
                    return False, None
            
            # Verificar saldo
            saldo = self.client.obter_saldo()
            if saldo < valor:
                logger.error(f"❌ Saldo insuficiente: ${saldo:.2f} < ${valor:.2f}")
                return False, None
            
            # Executar trade
            logger.info(f"📊 Executando: {par} {direcao.upper()} ${valor} {expiracao}s")
            logger.info(f"🏦 Conta: {self.client.obter_tipo_conta()} | Saldo: ${saldo:.2f}")
            
            sucesso, order_id = await self.client.executar_trade(
                par, direcao, valor, expiracao
            )
            
            if sucesso:
                logger.info(f"✅ Ordem executada! ID: {order_id}")
                return True, order_id
            else:
                logger.error("❌ Falha ao executar ordem")
                return False, None
                
        except Exception as e:
            logger.error(f"❌ Erro ao executar operação: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False, None
    
    async def verificar_resultado(self, order_id, aguardar_segundos=3):
        """
        Verifica resultado da operação
        Retorna: (resultado_str, valor_lucro)
        """
        try:
            resultado, lucro = await self.client.verificar_resultado(
                order_id, aguardar_segundos
            )
            
            logger.info(f"📊 Resultado: {resultado} - Valor: ${lucro:.2f}")
            
            return resultado, lucro
                
        except Exception as e:
            logger.error(f"❌ Erro ao verificar resultado: {e}")
            return "ERRO", 0
