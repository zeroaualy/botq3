# 🤖 Bot de Trading Completo - Com Auto Trade Integrado

## ✅ O QUE FOI FEITO

Este é o seu bot completo com **todas as funcionalidades de Auto Trade já integradas**.

### 📦 Modificações Realizadas

#### ✅ **1. Novo Módulo: core/auto_trader.py**
- Captura automática de sinais reais da API IQ Option
- Análise de tendências em tempo real
- Execução automática de trades
- Loop assíncrono com asyncio
- Sistema completo de notificações

#### ✅ **2. Atualizado: state/runtime.py**
- Adicionada variável `auto_trader`
- Adicionada flag `modo_automatico_ativo`
- Compatível com todo código existente

#### ✅ **3. Atualizado: bot/telegram_bot.py**
- Método `set_auto_trader()` adicionado
- Menu principal atualizado com botão "🔄 Automático"
- Handlers `toggle_auto_on` e `toggle_auto_off` implementados
- Status dinâmico (🟢 ATIVO / ⚪ PAUSADO)

#### ✅ **4. Atualizado: main.py**
- Import do AutoTrader
- Inicialização do AutoTrader
- Configuração do bot Telegram no AutoTrader
- Desativação automática ao encerrar

### 📚 Documentação Incluída

- **AUTO_TRADE_README.md** - Documentação completa do Auto Trade
- **AUTO_TRADE_INTEGRACAO.md** - Guia de integração (para referência)
- **AUTO_TRADE_EXEMPLOS.md** - Exemplos práticos de uso
- **test_auto_trader.py** - Script de testes (opcional)

---

## 🚀 COMO USAR

### **Passo 1: Configurar Credenciais**

Edite o arquivo `state/config.py` e configure:

```python
# Telegram
TOKEN = "SEU_TOKEN_AQUI"
GRUPO_ID = 123456789  # Seu ID de usuário

# IQ Option
EMAIL = "seu@email.com"
SENHA = "sua_senha"

# Groq API (opcional - para IA)
GROQ_API_KEY = "sua_chave_groq"
```

### **Passo 2: Instalar Dependências**

```bash
pip install -r requirements.txt
```

Se houver erro, instale manualmente:

```bash
pip install python-telegram-bot
pip install iqoptionapi
pip install groq
pip install pytz
```

### **Passo 3: Executar o Bot**

```bash
python main.py
```

Você verá:

```
🚀 Iniciando Bot Q3 IA v3.0 SÊNIOR...
✅ IA Guard inicializada
✅ Conectado!
📊 Tipo de conta: PRACTICE
💰 Saldo PRACTICE: $10000.00
✅ AutoTrader inicializado
✅ Sistema inicializado
✅ Bot Telegram configurado no AutoTrader
```

### **Passo 4: Usar no Telegram**

1. Abra o bot no Telegram
2. Digite `/start`
3. Você verá o menu com o botão "🔄 Automático: ⚪ PAUSADO"
4. Clique para ativar!

---

## 🎯 FUNCIONALIDADES DISPONÍVEIS

### **1. Modo Automático** 🆕
- ✅ Captura sinais reais da API IQ Option
- ✅ Analisa tendências automaticamente
- ✅ Executa trades na conta PRACTICE
- ✅ Notifica resultados em tempo real

**Como usar:**
- Menu → 🔄 Automático → Clique para ativar
- Receba notificações de sinais e resultados
- Clique novamente para desativar

### **2. Sinais Manuais**
- ✅ Envie sinais manualmente
- ✅ Formatos múltiplos aceitos
- ✅ Agendamento automático
- ✅ Validação com IA Guard

**Como usar:**
- Envie sinais no formato: `EURUSD 15:30 CALL M1`
- Bot agenda e executa automaticamente

### **3. Configurações**
- ✅ Ajustar valor de entrada
- ✅ Configurar stop loss/gain
- ✅ Ativar/desativar martingale
- ✅ Operar automaticamente

**Como usar:**
- Menu → ⚙️ Configurações
- Ajuste os parâmetros

### **4. Estatísticas**
- ✅ Wins e losses
- ✅ Winrate
- ✅ Lucro total
- ✅ Decisões da IA

**Como usar:**
- Menu → 📊 Estatísticas

### **5. IA & Governança**
- ✅ Validar contexto
- ✅ Criar estratégias
- ✅ Prever mercado
- ✅ Decidir direção

**Como usar:**
- Menu → 🤖 IA & Governança
- Ative/desative funções

---

## 📁 ESTRUTURA DO BOT

```
bot_completo/
├── core/
│   ├── auto_trader.py       ← NOVO: Módulo de Auto Trade
│   ├── iq_client.py
│   ├── trade_executor.py
│   ├── signal_parser.py
│   └── scheduler.py
├── state/
│   ├── runtime.py           ← ATUALIZADO: Com auto_trader
│   ├── config.py
│   └── stats.py
├── bot/
│   └── telegram_bot.py      ← ATUALIZADO: Com botão e handlers
├── ai/
│   └── ia_guard.py
├── main.py                  ← ATUALIZADO: Inicializa AutoTrader
├── AUTO_TRADE_README.md     ← Documentação do Auto Trade
├── AUTO_TRADE_INTEGRACAO.md ← Guia de integração
├── AUTO_TRADE_EXEMPLOS.md   ← Exemplos práticos
└── test_auto_trader.py      ← Script de testes
```

---

## 🧪 TESTANDO ANTES DE USAR

Execute o script de testes para validar:

```bash
python test_auto_trader.py
```

Saída esperada:

```
🧪 INICIANDO TESTES DO AUTO TRADER
==========================================
TESTE 1: Captura de Sinais
✅ Sinal detectado: EURUSD CALL (75%)
...
TESTE 2: Execução de Trade
✅ WIN! Lucro: $8.50
...
TESTE 3: Modo Automático
📊 Total operações: 2
✅ TODOS OS TESTES CONCLUÍDOS!
```

---

## ⚙️ CONFIGURAÇÕES RECOMENDADAS

### **Para Iniciantes:**

```python
# state/config.py
CONFIG = {
    "valor_entrada": 2.0,      # Começar pequeno
    "stop_loss": 20.0,         # Proteção
    "stop_gain": 40.0,         # Meta razoável
    "martingale": False,       # Desativado
    "operar_automatico": True  # Permitir automação
}
```

### **Para Experientes:**

```python
# state/config.py
CONFIG = {
    "valor_entrada": 10.0,     # Maior exposição
    "stop_loss": 100.0,        # Maior margem
    "stop_gain": 200.0,        # Meta ambiciosa
    "martingale": False,       # Depende da estratégia
    "operar_automatico": True
}
```

---

## 🔧 PERSONALIZAÇÕES

### **Alterar Intervalo de Verificação**

Em `core/auto_trader.py`, linha 91:

```python
intervalo_verificacao = 5  # segundos (padrão: 5)
# Altere para 10 se quiser menos chamadas à API
```

### **Alterar Pares Analisados**

Em `core/auto_trader.py`, linha 160:

```python
pares_analisar = [
    "EURUSD", "GBPUSD", "USDJPY",  # Principais
    # Adicione mais pares:
    "AUDUSD", "NZDUSD", "USDCAD",
]
```

### **Alterar Nível Mínimo de Confiança**

Em `core/auto_trader.py`, linha 205:

```python
if melhor_sinal and melhor_sinal["confianca"] >= 60:  # %
# Aumente para 70 ou 75 para ser mais seletivo
```

---

## 📊 EXEMPLO DE USO REAL

```
09:00 - Abrir Telegram e digitar /start
09:01 - Clicar em "🔄 Automático: ⚪ PAUSADO"
09:01 - Bot responde: "🟢 Modo Automático ATIVADO"

09:05 - Notificação: "🎯 Sinal Detectado: EURUSD CALL (75%)"
09:05 - Notificação: "⚡ Executando trade automaticamente..."
09:06 - Notificação: "✅ WIN! Lucro: $8.50"

09:12 - Notificação: "🎯 Sinal Detectado: GBPUSD PUT (82%)"
09:12 - Notificação: "⚡ Executando trade automaticamente..."
09:13 - Notificação: "✅ WIN! Lucro: $8.50"

... continua operando automaticamente ...

12:00 - Clicar em "🔄 Automático: 🟢 ATIVO"
12:00 - Bot responde: "⚪ Modo Automático DESATIVADO"
12:00 - Notificação: "📊 Sessão: 12 ops, 8 wins (66%), +$48.00"
```

---

## ❗ AVISOS IMPORTANTES

1. **Sempre use PRACTICE primeiro**
   - O bot força conta PRACTICE por segurança
   - Teste por pelo menos 1 semana

2. **Monitore regularmente**
   - Verifique notificações
   - Acompanhe estatísticas
   - Ajuste parâmetros

3. **Trading envolve riscos**
   - Não opere com dinheiro que não pode perder
   - Este é um bot educacional
   - Não garante lucros

4. **Mantenha credenciais seguras**
   - Não compartilhe seu `config.py`
   - Use senhas fortes
   - Ative 2FA na IQ Option

---

## 🆘 SUPORTE

### **Problemas Comuns:**

**❌ "Bot não inicia"**
- Verifique se configurou TOKEN e credenciais
- Verifique conexão de internet
- Veja logs de erro

**❌ "Botão Automático não aparece"**
- Bot foi integrado corretamente
- Faça `/start` novamente
- Reinicie o bot

**❌ "Sinais não são detectados"**
- Normal em mercado lateral
- Verifique horário (mercado aberto?)
- Ajuste nível de confiança

**❌ "Trades não executam"**
- Verifique saldo PRACTICE
- Verifique se ativo está aberto
- Veja logs de erro

### **Logs:**

Todos os logs aparecem no terminal onde você executou `python main.py`

---

## 📚 DOCUMENTAÇÃO ADICIONAL

Para informações mais detalhadas, consulte:

- **AUTO_TRADE_README.md** - Como funciona o Auto Trade
- **AUTO_TRADE_INTEGRACAO.md** - Detalhes técnicos da integração
- **AUTO_TRADE_EXEMPLOS.md** - Casos de uso e exemplos práticos

---

## ✅ CHECKLIST DE VERIFICAÇÃO

Antes de começar a operar:

- [ ] Configurei TOKEN do Telegram
- [ ] Configurei credenciais IQ Option
- [ ] Executei `python main.py` sem erros
- [ ] Botão "Automático" aparece no menu
- [ ] Consegui ativar/desativar o modo automático
- [ ] Li a documentação do Auto Trade
- [ ] Testei com conta PRACTICE
- [ ] Entendi os riscos do trading

---

## 🚀 PRONTO PARA COMEÇAR!

Seu bot está **100% funcional** com Auto Trade integrado.

**Próximos passos:**

1. Configure credenciais em `state/config.py`
2. Execute `python main.py`
3. Abra o bot no Telegram
4. Ative o modo automático
5. Monitore e ajuste conforme necessário

**Bons trades! 📈**

---

**Versão:** 1.0.0 (com Auto Trade integrado)  
**Data:** Fevereiro 2026  
**Compatibilidade:** Python 3.8+
