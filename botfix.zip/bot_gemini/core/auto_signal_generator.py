"""
Gerador Automático de Sinais
Usa MyIQ (dados reais) + Gemini AI
Não interfere com sinais manuais
"""
import asyncio
import logging
import time
import json
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class AutoSignalGenerator:
    """Gerador automático de sinais com MyIQ + Gemini"""
    
    def __init__(self, iq_client, gemini_client, runtime):
        self.iq_client = iq_client
        self.gemini_client = gemini_client
        self.runtime = runtime
        self.active = False
        self.task = None
        self.interval = 90
        self.min_confidence = 70
        self.max_per_hour = 5
        self.generated = []
        self.assets = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD"]
    
    async def start(self):
        if self.active:
            return False
        if not self.iq_client or not self.iq_client.esta_conectado():
            return False
        self.active = True
        self.task = asyncio.create_task(self._loop())
        logger.info("🤖 AutoSignalGenerator STARTED")
        return True
    
    async def stop(self):
        if not self.active:
            return False
        self.active = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
        logger.info("🛑 AutoSignalGenerator STOPPED")
        return True
    
    async def _loop(self):
        try:
            while self.active:
                try:
                    if not await self.iq_client.garantir_practice():
                        logger.error("❌ Not in PRACTICE")
                        break
                    
                    self._cleanup()
                    
                    # RULE: Only generate if manual queue is empty
                    if len(self.runtime.sinais_agendados) > 0:
                        logger.debug("⏸️ Manual signals exist - skipping auto generation")
                        await asyncio.sleep(10)
                        continue
                    
                    if len(self.generated) >= self.max_per_hour:
                        logger.debug(f"⏸️ Hour limit reached ({self.max_per_hour})")
                        await asyncio.sleep(self.interval)
                        continue
                    
                    signal = await self._generate()
                    
                    if signal:
                        self.runtime.adicionar_sinal(signal)
                        self.generated.append({"timestamp": datetime.now(TZ), "asset": signal["par"]})
                        logger.info(f"✅ Auto signal generated: {signal['par']} {signal['direcao']}")
                    
                    await asyncio.sleep(self.interval)
                    
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"❌ Loop error: {e}")
                    await asyncio.sleep(self.interval)
        finally:
            logger.info("🏁 AutoSignalGenerator loop ended")
    
    async def _generate(self):
        try:
            # Get best asset with candles
            asset_data = await self._fetch_candles()
            if not asset_data:
                return None
            
            asset = asset_data["asset"]
            candles = asset_data["candles"]
            
            logger.info(f"📊 Fetched {len(candles)} candles for {asset}")
            
            # Analyze with Gemini AI
            result = await self._analyze_with_ai(asset, candles)
            
            if not result or not result.get("valid"):
                return None
            
            if result["confidence"] < self.min_confidence:
                logger.debug(f"⚠️ Low confidence: {result['confidence']}%")
                return None
            
            # Create signal object
            signal = {
                "par": asset,
                "direcao": result["direction"],
                "tempo_expiracao": 60,
                "horario": datetime.now(TZ) + timedelta(seconds=10),
                "imediato": False,
                "formato": "AUTO_AI",
                "origem": "AUTOMATIC",
                "confianca": result["confidence"],
                "motivo": result.get("reason", "AI analysis")
            }
            
            return signal
            
        except Exception as e:
            logger.error(f"❌ Generation error: {e}")
            return None
    
    async def _fetch_candles(self):
        for asset in self.assets:
            try:
                available, final_asset = self.iq_client.verificar_ativo_disponivel(asset)
                if not available:
                    continue
                
                candles = self.iq_client.iq.get_candles(final_asset, 60, 100, time.time())
                
                if candles and len(candles) >= 30:
                    return {"asset": final_asset, "candles": candles}
                    
            except Exception as e:
                logger.debug(f"❌ Error fetching {asset}: {e}")
                continue
        
        return None
    
    async def _analyze_with_ai(self, asset, candles):
        if not self.gemini_client:
            return self._fallback_analysis(candles)
        
        try:
            prompt = self._build_prompt(asset, candles)
            
            response = self.gemini_client.chat.completions.create(
                model="gemini-1.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.2,
                max_tokens=300
            )
            
            content = response.choices[0].message.content.strip()
            
            # Clean markdown
            if content.startswith("```"):
                content = content.replace("```json", "").replace("```", "").strip()
            
            # Parse JSON
            data = json.loads(content)
            
            if not data.get("valid"):
                return None
            
            if data["direction"] not in ["CALL", "PUT"]:
                logger.warning(f"❌ Invalid direction: {data['direction']}")
                return None
            
            return {
                "valid": True,
                "direction": data["direction"],
                "confidence": int(data.get("confidence", 0)),
                "reason": data.get("reason", "")
            }
            
        except Exception as e:
            logger.error(f"❌ AI analysis error: {e}")
            return self._fallback_analysis(candles)
    
    def _build_prompt(self, asset, candles):
        last_10 = candles[-10:]
        candle_summary = []
        
        for i, c in enumerate(last_10, 1):
            trend = "🟢" if c['close'] > c['open'] else "🔴"
            candle_summary.append(
                f"{i}. {trend} O:{c['open']:.5f} C:{c['close']:.5f} H:{c['high']:.5f} L:{c['low']:.5f}"
            )
        
        candle_text = "\n".join(candle_summary)
        
        return f"""Analyze this forex asset for binary options trading.

ASSET: {asset}
TIMEFRAME: 1 minute
LAST 10 CANDLES:
{candle_text}

TASK:
Determine if there is a clear trading opportunity.

RULES:
- Return ONLY valid JSON
- If no clear opportunity (confidence < 65%), return {{"valid": false}}
- Only suggest CALL or PUT if you have strong conviction
- Consider: trend, momentum, support/resistance

RESPONSE FORMAT:
{{
    "valid": true/false,
    "direction": "CALL" or "PUT" (only if valid=true),
    "confidence": 0-100,
    "reason": "brief technical reason"
}}

EXAMPLE VALID:
{{"valid": true, "direction": "CALL", "confidence": 75, "reason": "Strong uptrend with higher lows"}}

EXAMPLE NO OPPORTUNITY:
{{"valid": false}}

Return JSON only:"""
    
    def _fallback_analysis(self, candles):
        try:
            last_10 = candles[-10:]
            up = sum(1 for c in last_10 if c['close'] > c['open'])
            down = sum(1 for c in last_10 if c['close'] < c['open'])
            
            if up >= 7:
                return {
                    "valid": True,
                    "direction": "CALL",
                    "confidence": min(85, int((up / 10) * 100)),
                    "reason": f"Uptrend {up}/10 candles"
                }
            elif down >= 7:
                return {
                    "valid": True,
                    "direction": "PUT",
                    "confidence": min(85, int((down / 10) * 100)),
                    "reason": f"Downtrend {down}/10 candles"
                }
            
            return None
            
        except:
            return None
    
    def _cleanup(self):
        now = datetime.now(TZ)
        self.generated = [
            s for s in self.generated
            if (now - s["timestamp"]).total_seconds() < 3600
        ]
