# Bot Q3 IA v3.1 - Playwright Edition

## 🎯 O QUE MUDOU

**PROBLEMA RESOLVIDO:** API não oficial não executava trades reais.

**SOLUÇÃO:** Automação completa do navegador com Playwright.

### Antes (v3.0)
- ✅ Conectava com API
- ✅ Lia saldo
- ❌ **NÃO executava trades**

### Agora (v3.1)
- ✅ Loga no navegador REAL
- ✅ Seleciona conta PRACTICE
- ✅ **EXECUTA TRADES clicando na interface**
- ✅ Confirma ordem aberta
- ✅ Verifica resultado

---

## 🚀 INSTALAÇÃO NO VPS UBUNTU

### Método 1: Script Automático (RECOMENDADO)

```bash
# 1. Fazer upload do projeto para VPS
scp -r bot/ root@seu_vps:/root/

# 2. Conectar no VPS
ssh root@seu_vps

# 3. Entrar no diretório
cd /root/bot

# 4. Executar instalador
sudo bash install_playwright.sh

# 5. Editar credenciais
nano .env
```

### Método 2: Manual

```bash
# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Python e pip
sudo apt install -y python3 python3-pip python3-venv

# Criar ambiente virtual
python3 -m venv venv
source venv/bin/activate

# Instalar dependências
pip install -r requirements_playwright.txt

# Instalar navegadores Playwright
playwright install chromium
playwright install-deps chromium

# Configurar .env
cp .env.example .env
nano .env  # Editar com suas credenciais
```

---

## ⚙️ CONFIGURAÇÃO

### Arquivo .env

```env
# IQ Option
EMAIL=seu_email@exemplo.com
SENHA=sua_senha_segura

# Telegram
TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
GRUPO_ID=-1001234567890

# Groq API (opcional para IA)
GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxxx
```

### Obter credenciais

**Token Telegram:**
1. Falar com [@BotFather](https://t.me/botfather)
2. Criar bot com `/newbot`
3. Copiar token

**Grupo ID:**
1. Adicionar bot no grupo
2. Enviar mensagem qualquer
3. Acessar: `https://api.telegram.org/bot<TOKEN>/getUpdates`
4. Procurar por `"chat":{"id":-1001234567890`

**Groq API (opcional):**
1. Criar conta em [console.groq.com](https://console.groq.com)
2. Gerar API key

---

## 🏃 EXECUÇÃO

### Modo Manual (Teste)

```bash
cd /root/bot
source venv/bin/activate
python3 main_playwright.py
```

### Modo Serviço (24/7)

```bash
# Iniciar
sudo systemctl start botq3

# Parar
sudo systemctl stop botq3

# Reiniciar
sudo systemctl restart botq3

# Ver status
sudo systemctl status botq3

# Ver logs em tempo real
sudo journalctl -u botq3 -f

# Habilitar auto-start no boot
sudo systemctl enable botq3
```

---

## 📊 ESTRUTURA DE ARQUIVOS

```
bot/
├── main_playwright.py              # ✨ NOVO - Main com Playwright
├── core/
│   ├── iq_playwright_client.py     # ✨ NOVO - Cliente Playwright
│   ├── playwright_trade_executor.py # ✨ NOVO - Executor Playwright
│   ├── playwright_wrapper.py       # ✨ NOVO - Wrapper compatibilidade
│   ├── iq_client.py                # ⚠️ ANTIGO - Não usar mais
│   ├── trade_executor.py           # ⚠️ ANTIGO - Não usar mais
│   ├── signal_parser.py
│   └── scheduler.py
├── ai/
│   └── ia_guard.py
├── bot/
│   └── telegram_bot.py
├── state/
│   ├── config.py
│   ├── runtime.py
│   └── stats.py
├── requirements_playwright.txt      # ✨ NOVO
├── install_playwright.sh           # ✨ NOVO
└── .env                            # Suas credenciais
```

---

## 🐛 DEBUGGING

### Testar Playwright

```bash
cd /root/bot
source venv/bin/activate
./test_playwright.sh
```

### Verificar logs

```bash
# Logs do systemd
sudo journalctl -u botq3 -n 100

# Logs em tempo real
sudo journalctl -u botq3 -f

# Filtrar erros
sudo journalctl -u botq3 | grep "ERROR"
```

### Problemas comuns

**1. "playwright: command not found"**
```bash
source venv/bin/activate
pip install playwright
playwright install chromium
```

**2. "Browser closed" ou "Session expired"**
- Verificar email/senha no .env
- IQ Option pode ter bloqueado login automático
- Tentar em horário diferente

**3. "Não encontrou botão CALL/PUT"**
- Interface da IQ Option mudou
- Verificar seletores no código
- Abrir issue no GitHub

**4. Bot não executa trade**
```bash
# Ver logs detalhados
sudo journalctl -u botq3 -f

# Verificar se está logado
# Logs devem mostrar: "✅ Login bem-sucedido!"
```

---

## 🔒 SEGURANÇA

### ✅ Garantias PRACTICE

1. **Login:** Força conta PRACTICE no `_garantir_practice()`
2. **Pré-trade:** Verifica tipo de conta antes de executar
3. **Logs:** Toda operação mostra tipo de conta

### 🚨 Nunca vai operar em REAL

O código tem múltiplas verificações:
- Detecção automática de conta REAL
- Troca forçada para PRACTICE
- Logs em todas as etapas

---

## 📈 COMO USAR

### 1. Iniciar bot

```bash
sudo systemctl start botq3
```

### 2. Enviar sinal no grupo Telegram

```
EURUSD
CALL
1M
```

Ou formato completo:
```
Par: EURUSD-OTC
Direção: PUT
Expiração: 60s
Horário: 14:35
```

### 3. Bot vai:

1. ✅ Validar sinal com IA (se ativado)
2. 🌐 Abrir navegador
3. 🔐 Fazer login
4. 🏦 Garantir PRACTICE
5. 📊 Selecionar ativo
6. 💰 Definir valor
7. 👆 Clicar CALL/PUT
8. ✅ Confirmar ordem
9. ⏳ Aguardar resultado
10. 📊 Reportar no Telegram

---

## 🎛️ COMANDOS TELEGRAM

- `/start` - Status do bot
- `/pausar` - Pausar operações
- `/retomar` - Retomar operações
- `/status` - Ver estatísticas

---

## 🔄 ATUALIZAÇÕES FUTURAS

### Melhorias planejadas:
- [ ] Screenshot de cada trade
- [ ] OCR para ler saldo exato
- [ ] Retry automático em falhas
- [ ] Multi-conta (várias contas PRACTICE)
- [ ] Dashboard web

---

## 📞 SUPORTE

**Problemas?**
1. Verificar logs: `sudo journalctl -u botq3 -f`
2. Testar Playwright: `./test_playwright.sh`
3. Verificar .env com credenciais corretas

**Dúvidas?**
- Criar issue no GitHub
- Verificar documentação Playwright: [playwright.dev](https://playwright.dev)

---

## ⚖️ AVISO LEGAL

**Este bot é para fins educacionais.**

- ✅ Use APENAS em conta PRACTICE
- ❌ Não opere com dinheiro real sem entender os riscos
- ❌ Trading envolve risco de perda
- ❌ Não somos responsáveis por perdas financeiras

**Respeite os Termos de Serviço da IQ Option.**

---

## 📄 LICENÇA

MIT License - Use por sua conta e risco.

---

**Bot Q3 IA v3.1 - Powered by Playwright** 🎭
