"""
Runtime state — Bot Q3 Beta
Global component references. Set during startup, never reset.
"""

# Core components
iq_connection = None          # IQClient
execution_engine = None       # ExecutionEngine (THE single execution path)
martingale_manager = None     # MartingaleManager
risk_manager = None           # RiskManager
gemini_client = None          # GeminiClient (optional)
auto_signal_generator = None  # AutoSignalGenerator

# Telegram app reference
_telegram_app = None

# Scheduled signals queue
sinais_agendados = []

# Signal capture active
captura_sinais_ativa = False

# Editing state per user
editing_state = {}            # {user_id: field_name | None}


def adicionar_sinal(sinal):
    sinais_agendados.append(sinal)


def remover_sinal(sinal):
    if sinal in sinais_agendados:
        sinais_agendados.remove(sinal)


def limpar_sinais():
    sinais_agendados.clear()
