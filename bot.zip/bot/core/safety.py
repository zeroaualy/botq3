"""
Kill Switch & Watchdog - Q3 IA Beta
Sistema de segurança e monitoramento de tasks
"""
import asyncio
import logging
from typing import Dict, Any, Optional, Set, Callable
from datetime import datetime, timedelta
from enum import Enum

logger = logging.getLogger(__name__)


class SystemStatus(str, Enum):
    """Status do sistema"""
    RUNNING = "running"
    DEGRADED = "degraded"  # Alguns componentes com problemas
    CRITICAL = "critical"   # Problemas graves
    STOPPED = "stopped"


class KillSwitch:
    """
    Kill Switch para parada de emergência do sistema
    
    Características:
    - Parada de emergência instantânea
    - Múltiplos níveis de severidade
    - Callbacks de shutdown
    - Registro de motivo
    """
    
    def __init__(self):
        """Inicializa o Kill Switch"""
        self._active = False
        self._triggered_at: Optional[datetime] = None
        self._reason: Optional[str] = None
        self._severity: Optional[str] = None
        self._shutdown_callbacks: list[Callable] = []
        
        logger.info("✅ Kill Switch inicializado")
    
    async def trigger(self, reason: str, severity: str = "high") -> None:
        """
        Ativa o Kill Switch
        
        Args:
            reason: Motivo da ativação
            severity: Severidade (low, medium, high, critical)
        """
        if self._active:
            logger.warning("⚠️ Kill Switch já estava ativo")
            return
        
        self._active = True
        self._triggered_at = datetime.now()
        self._reason = reason
        self._severity = severity
        
        logger.critical(
            f"🛑🛑🛑 KILL SWITCH ATIVADO 🛑🛑🛑\n"
            f"Motivo: {reason}\n"
            f"Severidade: {severity}\n"
            f"Timestamp: {self._triggered_at.isoformat()}"
        )
        
        # Executar callbacks de shutdown
        await self._execute_shutdown_callbacks()
    
    async def _execute_shutdown_callbacks(self) -> None:
        """Executa todos os callbacks de shutdown"""
        for callback in self._shutdown_callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback()
                else:
                    await asyncio.get_event_loop().run_in_executor(None, callback)
            except Exception as e:
                logger.error(f"❌ Erro ao executar callback de shutdown: {e}")
    
    def register_shutdown_callback(self, callback: Callable) -> None:
        """
        Registra um callback para ser executado no shutdown
        
        Args:
            callback: Função a executar (pode ser async)
        """
        self._shutdown_callbacks.append(callback)
        logger.info(f"📌 Callback de shutdown registrado: {callback.__name__}")
    
    def reset(self) -> None:
        """Reseta o Kill Switch (apenas para testes)"""
        logger.warning("⚠️ Kill Switch resetado manualmente")
        self._active = False
        self._triggered_at = None
        self._reason = None
        self._severity = None
    
    @property
    def is_active(self) -> bool:
        """Verifica se o Kill Switch está ativo"""
        return self._active
    
    def get_status(self) -> Dict[str, Any]:
        """Retorna o status do Kill Switch"""
        return {
            'active': self._active,
            'triggered_at': self._triggered_at.isoformat() if self._triggered_at else None,
            'reason': self._reason,
            'severity': self._severity,
            'callbacks_registered': len(self._shutdown_callbacks)
        }


class WatchedTask:
    """Representa uma task monitorada"""
    
    def __init__(self, task_id: str, task: asyncio.Task, timeout: float, 
                 description: str = ""):
        """
        Inicializa uma task monitorada
        
        Args:
            task_id: ID único da task
            task: Task do asyncio
            timeout: Timeout máximo em segundos
            description: Descrição da task
        """
        self.task_id = task_id
        self.task = task
        self.timeout = timeout
        self.description = description
        self.started_at = datetime.now()
        self.last_heartbeat = datetime.now()
        self.warnings = 0
    
    @property
    def elapsed_seconds(self) -> float:
        """Retorna o tempo decorrido desde o início"""
        return (datetime.now() - self.started_at).total_seconds()
    
    @property
    def is_timeout(self) -> bool:
        """Verifica se a task excedeu o timeout"""
        return self.elapsed_seconds >= self.timeout
    
    @property
    def is_done(self) -> bool:
        """Verifica se a task terminou"""
        return self.task.done()
    
    def heartbeat(self) -> None:
        """Atualiza o heartbeat da task"""
        self.last_heartbeat = datetime.now()


class Watchdog:
    """
    Watchdog para monitoramento de tasks
    
    Características:
    - Detecção de tasks travadas
    - Timeout configurável por task
    - Cancelamento automático de tasks travadas
    - Sistema de heartbeat
    - Alertas e métricas
    """
    
    def __init__(self, check_interval: float = 10.0):
        """
        Inicializa o Watchdog
        
        Args:
            check_interval: Intervalo de verificação em segundos
        """
        self.check_interval = check_interval
        self._watched_tasks: Dict[str, WatchedTask] = {}
        self._running = False
        self._watchdog_task: Optional[asyncio.Task] = None
        
        # Métricas
        self._total_watched = 0
        self._total_timeouts = 0
        self._total_cancelled = 0
        
        logger.info(
            f"✅ Watchdog inicializado (check_interval={check_interval}s)"
        )
    
    async def start(self) -> None:
        """Inicia o Watchdog"""
        if self._running:
            logger.warning("⚠️ Watchdog já está rodando")
            return
        
        self._running = True
        self._watchdog_task = asyncio.create_task(self._monitor_loop())
        
        logger.info("🚀 Watchdog iniciado")
    
    async def stop(self) -> None:
        """Para o Watchdog"""
        if not self._running:
            logger.warning("⚠️ Watchdog já está parado")
            return
        
        self._running = False
        
        if self._watchdog_task:
            self._watchdog_task.cancel()
            try:
                await self._watchdog_task
            except asyncio.CancelledError:
                pass
        
        logger.info("⛔ Watchdog parado")
    
    def watch(self, task: asyncio.Task, timeout: float, 
             task_id: Optional[str] = None, description: str = "") -> str:
        """
        Adiciona uma task para monitoramento
        
        Args:
            task: Task do asyncio a monitorar
            timeout: Timeout máximo em segundos
            task_id: ID opcional (gerado automaticamente se None)
            description: Descrição da task
        
        Returns:
            ID da task monitorada
        """
        if task_id is None:
            task_id = f"task_{id(task)}"
        
        watched = WatchedTask(task_id, task, timeout, description)
        self._watched_tasks[task_id] = watched
        self._total_watched += 1
        
        logger.debug(
            f"👁️ Task monitorada: {task_id[:16]} "
            f"(timeout={timeout}s, desc={description})"
        )
        
        return task_id
    
    def heartbeat(self, task_id: str) -> bool:
        """
        Registra heartbeat de uma task
        
        Args:
            task_id: ID da task
        
        Returns:
            True se task foi atualizada, False se não existe
        """
        watched = self._watched_tasks.get(task_id)
        
        if watched is None:
            return False
        
        watched.heartbeat()
        return True
    
    def unwatch(self, task_id: str) -> bool:
        """
        Remove uma task do monitoramento
        
        Args:
            task_id: ID da task
        
        Returns:
            True se removida, False se não existia
        """
        if task_id in self._watched_tasks:
            del self._watched_tasks[task_id]
            logger.debug(f"👁️‍🗨️ Task removida do monitoramento: {task_id[:16]}")
            return True
        return False
    
    async def _monitor_loop(self) -> None:
        """Loop de monitoramento"""
        logger.info("🔄 Loop de monitoramento do Watchdog iniciado")
        
        try:
            while self._running:
                await asyncio.sleep(self.check_interval)
                
                # Verificar cada task
                for task_id in list(self._watched_tasks.keys()):
                    watched = self._watched_tasks[task_id]
                    
                    # Remover tasks concluídas
                    if watched.is_done:
                        self.unwatch(task_id)
                        continue
                    
                    # Verificar timeout
                    if watched.is_timeout:
                        elapsed = watched.elapsed_seconds
                        
                        logger.error(
                            f"⏱️ TIMEOUT detectado: {task_id[:16]} "
                            f"(elapsed={elapsed:.1f}s, timeout={watched.timeout}s)\n"
                            f"Descrição: {watched.description}"
                        )
                        
                        # Cancelar task
                        watched.task.cancel()
                        self._total_timeouts += 1
                        self._total_cancelled += 1
                        
                        # Remover do monitoramento
                        self.unwatch(task_id)
        
        except asyncio.CancelledError:
            logger.info("✅ Loop de monitoramento cancelado")
        except Exception as e:
            logger.error(f"❌ Erro no loop de monitoramento: {e}", exc_info=True)
    
    def get_watched_tasks(self) -> list[Dict[str, Any]]:
        """
        Retorna lista de tasks monitoradas
        
        Returns:
            Lista com informações das tasks
        """
        return [
            {
                'task_id': w.task_id,
                'description': w.description,
                'elapsed_seconds': w.elapsed_seconds,
                'timeout': w.timeout,
                'is_timeout': w.is_timeout,
                'warnings': w.warnings,
                'started_at': w.started_at.isoformat()
            }
            for w in self._watched_tasks.values()
        ]
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas do Watchdog
        
        Returns:
            Dicionário com métricas
        """
        return {
            'running': self._running,
            'watched_count': len(self._watched_tasks),
            'total_watched': self._total_watched,
            'total_timeouts': self._total_timeouts,
            'total_cancelled': self._total_cancelled,
            'tasks': self.get_watched_tasks()
        }
    
    def __len__(self) -> int:
        """Retorna o número de tasks monitoradas"""
        return len(self._watched_tasks)


# Instâncias globais
_kill_switch_instance: Optional[KillSwitch] = None
_watchdog_instance: Optional[Watchdog] = None


def get_kill_switch() -> KillSwitch:
    """
    Retorna a instância global do Kill Switch (singleton)
    
    Returns:
        Instância do KillSwitch
    """
    global _kill_switch_instance
    
    if _kill_switch_instance is None:
        _kill_switch_instance = KillSwitch()
    
    return _kill_switch_instance


def get_watchdog() -> Watchdog:
    """
    Retorna a instância global do Watchdog (singleton)
    
    Returns:
        Instância do Watchdog
    """
    global _watchdog_instance
    
    if _watchdog_instance is None:
        _watchdog_instance = Watchdog()
    
    return _watchdog_instance
