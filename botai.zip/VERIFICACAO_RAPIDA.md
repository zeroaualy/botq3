# ✅ VERIFICAÇÃO RÁPIDA

## Antes de executar, verifique:

### 1. Biblioteca myiq presente?
```bash
ls -la myiq/
```
✅ Deve existir e conter: core/, http/, models/

### 2. Módulo signal_engine presente?
```bash
ls -la core/signal_engine.py
```
✅ Deve existir (~15KB)

### 3. Teste de importação:
```bash
python3 -c "from core.signal_engine import SignalEngine; print('OK')"
python3 -c "from myiq.core.client import IQOption; print('OK')"
```
✅ Ambos devem mostrar "OK"

## Se tudo OK, instale:

```bash
pip install -r requirements.txt --break-system-packages
python main.py
```

## Problemas?

- Faltando myiq? → Extraia o ZIP novamente
- Erro de importação? → `pip install -r requirements.txt`
- Outras dúvidas? → Leia GUIA_INSTALACAO_AUTOMACAO.md
