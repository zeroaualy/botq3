"""
Script de Teste do Auto Trader
Teste a funcionalidade sem executar trades reais
"""
import asyncio
import logging
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class MockIQClient:
    """Cliente IQ Option simulado para testes"""
    
    def __init__(self):
        self.conectado = True
        self.saldo = 10000.0
        self.tipo_conta = "PRACTICE"
    
    def esta_conectado(self):
        return self.conectado
    
    def garantir_practice(self):
        return self.tipo_conta == "PRACTICE"
    
    def obter_saldo(self):
        return self.saldo
    
    def obter_tipo_conta(self):
        return self.tipo_conta
    
    def verificar_ativo_disponivel(self, par):
        """Simula verificação de ativo"""
        pares_disponiveis = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD"]
        disponivel = par in pares_disponiveis
        return disponivel, par if disponivel else None
    
    class IQApi:
        """API simulada"""
        def get_candles(self, par, intervalo, quantidade, timestamp):
            """Simula candles"""
            import random
            candles = []
            for i in range(quantidade):
                open_price = 1.0850 + random.uniform(-0.0010, 0.0010)
                close_price = open_price + random.uniform(-0.0005, 0.0005)
                candles.append({
                    "open": open_price,
                    "close": close_price,
                    "high": max(open_price, close_price) + 0.0002,
                    "low": min(open_price, close_price) - 0.0002,
                    "volume": random.randint(100, 1000)
                })
            return candles
        
        def buy(self, valor, par, acao, expiracao):
            """Simula compra"""
            import random
            sucesso = random.choice([True, True, True, False])  # 75% sucesso
            order_id = f"ORDER_{random.randint(10000, 99999)}"
            return sucesso, order_id if sucesso else None
        
        def check_win_v4(self, order_id):
            """Simula resultado"""
            import random
            # 60% win, 30% loss, 10% empate
            resultado = random.choices(
                [8.50, -5.00, 0],
                weights=[60, 30, 10]
            )[0]
            return resultado
    
    def __init__(self):
        self.conectado = True
        self.saldo = 10000.0
        self.tipo_conta = "PRACTICE"
        self.iq = self.IQApi()


class MockTradeExecutor:
    """Executor simulado para testes"""
    
    def __init__(self, iq_client):
        self.iq_client = iq_client
    
    def executar(self, par, direcao, valor, expiracao):
        """Simula execução de trade"""
        logger.info(f"📊 [SIMULADO] Executando: {par} {direcao} ${valor} {expiracao}s")
        
        # Simular chamada à API
        acao = "call" if direcao.upper() == "CALL" else "put"
        sucesso, order_id = self.iq_client.iq.buy(valor, par, acao, expiracao)
        
        if sucesso:
            logger.info(f"✅ [SIMULADO] Ordem executada! ID: {order_id}")
            return True, order_id
        else:
            logger.error(f"❌ [SIMULADO] Falha ao executar ordem")
            return False, None
    
    def verificar_resultado(self, order_id, aguardar_segundos=3):
        """Simula verificação de resultado"""
        import time
        time.sleep(aguardar_segundos)
        
        resultado = self.iq_client.iq.check_win_v4(order_id)
        
        if resultado > 0:
            logger.info(f"✅ [SIMULADO] WIN - Lucro: ${resultado:.2f}")
            return "WIN", resultado
        elif resultado < 0:
            logger.info(f"❌ [SIMULADO] LOSS - Perda: ${abs(resultado):.2f}")
            return "LOSS", abs(resultado)
        else:
            logger.info("⚪ [SIMULADO] EMPATE")
            return "EMPATE", 0


async def testar_captura_sinais():
    """Testa a captura de sinais"""
    logger.info("=" * 60)
    logger.info("TESTE 1: Captura de Sinais")
    logger.info("=" * 60)
    
    # Importar AutoTrader
    import sys
    sys.path.insert(0, '/home/claude')
    from auto_trader import AutoTrader
    
    # Criar mocks
    iq_client = MockIQClient()
    trade_executor = MockTradeExecutor(iq_client)
    config = {"valor_entrada": 5.0}
    stats = {
        "total_operacoes": 0,
        "wins": 0,
        "losses": 0,
        "lucro_total": 0.0
    }
    
    # Criar AutoTrader
    auto_trader = AutoTrader(iq_client, trade_executor, config, stats)
    
    # Testar captura de sinais
    logger.info("\n📡 Testando captura de sinais...")
    
    for i in range(5):
        sinal = await auto_trader._captura_sinal_real()
        
        if sinal and sinal.get("valido"):
            logger.info(f"\n✅ Sinal {i+1} detectado:")
            logger.info(f"   Par: {sinal['par']}")
            logger.info(f"   Ação: {sinal['acao']}")
            logger.info(f"   Confiança: {sinal['confianca']}%")
            logger.info(f"   Análise: {sinal['analise']}")
        else:
            logger.info(f"\n⚪ Tentativa {i+1}: Nenhum sinal válido detectado")
        
        await asyncio.sleep(1)
    
    logger.info("\n✅ Teste de captura de sinais concluído!")


async def testar_execucao_trade():
    """Testa a execução de trade"""
    logger.info("\n" + "=" * 60)
    logger.info("TESTE 2: Execução de Trade")
    logger.info("=" * 60)
    
    # Criar mocks
    iq_client = MockIQClient()
    trade_executor = MockTradeExecutor(iq_client)
    
    # Sinal simulado
    sinal = {
        "valido": True,
        "par": "EURUSD",
        "acao": "CALL",
        "expiracao": 60,
        "confianca": 75,
        "analise": "Tendência de alta detectada (8/10 velas)"
    }
    
    logger.info(f"\n🎯 Executando trade com sinal:")
    logger.info(f"   {sinal['par']} {sinal['acao']} ({sinal['confianca']}%)")
    
    # Executar
    sucesso, order_id = trade_executor.executar(
        par=sinal["par"],
        direcao=sinal["acao"],
        valor=5.0,
        expiracao=sinal["expiracao"]
    )
    
    if sucesso:
        logger.info(f"\n⏳ Aguardando resultado...")
        resultado, valor = trade_executor.verificar_resultado(order_id)
        
        if resultado == "WIN":
            logger.info(f"✅ WIN! Lucro: ${valor:.2f}")
        elif resultado == "LOSS":
            logger.info(f"❌ LOSS! Perda: ${valor:.2f}")
        else:
            logger.info(f"⚪ EMPATE")
    
    logger.info("\n✅ Teste de execução de trade concluído!")


async def testar_modo_automatico():
    """Testa o modo automático completo"""
    logger.info("\n" + "=" * 60)
    logger.info("TESTE 3: Modo Automático (10 segundos)")
    logger.info("=" * 60)
    
    # Importar AutoTrader
    import sys
    sys.path.insert(0, '/home/claude')
    from auto_trader import AutoTrader
    
    # Criar mocks
    iq_client = MockIQClient()
    trade_executor = MockTradeExecutor(iq_client)
    config = {"valor_entrada": 5.0}
    stats = {
        "total_operacoes": 0,
        "wins": 0,
        "losses": 0,
        "lucro_total": 0.0
    }
    
    # Criar AutoTrader
    auto_trader = AutoTrader(iq_client, trade_executor, config, stats)
    
    # Ativar modo automático
    logger.info("\n🟢 Ativando modo automático...")
    await auto_trader.ativar(chat_id=123456)
    
    # Aguardar 10 segundos
    logger.info("⏳ Aguardando 10 segundos de operação automática...")
    await asyncio.sleep(10)
    
    # Desativar
    logger.info("\n🛑 Desativando modo automático...")
    await auto_trader.desativar()
    
    # Mostrar estatísticas
    logger.info("\n📊 Estatísticas da sessão:")
    logger.info(f"   Total operações: {stats['total_operacoes']}")
    logger.info(f"   Wins: {stats['wins']}")
    logger.info(f"   Losses: {stats['losses']}")
    logger.info(f"   Lucro total: ${stats['lucro_total']:.2f}")
    
    if stats['total_operacoes'] > 0:
        taxa_acerto = (stats['wins'] / stats['total_operacoes']) * 100
        logger.info(f"   Taxa de acerto: {taxa_acerto:.1f}%")
    
    logger.info("\n✅ Teste de modo automático concluído!")


async def main():
    """Executa todos os testes"""
    logger.info("\n" + "=" * 60)
    logger.info("🧪 INICIANDO TESTES DO AUTO TRADER")
    logger.info("=" * 60)
    
    try:
        # Teste 1: Captura de sinais
        await testar_captura_sinais()
        
        # Teste 2: Execução de trade
        await testar_execucao_trade()
        
        # Teste 3: Modo automático
        await testar_modo_automatico()
        
        logger.info("\n" + "=" * 60)
        logger.info("✅ TODOS OS TESTES CONCLUÍDOS COM SUCESSO!")
        logger.info("=" * 60)
        
    except Exception as e:
        logger.error(f"\n❌ Erro durante os testes: {e}")
        import traceback
        logger.error(traceback.format_exc())


if __name__ == "__main__":
    # Executar testes
    asyncio.run(main())
