"""
Risk Manager — Bot Q3 Beta
Persistent state, payout-aware Kelly sizing, latency guard.
"""
import logging
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from typing import Dict, Tuple
from db import database

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")

# Maximum allowed latency between signal_received and execution
DEFAULT_MAX_SLIPPAGE_MS = 4000  # 4 seconds


class RiskManager:
    """
    Risk controls:
    1. Daily stop-loss / stop-gain (from CONFIG, DB-backed)
    2. Consecutive loss pause (from DB)
    3. Payout-aware Kelly position sizing
    4. Latency / slippage guard
    5. Max concurrent operations
    """

    def __init__(self, global_config: dict):
        self._cfg = global_config
        self.pausado = False
        self.tempo_pausa_ate = None
        self.operacoes_ativas = 0

    # ─────────────────────────────────────────────────────────
    # CONFIG HELPERS (always reads live CONFIG)
    # ─────────────────────────────────────────────────────────

    @property
    def _stop_loss(self) -> float:
        return float(self._cfg.get("stop_loss", 20.0))

    @property
    def _stop_gain(self) -> float:
        return float(self._cfg.get("stop_gain", 50.0))

    @property
    def _max_perdas_pausa(self) -> int:
        return int(self._cfg.get("risco_max_perdas_pausa", 5))

    @property
    def _max_slippage_ms(self) -> int:
        return int(self._cfg.get("max_slippage_ms", DEFAULT_MAX_SLIPPAGE_MS))

    @property
    def _max_ops_simultaneas(self) -> int:
        return int(self._cfg.get("max_operacoes_simultaneas", 3))

    # ─────────────────────────────────────────────────────────
    # KELLY CRITERION
    # ─────────────────────────────────────────────────────────

    async def _kelly_value(self, payout_pct: float) -> float:
        """
        Full Kelly: f* = (p*b - q) / b
        p = historical win rate (from DB)
        b = payout as decimal (e.g. 0.87 for 87%)
        q = 1 - p

        Returns a multiplier applied to base value.
        Caps at 1.0x (never bet more than configured amount).
        Falls back to base value when insufficient history.
        """
        base = float(self._cfg.get("valor_entrada", 10.0))
        stats = await database.get_today_stats()
        total = stats.get("total", 0)

        if total < 10:
            # Not enough history → use base value as-is
            return base

        p = (stats.get("wins", 0) / total)
        q = 1.0 - p
        b = payout_pct / 100.0

        if b <= 0:
            return base

        kelly_fraction = (p * b - q) / b
        kelly_fraction = max(0.0, min(kelly_fraction, 1.0))  # clamp 0–1

        # Apply Kelly as a multiplier on the configured base
        # Half-Kelly for safety (industry standard)
        half_kelly = kelly_fraction * 0.5
        result = base * (1.0 + half_kelly)  # can increase up to 1.5x base
        result = max(base * 0.3, min(result, base * 1.5))  # hard cap ±50%

        logger.info(
            f"📐 Kelly: p={p:.2f} b={b:.2f} → f*={kelly_fraction:.3f} "
            f"half={half_kelly:.3f} → ${result:.2f}"
        )
        return round(result, 2)

    # ─────────────────────────────────────────────────────────
    # VALIDATE OPERATION
    # ─────────────────────────────────────────────────────────

    async def validar_operacao(
        self,
        sinal: Dict,
        payout_pct: float,
        slippage_ms: int = 0,
    ) -> Tuple[bool, str, float]:
        """
        Validate and return (can_execute, reason, amount).

        slippage_ms: milliseconds between signal_received and now.
        """
        # 1. Pause check
        if self.pausado:
            if self.tempo_pausa_ate and datetime.now(TZ) < self.tempo_pausa_ate:
                remaining = int((self.tempo_pausa_ate - datetime.now(TZ)).total_seconds())
                return False, f"⏸️ Sistema pausado ({remaining}s)", 0.0
            else:
                self._reativar()

        # 2. Daily stop-loss check
        today = await database.get_today_stats()
        pnl = today.get("pnl", 0.0)
        if pnl <= -abs(self._stop_loss):
            return False, f"🛑 Stop Loss diário atingido (${pnl:.2f})", 0.0

        # 3. Daily stop-gain check
        if pnl >= self._stop_gain:
            return False, f"🎯 Stop Gain diário atingido (+${pnl:.2f})", 0.0

        # 4. Consecutive losses
        perdas = await database.get_consecutive_losses()
        if perdas >= self._max_perdas_pausa:
            self._pausar(1800)
            return False, f"⏸️ Pausa automática: {perdas} perdas consecutivas", 0.0

        # 5. Max concurrent ops
        if self.operacoes_ativas >= self._max_ops_simultaneas:
            return False, f"⚠️ Limite de operações simultâneas ({self.operacoes_ativas})", 0.0

        # 6. Slippage guard
        if slippage_ms > self._max_slippage_ms:
            return False, f"⏱️ Sinal atrasado ({slippage_ms}ms > {self._max_slippage_ms}ms)", 0.0

        # 7. Payout minimum check
        min_payout = int(self._cfg.get("min_payout_percent", 70))
        if payout_pct < min_payout:
            return False, f"📉 Payout insuficiente ({payout_pct:.0f}% < {min_payout}%)", 0.0

        # 8. Calculate amount (Kelly-adjusted)
        amount = await self._kelly_value(payout_pct)
        logger.info(f"✅ RiskManager aprovado — valor=${amount:.2f} payout={payout_pct:.0f}%")
        return True, "Aprovado", amount

    # ─────────────────────────────────────────────────────────
    # STATE MANAGEMENT
    # ─────────────────────────────────────────────────────────

    def registrar_inicio(self):
        self.operacoes_ativas += 1

    def registrar_fim(self):
        if self.operacoes_ativas > 0:
            self.operacoes_ativas -= 1

    def _pausar(self, segundos: int = 1800):
        self.pausado = True
        self.tempo_pausa_ate = datetime.now(TZ) + timedelta(seconds=segundos)
        logger.warning(f"⏸️ RiskManager pausado até {self.tempo_pausa_ate.strftime('%H:%M:%S')}")

    def _reativar(self):
        self.pausado = False
        self.tempo_pausa_ate = None
        logger.info("▶️ RiskManager reativado")

    def forcar_retomada(self):
        self._reativar()

    def forcar_pausa(self, segundos: int = 1800):
        self._pausar(segundos)

    def obter_status(self) -> Dict:
        return {
            "pausado": self.pausado,
            "tempo_pausa_ate": str(self.tempo_pausa_ate) if self.tempo_pausa_ate else None,
            "operacoes_ativas": self.operacoes_ativas,
        }
