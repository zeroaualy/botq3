"""
Watchdog Engine
Monitors system health and auto-recovers
"""
import logging
from typing import Dict
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class WatchdogEngine:
    """
    System watchdog for monitoring and recovery
    
    Monitors:
    - MyIQ connectivity
    - Gemini API failures
    - No-trade anomaly
    - Loop health
    - Excessive errors
    """
    
    def __init__(self):
        self.last_trade_time = None
        self.last_myiq_check = None
        self.gemini_failure_count = 0
        self.error_count = 0
        self.loop_heartbeat = datetime.now(TZ)
        
        # Thresholds
        self.max_no_trade_minutes = 120  # 2 hours
        self.max_gemini_failures = 5
        self.max_errors_per_hour = 20
        self.loop_timeout_seconds = 300  # 5 minutes
    
    def update_heartbeat(self):
        """Update loop heartbeat"""
        self.loop_heartbeat = datetime.now(TZ)
    
    def record_trade(self):
        """Record that a trade occurred"""
        self.last_trade_time = datetime.now(TZ)
    
    def record_myiq_check(self, success: bool):
        """Record MyIQ connectivity check"""
        self.last_myiq_check = {
            "timestamp": datetime.now(TZ),
            "success": success
        }
    
    def record_gemini_failure(self):
        """Record Gemini API failure"""
        self.gemini_failure_count += 1
    
    def record_error(self):
        """Record general error"""
        self.error_count += 1
    
    def check_health(self) -> Dict:
        """
        Check overall system health
        
        Returns:
            Dict with health status and issues
        """
        issues = []
        warnings = []
        status = "HEALTHY"
        
        now = datetime.now(TZ)
        
        # Check loop heartbeat
        heartbeat_age = (now - self.loop_heartbeat).total_seconds()
        if heartbeat_age > self.loop_timeout_seconds:
            issues.append(f"Loop timeout: {int(heartbeat_age)}s since last heartbeat")
            status = "CRITICAL"
        
        # Check no-trade anomaly
        if self.last_trade_time:
            no_trade_minutes = (now - self.last_trade_time).total_seconds() / 60
            if no_trade_minutes > self.max_no_trade_minutes:
                warnings.append(f"No trades for {int(no_trade_minutes)} minutes")
                if status == "HEALTHY":
                    status = "WARNING"
        
        # Check MyIQ connectivity
        if self.last_myiq_check:
            check_age = (now - self.last_myiq_check["timestamp"]).total_seconds()
            if check_age > 300:  # 5 minutes since last check
                warnings.append("MyIQ check stale")
            elif not self.last_myiq_check["success"]:
                issues.append("MyIQ connection failure")
                status = "CRITICAL"
        
        # Check Gemini failures
        if self.gemini_failure_count >= self.max_gemini_failures:
            issues.append(f"Excessive Gemini failures: {self.gemini_failure_count}")
            status = "CRITICAL"
        
        # Check error rate
        if self.error_count >= self.max_errors_per_hour:
            issues.append(f"High error rate: {self.error_count} errors")
            if status == "HEALTHY":
                status = "WARNING"
        
        return {
            "status": status,
            "issues": issues,
            "warnings": warnings,
            "details": {
                "heartbeat_age_seconds": int(heartbeat_age),
                "gemini_failures": self.gemini_failure_count,
                "error_count": self.error_count,
                "last_trade_minutes_ago": int((now - self.last_trade_time).total_seconds() / 60) if self.last_trade_time else None
            }
        }
    
    def reset_counters(self):
        """Reset hourly counters"""
        self.gemini_failure_count = 0
        self.error_count = 0
        logger.info("🔄 Watchdog counters reset")
    
    def get_recovery_action(self) -> Dict:
        """Determine if recovery action needed"""
        health = self.check_health()
        
        if health["status"] == "CRITICAL":
            return {
                "action": "RESTART_REQUIRED",
                "reason": ", ".join(health["issues"]),
                "automated": False  # Requires manual intervention
            }
        elif health["status"] == "WARNING":
            return {
                "action": "MONITOR",
                "reason": ", ".join(health["warnings"]),
                "automated": True
            }
        else:
            return {
                "action": "NONE",
                "reason": "System healthy",
                "automated": True
            }
