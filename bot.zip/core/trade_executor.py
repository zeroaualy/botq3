"""
Executor de trades
Responsável pela execução segura de operações
"""
import logging
import time

logger = logging.getLogger(__name__)


class TradeExecutor:
    """Executor de operações com segurança"""
    
    def __init__(self, iq_client):
        self.iq_client = iq_client
    
    def executar(self, par, direcao, valor, expiracao):
        """
        Executa operação COM SEGURANÇA
        Retorna: (sucesso, order_id)
        """
        # SEGURANÇA CRÍTICA: Garantir PRACTICE
        if not self.iq_client.garantir_practice():
            logger.error("❌ OPERAÇÃO ABORTADA: Falha na verificação PRACTICE")
            return False, None
        
        try:
            # Verificar ativo disponível
            disponivel, par_final = self.iq_client.verificar_ativo_disponivel(par)
            
            if not disponivel:
                logger.error(f"❌ Ativo {par} não disponível")
                return False, None
            
            # Verificar saldo
            saldo = self.iq_client.obter_saldo()
            if saldo < valor:
                logger.error(f"❌ Saldo insuficiente: ${saldo:.2f} < ${valor:.2f}")
                return False, None
            
            # Executar ordem
            action = "call" if direcao.upper() == "CALL" else "put"
            
            logger.info(f"📊 Executando: {par_final} {action.upper()} ${valor} {expiracao}s")
            logger.info(f"🏦 Conta: PRACTICE | Saldo: ${saldo:.2f}")
            
            status, order_id = self.iq_client.iq.buy(valor, par_final, action, expiracao)
            
            if status:
                logger.info(f"✅ Ordem executada! ID: {order_id}")
                return True, order_id
            else:
                logger.error(f"❌ Falha ao executar ordem")
                return False, None
                
        except Exception as e:
            logger.error(f"❌ Erro ao executar operação: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False, None
    
    def verificar_resultado(self, order_id, aguardar_segundos=3):
        """
        Verifica resultado da operação
        Retorna: (resultado_str, valor_lucro)
        """
        try:
            time.sleep(aguardar_segundos)
            
            resultado = self.iq_client.iq.check_win_v4(order_id)
            
            logger.info(f"📊 Resultado bruto: {resultado}")
            
            if resultado is None:
                logger.warning("⚠️ Resultado não disponível")
                return "PROCESSANDO", 0
            
            if resultado > 0:
                logger.info(f"✅ WIN - Lucro: ${resultado:.2f}")
                return "WIN", resultado
            elif resultado < 0:
                logger.info(f"❌ LOSS - Perda: ${abs(resultado):.2f}")
                return "LOSS", abs(resultado)
            else:
                logger.info("⚪ EMPATE")
                return "EMPATE", 0
                
        except Exception as e:
            logger.error(f"❌ Erro ao verificar resultado: {e}")
            return "ERRO", 0
