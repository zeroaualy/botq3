"""
Bot Telegram
Interface de controle e governança
"""
import asyncio
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)
import logging

logger = logging.getLogger(__name__)


class TelegramBot:
    """Bot Telegram com controle de governança"""
    
    def __init__(self, config, stats, runtime, signal_parser, 
                 trade_executor, ia_guard, permissoes):
        self.config = config
        self.stats = stats
        self.runtime = runtime
        self.signal_parser = signal_parser
        self.trade_executor = trade_executor
        self.ia_guard = ia_guard
        self.permissoes = permissoes
        self.iq_client = None
        self.auto_trader = None
        
    def set_iq_client(self, iq_client):
        """Define cliente IQ Option"""
        self.iq_client = iq_client
    
    def set_auto_trader(self, auto_trader):
        """Define instância do AutoTrader"""
        self.auto_trader = auto_trader
    
    # ======================================
    # MENUS
    # ======================================
    def menu_principal(self):
        from state import runtime
        
        if runtime.auto_trader and runtime.auto_trader.is_ativo():
            auto_status = "🟢 ATIVO"
            auto_data = "toggle_auto_off"
        else:
            auto_status = "⚪ PAUSADO"
            auto_data = "toggle_auto_on"
        
        if runtime.auto_signal_generator and runtime.auto_signal_generator.active:
            automacao_status = "🟢 ATIVADO"
            automacao_data = "toggle_automacao_off"
        else:
            automacao_status = "⚪ DESATIVADO"
            automacao_data = "toggle_automacao_on"
        
        keyboard = [
            [
                InlineKeyboardButton("⚙️ Configurações", callback_data="config"),
                InlineKeyboardButton("📊 Estatísticas", callback_data="stats")
            ],
            [
                InlineKeyboardButton("📥 Sinais", callback_data="sinais"),
                InlineKeyboardButton("🤖 IA & Governança", callback_data="ia_menu")
            ],
            [
                InlineKeyboardButton(f"🔄 Automático: {auto_status}", callback_data=auto_data),
            ],
            [
                InlineKeyboardButton(f"🧠 Automação: {automacao_status}", callback_data=automacao_data),
            ],
            [
                InlineKeyboardButton("💰 Ver Saldo", callback_data="ver_saldo"),
            ],
            [
                InlineKeyboardButton("▶️ Iniciar", callback_data="start_bot"),
                InlineKeyboardButton("⏸️ Pausar", callback_data="pause_bot")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def menu_config(self):
        auto = "✅" if self.config["operar_automatico"] else "❌"
        martingale = "✅" if self.config["martingale"] else "❌"
        
        keyboard = [
            [InlineKeyboardButton("━━━ OPERAÇÃO ━━━", callback_data="info_config")],
            [InlineKeyboardButton(f"{auto} Operação Automática", callback_data="toggle_auto")],
            [InlineKeyboardButton(f"{martingale} Martingale", callback_data="toggle_martingale")],
            [InlineKeyboardButton("━━━ VALORES ━━━", callback_data="info_valores")],
            [InlineKeyboardButton(f"💰 Entrada: ${self.config['valor_entrada']}", callback_data="edit_valor_entrada")],
            [InlineKeyboardButton(f"🛑 Stop Loss: ${self.config['stop_loss']}", callback_data="edit_stop_loss")],
            [InlineKeyboardButton(f"🎯 Stop Gain: ${self.config['stop_gain']}", callback_data="edit_stop_gain")],
            [InlineKeyboardButton("❓ Sobre Configurações", callback_data="explicar_config")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def menu_ia_governanca(self):
        validar = "✅" if self.config["ia_validar_contexto"] else "❌"
        
        keyboard = [
            [InlineKeyboardButton("━━━ IA GUARD ━━━", callback_data="info_validacao")],
            [InlineKeyboardButton(f"{validar} Validar Contexto", callback_data="toggle_ia_validar")],
            [InlineKeyboardButton("❓ Sobre Validação", callback_data="info_sobre_validacao")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def menu_sinais(self):
        captura = "✅ ATIVA" if self.runtime.captura_sinais_ativa else "❌ PAUSADA"
        qtd_sinais = self.runtime.quantidade_sinais()
        
        keyboard = [
            [InlineKeyboardButton(f"📡 Captura: {captura}", callback_data="toggle_captura")],
            [InlineKeyboardButton(f"📋 Agendados ({qtd_sinais})", callback_data="listar_sinais")],
            [InlineKeyboardButton("🗑️ Limpar Fila", callback_data="limpar_sinais")],
            [InlineKeyboardButton("📝 Formatos Aceitos", callback_data="formatos_sinal")],
            [InlineKeyboardButton("💡 Como Enviar", callback_data="tutorial_sinais")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    # ======================================
    # HANDLERS
    # ======================================
    async def start(self, update: Update, context):
        status_iq = "✅ Conectado" if self.iq_client and self.iq_client.esta_conectado() else "❌ Desconectado"
        status_ia = "✅ Ativa" if not self.ia_guard.desabilitado() else "❌ Inativa"
        
        saldo_msg = ""
        if self.iq_client and self.iq_client.esta_conectado():
            try:
                saldo = await self.iq_client.obter_saldo()
                tipo = self.iq_client.obter_tipo_conta()
                saldo_msg = f"└ 💰 {tipo}: ${saldo:.2f}"
            except:
                pass
        
        mensagem = f"""🤖 <b>Bot Q3 Beta</b>
━━━━━━━━━━━━━━━━━━
📡 IQ Option: {status_iq}
🧠 IA Guard: {status_ia}
📥 Sinais: {self.runtime.quantidade_sinais()}
{saldo_msg}
━━━━━━━━━━━━━━━━━━
<b>Formatos aceitos:</b>
<code>M5 EURUSD CALL 14:30</code>
<code>EURUSD PUT</code>
<code>ATIVO: EURUSD
DIREÇÃO: CALL
TIMEFRAME: 1M
HORÁRIO: 14:30</code>
━━━━━━━━━━━━━━━━━━
👇 Use o menu abaixo"""
        
        await update.message.reply_text(
            mensagem,
            parse_mode="HTML",
            reply_markup=self.menu_principal()
        )
    
    async def button_handler(self, update: Update, context):
        """Handler de botões"""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        
        if data == "menu":
            await query.edit_message_text(
                "🤖 <b>Menu Principal</b>",
                parse_mode="HTML",
                reply_markup=self.menu_principal()
            )
        
        elif data == "ver_saldo":
            if not self.iq_client or not self.iq_client.esta_conectado():
                await query.edit_message_text(
                    "❌ Sem conexão com IQ Option",
                    reply_markup=self.menu_principal()
                )
                return
            
            saldo = await self.iq_client.obter_saldo()
            tipo = self.iq_client.obter_tipo_conta()
            
            await query.edit_message_text(
                f"💰 <b>Conta</b>\n\n"
                f"Tipo: <b>{tipo}</b>\n"
                f"Saldo: <b>${saldo:.2f}</b>\n\n"
                f"{'✅ PRACTICE' if tipo == 'PRACTICE' else '⚠️ REAL — cuidado!'}",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("◀️ Voltar", callback_data="menu")
                ]])
            )
        
        elif data == "config":
            await query.edit_message_text(
                "⚙️ <b>Configurações</b>",
                parse_mode="HTML",
                reply_markup=self.menu_config()
            )
        
        elif data == "toggle_auto":
            self.config["operar_automatico"] = not self.config["operar_automatico"]
            status = "✅ ATIVADA" if self.config["operar_automatico"] else "❌ DESATIVADA"
            await query.edit_message_text(
                f"🤖 <b>Operação Automática: {status}</b>",
                parse_mode="HTML",
                reply_markup=self.menu_config()
            )
        
        elif data == "toggle_martingale":
            self.config["martingale"] = not self.config["martingale"]
            status = "✅ ATIVADO" if self.config["martingale"] else "❌ DESATIVADO"
            aviso = "\n⚠️ Dobra o valor após perdas." if self.config["martingale"] else ""
            await query.edit_message_text(
                f"📊 <b>Martingale: {status}</b>{aviso}",
                parse_mode="HTML",
                reply_markup=self.menu_config()
            )
        
        elif data == "edit_valor_entrada":
            from state import runtime
            user_id = query.from_user.id
            runtime.editing_state[user_id] = "valor_entrada"
            
            await query.edit_message_text(
                f"💰 <b>Valor de Entrada</b>\n\n"
                f"Atual: <b>${self.config['valor_entrada']}</b>\n\n"
                f"Digite o novo valor:\n<code>10</code> ou <code>10.50</code>",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("❌ Cancelar", callback_data="config")
                ]])
            )
        
        elif data == "edit_stop_loss":
            from state import runtime
            user_id = query.from_user.id
            runtime.editing_state[user_id] = "stop_loss"
            
            await query.edit_message_text(
                f"🛑 <b>Stop Loss</b>\n\n"
                f"Atual: <b>${self.config['stop_loss']}</b>\n\n"
                f"Digite o limite de perda diária:",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("❌ Cancelar", callback_data="config")
                ]])
            )
        
        elif data == "edit_stop_gain":
            from state import runtime
            user_id = query.from_user.id
            runtime.editing_state[user_id] = "stop_gain"
            
            await query.edit_message_text(
                f"🎯 <b>Stop Gain</b>\n\n"
                f"Atual: <b>${self.config['stop_gain']}</b>\n\n"
                f"Digite a meta de lucro diária:",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("❌ Cancelar", callback_data="config")
                ]])
            )
        
        elif data == "explicar_config":
            await query.edit_message_text(
                "📚 <b>Configurações</b>\n\n"
                "<b>💰 Entrada</b> — Valor por operação.\n\n"
                "<b>🛑 Stop Loss</b> — Perda máxima diária. Bot pausa ao atingir.\n\n"
                "<b>🎯 Stop Gain</b> — Meta de lucro diária. Bot pausa ao atingir.\n\n"
                "<b>🤖 Automático</b> — Executa sinais sem confirmação manual.\n\n"
                "<b>📊 Martingale</b> — Dobra valor após perdas. ⚠️ Alto risco.",
                parse_mode="HTML",
                reply_markup=self.menu_config()
            )
        
        elif data == "ia_menu":
            await query.edit_message_text(
                "🧠 <b>IA Guard</b>\n\n"
                "Valida o contexto operacional antes de cada execução.\n"
                "Decisões: <b>EXECUTAR</b> · <b>IGNORAR</b> · <b>RISCO</b>",
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        elif data == "toggle_ia_validar":
            self.config["ia_validar_contexto"] = not self.config["ia_validar_contexto"]
            status = "ativada" if self.config["ia_validar_contexto"] else "desativada"
            await query.edit_message_text(
                f"✅ Validação de contexto {status}",
                reply_markup=self.menu_ia_governanca()
            )

        elif data == "info_sobre_validacao":
            await query.edit_message_text(
                "📚 <b>IA Guard — Validação de Contexto</b>\n\n"
                "Verifica condições antes de cada operação:\n"
                "• Ativos disponíveis\n"
                "• Atraso de execução\n"
                "• Condições operacionais\n\n"
                "<b>Decisões possíveis:</b>\n"
                "✅ EXECUTAR — Contexto OK\n"
                "⚠️ IGNORAR — Condições inadequadas\n"
                "🔴 RISCO — Problema crítico\n\n"
                "⚠️ Não analisa tendências nem prevê mercado.",
                parse_mode="HTML",
                reply_markup=self.menu_ia_governanca()
            )
        
        elif data == "sinais":
            await query.edit_message_text(
                f"📡 <b>Sinais</b> — {self.runtime.quantidade_sinais()} agendado(s)",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "toggle_captura":
            self.runtime.captura_sinais_ativa = not self.runtime.captura_sinais_ativa
            status = "✅ ATIVA" if self.runtime.captura_sinais_ativa else "❌ PAUSADA"
            await query.edit_message_text(
                f"📡 <b>Captura: {status}</b>",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "listar_sinais":
            from zoneinfo import ZoneInfo
            FUSO_SP = ZoneInfo("America/Sao_Paulo")
            
            sinais = self.runtime.obter_sinais_pendentes()
            if not sinais:
                await query.edit_message_text(
                    "📭 <b>Nenhum sinal agendado</b>\n\nEnvie um sinal para agendar.",
                    parse_mode="HTML",
                    reply_markup=self.menu_sinais()
                )
                return
            
            agora_sp = datetime.now(FUSO_SP)
            lista = f"📋 <b>Sinais Agendados</b> · {agora_sp.strftime('%H:%M:%S')}\n\n"
            
            for i, s in enumerate(sinais[:10], 1):
                if s['horario'].tzinfo is None:
                    horario_sinal = s['horario'].replace(tzinfo=FUSO_SP)
                else:
                    horario_sinal = s['horario'].astimezone(FUSO_SP)
                
                tempo_restante = (horario_sinal - agora_sp).total_seconds()
                
                if tempo_restante < 0:
                    tempo_str = "⚠️ ATRASADO"
                elif tempo_restante < 60:
                    tempo_str = f"{int(tempo_restante)}s"
                elif tempo_restante < 3600:
                    tempo_str = f"{int(tempo_restante/60)}min"
                else:
                    tempo_str = f"{int(tempo_restante/3600)}h{int((tempo_restante%3600)/60)}min"
                
                lista += f"{i}. <b>{s['par']}</b> {s['direcao']} · {horario_sinal.strftime('%H:%M')} <code>({tempo_str})</code>\n"
            
            if len(sinais) > 10:
                lista += f"\n+{len(sinais) - 10} sinais"
            
            await query.edit_message_text(
                lista,
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "limpar_sinais":
            qtd = self.runtime.quantidade_sinais()
            self.runtime.limpar_sinais()
            await query.edit_message_text(
                f"🗑️ <b>{qtd} sinal(is) removido(s)</b>\nFila vazia.",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "formatos_sinal":
            await query.edit_message_text(
                "📝 <b>Formatos Aceitos</b>\n\n"
                "<b>Estruturado:</b>\n"
                "<code>ATIVO: EURUSD\n"
                "DIREÇÃO: CALL\n"
                "TIMEFRAME: 1M\n"
                "HORÁRIO: 14:30</code>\n\n"
                "<b>Compacto:</b>\n"
                "<code>M5 EURUSD CALL 14:30</code>\n\n"
                "<b>Imediato:</b>\n"
                "<code>M5 EURUSD CALL</code>\n\n"
                "CALL = compra · PUT = venda\n"
                "M1, M5, M15 = timeframe",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "tutorial_sinais":
            await query.edit_message_text(
                "💡 <b>Como Enviar Sinais</b>\n\n"
                "1️⃣ Ative a captura: <b>Sinais → Captura</b>\n"
                "2️⃣ Envie o sinal no chat\n"
                "3️⃣ Aguarde confirmação de agendamento\n"
                "4️⃣ Bot executa no horário programado\n\n"
                "<b>Exemplos:</b>\n"
                "<code>M5 EURUSD CALL 14:30</code>\n"
                "<code>GBPUSD PUT</code>",
                parse_mode="HTML",
                reply_markup=self.menu_sinais()
            )
        
        elif data == "stats":
            from state.stats import obter_winrate
            winrate = obter_winrate()
            
            empate_rate = 0
            if self.stats['total_operacoes'] > 0:
                empate_rate = (self.stats['empates'] / self.stats['total_operacoes']) * 100
            
            lucro_medio = 0
            if self.stats['total_operacoes'] > 0:
                lucro_medio = self.stats['lucro_dia'] / self.stats['total_operacoes']
            
            if self.stats['lucro_dia'] > 0:
                status_emoji = "📈"
            elif self.stats['lucro_dia'] < 0:
                status_emoji = "📉"
            else:
                status_emoji = "➖"
            
            if winrate >= 60:
                analise = "✅ Win rate saudável."
            elif winrate >= 45:
                analise = "📊 Desempenho neutro."
            else:
                analise = "⚠️ Win rate abaixo do ideal."
            
            if self.stats["lucro_dia"] < 0:
                limite = f"🛑 Stop Loss: ${abs(self.stats['lucro_dia']):.2f} / ${self.config['stop_loss']:.2f}"
            elif self.stats["lucro_dia"] > 0:
                limite = f"🎯 Stop Gain: ${self.stats['lucro_dia']:.2f} / ${self.config['stop_gain']:.2f}"
            else:
                limite = ""
            
            mensagem = (
                f"📊 <b>Performance</b>\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"🎯 Total: <b>{self.stats['total_operacoes']}</b>  "
                f"✅ {self.stats['vitorias']}  "
                f"❌ {self.stats['derrotas']}  "
                f"⚪ {self.stats['empates']}\n\n"
                f"📈 Win Rate: <b>{winrate:.1f}%</b>  |  ⚪ {empate_rate:.1f}%\n"
                f"{status_emoji} P&L: <b>${self.stats['lucro_dia']:.2f}</b>  |  Média: ${lucro_medio:.2f}\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"🧠 <b>IA Guard</b>\n"
                f"✅ {self.stats['ia_decisoes']['executar']}  "
                f"❌ {self.stats['ia_decisoes']['ignorar']}  "
                f"⚠️ {self.stats['ia_decisoes']['risco']}\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"{analise}"
                f"{chr(10) + limite if limite else ''}"
            )
            
            await query.edit_message_text(
                mensagem,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🔄 Atualizar", callback_data="stats"),
                    InlineKeyboardButton("◀️ Voltar", callback_data="menu")
                ]])
            )
        
        elif data == "start_bot":
            self.config["operar_automatico"] = True
            await query.edit_message_text(
                "✅ Bot iniciado.",
                reply_markup=self.menu_principal()
            )
        
        elif data == "pause_bot":
            self.config["operar_automatico"] = False
            await query.edit_message_text(
                "⏸️ Bot pausado.",
                reply_markup=self.menu_principal()
            )
        
        elif data == "toggle_auto_on":
            from state import runtime
            
            if not runtime.auto_trader:
                await query.answer("❌ AutoTrader não inicializado", show_alert=True)
                return
            
            if not self.iq_client or not self.iq_client.esta_conectado():
                await query.answer("❌ IQ Option não conectado.", show_alert=True)
                return
            
            sucesso = await runtime.auto_trader.ativar(query.message.chat_id)
            
            if sucesso:
                runtime.modo_automatico_ativo = True
                await query.edit_message_text(
                    "🟢 <b>Modo Automático ATIVADO</b>\n\n"
                    "✅ Captura de sinais: <b>ATIVA</b>\n"
                    "✅ Execução automática: <b>ATIVA</b>\n"
                    "✅ Conta: <b>PRACTICE</b>\n\n"
                    "🔔 Você receberá notificações de sinais, execuções e resultados.",
                    parse_mode="HTML",
                    reply_markup=self.menu_principal()
                )
                logger.info(f"✅ Modo automático ativado pelo usuário {query.from_user.id}")
            else:
                await query.answer("❌ Erro ao ativar modo automático", show_alert=True)
        
        elif data == "toggle_auto_off":
            from state import runtime
            
            if not runtime.auto_trader:
                await query.answer("❌ AutoTrader não inicializado", show_alert=True)
                return
            
            sucesso = await runtime.auto_trader.desativar()
            
            if sucesso:
                runtime.modo_automatico_ativo = False
                await query.edit_message_text(
                    "⚪ <b>Modo Automático DESATIVADO</b>\n\n"
                    "🛑 Captura e execução pausadas.\n"
                    "📊 Estatísticas da sessão salvas.",
                    parse_mode="HTML",
                    reply_markup=self.menu_principal()
                )
                logger.info(f"🛑 Modo automático desativado pelo usuário {query.from_user.id}")
            else:
                await query.answer("❌ Erro ao desativar modo automático", show_alert=True)
        
        elif data == "toggle_automacao_on":
            from state import runtime
            
            if not runtime.auto_signal_generator:
                await query.answer("❌ AutoSignalGenerator não inicializado", show_alert=True)
                return
            
            if not self.iq_client or not self.iq_client.esta_conectado():
                await query.answer("❌ IQ Option não conectado.", show_alert=True)
                return
            
            if not runtime.modo_automatico_ativo:
                await query.answer(
                    "⚠️ Ative o Modo Automático primeiro.",
                    show_alert=True
                )
                return
            
            sucesso = await runtime.auto_signal_generator.start()
            
            if sucesso:
                runtime.automacao_sinais_ativa = True
                await query.edit_message_text(
                    "🤖 <b>Geração Automática ATIVADA</b>\n\n"
                    "✅ Pipeline: <b>MyIQ → Gemini AI → Fila</b>\n"
                    "✅ Conta: <b>PRACTICE</b>\n\n"
                    "🔍 Sinais manuais têm prioridade.\n"
                    "⚙️ IA Guard · Risk Manager ativos.",
                    parse_mode="HTML",
                    reply_markup=self.menu_principal()
                )
                logger.info(f"🤖 Geração Automática ativada pelo usuário {query.from_user.id}")
            else:
                await query.answer("❌ Erro ao ativar geração automática", show_alert=True)
        
        elif data == "toggle_automacao_off":
            from state import runtime
            
            if not runtime.auto_signal_generator:
                await query.answer("❌ AutoSignalGenerator não inicializado", show_alert=True)
                return
            
            sucesso = await runtime.auto_signal_generator.stop()
            
            if sucesso:
                runtime.automacao_sinais_ativa = False
                await query.edit_message_text(
                    "⚪ <b>Geração Automática DESATIVADA</b>\n\n"
                    "🛑 Pipeline pausado.\n"
                    "✅ Sinais manuais continuam funcionando.",
                    parse_mode="HTML",
                    reply_markup=self.menu_principal()
                )
                logger.info(f"⛔ Geração Automática desativada pelo usuário {query.from_user.id}")
            else:
                await query.answer("❌ Erro ao desativar geração automática", show_alert=True)
    
    async def mensagem(self, update: Update, context):
        """
        Handler de mensagens de texto
        Processa sinais E edição de valores
        SUPORTA MÚLTIPLOS SINAIS SIMULTANEAMENTE
        """
        from state import runtime
        from datetime import datetime
        from zoneinfo import ZoneInfo
        
        user_id = update.message.from_user.id
        texto = update.message.text
        
        if user_id in runtime.editing_state and runtime.editing_state[user_id]:
            campo = runtime.editing_state[user_id]
            
            try:
                valor = float(texto.replace(',', '.').strip())
                
                if valor <= 0:
                    await update.message.reply_text("❌ Valor deve ser maior que zero.")
                    return
                
                if valor > 10000:
                    await update.message.reply_text("❌ Valor muito alto. Máximo: $10.000.")
                    return
                
                if campo == "valor_entrada":
                    self.config["valor_entrada"] = valor
                    nome_campo = "Valor de Entrada"
                    emoji = "💰"
                elif campo == "stop_loss":
                    self.config["stop_loss"] = valor
                    nome_campo = "Stop Loss"
                    emoji = "🛑"
                elif campo == "stop_gain":
                    self.config["stop_gain"] = valor
                    nome_campo = "Stop Gain"
                    emoji = "🎯"
                else:
                    nome_campo = "Valor"
                    emoji = "✅"
                
                runtime.editing_state[user_id] = None
                
                await update.message.reply_text(
                    f"{emoji} <b>{nome_campo}:</b> ${valor:.2f}",
                    parse_mode="HTML"
                )
                return
                
            except ValueError:
                await update.message.reply_text(
                    "❌ Valor inválido. Use apenas números: <code>5</code> ou <code>10.50</code>",
                    parse_mode="HTML"
                )
                return
        
        sinais = self.signal_parser.parsear_sinal(texto)
        
        if not sinais:
            return
        
        FUSO_SP = ZoneInfo("America/Sao_Paulo")
        
        sinais_agendados_count = 0
        sinais_imediatos_count = 0
        
        for sinal in sinais:
            if sinal["imediato"] and self.config["operar_automatico"]:
                sinais_imediatos_count += 1
                await update.message.reply_text(
                    f"⚡ <b>Sinal Imediato</b>\n"
                    f"📊 {sinal['par']} {sinal['direcao']} · {sinal['tempo_expiracao']}s",
                    parse_mode="HTML"
                )
            
            elif not sinal["imediato"]:
                if self.runtime.captura_sinais_ativa or self.config["operar_automatico"]:
                    self.runtime.adicionar_sinal(sinal)
                    sinais_agendados_count += 1
                    
                    agora_sp = datetime.now(FUSO_SP)
                    
                    if sinal['horario'].tzinfo is None:
                        horario_sinal = sinal['horario'].replace(tzinfo=FUSO_SP)
                    else:
                        horario_sinal = sinal['horario'].astimezone(FUSO_SP)
                    
                    tempo_restante = (horario_sinal - agora_sp).total_seconds()
                    
                    if tempo_restante < 0:
                        tempo_str = "ERRO: horário já passou!"
                        logger.warning(f"⚠️ Sinal com horário passado: {horario_sinal}")
                    elif tempo_restante < 60:
                        tempo_str = f"{int(tempo_restante)}s"
                    elif tempo_restante < 3600:
                        minutos = int(tempo_restante / 60)
                        segundos = int(tempo_restante % 60)
                        tempo_str = f"{minutos}min {segundos}s"
                    else:
                        horas = int(tempo_restante / 3600)
                        minutos = int((tempo_restante % 3600) / 60)
                        tempo_str = f"{horas}h {minutos}min"
        
        if sinais_agendados_count > 0:
            ultimo_sinal = sinais[-1] if not sinais[-1]["imediato"] else None
            
            if ultimo_sinal:
                agora_sp = datetime.now(FUSO_SP)
                if ultimo_sinal['horario'].tzinfo is None:
                    horario_sinal = ultimo_sinal['horario'].replace(tzinfo=FUSO_SP)
                else:
                    horario_sinal = ultimo_sinal['horario'].astimezone(FUSO_SP)
                
                tempo_restante = (horario_sinal - agora_sp).total_seconds()
                
                if tempo_restante < 60:
                    tempo_str = f"{int(tempo_restante)}s"
                elif tempo_restante < 3600:
                    minutos = int(tempo_restante / 60)
                    segundos = int(tempo_restante % 60)
                    tempo_str = f"{minutos}min {segundos}s"
                else:
                    horas = int(tempo_restante / 3600)
                    minutos = int((tempo_restante % 3600) / 60)
                    tempo_str = f"{horas}h {minutos}min"
                
                if sinais_agendados_count == 1:
                    mensagem = (
                        f"✅ <b>Sinal Agendado</b>\n"
                        f"━━━━━━━━━━━━━━━━━━\n"
                        f"📊 {ultimo_sinal['par']} · {ultimo_sinal['direcao']}\n"
                        f"🕐 {horario_sinal.strftime('%H:%M:%S')} · ⏳ {tempo_str}\n"
                        f"⏱️ Exp: {ultimo_sinal['tempo_expiracao']}s"
                    )
                else:
                    mensagem = (
                        f"✅ <b>{sinais_agendados_count} Sinais Agendados</b>\n"
                        f"📋 Total na fila: <b>{self.runtime.quantidade_sinais()}</b>\n\n"
                        f"Último: {ultimo_sinal['par']} {ultimo_sinal['direcao']} "
                        f"· {horario_sinal.strftime('%H:%M')} ({tempo_str})"
                    )
                
                await update.message.reply_text(mensagem, parse_mode="HTML")
