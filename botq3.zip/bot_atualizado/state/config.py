"""
Configurações do bot
Inclui flags de PERMISSÃO (para governança) que NÃO alteram comportamento real
"""

# ======================================
# CREDENCIAIS (NÃO ALTERAR)
# ======================================
TOKEN = "8287743466:AAFk9v4pwzIU7T70W9nuQWbAytmfAueXE6g"
GRUPO_ID = -1002650727256
GROQ_API_KEY = "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"

EMAIL = "borita5094@codgal.com"
SENHA = "LucasPrimos"

# ======================================
# CONFIGURAÇÕES OPERACIONAIS
# ======================================
CONFIG = {
    # Operação
    "ativos": ["EURUSD", "GBPUSD", "USDJPY"],
    "timeframe": 60,
    "operar_automatico": False,
    "valor_entrada": 100.0,
    "martingale": False,
    
    # Proteção
    "stop_loss": 20.0,
    "stop_gain": 50.0,
    
    # IA (validação de contexto/risco)
    "ia_validar_contexto": True,
    
    # Agendamento
    "tolerancia_agendamento_ms": 3000,  # 3 segundos
    
    # Automação de Sinais
    "automacao_sinais_habilitada": True,  # Permite usar a funcionalidade
    "automacao_confianca_minima": 65,    # Confiança mínima para gerar sinais
    "automacao_intervalo_analise": 30,   # Segundos entre análises
    "automacao_max_sinais_hora": 10,     # Limite de sinais por hora
}

# ======================================
# PERMISSÕES DE GOVERNANÇA
# CRÍTICO: Estas flags NÃO habilitam funcionalidade real
# Servem APENAS para auditoria e transparência
# ======================================
PERMISSOES = {
    # Flag visual - IA NÃO cria estratégia mesmo se True
    "ia_pode_criar_estrategia": False,
    
    # Flag visual - IA NÃO prevê mercado mesmo se True
    "ia_pode_prever_mercado": False,
    
    # Flag visual - IA NÃO decide direção mesmo se True
    "ia_pode_decidir_direcao": False,
}

# Mensagem exibida quando permissão é alterada
AVISO_PERMISSAO = """
⚠️ <b>AVISO IMPORTANTE</b>

Esta permissão foi alterada apenas como <b>FLAG DE GOVERNANÇA</b>.

O comportamento REAL do bot permanece inalterado:
• IA NÃO cria estratégias
• IA NÃO prevê mercado
• IA NÃO decide CALL ou PUT
• IA APENAS valida contexto e risco

Esta flag serve para:
✓ Auditoria
✓ Transparência
✓ Trava explícita de poder
"""
