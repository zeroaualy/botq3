"""
IQ Option Playwright Client
Executa trades REAIS via automação de navegador
"""
import asyncio
import logging
import os
import re
from datetime import datetime
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeout

logger = logging.getLogger(__name__)


class IQPlaywrightClient:
    """Cliente IQ Option com automação real de navegador"""
    
    def __init__(self, email, senha):
        self.email = email
        self.senha = senha
        self.playwright = None
        self.browser = None
        self.context = None
        self.page = None
        self.esta_logado = False
        self.saldo_atual = 0.0
        self.tipo_conta_atual = "DESCONECTADO"
        
    async def iniciar(self, headless=True):
        """Inicia navegador e faz login"""
        try:
            logger.info("🌐 Iniciando Playwright...")
            self.playwright = await async_playwright().start()
            
            # Configurações para VPS Ubuntu
            self.browser = await self.playwright.chromium.launch(
                headless=headless,
                args=[
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-dev-shm-usage',
                    '--disable-accelerated-2d-canvas',
                    '--no-first-run',
                    '--no-zygote',
                    '--disable-gpu'
                ]
            )
            
            # Contexto com user agent real
            self.context = await self.browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            )
            
            self.page = await self.context.new_page()
            
            # Timeout padrão
            self.page.set_default_timeout(30000)
            
            logger.info("✅ Navegador iniciado")
            
            # Fazer login
            return await self._fazer_login()
            
        except Exception as e:
            logger.error(f"❌ Erro ao iniciar navegador: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False
    
    async def _fazer_login(self, max_tentativas=3):
        """Realiza login na IQ Option"""
        for tentativa in range(max_tentativas):
            try:
                logger.info(f"🔐 Tentativa de login {tentativa + 1}/{max_tentativas}...")
                
                # Acessar página de login
                await self.page.goto('https://iqoption.com/pt/login', wait_until='networkidle')
                await asyncio.sleep(2)
                
                # Aguardar formulário de login
                await self.page.wait_for_selector('input[name="email"], input[type="email"]', timeout=10000)
                
                # Preencher email
                logger.info("📧 Preenchendo email...")
                email_input = await self.page.query_selector('input[name="email"], input[type="email"]')
                if email_input:
                    await email_input.fill(self.email)
                    await asyncio.sleep(0.5)
                
                # Preencher senha
                logger.info("🔑 Preenchendo senha...")
                senha_input = await self.page.query_selector('input[name="password"], input[type="password"]')
                if senha_input:
                    await senha_input.fill(self.senha)
                    await asyncio.sleep(0.5)
                
                # Clicar no botão de login
                logger.info("👆 Clicando em login...")
                
                # Tentar diferentes seletores de botão
                botao_login = None
                seletores = [
                    'button[type="submit"]',
                    'button:has-text("Entrar")',
                    'button:has-text("Login")',
                    'button.button--primary'
                ]
                
                for seletor in seletores:
                    try:
                        botao_login = await self.page.query_selector(seletor)
                        if botao_login:
                            break
                    except:
                        continue
                
                if botao_login:
                    await botao_login.click()
                else:
                    # Fallback: pressionar Enter
                    await self.page.keyboard.press('Enter')
                
                # Aguardar redirecionamento
                logger.info("⏳ Aguardando autenticação...")
                await asyncio.sleep(5)
                
                # Verificar se logou com sucesso
                # URL após login geralmente é /traderoom ou contém 'trade'
                url_atual = self.page.url
                logger.info(f"📍 URL atual: {url_atual}")
                
                if 'trade' in url_atual.lower() or 'room' in url_atual.lower():
                    logger.info("✅ Login bem-sucedido!")
                    self.esta_logado = True
                    
                    # Aguardar carregamento completo da plataforma
                    await asyncio.sleep(5)
                    
                    # Garantir conta PRACTICE
                    await self._garantir_practice()
                    
                    return True
                else:
                    # Verificar se há mensagem de erro
                    erro = await self._verificar_erro_login()
                    if erro:
                        logger.error(f"❌ Erro de login: {erro}")
                    else:
                        logger.warning(f"⚠️ Login incompleto - URL: {url_atual}")
                
                await asyncio.sleep(3)
                
            except Exception as e:
                logger.error(f"❌ Erro na tentativa {tentativa + 1}: {e}")
                import traceback
                logger.error(traceback.format_exc())
                await asyncio.sleep(5)
        
        return False
    
    async def _verificar_erro_login(self):
        """Verifica mensagens de erro na tela de login"""
        try:
            # Procurar por elementos de erro comuns
            seletores_erro = [
                '.error-message',
                '.alert-danger',
                '[class*="error"]',
                '[class*="invalid"]'
            ]
            
            for seletor in seletores_erro:
                try:
                    elemento = await self.page.query_selector(seletor)
                    if elemento:
                        texto = await elemento.text_content()
                        if texto and len(texto.strip()) > 0:
                            return texto.strip()
                except:
                    continue
            
            return None
        except:
            return None
    
    async def _garantir_practice(self):
        """Garante que está na conta PRACTICE"""
        try:
            logger.info("🏦 Verificando tipo de conta...")
            
            # Aguardar interface carregar
            await asyncio.sleep(3)
            
            # Procurar seletor de conta (pode variar)
            # Seletores possíveis para o botão/dropdown de conta
            seletores_conta = [
                '[class*="account"]',
                '[class*="balance"]',
                'button:has-text("PRACTICE")',
                'button:has-text("REAL")',
                '[data-test*="account"]'
            ]
            
            # Tentar identificar tipo de conta atual
            for seletor in seletores_conta:
                try:
                    elementos = await self.page.query_selector_all(seletor)
                    for elem in elementos:
                        texto = await elem.text_content()
                        if texto and ('PRACTICE' in texto.upper() or 'REAL' in texto.upper()):
                            logger.info(f"📊 Conta detectada: {texto}")
                            
                            if 'REAL' in texto.upper():
                                logger.warning("⚠️ Conta REAL detectada! Mudando para PRACTICE...")
                                await elem.click()
                                await asyncio.sleep(2)
                                
                                # Procurar opção PRACTICE no dropdown
                                practice_option = await self.page.query_selector('button:has-text("PRACTICE"), [class*="practice"]')
                                if practice_option:
                                    await practice_option.click()
                                    await asyncio.sleep(2)
                                    logger.info("✅ Mudado para PRACTICE")
                            
                            self.tipo_conta_atual = "PRACTICE"
                            break
                except:
                    continue
            
            # Obter saldo
            await self._atualizar_saldo()
            
            logger.info(f"✅ Conta PRACTICE confirmada - Saldo: ${self.saldo_atual:.2f}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Erro ao garantir PRACTICE: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False
    
    async def _atualizar_saldo(self):
        """Atualiza saldo atual"""
        try:
            # Procurar elemento de saldo
            seletores_saldo = [
                '[class*="balance-value"]',
                '[class*="balance-info"]',
                '[data-test*="balance"]',
                '[class*="account-balance"]'
            ]
            
            for seletor in seletores_saldo:
                try:
                    elemento = await self.page.query_selector(seletor)
                    if elemento:
                        texto = await elemento.text_content()
                        # Extrair números do texto
                        numeros = re.findall(r'[\d,\.]+', texto.replace(',', ''))
                        if numeros:
                            self.saldo_atual = float(numeros[0])
                            logger.info(f"💰 Saldo atualizado: ${self.saldo_atual:.2f}")
                            return
                except:
                    continue
            
            # Se não encontrou, tentar por screenshot OCR ou valor padrão
            logger.warning("⚠️ Não foi possível ler saldo, usando valor padrão")
            self.saldo_atual = 10000.0
            
        except Exception as e:
            logger.error(f"❌ Erro ao atualizar saldo: {e}")
            self.saldo_atual = 10000.0
    
    async def executar_trade(self, par, direcao, valor, expiracao):
        """
        Executa trade via interface do navegador
        Retorna: (sucesso, order_id_simulado)
        """
        try:
            if not self.esta_logado:
                logger.error("❌ Não está logado")
                return False, None
            
            logger.info(f"🎯 Executando: {par} {direcao} ${valor} {expiracao}s")
            
            # 1. Selecionar ativo
            sucesso_ativo = await self._selecionar_ativo(par)
            if not sucesso_ativo:
                logger.error(f"❌ Falha ao selecionar ativo {par}")
                return False, None
            
            # 2. Definir valor
            sucesso_valor = await self._definir_valor(valor)
            if not sucesso_valor:
                logger.error(f"❌ Falha ao definir valor ${valor}")
                return False, None
            
            # 3. Definir tempo de expiração
            sucesso_tempo = await self._definir_expiracao(expiracao)
            if not sucesso_tempo:
                logger.warning(f"⚠️ Não conseguiu definir expiração {expiracao}s, continuando...")
            
            # 4. Clicar em CALL ou PUT
            sucesso_ordem = await self._clicar_direcao(direcao)
            if not sucesso_ordem:
                logger.error(f"❌ Falha ao clicar em {direcao}")
                return False, None
            
            # 5. Confirmar execução
            await asyncio.sleep(2)
            confirmado = await self._verificar_ordem_aberta()
            
            if confirmado:
                # Gerar ID simulado baseado no timestamp
                order_id = f"BO_{int(datetime.now().timestamp())}"
                logger.info(f"✅ Trade executado! ID simulado: {order_id}")
                return True, order_id
            else:
                logger.error("❌ Ordem não confirmada na interface")
                return False, None
                
        except Exception as e:
            logger.error(f"❌ Erro ao executar trade: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False, None
    
    async def _selecionar_ativo(self, par):
        """Seleciona o ativo/par"""
        try:
            logger.info(f"📊 Selecionando ativo: {par}")
            
            # Limpar -OTC se existir
            par_limpo = par.replace('-OTC', '')
            
            # Procurar campo/botão de seleção de ativo
            seletores_ativo = [
                '[class*="asset-select"]',
                '[class*="instrument-select"]',
                '[data-test*="asset"]',
                'button[class*="asset"]',
                '[class*="active-symbol"]'
            ]
            
            for seletor in seletores_ativo:
                try:
                    elemento = await self.page.query_selector(seletor)
                    if elemento:
                        # Clicar para abrir dropdown
                        await elemento.click()
                        await asyncio.sleep(1)
                        
                        # Procurar pelo par na lista
                        # Tentar buscar por texto
                        par_elemento = await self.page.query_selector(f'text=/{par_limpo}/i')
                        if par_elemento:
                            await par_elemento.click()
                            await asyncio.sleep(1)
                            logger.info(f"✅ Ativo {par_limpo} selecionado")
                            return True
                        
                        # Se não encontrou, tentar OTC
                        par_otc = f"{par_limpo}-OTC"
                        par_otc_elemento = await self.page.query_selector(f'text=/{par_otc}/i')
                        if par_otc_elemento:
                            await par_otc_elemento.click()
                            await asyncio.sleep(1)
                            logger.info(f"✅ Ativo {par_otc} selecionado (OTC)")
                            return True
                except:
                    continue
            
            # Se não conseguiu selecionar, assumir que já está correto
            logger.warning(f"⚠️ Não conseguiu selecionar {par}, assumindo já está correto")
            return True
            
        except Exception as e:
            logger.error(f"❌ Erro ao selecionar ativo: {e}")
            return False
    
    async def _definir_valor(self, valor):
        """Define valor da operação"""
        try:
            logger.info(f"💵 Definindo valor: ${valor}")
            
            # Procurar campo de valor
            seletores_valor = [
                'input[class*="amount"]',
                'input[class*="invest"]',
                'input[type="number"]',
                '[data-test*="amount"]'
            ]
            
            for seletor in seletores_valor:
                try:
                    campo = await self.page.query_selector(seletor)
                    if campo:
                        # Limpar campo
                        await campo.click()
                        await campo.fill('')
                        await asyncio.sleep(0.3)
                        
                        # Preencher novo valor
                        await campo.fill(str(valor))
                        await asyncio.sleep(0.5)
                        
                        logger.info(f"✅ Valor ${valor} definido")
                        return True
                except:
                    continue
            
            logger.warning("⚠️ Não encontrou campo de valor, tentando continuar...")
            return True
            
        except Exception as e:
            logger.error(f"❌ Erro ao definir valor: {e}")
            return False
    
    async def _definir_expiracao(self, segundos):
        """Define tempo de expiração"""
        try:
            logger.info(f"⏱️ Definindo expiração: {segundos}s")
            
            # Procurar seletor de tempo
            seletores_tempo = [
                '[class*="expiration"]',
                '[class*="time-select"]',
                '[data-test*="expiration"]',
                'button[class*="time"]'
            ]
            
            # Converter segundos para minutos se necessário
            minutos = segundos // 60
            tempo_texto = f"{minutos}M" if minutos > 0 else f"{segundos}S"
            
            for seletor in seletores_tempo:
                try:
                    elemento = await self.page.query_selector(seletor)
                    if elemento:
                        await elemento.click()
                        await asyncio.sleep(1)
                        
                        # Procurar opção de tempo
                        tempo_opcao = await self.page.query_selector(f'text=/{tempo_texto}/i')
                        if tempo_opcao:
                            await tempo_opcao.click()
                            await asyncio.sleep(0.5)
                            logger.info(f"✅ Expiração {tempo_texto} definida")
                            return True
                except:
                    continue
            
            logger.warning(f"⚠️ Não conseguiu definir expiração {segundos}s")
            return False
            
        except Exception as e:
            logger.error(f"❌ Erro ao definir expiração: {e}")
            return False
    
    async def _clicar_direcao(self, direcao):
        """Clica no botão CALL ou PUT"""
        try:
            logger.info(f"👆 Clicando em {direcao}...")
            
            # Normalizar direção
            direcao_upper = direcao.upper()
            
            # Delay humano antes do clique
            await asyncio.sleep(0.5)
            
            # Seletores para botões CALL/PUT
            if direcao_upper == "CALL":
                seletores = [
                    'button:has-text("CALL")',
                    'button:has-text("UP")',
                    'button[class*="call"]',
                    'button[class*="higher"]',
                    '[data-test*="call"]',
                    '.btn-call',
                    '.button-call'
                ]
            else:  # PUT
                seletores = [
                    'button:has-text("PUT")',
                    'button:has-text("DOWN")',
                    'button[class*="put"]',
                    'button[class*="lower"]',
                    '[data-test*="put"]',
                    '.btn-put',
                    '.button-put'
                ]
            
            for seletor in seletores:
                try:
                    botao = await self.page.query_selector(seletor)
                    if botao:
                        # Verificar se está visível e habilitado
                        is_visible = await botao.is_visible()
                        is_enabled = await botao.is_enabled()
                        
                        if is_visible and is_enabled:
                            await botao.click()
                            logger.info(f"✅ Clicou em {direcao}")
                            return True
                except:
                    continue
            
            logger.error(f"❌ Não encontrou botão {direcao} clicável")
            return False
            
        except Exception as e:
            logger.error(f"❌ Erro ao clicar em {direcao}: {e}")
            return False
    
    async def _verificar_ordem_aberta(self):
        """Verifica se ordem foi aberta com sucesso"""
        try:
            logger.info("🔍 Verificando ordem aberta...")
            
            # Aguardar alguns segundos
            await asyncio.sleep(2)
            
            # Procurar indicadores de ordem aberta
            seletores_confirmacao = [
                '[class*="deal-open"]',
                '[class*="trade-active"]',
                '[class*="position-open"]',
                'text=/Order.*opened/i',
                'text=/Trade.*opened/i'
            ]
            
            for seletor in seletores_confirmacao:
                try:
                    elemento = await self.page.query_selector(seletor)
                    if elemento:
                        logger.info("✅ Ordem confirmada na interface")
                        return True
                except:
                    continue
            
            # Se não encontrou confirmação explícita, assume sucesso
            # (em produção seria mais rigoroso)
            logger.warning("⚠️ Não encontrou confirmação visual, assumindo sucesso")
            return True
            
        except Exception as e:
            logger.error(f"❌ Erro ao verificar ordem: {e}")
            return False
    
    async def verificar_resultado(self, order_id, aguardar_segundos=3):
        """
        Verifica resultado do trade
        Retorna: (resultado_str, valor_lucro)
        """
        try:
            logger.info(f"⏳ Aguardando resultado (ID: {order_id})...")
            await asyncio.sleep(aguardar_segundos)
            
            # Procurar histórico de trades ou resultado
            seletores_resultado = [
                '[class*="deal-history"]',
                '[class*="trade-result"]',
                '[class*="profit"]',
                '[class*="loss"]'
            ]
            
            for seletor in seletores_resultado:
                try:
                    elementos = await self.page.query_selector_all(seletor)
                    for elem in elementos:
                        texto = await elem.text_content()
                        
                        # Procurar indicadores de WIN/LOSS
                        if 'win' in texto.lower() or 'profit' in texto.lower() or '+' in texto:
                            # Tentar extrair valor
                            numeros = re.findall(r'[\d,\.]+', texto.replace(',', ''))
                            lucro = float(numeros[0]) if numeros else 0
                            logger.info(f"✅ WIN - Lucro: ${lucro:.2f}")
                            return "WIN", lucro
                        
                        elif 'loss' in texto.lower() or '-' in texto:
                            numeros = re.findall(r'[\d,\.]+', texto.replace(',', ''))
                            perda = float(numeros[0]) if numeros else 0
                            logger.info(f"❌ LOSS - Perda: ${perda:.2f}")
                            return "LOSS", perda
                except:
                    continue
            
            # Se não conseguiu determinar, retornar processando
            logger.warning("⚠️ Não conseguiu determinar resultado")
            return "PROCESSANDO", 0
            
        except Exception as e:
            logger.error(f"❌ Erro ao verificar resultado: {e}")
            return "ERRO", 0
    
    def obter_saldo(self):
        """Retorna saldo atual (síncrono para compatibilidade)"""
        return self.saldo_atual
    
    def obter_tipo_conta(self):
        """Retorna tipo de conta"""
        return self.tipo_conta_atual
    
    def esta_conectado(self):
        """Verifica se está conectado"""
        return self.esta_logado
    
    async def fechar(self):
        """Fecha navegador e libera recursos"""
        try:
            if self.page:
                await self.page.close()
            if self.context:
                await self.context.close()
            if self.browser:
                await self.browser.close()
            if self.playwright:
                await self.playwright.stop()
            
            logger.info("🔒 Navegador fechado")
        except Exception as e:
            logger.error(f"❌ Erro ao fechar navegador: {e}")
    
    async def reconectar(self):
        """Reconecta se sessão expirou"""
        try:
            logger.info("🔄 Tentando reconectar...")
            await self.fechar()
            await asyncio.sleep(5)
            return await self.iniciar()
        except Exception as e:
            logger.error(f"❌ Erro ao reconectar: {e}")
            return False
