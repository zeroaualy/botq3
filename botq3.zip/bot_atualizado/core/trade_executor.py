"""
Executor de trades
Responsável pela execução segura de operações
"""
import logging
import time

logger = logging.getLogger(__name__)


class TradeExecutor:
    """Executor de operações com segurança"""
    
    def __init__(self, iq_client):
        self.iq_client = iq_client
        self._last_result = {}  # Cache do último resultado
    
    def executar(self, par, direcao, valor, expiracao):
        """
        Executa operação COM SEGURANÇA usando myiq
        Retorna: (sucesso, order_id)
        """
        # SEGURANÇA CRÍTICA: Garantir PRACTICE
        if not self.iq_client.garantir_practice():
            logger.error("❌ OPERAÇÃO ABORTADA: Falha na verificação PRACTICE")
            return False, None
        
        try:
            # Verificar saldo
            saldo = self.iq_client.obter_saldo()
            if saldo < valor:
                logger.error(f"❌ Saldo insuficiente: ${saldo:.2f} < ${valor:.2f}")
                return False, None
            
            logger.info(f"📊 Executando: {par} {direcao.upper()} ${valor} {expiracao}s")
            logger.info(f"🏦 Conta: PRACTICE | Saldo: ${saldo:.2f}")
            
            # Usar método executar_ordem que já faz toda a validação
            # e retorna o resultado completo
            status, order_id = self.iq_client.executar_ordem(par, direcao, valor, expiracao)
            
            if status:
                logger.info(f"✅ Ordem executada! ID: {order_id}")
                return True, order_id
            else:
                logger.error(f"❌ Falha ao executar ordem")
                return False, None
                
        except Exception as e:
            logger.error(f"❌ Erro ao executar operação: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False, None
    
    def verificar_resultado(self, order_id, aguardar_segundos=3):
        """
        Verifica resultado da operação
        Com myiq, o resultado já vem junto da execução
        Retorna: (resultado_str, valor_lucro)
        """
        try:
            # Com myiq, a execução já aguarda o resultado
            # Então não precisamos aguardar novamente
            logger.info("ℹ️ Com myiq, resultado já foi obtido durante execução")
            
            # Verificar se temos resultado cached
            if order_id in self._last_result:
                result_data = self._last_result[order_id]
                
                result_type = result_data.get("result", "").lower()
                pnl = result_data.get("pnl", 0)
                
                if result_type == "win":
                    logger.info(f"✅ WIN - Lucro: ${pnl:.2f}")
                    return "WIN", pnl
                elif result_type == "loose":
                    logger.info(f"❌ LOSS - Perda: ${abs(pnl):.2f}")
                    return "LOSS", abs(pnl)
                elif result_type == "equal":
                    logger.info("⚪ EMPATE")
                    return "EMPATE", 0
            
            # Se não temos cache, retornar desconhecido
            logger.warning("⚠️ Resultado não disponível no cache")
            return "DESCONHECIDO", 0
                
        except Exception as e:
            logger.error(f"❌ Erro ao verificar resultado: {e}")
            return "ERRO", 0
    
    def _cache_result(self, order_id, result_data):
        """Armazena resultado no cache interno"""
        self._last_result[order_id] = result_data
