"""
Telegram Bot — Bot Q3 Beta
All menus functional. No ghost options. DB-backed stats.
Martingale controls fully wired to MartingaleManager.
"""
import logging
from datetime import datetime
from zoneinfo import ZoneInfo

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from state import runtime
from state.config import CONFIG, GRUPO_ID
from db import database
from bot.auth import is_admin

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class TelegramBot:

    def __init__(self, config: dict, signal_parser, permissoes: dict):
        self.config = config
        self.signal_parser = signal_parser
        self.permissoes = permissoes
        self.iq_client = None

    def set_iq_client(self, iq_client):
        self.iq_client = iq_client

    async def _check_admin(self, update_or_query) -> bool:
        """Verifica se o usuário é admin. Funciona com Update e CallbackQuery."""
        try:
            if hasattr(update_or_query, "from_user"):
                user_id = update_or_query.from_user.id
                bot = update_or_query.get_bot()
                chat_id = update_or_query.message.chat_id
            else:
                # Update object
                user = (update_or_query.message or update_or_query.callback_query).from_user
                user_id = user.id
                bot = update_or_query.get_bot()
                chat_id = GRUPO_ID
            return await is_admin(bot, user_id, chat_id)
        except Exception as e:
            logger.warning(f"_check_admin error: {e}")
            return False

    async def _deny(self, query_or_update, is_callback=True):
        """Responde com negação sem mostrar detalhes internos."""
        msg = "🔒 Apenas administradores podem alterar configurações."
        if is_callback:
            await query_or_update.answer(msg, show_alert=True)
        else:
            await query_or_update.message.reply_text(msg)

    # ─────────────────────────────────────────────────────────
    # MENUS
    # ─────────────────────────────────────────────────────────

    def _menu_principal(self):
        auto = "✅ ATIVO" if self.config.get("operar_automatico") else "⚪ PAUSADO"
        auto_cb = "pause_bot" if self.config.get("operar_automatico") else "start_bot"

        gen_active = (runtime.auto_signal_generator and
                      getattr(runtime.auto_signal_generator, "active", False))
        gen = "🟢 ATIVADO" if gen_active else "⚪ DESATIVADO"
        gen_cb = "toggle_automacao_off" if gen_active else "toggle_automacao_on"

        keyboard = [
            [InlineKeyboardButton("⚙️ Configurações", callback_data="config"),
             InlineKeyboardButton("📊 Estatísticas", callback_data="stats")],
            [InlineKeyboardButton("📥 Sinais", callback_data="sinais"),
             InlineKeyboardButton("🎲 Martingale", callback_data="martingale_menu")],
            [InlineKeyboardButton(f"🤖 Automático: {auto}", callback_data=auto_cb)],
            [InlineKeyboardButton(f"🧠 Geração AI: {gen}", callback_data=gen_cb)],
            [InlineKeyboardButton("💰 Ver Saldo", callback_data="ver_saldo")],
        ]
        return InlineKeyboardMarkup(keyboard)

    def _menu_config(self):
        auto = "✅" if self.config.get("operar_automatico") else "❌"
        mg = "✅" if self.config.get("martingale") else "❌"
        ia = "✅" if self.config.get("ia_validar_contexto") else "❌"
        slip   = "✅" if self.config.get("slippage_filter_enabled") else "❌"
        bypass = "❌" if self.config.get("bypass_schedule_check", True) else "✅"  # inverted: bypass=True means check is OFF

        keyboard = [
            [InlineKeyboardButton("─── EXECUÇÃO ───", callback_data="noop")],
            [InlineKeyboardButton(f"{auto} Operação Automática", callback_data="toggle_auto")],
            [InlineKeyboardButton(f"{mg} Martingale", callback_data="toggle_martingale")],
            [InlineKeyboardButton(f"{ia} IA Guard", callback_data="toggle_ia_validar")],
            [InlineKeyboardButton(f"{slip} Filtro de Atraso", callback_data="toggle_slippage_filter")],
            [InlineKeyboardButton(f"{bypass} Verificar Horário Ativo", callback_data="toggle_bypass_schedule")],
            [InlineKeyboardButton("─── VALORES ───", callback_data="noop")],
            [InlineKeyboardButton(f"💰 Entrada: ${self.config['valor_entrada']:.0f}",
                                  callback_data="edit_valor_entrada")],
            [InlineKeyboardButton(f"🛑 Stop Loss: ${self.config['stop_loss']:.0f}",
                                  callback_data="edit_stop_loss")],
            [InlineKeyboardButton(f"🎯 Stop Gain: ${self.config['stop_gain']:.0f}",
                                  callback_data="edit_stop_gain")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")],
        ]
        return InlineKeyboardMarkup(keyboard)

    def _menu_martingale(self):
        mg = self.config.get("martingale", False)
        toggle_label = "❌ Desativar" if mg else "✅ Ativar"
        mult = self.config.get("martingale_multiplier", 2.0)
        lvl = self.config.get("martingale_max_levels", 3)

        keyboard = [
            [InlineKeyboardButton(toggle_label, callback_data="toggle_martingale_menu")],
            [InlineKeyboardButton(f"✖️ Multiplicador: {mult}x",
                                  callback_data="edit_mg_multiplier")],
            [InlineKeyboardButton(f"📶 Níveis Máx: {lvl}",
                                  callback_data="edit_mg_max_levels")],
            [InlineKeyboardButton("🔄 Resetar Sequência", callback_data="mg_reset")],
            [InlineKeyboardButton("📊 Ver Estado Atual", callback_data="mg_status")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")],
        ]
        return InlineKeyboardMarkup(keyboard)

    def _menu_sinais(self):
        cap = "✅ ATIVA" if runtime.captura_sinais_ativa else "❌ PAUSADA"
        qtd = len(runtime.sinais_agendados)

        keyboard = [
            [InlineKeyboardButton(f"📡 Captura: {cap}", callback_data="toggle_captura")],
            [InlineKeyboardButton(f"📋 Agendados ({qtd})", callback_data="listar_sinais")],
            [InlineKeyboardButton("🗑️ Limpar Fila", callback_data="limpar_sinais")],
            [InlineKeyboardButton("📝 Formatos Aceitos", callback_data="formatos_sinal")],
            [InlineKeyboardButton("◀️ Voltar", callback_data="menu")],
        ]
        return InlineKeyboardMarkup(keyboard)

    def _back_btn(self, cb="menu"):
        return InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Voltar", callback_data=cb)]])

    # ─────────────────────────────────────────────────────────
    # /start COMMAND
    # ─────────────────────────────────────────────────────────

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        iq_ok = self.iq_client and self.iq_client.esta_conectado()
        status_iq = "✅ Conectado" if iq_ok else "❌ Desconectado"

        saldo_msg = ""
        if iq_ok:
            try:
                saldo = await self.iq_client.obter_saldo()
                tipo = self.iq_client.obter_tipo_conta()
                saldo_msg = f"\n💰 {tipo}: <b>${saldo:.2f}</b>"
            except Exception:
                pass

        today = await database.get_today_stats()

        text = (
            f"🤖 <b>Bot Q3 Beta</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"📡 IQ Option: {status_iq}"
            f"{saldo_msg}\n"
            f"📈 Hoje: {today['wins']}W {today['losses']}L · "
            f"{today['winrate']:.0f}% · ${today['pnl']:+.2f}\n"
            f"📥 Sinais na fila: {len(runtime.sinais_agendados)}\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"<b>Formatos aceitos:</b>\n"
            f"<code>M5 EURUSD CALL 14:30</code>\n"
            f"<code>EURUSD PUT</code>"
        )
        await update.message.reply_text(text, parse_mode="HTML",
                                        reply_markup=self._menu_principal())

    # ─────────────────────────────────────────────────────────
    # BUTTON HANDLER
    # ─────────────────────────────────────────────────────────

    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data

        # ── Navigation ───────────────────────────────────────
        if data == "noop":
            return

        # Read-only actions allowed for everyone
        READ_ONLY = {"menu", "ver_saldo", "stats", "sinais", "listar_sinais",
                     "formatos_sinal", "martingale_menu", "mg_status"}

        if data not in READ_ONLY:
            if not await is_admin(query.get_bot(), query.from_user.id,
                                  query.message.chat_id):
                await query.answer(
                    "🔒 Apenas administradores podem alterar configurações.",
                    show_alert=True
                )
                return

        if data == "menu":
            await query.edit_message_text(
                "🤖 <b>Menu Principal</b>",
                parse_mode="HTML",
                reply_markup=self._menu_principal()
            )
            return

        # ── Balance ──────────────────────────────────────────
        if data == "ver_saldo":
            await self._handle_ver_saldo(query)
            return

        # ── Config ───────────────────────────────────────────
        if data == "config":
            await query.edit_message_text(
                "⚙️ <b>Configurações</b>",
                parse_mode="HTML",
                reply_markup=self._menu_config()
            )
            return

        if data == "toggle_auto":
            self.config["operar_automatico"] = not self.config["operar_automatico"]
            s = "✅ ATIVADA" if self.config["operar_automatico"] else "❌ DESATIVADA"
            await query.edit_message_text(
                f"🤖 Operação Automática: <b>{s}</b>",
                parse_mode="HTML",
                reply_markup=self._menu_config()
            )
            return

        if data == "start_bot":
            self.config["operar_automatico"] = True
            await query.edit_message_text(
                "✅ Bot iniciado.", reply_markup=self._menu_principal()
            )
            return

        if data == "pause_bot":
            self.config["operar_automatico"] = False
            await query.edit_message_text(
                "⏸️ Bot pausado.", reply_markup=self._menu_principal()
            )
            return

        if data == "toggle_ia_validar":
            self.config["ia_validar_contexto"] = not self.config["ia_validar_contexto"]
            s = "✅ ATIVADO" if self.config["ia_validar_contexto"] else "❌ DESATIVADO"
            await query.edit_message_text(
                f"🧠 IA Guard: <b>{s}</b>",
                parse_mode="HTML",
                reply_markup=self._menu_config()
            )
            return

        if data == "toggle_slippage_filter":
            self.config["slippage_filter_enabled"] = not self.config["slippage_filter_enabled"]
            s = "✅ ATIVADO" if self.config["slippage_filter_enabled"] else "❌ DESATIVADO"
            note = (
                "\n⚠️ Sinais atrasados serão bloqueados." if self.config["slippage_filter_enabled"]
                else "\nOperações executam independente do atraso (recomendado para API não-oficial)."
            )
            await query.edit_message_text(
                f"⏱️ Filtro de Atraso: <b>{s}</b>{note}",
                parse_mode="HTML",
                reply_markup=self._menu_config()
            )
            return

        if data == "toggle_bypass_schedule":
            # bypass=True means schedule check is DISABLED (default safe behavior)
            self.config["bypass_schedule_check"] = not self.config.get("bypass_schedule_check", True)
            ativo = not self.config["bypass_schedule_check"]  # check is active when bypass is False
            s = "✅ ATIVADO" if ativo else "❌ DESATIVADO"
            note = (
                "\n⚠️ Ativos fora do horário de mercado serão bloqueados."
                if ativo else
                "\nVerificação de horário desativada — IQ Option gerencia disponibilidade."
            )
            await query.edit_message_text(
                f"🕐 Verificar Horário: <b>{s}</b>{note}",
                parse_mode="HTML",
                reply_markup=self._menu_config()
            )
            return

        if data == "toggle_martingale":
            self.config["martingale"] = not self.config["martingale"]
            s = "✅ ATIVADO" if self.config["martingale"] else "❌ DESATIVADO"
            note = "\n⚠️ Multiplica o valor após perdas." if self.config["martingale"] else ""
            await query.edit_message_text(
                f"🎲 Martingale: <b>{s}</b>{note}",
                parse_mode="HTML",
                reply_markup=self._menu_config()
            )
            return

        # Edits
        for field, cb in [("edit_valor_entrada", "valor_entrada"),
                          ("edit_stop_loss", "stop_loss"),
                          ("edit_stop_gain", "stop_gain"),
                          ("edit_mg_multiplier", "martingale_multiplier"),
                          ("edit_mg_max_levels", "martingale_max_levels")]:
            if data == field:
                user_id = query.from_user.id
                # Store field + admin-confirmed flag (admin already checked above)
                runtime.editing_state[user_id] = {"field": cb, "admin_ok": True}
                labels = {
                    "valor_entrada": ("💰 Valor de Entrada", f"${self.config.get('valor_entrada'):.2f}", "ex: 50"),
                    "stop_loss": ("🛑 Stop Loss", f"${self.config.get('stop_loss'):.2f}", "ex: 30"),
                    "stop_gain": ("🎯 Stop Gain", f"${self.config.get('stop_gain'):.2f}", "ex: 60"),
                    "martingale_multiplier": ("✖️ Multiplicador", f"{self.config.get('martingale_multiplier', 2.0)}x", "ex: 2.0"),
                    "martingale_max_levels": ("📶 Níveis Máx", f"{self.config.get('martingale_max_levels', 3)}", "ex: 3"),
                }
                lbl, atual, hint = labels[cb]
                await query.edit_message_text(
                    f"{lbl}\nAtual: <b>{atual}</b>\n\nDigite o novo valor (<code>{hint}</code>):",
                    parse_mode="HTML",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("❌ Cancelar", callback_data="config")
                    ]])
                )
                return

        # ── Martingale menu ───────────────────────────────────
        if data == "martingale_menu":
            await query.edit_message_text(
                "🎲 <b>Martingale</b>",
                parse_mode="HTML",
                reply_markup=self._menu_martingale()
            )
            return

        if data == "toggle_martingale_menu":
            self.config["martingale"] = not self.config["martingale"]
            s = "✅ ATIVADO" if self.config["martingale"] else "❌ DESATIVADO"
            note = "\n⚠️ Multiplica o valor após perdas." if self.config["martingale"] else ""
            await query.edit_message_text(
                f"🎲 Martingale: <b>{s}</b>{note}",
                parse_mode="HTML",
                reply_markup=self._menu_martingale()
            )
            return

        if data == "mg_reset":
            if runtime.martingale_manager:
                await runtime.martingale_manager.manual_reset()
                await query.edit_message_text(
                    "🔄 <b>Martingale resetado</b>\nNível: 0 · Próximo: base",
                    parse_mode="HTML",
                    reply_markup=self._menu_martingale()
                )
            else:
                await query.answer("MartingaleManager não inicializado", show_alert=True)
            return

        if data == "mg_status":
            await self._handle_mg_status(query)
            return

        # ── Stats ─────────────────────────────────────────────
        if data == "stats":
            await self._handle_stats(query)
            return

        # ── Signals ──────────────────────────────────────────
        if data == "sinais":
            await query.edit_message_text(
                f"📡 <b>Sinais</b> · {len(runtime.sinais_agendados)} agendado(s)",
                parse_mode="HTML",
                reply_markup=self._menu_sinais()
            )
            return

        if data == "toggle_captura":
            runtime.captura_sinais_ativa = not runtime.captura_sinais_ativa
            s = "✅ ATIVA" if runtime.captura_sinais_ativa else "❌ PAUSADA"
            await query.edit_message_text(
                f"📡 Captura: <b>{s}</b>",
                parse_mode="HTML",
                reply_markup=self._menu_sinais()
            )
            return

        if data == "listar_sinais":
            await self._handle_listar_sinais(query)
            return

        if data == "limpar_sinais":
            qtd = len(runtime.sinais_agendados)
            runtime.limpar_sinais()
            await query.edit_message_text(
                f"🗑️ <b>{qtd} sinal(is) removido(s)</b>",
                parse_mode="HTML",
                reply_markup=self._menu_sinais()
            )
            return

        if data == "formatos_sinal":
            await query.edit_message_text(
                "📝 <b>Formatos Aceitos</b>\n\n"
                "<code>M5 EURUSD CALL 14:30</code>\n"
                "<code>EURUSD PUT</code>\n"
                "<code>ATIVO: EURUSD\nDIREÇÃO: CALL\nTIMEFRAME: M5\nHORÁRIO: 14:30</code>\n\n"
                "CALL = compra · PUT = venda\n"
                "Múltiplos sinais: um por linha",
                parse_mode="HTML",
                reply_markup=self._back_btn("sinais")
            )
            return

        # ── Automation ────────────────────────────────────────
        if data in ("toggle_automacao_on", "toggle_automacao_off"):
            await self._handle_automacao(query, data)
            return

    # ─────────────────────────────────────────────────────────
    # SUB-HANDLERS
    # ─────────────────────────────────────────────────────────

    async def _handle_ver_saldo(self, query):
        if not self.iq_client or not self.iq_client.esta_conectado():
            await query.edit_message_text(
                "❌ Sem conexão com IQ Option",
                reply_markup=self._menu_principal()
            )
            return
        saldo = await self.iq_client.obter_saldo()
        tipo = self.iq_client.obter_tipo_conta()
        prat = "✅ PRACTICE" if tipo == "PRACTICE" else "⚠️ REAL — cuidado!"
        await query.edit_message_text(
            f"💰 <b>Saldo</b>\n\nTipo: <b>{tipo}</b>\nValor: <b>${saldo:.2f}</b>\n\n{prat}",
            parse_mode="HTML",
            reply_markup=self._back_btn()
        )

    async def _handle_stats(self, query):
        today = await database.get_today_stats()
        total_all = await database.get_all_time_stats()
        mg_status = ""
        if runtime.martingale_manager:
            st = runtime.martingale_manager.get_status()
            if st["enabled"]:
                mg_status = (
                    f"\n🎲 <b>Martingale</b>\n"
                    f"Nível: {st['level']}/{st['max_levels']} · "
                    f"Perdas: {st['consecutive_losses']} · "
                    f"Próximo: ${st['next_value']:.2f}\n"
                )

        s_emoji = "📈" if today["pnl"] >= 0 else "📉"
        text = (
            f"📊 <b>Estatísticas</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"📅 <b>Hoje</b>\n"
            f"🎯 {today['total']} ops · ✅ {today['wins']} · ❌ {today['losses']} · ⚪ {today['draws']}\n"
            f"📈 Win Rate: <b>{today['winrate']:.1f}%</b>\n"
            f"{s_emoji} P&L: <b>${today['pnl']:+.2f}</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"🗓️ <b>Total Geral</b>\n"
            f"🎯 {total_all['total']} ops · ✅ {total_all['wins']} · ❌ {total_all['losses']}\n"
            f"📈 Win Rate: <b>{total_all['winrate']:.1f}%</b>\n"
            f"💰 P&L Total: <b>${total_all['pnl']:+.2f}</b>\n"
            f"━━━━━━━━━━━━━━━━━━"
            f"{mg_status}"
        )
        await query.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔄 Atualizar", callback_data="stats"),
                InlineKeyboardButton("◀️ Voltar", callback_data="menu")
            ]])
        )

    async def _handle_mg_status(self, query):
        if not runtime.martingale_manager:
            await query.answer("MartingaleManager não inicializado", show_alert=True)
            return
        st = runtime.martingale_manager.get_status()
        ativo = "✅ ATIVO" if st["enabled"] else "❌ DESATIVADO"
        bloq = "\n⛔ <b>BLOQUEADO — resetar manualmente</b>" if st["blocked"] else ""
        text = (
            f"🎲 <b>Martingale</b>\n"
            f"Estado: {ativo}\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"Nível atual: <b>{st['level']}/{st['max_levels']}</b>\n"
            f"Perdas consecutivas: <b>{st['consecutive_losses']}</b>\n"
            f"Multiplicador: <b>{st['multiplier']}x</b>\n"
            f"Valor base: <b>${st['base_value']:.2f}</b>\n"
            f"Próxima entrada: <b>${st['next_value']:.2f}</b>"
            f"{bloq}"
        )
        await query.edit_message_text(
            text, parse_mode="HTML",
            reply_markup=self._menu_martingale()
        )

    async def _handle_listar_sinais(self, query):
        sinais = runtime.sinais_agendados
        if not sinais:
            await query.edit_message_text(
                "📭 <b>Nenhum sinal agendado</b>\nEnvie um sinal para agendar.",
                parse_mode="HTML",
                reply_markup=self._menu_sinais()
            )
            return
        agora = datetime.now(TZ)
        lista = f"📋 <b>Sinais Agendados</b> · {agora.strftime('%H:%M:%S')}\n\n"
        for i, s in enumerate(sinais[:10], 1):
            h = s["horario"]
            if h.tzinfo is None:
                h = h.replace(tzinfo=TZ)
            diff = (h - agora).total_seconds()
            if diff < 0:
                t = "⚠️ atrasado"
            elif diff < 60:
                t = f"{int(diff)}s"
            else:
                t = f"{int(diff/60)}min"
            lista += f"{i}. <b>{s['par']}</b> {s['direcao']} · {h.strftime('%H:%M')} ({t})\n"
        if len(sinais) > 10:
            lista += f"\n+{len(sinais) - 10} sinais"
        await query.edit_message_text(
            lista, parse_mode="HTML",
            reply_markup=self._menu_sinais()
        )

    async def _handle_automacao(self, query, data):
        if not runtime.auto_signal_generator:
            await query.answer("AutoSignalGenerator não inicializado", show_alert=True)
            return
        if data == "toggle_automacao_on":
            if not self.iq_client or not self.iq_client.esta_conectado():
                await query.answer("❌ IQ Option não conectado", show_alert=True)
                return
            ok = await runtime.auto_signal_generator.start()
            if ok:
                await query.edit_message_text(
                    "🤖 <b>Geração AI ATIVADA</b>\n"
                    "Pipeline: MyIQ → Análise → Fila de sinais",
                    parse_mode="HTML", reply_markup=self._menu_principal()
                )
            else:
                await query.answer("Erro ao ativar", show_alert=True)
        else:
            await runtime.auto_signal_generator.stop()
            await query.edit_message_text(
                "⚪ <b>Geração AI desativada</b>",
                parse_mode="HTML", reply_markup=self._menu_principal()
            )

    # ─────────────────────────────────────────────────────────
    # MESSAGE HANDLER (signals + value editing)
    # ─────────────────────────────────────────────────────────

    async def mensagem(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.message.from_user.id
        texto = update.message.text.strip()

        # Editing state
        estado = runtime.editing_state.get(user_id)
        if estado:
            # Support both old str format and new dict format
            if isinstance(estado, dict):
                campo = estado.get("field")
                admin_ok = estado.get("admin_ok", False)
            else:
                campo = estado
                admin_ok = False

            # Re-check admin only if not already confirmed at button click
            if not admin_ok:
                chat_id = update.message.chat_id
                if not await is_admin(update.get_bot(), user_id, chat_id):
                    runtime.editing_state.pop(user_id, None)
                    await update.message.reply_text(
                        "🔒 Apenas administradores podem alterar configurações."
                    )
                    return

            await self._handle_edit_value(update, user_id, campo, texto)
            return

        # Signal parsing
        sinais = self.signal_parser.parsear_sinal(texto)
        if not sinais:
            return

        agendados = 0
        imediatos = []

        for sinal in sinais:
            sinal["signal_source"] = "manual"
            sinal["signal_received_at"] = datetime.now(TZ)

            if sinal.get("imediato"):
                if self.config.get("operar_automatico"):
                    imediatos.append(sinal)
            else:
                if runtime.captura_sinais_ativa or self.config.get("operar_automatico"):
                    runtime.adicionar_sinal(sinal)
                    agendados += 1

        # Execute immediate signals via ExecutionEngine
        for sinal in imediatos:
            if runtime.execution_engine:
                # Fire and forget (result notified via callback)
                import asyncio
                asyncio.create_task(runtime.execution_engine.execute(
                    sinal,
                    signal_received_at=sinal["signal_received_at"]
                ))
            await update.message.reply_text(
                f"⚡ <b>Executando agora</b>\n"
                f"📊 {sinal['par']} {sinal['direcao']} · {sinal['tempo_expiracao']}s",
                parse_mode="HTML"
            )

        if agendados > 0:
            agora = datetime.now(TZ)
            ultimo = [s for s in sinais if not s.get("imediato")]
            if ultimo:
                s = ultimo[-1]
                h = s["horario"]
                if h.tzinfo is None:
                    h = h.replace(tzinfo=TZ)
                diff = (h - agora).total_seconds()
                if diff < 60:
                    t = f"{int(diff)}s"
                elif diff < 3600:
                    t = f"{int(diff/60)}min {int(diff%60)}s"
                else:
                    t = f"{int(diff/3600)}h {int((diff%3600)/60)}min"
                if agendados == 1:
                    msg = (
                        f"✅ <b>Sinal Agendado</b>\n"
                        f"📊 {s['par']} {s['direcao']} · {h.strftime('%H:%M:%S')}\n"
                        f"⏳ Em {t} · {s['tempo_expiracao']}s"
                    )
                else:
                    msg = (
                        f"✅ <b>{agendados} Sinais Agendados</b>\n"
                        f"📋 Fila: {len(runtime.sinais_agendados)}"
                    )
                await update.message.reply_text(msg, parse_mode="HTML")

    async def _handle_edit_value(self, update, user_id, campo, texto):
        try:
            valor = float(texto.replace(",", "."))
            if valor <= 0:
                await update.message.reply_text("❌ Valor deve ser maior que zero.")
                return

            # Apply field-specific limits
            if campo in ("valor_entrada", "stop_loss", "stop_gain") and valor > 10000:
                await update.message.reply_text("❌ Valor muito alto. Máximo: $10.000.")
                return
            if campo == "martingale_multiplier" and (valor < 1.1 or valor > 10):
                await update.message.reply_text("❌ Multiplicador: entre 1.1 e 10.")
                return
            if campo == "martingale_max_levels" and (valor < 1 or valor > 10):
                await update.message.reply_text("❌ Níveis: entre 1 e 10.")
                return

            # Use int for levels
            if campo == "martingale_max_levels":
                valor = int(valor)

            self.config[campo] = valor
            runtime.editing_state.pop(user_id, None)

            labels = {
                "valor_entrada": "💰 Valor de Entrada",
                "stop_loss": "🛑 Stop Loss",
                "stop_gain": "🎯 Stop Gain",
                "martingale_multiplier": "✖️ Multiplicador",
                "martingale_max_levels": "📶 Níveis Máx",
            }
            label = labels.get(campo, campo)

            # If base value changed, sync martingale base
            if campo == "valor_entrada" and runtime.martingale_manager:
                from db.database import save_martingale_state, load_martingale_state
                state = await load_martingale_state()
                await save_martingale_state(
                    state["current_level"],
                    state["consecutive_losses"],
                    valor,
                    state.get("last_result"),
                )

            suffix = "x" if campo == "martingale_multiplier" else ""
            prefix = "" if campo in ("martingale_multiplier", "martingale_max_levels") else "$"
            await update.message.reply_text(
                f"✅ {label}: <b>{prefix}{valor}{suffix}</b>",
                parse_mode="HTML"
            )
        except ValueError:
            await update.message.reply_text(
                "❌ Valor inválido. Use: <code>10</code> ou <code>10.50</code>",
                parse_mode="HTML"
            )
