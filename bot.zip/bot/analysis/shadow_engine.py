"""
Shadow Mode Engine
Simulates alternative strategies without execution
"""
import logging
from typing import Dict, List
from datetime import datetime
from zoneinfo import ZoneInfo

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class ShadowEngine:
    """
    Shadow mode for testing alternative parameters
    
    Runs parallel simulations with different settings
    Does NOT interfere with live trading
    """
    
    def __init__(self):
        self.shadow_trades = []
        self.shadow_settings = {
            "threshold": 70,  # Alternative threshold
            "risk_multiplier": 1.2  # Alternative risk sizing
        }
    
    def evaluate_shadow_signal(self, signal: Dict, score: int) -> Dict:
        """
        Evaluate if signal would pass shadow criteria
        
        Args:
            signal: Signal dict
            score: Calculated score
            
        Returns:
            Dict with shadow evaluation
        """
        shadow_threshold = self.shadow_settings["threshold"]
        
        would_trade = score >= shadow_threshold
        
        return {
            "would_trade_shadow": would_trade,
            "shadow_threshold": shadow_threshold,
            "score_diff": score - shadow_threshold
        }
    
    def record_shadow_outcome(self, signal: Dict, actual_result: str, actual_pnl: float):
        """Record hypothetical shadow trade result"""
        shadow_eval = self.evaluate_shadow_signal(signal, signal.get("score", 0))
        
        if shadow_eval["would_trade_shadow"]:
            self.shadow_trades.append({
                "timestamp": datetime.now(TZ),
                "asset": signal.get("asset"),
                "direction": signal.get("direction"),
                "score": signal.get("score"),
                "result": actual_result,
                "pnl": actual_pnl * self.shadow_settings["risk_multiplier"]
            })
    
    def get_shadow_performance(self) -> Dict:
        """Get shadow mode performance stats"""
        if not self.shadow_trades:
            return {
                "total_trades": 0,
                "winrate": 0,
                "total_pnl": 0,
                "status": "NO_DATA"
            }
        
        wins = sum(1 for t in self.shadow_trades if t["result"] == "WIN")
        total = len(self.shadow_trades)
        winrate = (wins / total) * 100 if total > 0 else 0
        total_pnl = sum(t["pnl"] for t in self.shadow_trades)
        
        return {
            "total_trades": total,
            "wins": wins,
            "losses": total - wins,
            "winrate": round(winrate, 2),
            "total_pnl": round(total_pnl, 2),
            "status": "ACTIVE"
        }
    
    def compare_with_live(self, live_performance: Dict) -> Dict:
        """Compare shadow performance with live"""
        shadow_perf = self.get_shadow_performance()
        
        if shadow_perf["total_trades"] < 20:
            return {
                "comparison": "INSUFFICIENT_DATA",
                "recommendation": "MAINTAIN",
                "trades_needed": 20 - shadow_perf["total_trades"]
            }
        
        live_winrate = live_performance.get("winrate", 0)
        shadow_winrate = shadow_perf["winrate"]
        
        winrate_diff = shadow_winrate - live_winrate
        
        if winrate_diff > 5:
            return {
                "comparison": "SHADOW_BETTER",
                "recommendation": "CONSIDER_SWITCH",
                "winrate_diff": round(winrate_diff, 2),
                "details": f"Shadow outperforming by {winrate_diff:.1f}%"
            }
        elif winrate_diff < -5:
            return {
                "comparison": "LIVE_BETTER",
                "recommendation": "MAINTAIN",
                "winrate_diff": round(winrate_diff, 2),
                "details": f"Live performing better by {abs(winrate_diff):.1f}%"
            }
        else:
            return {
                "comparison": "SIMILAR",
                "recommendation": "MAINTAIN",
                "winrate_diff": round(winrate_diff, 2),
                "details": "Performance similar"
            }
