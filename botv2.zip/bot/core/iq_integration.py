"""
IQ Integration Layer - Bot Q3 Beta
Camada de integração usando APENAS métodos públicos do myiq
"""
import asyncio
import logging
from typing import Tuple, Optional, Dict
from datetime import datetime

logger = logging.getLogger(__name__)


class IQIntegration:
    """
    Camada de integração IQ Option usando APENAS API pública do myiq.
    
    Princípios:
    - Zero acesso a propriedades internas
    - Validação LIVE sempre
    - Seleção dinâmica de instrumento (turbo vs digital)
    - Erros precisos da API
    """
    
    def __init__(self, iq_client, config: dict):
        """
        Args:
            iq_client: Instância do cliente myiq
            config: Configurações do bot
        """
        self.iq = iq_client
        self.config = config
        self.practice_balance_id = None
        self._last_trade_time: Optional[datetime] = None
        self._pending_trade = False
        self._actives_map = {}  # Cache local (não interno do myiq)
        self._last_trade_result = {}  # {order_id: raw_result_dict}
    
    async def ensure_connection(self) -> bool:
        """Garante que websocket está conectado"""
        try:
            if not self.iq or not self.iq.check_connect():
                logger.error("❌ Websocket desconectado")
                return False
            return True
        except Exception as e:
            logger.error(f"❌ Erro ao verificar conexão: {e}")
            return False
    
    async def ensure_practice_account(self) -> bool:
        """
        Garante que está operando em conta PRACTICE.
        Usa apenas métodos públicos.
        """
        try:
            if not await self.ensure_connection():
                return False
            
            # Obter balanços disponíveis
            balances = await self.iq.get_balances()
            
            if not balances:
                logger.error("❌ Não foi possível obter balanços")
                return False
            
            # Encontrar balance PRACTICE (type == 4)
            practice = None
            for bal in balances:
                if bal.type == 4:
                    practice = bal
                    break
            
            if not practice:
                logger.error("❌ Conta PRACTICE não encontrada")
                return False
            
            # Verificar se já está em PRACTICE
            if self.iq.active_balance_id == practice.id:
                self.practice_balance_id = practice.id
                return True
            
            # Mudar para PRACTICE
            logger.info("🔄 Mudando para conta PRACTICE...")
            await self.iq.change_balance(practice.id)
            self.practice_balance_id = practice.id
            
            # Confirmar mudança
            if self.iq.active_balance_id == practice.id:
                logger.info("✅ Operando na conta PRACTICE")
                return True
            else:
                logger.error("❌ Falha ao mudar para PRACTICE")
                return False
                
        except Exception as e:
            logger.error(f"❌ Erro ao garantir PRACTICE: {e}")
            return False
    
    async def _discover_active_id(self, asset_symbol: str, instrument: str) -> Optional[int]:
        """
        Descobre active_id usando método get_actives do myiq.
        Este é um método PÚBLICO e OFICIAL.
        """
        try:
            # get_actives retorna dict de ativos para o instrumento
            result = await asyncio.wait_for(
                self.iq.get_actives(instrument),
                timeout=10.0
            )
            
            if not result or not isinstance(result, dict):
                return None
            
            asset_upper = asset_symbol.upper().replace("-OTC", "")
            is_otc = "-OTC" in asset_symbol.upper()
            
            # Procurar correspondência
            for active_id, data in result.items():
                if not isinstance(data, dict):
                    continue
                
                name = str(data.get("name", "")).upper()
                ticker = str(data.get("ticker", "")).upper()
                
                # Match exato
                if is_otc:
                    if f"{asset_upper}-OTC" in name or (asset_upper in name and "OTC" in name):
                        return int(active_id)
                else:
                    name_clean = name.replace("-OTC", "")
                    if name_clean == asset_upper or ticker == asset_upper:
                        return int(active_id)
            
            return None
            
        except asyncio.TimeoutError:
            logger.warning(f"⏱️ Timeout ao descobrir active_id para {asset_symbol} [{instrument}]")
            return None
        except Exception as e:
            logger.debug(f"Erro ao descobrir active_id: {e}")
            return None
    
    async def validate_asset_live(self, asset_symbol: str) -> Dict:
        """
        Valida ativo DINAMICAMENTE tentando ambos os instrumentos.
        Usa APENAS API pública (get_actives, get_profit_percent, is_active_open).
        
        Returns:
            {
                "valid": bool,
                "active_id": int,
                "instrument": "turbo" | "digital",
                "payout": int,
                "error": str (se invalid)
            }
        """
        try:
            if not await self.ensure_connection():
                return {"valid": False, "error": "Websocket desconectado"}
            
            debug = self.config.get("debug_trade_validation", False)
            
            # Tentar turbo primeiro
            if debug:
                logger.info(f"🔍 Procurando {asset_symbol} em turbo...")
            
            turbo_id = await self._discover_active_id(asset_symbol, "turbo")
            
            if turbo_id:
                turbo_result = await self._check_instrument_live(
                    turbo_id, "turbo", asset_symbol
                )
                if turbo_result["valid"]:
                    if debug:
                        logger.info(
                            f"✅ {asset_symbol} disponível [turbo] "
                            f"ID:{turbo_id} Payout:{turbo_result['payout']}%"
                        )
                    return turbo_result
            
            # Tentar digital como fallback
            if debug:
                logger.info(f"🔍 Procurando {asset_symbol} em digital...")
            
            digital_id = await self._discover_active_id(asset_symbol, "digital")
            
            if digital_id:
                digital_result = await self._check_instrument_live(
                    digital_id, "digital", asset_symbol
                )
                if digital_result["valid"]:
                    if debug:
                        logger.info(
                            f"✅ {asset_symbol} disponível [digital] "
                            f"ID:{digital_id} Payout:{digital_result['payout']}%"
                        )
                    return digital_result
            
            # Ambos falharam
            return {
                "valid": False,
                "error": f"Ativo {asset_symbol} fechado ou indisponível"
            }
            
        except Exception as e:
            logger.error(f"❌ Erro na validação live: {e}")
            return {"valid": False, "error": str(e)}
    
    async def _check_instrument_live(
        self,
        active_id: int,
        instrument: str,
        asset_name: str
    ) -> Dict:
        """
        Verifica se um instrumento específico está disponível.
        Usa apenas métodos públicos: get_profit_percent, is_active_open.
        """
        try:
            # 1) Obter payout (indica disponibilidade)
            try:
                payout = self.iq.get_profit_percent(active_id)
            except AttributeError:
                return {
                    "valid": False,
                    "active_id": active_id,
                    "instrument": instrument,
                    "payout": 0,
                    "error": "Método get_profit_percent não disponível"
                }
            except Exception as e:
                return {
                    "valid": False,
                    "active_id": active_id,
                    "instrument": instrument,
                    "payout": 0,
                    "error": f"Erro ao obter payout: {str(e)}"
                }
            
            # 2) Validar payout mínimo
            if payout < 50:
                return {
                    "valid": False,
                    "active_id": active_id,
                    "instrument": instrument,
                    "payout": payout,
                    "error": "Payout insuficiente ou ativo fechado"
                }
            
            min_payout = self.config.get("min_payout_percent", 70)
            if payout < min_payout:
                return {
                    "valid": False,
                    "active_id": active_id,
                    "instrument": instrument,
                    "payout": payout,
                    "error": f"Payout abaixo do mínimo ({payout}% < {min_payout}%)"
                }
            
            # 3) Verificar se está aberto (se método disponível)
            if hasattr(self.iq, "is_active_open"):
                try:
                    is_open = self.iq.is_active_open(active_id)
                    if not is_open:
                        return {
                            "valid": False,
                            "active_id": active_id,
                            "instrument": instrument,
                            "payout": payout,
                            "error": "Ativo fechado"
                        }
                except Exception:
                    pass  # Método pode falhar, continuar
            
            # Tudo OK
            return {
                "valid": True,
                "active_id": active_id,
                "instrument": instrument,
                "payout": payout
            }
            
        except Exception as e:
            return {
                "valid": False,
                "error": f"Erro crítico: {str(e)}"
            }
    
    async def execute_trade(
        self,
        asset_symbol: str,
        direction: str,
        amount: float,
        timeframe_minutes: int
    ) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Executa trade com validação live e seleção dinâmica de instrumento.
        
        Args:
            asset_symbol: Símbolo do ativo (ex: EURUSD, GBPUSD-OTC)
            direction: CALL ou PUT
            amount: Valor em dólares
            timeframe_minutes: 1, 5 ou 15
        
        Returns:
            (sucesso, order_id, mensagem_erro_pt_br)
        """
        try:
            # 1) Verificar se tem trade pendente
            if self._pending_trade:
                return False, None, "⏳ Trade anterior ainda em execução"
            
            # Cooldown is managed by ExecutionEngine/RiskManager
            
            # 3) Garantir conexão
            if not await self.ensure_connection():
                return False, None, "🔌 Websocket desconectado"
            
            # 4) Garantir PRACTICE
            if not await self.ensure_practice_account():
                return False, None, "⚠️ Falha ao confirmar conta PRACTICE"
            
            # 5) Verificar saldo
            balances = await self.iq.get_balances()
            practice_bal = next((b for b in balances if b.type == 4), None)
            if not practice_bal or practice_bal.amount < amount:
                saldo_atual = practice_bal.amount if practice_bal else 0
                return False, None, f"💰 Saldo insuficiente (${saldo_atual:.2f})"
            
            # 6) Validar ativo LIVE
            validation = await self.validate_asset_live(asset_symbol)
            
            if not validation["valid"]:
                error_msg = validation.get("error", "Ativo indisponível")
                return False, None, f"❌ {error_msg}"
            
            active_id = validation["active_id"]
            instrument = validation["instrument"]
            payout = validation["payout"]
            
            logger.info(
                f"🎯 Executando: {asset_symbol} {direction} ${amount} "
                f"[{instrument}] ID:{active_id} Payout:{payout}%"
            )
            
            # 7) Marcar trade como iniciado
            self._pending_trade = True
            self._last_trade_time = datetime.now()
            
            # 8) Executar baseado no instrumento
            duration_seconds = timeframe_minutes * 60
            direction_lower = direction.lower()
            
            try:
                if instrument == "turbo":
                    result = await self._execute_turbo(
                        active_id, direction_lower, amount, duration_seconds
                    )
                else:  # digital
                    result = await self._execute_digital(
                        active_id, direction_lower, amount, duration_seconds
                    )
                
                # 9) Processar resultado
                self._pending_trade = False
                
                if result["success"]:
                    order_id = result["order_id"]
                    logger.info(f"✅ Trade executado: ID {order_id}")
                    # Cache full result for ExecutionEngine settlement
                    if "raw_result" in result:
                        self._last_trade_result[str(order_id)] = result["raw_result"]
                    return True, order_id, None
                else:
                    error = result.get("error", "Erro desconhecido")
                    logger.error(f"❌ Falha no trade: {error}")
                    return False, None, f"❌ {error}"
                    
            except Exception as e:
                self._pending_trade = False
                logger.error(f"❌ Erro na execução: {e}")
                import traceback
                logger.error(traceback.format_exc())
                return False, None, f"❌ Erro na execução: {str(e)}"
                
        except Exception as e:
            self._pending_trade = False
            logger.error(f"❌ Erro crítico: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False, None, f"❌ Erro crítico: {str(e)}"
    
    async def _execute_turbo(
        self,
        active_id: int,
        direction: str,
        amount: float,
        duration: int
    ) -> Dict:
        """
        Executa trade em turbo/binary.
        Usa método público buy() ou equivalente.
        """
        try:
            debug = self.config.get("debug_trade_validation", False)
            
            if debug:
                logger.info(
                    f"📤 Executando turbo: active_id={active_id}, "
                    f"direction={direction}, amount={amount}, duration={duration}"
                )
            
            # Tentar buy() primeiro (método mais comum)
            if hasattr(self.iq, "buy"):
                result = await self.iq.buy(
                    active_id=active_id,
                    direction=direction,
                    amount=amount,
                    duration=duration
                )
            # Fallback para buy_blitz se disponível
            elif hasattr(self.iq, "buy_blitz"):
                result = await self.iq.buy_blitz(
                    active_id=active_id,
                    direction=direction,
                    amount=amount,
                    duration=duration
                )
            else:
                return {
                    "success": False,
                    "error": "Método de compra turbo não disponível"
                }
            
            if not result:
                return {"success": False, "error": "API não retornou resposta"}
            
            # Extrair order_id
            order_id = result.get("id") or result.get("order_id") or result.get("external_id")
            
            if not order_id:
                api_message = result.get("message", result.get("msg", "Sem detalhes"))
                if isinstance(api_message, dict):
                    api_message = api_message.get("message", str(api_message))
                return {
                    "success": False,
                    "error": f"Ordem rejeitada: {api_message}"
                }
            
            # buy_blitz returns full settled result — pass it through
            raw_result = {
                "result": result.get("result", "unknown"),
                "pnl": result.get("pnl", 0.0),
                "order_id": order_id,
            }
            return {"success": True, "order_id": str(order_id), "raw_result": raw_result}
            
        except Exception as e:
            logger.error(f"❌ Erro em turbo: {e}")
            return {"success": False, "error": str(e)}
    
    async def _execute_digital(
        self,
        active_id: int,
        direction: str,
        amount: float,
        duration: int
    ) -> Dict:
        """
        Executa trade em digital.
        Usa método público buy_digital_spot() ou equivalente.
        """
        try:
            debug = self.config.get("debug_trade_validation", False)
            
            if debug:
                logger.info(
                    f"📤 Executando digital: active_id={active_id}, "
                    f"direction={direction}, amount={amount}, duration={duration}"
                )
            
            if not hasattr(self.iq, "buy_digital_spot"):
                return {
                    "success": False,
                    "error": "Método buy_digital_spot não disponível"
                }
            
            result = await self.iq.buy_digital_spot(
                active_id=active_id,
                direction=direction,
                amount=amount,
                duration=duration
            )
            
            if not result:
                return {"success": False, "error": "API não retornou resposta"}
            
            order_id = result.get("id") or result.get("order_id") or result.get("external_id")
            
            if not order_id:
                api_message = result.get("message", result.get("msg", "Sem detalhes"))
                if isinstance(api_message, dict):
                    api_message = api_message.get("message", str(api_message))
                return {
                    "success": False,
                    "error": f"Ordem rejeitada: {api_message}"
                }
            
            return {"success": True, "order_id": str(order_id)}
            
        except AttributeError:
            return {
                "success": False,
                "error": "Método buy_digital_spot não disponível"
            }
        except Exception as e:
            logger.error(f"❌ Erro em digital: {e}")
            return {"success": False, "error": str(e)}

