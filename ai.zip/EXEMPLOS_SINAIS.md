# Exemplos de Sinais - Bot Q3 AI

## ✅ CORRIGIDO: Fuso Horário de São Paulo

O bot agora está **sincronizado com o horário de São Paulo**.

Se você enviar um sinal para `14:30` e o horário atual em SP é `14:28`, 
o bot mostrará corretamente: **"2min 0s"** (e não 21 horas).

---

## 📋 Como Enviar MÚLTIPLOS SINAIS de Uma Vez

### Opção 1: Lista de Sinais (Um por Linha)

```
M5 EURUSD CALL 14:30
M5 GBPUSD PUT 14:35
M5 USDJPY CALL 14:40
```

**Resultado:** 3 sinais agendados simultaneamente!

---

### Opção 2: Sinais com Diferentes Timeframes

```
M1 EURUSD CALL 10:15
M5 GBPUSD PUT 10:20
M15 USDJPY CALL 10:30
```

**Resultado:** 3 sinais com expirações diferentes (1min, 5min, 15min)

---

### Opção 3: Mix de Sinais Imediatos e Agendados

```
EURUSD CALL
M5 GBPUSD PUT 15:00
USDJPY CALL
M5 AUDCAD PUT 15:30
```

**Resultado:** 
- 2 sinais executados imediatamente (EURUSD e USDJPY)
- 2 sinais agendados (GBPUSD às 15:00, AUDCAD às 15:30)

---

### Opção 4: Sinais com OTC

```
M5 EURUSD-OTC CALL 14:30
M5 GBPUSD-OTC PUT 14:35
```

**Resultado:** Sinais agendados para versão OTC dos pares

---

## 🕐 Exemplos de Horários (São Paulo)

### Cenário 1: Horário Atual 08:37

**Você envia:**
```
M5 EURUSD CALL 08:40
```

**Bot mostra:**
```
✅ Sinal agendado!
🕐 Horário: 08:40:00
⏳ Tempo restante: 3min 0s  ← CORRETO!
🕐 Horário atual SP: 08:37:00
```

---

### Cenário 2: Horário Atual 14:50

**Você envia:**
```
M5 EURUSD CALL 14:30
```

**Bot mostra:**
```
✅ Sinal agendado!
🕐 Horário: 14:30:00 (amanhã)
⏳ Tempo restante: 23h 40min
```

Porque o horário já passou hoje, então agendou para amanhã.

---

## 📝 Formato Estruturado (Único Sinal)

```
ATIVO: EURUSD
DIREÇÃO: CALL
TIMEFRAME: 5M
HORÁRIO: 14:30
```

**Resultado:** 1 sinal agendado

---

## ⚠️ Observações Importantes

### ✅ O que mudou:

1. **Fuso Horário Correto**
   - Agora usa `America/Sao_Paulo`
   - Cálculos precisos de tempo

2. **Múltiplos Sinais**
   - Envie vários sinais de uma vez
   - Separe por linha
   - Bot processa todos

3. **Confirmação Melhorada**
   - Mostra horário atual SP
   - Exibe tempo restante correto
   - Indica quantos sinais foram agendados

### 🎯 Teste Rápido

Envie agora (substitua XX:XX por 2 minutos no futuro):

```
M5 EURUSD CALL XX:XX
M5 GBPUSD PUT XX:XX
```

O bot deve mostrar **"2min"** para cada sinal!

---

## 💡 Dicas

1. **Sempre use horário de São Paulo**
2. **Envie múltiplos sinais separados por linha**
3. **Verifique "Horário atual SP" na confirmação**
4. **Use /start → 📥 Sinais → 📋 Listar para ver todos**

---

## 🐛 Se Ainda Houver Erro

Execute `/start` e clique em:
- 📥 Sinais
- 📋 Sinais Agendados

Você verá:
- 🕐 Horário atual SP: XX:XX:XX
- Lista de sinais com tempo restante

Se mostrar 21 horas para algo que deveria ser 2 minutos, 
**tire um print e reporte** para análise.
