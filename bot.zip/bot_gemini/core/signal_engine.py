"""
Motor de Automação de Sinais - Q3 IA Beta
Gera sinais internos baseados em análise estatística
"""
import asyncio
import logging
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from typing import Optional, Dict, List
import time

logger = logging.getLogger(__name__)

TZ = ZoneInfo("America/Sao_Paulo")


class SignalEngine:
    """
    Motor de Automação de Sinais
    
    Responsável por:
    - Análise estatística por ativo
    - Análise de winrate por horário
    - Score interno por ativo
    - Filtro mínimo de confiança
    - Envio interno para scheduler
    """
    
    def __init__(self, iq_client, runtime, config):
        """
        Inicializa o Motor de Automação de Sinais
        
        Args:
            iq_client: Cliente IQ Option para acesso à API
            runtime: Estado de runtime do bot
            config: Configurações do bot
        """
        self.iq_client = iq_client
        self.runtime = runtime
        self.config = config
        self.ativo = False
        self.task_engine = None
        
        # Configurações do motor
        self.confianca_minima = 65  # Confiança mínima em %
        self.intervalo_analise = 30  # Segundos entre análises
        self.max_sinais_por_hora = 10  # Limite de sinais por hora
        
        # Estatísticas internas
        self.stats_por_ativo = {}
        self.stats_por_horario = {}
        self.sinais_gerados_hora = []
        
        # Lista de ativos para análise
        self.ativos_analise = [
            "EURUSD", "GBPUSD", "USDJPY", "AUDUSD",
            "EURJPY", "GBPJPY", "USDCAD", "NZDUSD"
        ]
    
    def is_ativo(self) -> bool:
        """Verifica se o motor está ativo"""
        return self.ativo
    
    async def ativar(self):
        """
        Ativa o Motor de Automação de Sinais
        
        Returns:
            bool: True se ativado com sucesso
        """
        if self.ativo:
            logger.warning("⚠️ Motor de Automação já está ativo")
            return False
        
        if not self.iq_client or not self.iq_client.esta_conectado():
            logger.error("❌ IQ Option não está conectado")
            return False
        
        # Verificar se modo automático está ativo
        if not self.runtime.modo_automatico_ativo:
            logger.error("❌ Modo Automático precisa estar ativo")
            return False
        
        self.ativo = True
        logger.info("🧠 Automação de Sinais ATIVADA")
        
        # Iniciar task de geração de sinais
        self.task_engine = asyncio.create_task(self._loop_signal_engine())
        
        return True
    
    async def desativar(self):
        """
        Desativa o Motor de Automação de Sinais
        
        Returns:
            bool: True se desativado com sucesso
        """
        if not self.ativo:
            logger.warning("⚠️ Motor de Automação já está desativado")
            return False
        
        self.ativo = False
        logger.info("⛔ Automação de Sinais DESATIVADA")
        
        # Cancelar task
        if self.task_engine and not self.task_engine.done():
            self.task_engine.cancel()
            try:
                await self.task_engine
            except asyncio.CancelledError:
                logger.info("✅ Task do motor cancelada com sucesso")
        
        return True
    
    async def _loop_signal_engine(self):
        """
        Loop principal do motor de automação
        Analisa mercado e gera sinais internamente
        """
        logger.info("🔄 Iniciando loop do Motor de Automação...")
        
        try:
            while self.ativo:
                try:
                    # Garantir que está em conta PRACTICE
                    if not self.iq_client.garantir_practice():
                        logger.error("❌ Falha na verificação PRACTICE - pausando motor")
                        break
                    
                    # Verificar se modo automático ainda está ativo
                    if not self.runtime.modo_automatico_ativo:
                        logger.warning("⚠️ Modo Automático desativado - pausando motor")
                        await self.desativar()
                        break
                    
                    # Limpar sinais antigos (mais de 1 hora)
                    self._limpar_sinais_antigos()
                    
                    # Verificar limite de sinais por hora
                    if len(self.sinais_gerados_hora) >= self.max_sinais_por_hora:
                        logger.debug(f"⏸️ Limite de sinais/hora atingido ({self.max_sinais_por_hora})")
                        await asyncio.sleep(self.intervalo_analise)
                        continue
                    
                    # Analisar mercado e gerar sinal
                    sinal = await self._analisar_e_gerar_sinal()
                    
                    if sinal:
                        # Enviar sinal para o pipeline existente
                        await self._enviar_sinal_para_pipeline(sinal)
                    
                    # Aguardar próxima análise
                    await asyncio.sleep(self.intervalo_analise)
                    
                except asyncio.CancelledError:
                    logger.info("⏹️ Loop do motor cancelado")
                    break
                    
                except Exception as e:
                    logger.error(f"❌ Erro no loop do motor: {e}")
                    import traceback
                    logger.error(traceback.format_exc())
                    await asyncio.sleep(self.intervalo_analise)
        
        finally:
            logger.info("🏁 Loop do motor finalizado")
    
    async def _analisar_e_gerar_sinal(self) -> Optional[Dict]:
        """
        Analisa mercado e gera sinal se encontrar oportunidade
        
        Returns:
            Dict ou None: Sinal gerado ou None se não houver oportunidade
        """
        try:
            melhor_sinal = None
            maior_score = 0
            
            for ativo in self.ativos_analise:
                try:
                    # Verificar se ativo está disponível
                    disponivel, ativo_final = self.iq_client.verificar_ativo_disponivel(ativo)
                    if not disponivel:
                        continue
                    
                    # Obter candles recentes
                    candles = self.iq_client.iq.get_candles(ativo_final, 1, 100, time.time())
                    
                    if not candles or len(candles) < 50:
                        continue
                    
                    # Análise estatística do ativo
                    analise = self._analisar_ativo(candles, ativo_final)
                    
                    if analise and analise["score"] > maior_score:
                        maior_score = analise["score"]
                        melhor_sinal = {
                            "par": ativo_final,
                            "direcao": analise["direcao"],
                            "confianca": analise["confianca"],
                            "score": analise["score"],
                            "motivo": analise["motivo"]
                        }
                
                except Exception as e:
                    logger.debug(f"Erro ao analisar {ativo}: {e}")
                    continue
            
            # Retornar sinal apenas se passar no filtro de confiança
            if melhor_sinal and melhor_sinal["confianca"] >= self.confianca_minima:
                logger.info(
                    f"📡 Sinal interno gerado: {melhor_sinal['par']} "
                    f"{melhor_sinal['direcao']} ({melhor_sinal['confianca']}% confiança)"
                )
                return melhor_sinal
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Erro ao gerar sinal: {e}")
            return None
    
    def _analisar_ativo(self, candles: List, ativo: str) -> Optional[Dict]:
        """
        Análise estatística de um ativo
        
        Combina:
        - Análise de tendência (últimas 20 velas)
        - Análise de momentum (últimas 10 velas)
        - Análise de volume relativo
        - Winrate histórico do ativo
        - Winrate por horário atual
        
        Args:
            candles: Lista de candles da API
            ativo: Nome do ativo
            
        Returns:
            Dict com análise ou None
        """
        try:
            # Análise de tendência (últimas 20 velas)
            tendencia = self._calcular_tendencia(candles[-20:])
            
            # Análise de momentum (últimas 10 velas)
            momentum = self._calcular_momentum(candles[-10:])
            
            # Análise de volume
            volume_score = self._analisar_volume(candles[-20:])
            
            # Winrate por horário
            hora_atual = datetime.now(TZ).hour
            winrate_horario = self._obter_winrate_horario(hora_atual)
            
            # Calcular score combinado (0-100)
            score = (
                tendencia["score"] * 0.35 +
                momentum["score"] * 0.35 +
                volume_score * 0.15 +
                winrate_horario * 0.15
            )
            
            # Definir direção
            if tendencia["direcao"] == momentum["direcao"]:
                # Confirmação de tendência e momentum
                direcao = tendencia["direcao"]
                confianca = min(95, int(score))
            else:
                # Sinais conflitantes - reduzir confiança
                direcao = tendencia["direcao"]
                confianca = int(score * 0.7)
            
            motivo = (
                f"Tendência {tendencia['direcao']} ({tendencia['score']:.0f}%), "
                f"Momentum {momentum['direcao']} ({momentum['score']:.0f}%), "
                f"Volume {volume_score:.0f}%"
            )
            
            return {
                "direcao": direcao,
                "confianca": confianca,
                "score": score,
                "motivo": motivo
            }
            
        except Exception as e:
            logger.error(f"Erro na análise estatística: {e}")
            return None
    
    def _calcular_tendencia(self, candles: List) -> Dict:
        """
        Calcula tendência baseada em velas
        
        Returns:
            Dict: {"direcao": "CALL/PUT", "score": 0-100}
        """
        velas_alta = 0
        velas_baixa = 0
        
        for candle in candles:
            if candle["close"] > candle["open"]:
                velas_alta += 1
            elif candle["close"] < candle["open"]:
                velas_baixa += 1
        
        total = len(candles)
        
        if velas_alta > velas_baixa:
            score = (velas_alta / total) * 100
            return {"direcao": "CALL", "score": score}
        else:
            score = (velas_baixa / total) * 100
            return {"direcao": "PUT", "score": score}
    
    def _calcular_momentum(self, candles: List) -> Dict:
        """
        Calcula momentum das últimas velas
        
        Returns:
            Dict: {"direcao": "CALL/PUT", "score": 0-100}
        """
        if len(candles) < 2:
            return {"direcao": "NEUTRO", "score": 0}
        
        # Comparar últimas 5 velas com 5 anteriores
        ultimas_5 = candles[-5:]
        anteriores_5 = candles[-10:-5]
        
        media_ultimas = sum(c["close"] for c in ultimas_5) / len(ultimas_5)
        media_anteriores = sum(c["close"] for c in anteriores_5) / len(anteriores_5)
        
        variacao = ((media_ultimas - media_anteriores) / media_anteriores) * 100
        
        if abs(variacao) < 0.01:
            return {"direcao": "NEUTRO", "score": 50}
        
        if variacao > 0:
            score = min(100, 50 + abs(variacao) * 1000)
            return {"direcao": "CALL", "score": score}
        else:
            score = min(100, 50 + abs(variacao) * 1000)
            return {"direcao": "PUT", "score": score}
    
    def _analisar_volume(self, candles: List) -> float:
        """
        Analisa volume relativo
        
        Returns:
            float: Score de 0-100
        """
        try:
            volumes = [c.get("volume", 0) for c in candles]
            if not volumes or all(v == 0 for v in volumes):
                return 50  # Neutro se sem dados de volume
            
            media_volume = sum(volumes) / len(volumes)
            volume_atual = volumes[-1]
            
            if volume_atual > media_volume * 1.5:
                return 80  # Volume alto
            elif volume_atual > media_volume:
                return 65
            else:
                return 50  # Volume normal/baixo
                
        except Exception as e:
            logger.debug(f"Erro ao analisar volume: {e}")
            return 50
    
    def _obter_winrate_horario(self, hora: int) -> float:
        """
        Obtém winrate estatístico para determinado horário
        
        Args:
            hora: Hora do dia (0-23)
            
        Returns:
            float: Score de 0-100
        """
        # Inicialmente retornar score neutro
        # Pode ser melhorado com histórico real
        if hora not in self.stats_por_horario:
            return 50
        
        return self.stats_por_horario[hora]
    
    async def _enviar_sinal_para_pipeline(self, sinal_gerado: Dict):
        """
        Envia sinal gerado para o pipeline de execução do modo automático
        
        Args:
            sinal_gerado: Dicionário com dados do sinal gerado
        """
        try:
            # Criar sinal no formato esperado pelo parser
            sinal_formatado = {
                "par": sinal_gerado["par"],
                "direcao": sinal_gerado["direcao"],
                "tempo_expiracao": 60,  # 1 minuto
                "horario": datetime.now(TZ) + timedelta(seconds=5),  # 5s no futuro
                "imediato": False,
                "formato": "SIGNAL_ENGINE",
                "origem": "AUTOMACAO",
                "confianca": sinal_gerado["confianca"],
                "motivo": sinal_gerado.get("motivo", "Análise automática")
            }
            
            # Adicionar à fila de sinais agendados
            self.runtime.adicionar_sinal(sinal_formatado)
            
            # Registrar sinal gerado
            self.sinais_gerados_hora.append({
                "timestamp": datetime.now(TZ),
                "ativo": sinal_gerado["par"],
                "direcao": sinal_gerado["direcao"]
            })
            
            logger.info(
                f"🚀 Enviado para modo Automático: {sinal_formatado['par']} "
                f"{sinal_formatado['direcao']} às "
                f"{sinal_formatado['horario'].strftime('%H:%M:%S')}"
            )
            
        except Exception as e:
            logger.error(f"❌ Erro ao enviar sinal para pipeline: {e}")
            import traceback
            logger.error(traceback.format_exc())
    
    def _limpar_sinais_antigos(self):
        """Remove sinais com mais de 1 hora da lista"""
        agora = datetime.now(TZ)
        self.sinais_gerados_hora = [
            s for s in self.sinais_gerados_hora
            if (agora - s["timestamp"]).total_seconds() < 3600
        ]
    
    def obter_estatisticas(self) -> Dict:
        """
        Retorna estatísticas do motor
        
        Returns:
            Dict com estatísticas
        """
        return {
            "ativo": self.ativo,
            "sinais_ultima_hora": len(self.sinais_gerados_hora),
            "confianca_minima": self.confianca_minima,
            "intervalo_analise": self.intervalo_analise,
            "max_sinais_hora": self.max_sinais_por_hora
        }
