# Guia Rápido - Bot Q3 IA v3.0 Sênior

## 📦 Instalação

```bash
# 1. Instalar dependências
pip install -r requirements.txt

# 2. Executar
python main.py
```

## 🎮 Uso via Telegram

### 1. Iniciar Bot
```
/start
```

### 2. Enviar Sinais

**Formato Estruturado:**
```
ATIVO: EURUSD
DIREÇÃO: CALL
TIMEFRAME: 1M
HORÁRIO: 14:32
```

**Formato Simples:**
```
M5 EURUSD CALL 14:30
```

**Execução Imediata:**
```
EURUSD CALL
```

### 3. Controlar via Menus

- **▶️ Iniciar Bot**: Ativa execução automática
- **⏸️ Pausar Bot**: Pausa execução
- **⚙️ Configurações**: Ajustar valores
- **🤖 IA & Governança**: Controlar IA e ver permissões
- **📊 Estatísticas**: Ver resultados

## 🔒 Segurança

### Conta PRACTICE
O bot **sempre** opera em PRACTICE (demo).

Verificações:
1. Ao conectar
2. Antes de cada operação
3. Logs em cada etapa

### Como Confirmar
Menu > **💰 Ver Saldo**
- Deve mostrar: "✅ PRACTICE (seguro)"

## 🤖 IA Guard

### O Que Faz
- Valida contexto operacional
- Bloqueia condições extremas
- Responde: EXECUTAR / IGNORAR / RISCO

### O Que NÃO Faz
- ❌ Criar estratégias
- ❌ Prever mercado
- ❌ Decidir CALL/PUT
- ❌ Gerar sinais

### Ativar/Desativar
Menu > **🤖 IA & Governança** > Toggle validação

## 📊 Permissões de Governança

### O Que São
Flags de **auditoria** que:
- Mostram estado de permissões
- Servem para transparência
- **NÃO** habilitam funcionalidade

### Como Acessar
Menu > **🤖 IA & Governança**

### Exemplo
```
🔐 Criar Estratégia (BLOQUEADO)
```
- Mesmo ativando (🔒), código BLOQUEIA comportamento

## 🛡️ Proteções

### Stop Loss
Pausa bot se perda atingir limite.

**Configurar:**
Menu > Configurações > Stop Loss

### Stop Gain
Pausa bot se lucro atingir meta.

**Configurar:**
Menu > Configurações > Stop Gain

## 📈 Fluxo de Operação

```
1. Sinal recebido
2. IA valida contexto (se habilitado)
3. Garante PRACTICE
4. Executa operação
5. Aguarda resultado
6. Mostra resultado + estatísticas
```

## ❓ FAQ

### P: Como sei que estou em PRACTICE?
R: Veja em "Ver Saldo" - deve mostrar "PRACTICE ✅"

### P: IA pode gerar sinais sozinha?
R: NÃO. IA apenas valida sinais recebidos.

### P: O que acontece se eu ativar "IA pode prever mercado"?
R: NADA. É apenas uma flag de auditoria. O código bloqueia o comportamento.

### P: Posso desativar a IA?
R: Sim. Menu > IA & Governança > Toggle "Validar Contexto"

### P: Como agendar um sinal?
R: Envie no formato com horário: `M5 EURUSD CALL 14:30`

### P: Como executar imediatamente?
R: Envie sem horário: `EURUSD CALL`

### P: O bot opera sozinho?
R: Apenas se você habilitar "Operação Automática" e enviar sinais.

## ⚠️ Avisos

1. **Apenas PRACTICE**: Bot configurado para demo
2. **Sem Sinais Automáticos**: Bot não gera sinais
3. **Responsabilidade**: Use por sua conta e risco
4. **Educacional**: Projeto demonstrativo

## 📞 Suporte

- Leia `README.md` para documentação completa
- Veja `CHANGES.md` para entender mudanças
- Código está documentado com comentários

## 🎯 Resumo Rápido

1. Execute `python main.py`
2. Envie `/start` no Telegram
3. Envie sinais no formato aceito
4. Bot valida e executa (se automático)
5. Veja resultados nas mensagens

**Importante:** Bot NÃO é estrategista. Ele executa sinais que VOCÊ envia.
