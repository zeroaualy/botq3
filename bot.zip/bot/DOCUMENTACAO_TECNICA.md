# 📚 DOCUMENTAÇÃO TÉCNICA - BOT Q3 IA v3.1 PLAYWRIGHT

## 🏗️ ARQUITETURA

### Diagrama de Fluxo

```
┌─────────────────────────────────────────────────────────────┐
│                      TELEGRAM BOT                            │
│  (Recebe sinais do usuário/grupo)                           │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                   SIGNAL PARSER                              │
│  (Parseia: PAR, DIREÇÃO, TEMPO, HORÁRIO)                    │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                     IA GUARD (Opcional)                      │
│  (Valida contexto: EXECUTAR / IGNORAR / RISCO)              │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              PLAYWRIGHT TRADE EXECUTOR                       │
│  (Coordena execução via navegador)                          │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│            IQ PLAYWRIGHT CLIENT                              │
│                                                              │
│  1. Iniciar navegador (Chromium headless)                   │
│  2. Login automático                                        │
│  3. Garantir conta PRACTICE                                 │
│  4. Selecionar ativo                                        │
│  5. Definir valor                                           │
│  6. Definir expiração                                       │
│  7. Clicar CALL/PUT                                         │
│  8. Verificar ordem aberta                                  │
│  9. Aguardar resultado                                      │
│  10. Verificar WIN/LOSS                                     │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔧 COMPONENTES PRINCIPAIS

### 1. `IQPlaywrightClient` (core/iq_playwright_client.py)

**Responsabilidade:** Gerenciar navegador e interações com IQ Option

**Métodos principais:**
- `iniciar(headless=True)` - Inicia navegador e faz login
- `_fazer_login()` - Realiza login automático
- `_garantir_practice()` - Força conta PRACTICE
- `executar_trade()` - Executa trade clicando na interface
- `verificar_resultado()` - Verifica WIN/LOSS
- `fechar()` - Fecha navegador
- `reconectar()` - Reconecta se sessão expirar

**Recursos de resiliência:**
- Múltiplas tentativas de login
- Detecção automática de erro
- Espera dinâmica de elementos
- Delay humano entre ações
- Tratamento de timeout

### 2. `PlaywrightTradeExecutor` (core/playwright_trade_executor.py)

**Responsabilidade:** Coordenar execução de trades

**Métodos:**
- `executar()` - Executa trade com validações
- `verificar_resultado()` - Verifica resultado do trade

**Validações antes de executar:**
- Cliente conectado
- Saldo suficiente
- Tentativa de reconexão se necessário

### 3. `main_playwright.py`

**Responsabilidade:** Orquestração geral do bot

**Fluxo de inicialização:**
```python
async def inicializar_sistema():
    # 1. Inicializar IA Guard
    groq_client = inicializar_ia()
    
    # 2. Inicializar Playwright Client
    iq_client = IQPlaywrightClient(EMAIL, SENHA)
    await iq_client.iniciar(headless=True)
    
    # 3. Criar executor
    trade_executor = PlaywrightTradeExecutor(iq_client)
    
    # 4. Criar bot Telegram
    telegram_bot = TelegramBot(...)
    
    return telegram_bot, trade_executor, ...
```

**Loop principal:**
```python
async def loop_auto():
    while True:
        # 1. Verificar sinais agendados
        # 2. Executar trades prontos
        # 3. Monitorar stop loss/gain
        # 4. Sleep 1s
```

---

## 🎭 PLAYWRIGHT - COMO FUNCIONA

### Seletores CSS usados

**Login:**
```python
'input[name="email"]'          # Campo email
'input[type="password"]'       # Campo senha
'button[type="submit"]'        # Botão login
```

**Conta PRACTICE:**
```python
'[class*="account"]'           # Botão/dropdown de conta
'button:has-text("PRACTICE")'  # Opção PRACTICE
```

**Saldo:**
```python
'[class*="balance-value"]'     # Elemento com saldo
```

**Seleção de ativo:**
```python
'[class*="asset-select"]'      # Dropdown de ativos
```

**Valor da operação:**
```python
'input[class*="amount"]'       # Campo de valor
```

**Tempo de expiração:**
```python
'[class*="expiration"]'        # Dropdown de tempo
```

**Botões CALL/PUT:**
```python
'button:has-text("CALL")'      # Botão CALL
'button:has-text("PUT")'       # Botão PUT
```

**Confirmação de ordem:**
```python
'[class*="deal-open"]'         # Indicador de ordem aberta
```

### Estratégia de seleção resiliente

O código usa **múltiplos seletores** para cada elemento:

```python
seletores = [
    'button:has-text("CALL")',
    'button[class*="call"]',
    '[data-test*="call"]',
    '.btn-call'
]

for seletor in seletores:
    try:
        botao = await page.query_selector(seletor)
        if botao and await botao.is_visible():
            await botao.click()
            return True
    except:
        continue
```

**Vantagens:**
- Interface da IQ Option muda? Código se adapta
- Suporta diferentes idiomas
- Fallback automático

---

## ⚙️ CONFIGURAÇÕES E OTIMIZAÇÕES

### Modo Headless

```python
browser = await playwright.chromium.launch(
    headless=True,  # Sem janela visível
    args=[
        '--no-sandbox',              # Segurança VPS
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',   # Economia memória
        '--disable-gpu'              # VPS sem GPU
    ]
)
```

**Quando usar headless=False:**
- Debug local
- Ver execução visualmente
- Capturar screenshots

**Quando usar headless=True:**
- VPS (sempre)
- Produção 24/7
- Economia de recursos

### Timeouts

```python
page.set_default_timeout(30000)  # 30 segundos

# OU por elemento:
await page.wait_for_selector('button', timeout=10000)
```

### User Agent

```python
context = await browser.new_context(
    user_agent='Mozilla/5.0 (X11; Linux x86_64)...'
)
```

**Por que importante:**
- IQ Option detecta bots
- User agent real = menos chance de bloqueio

---

## 🔐 SEGURANÇA E GARANTIAS

### Múltiplas camadas de proteção PRACTICE

**1. No login:**
```python
async def _fazer_login():
    # ... login ...
    await self._garantir_practice()  # Força PRACTICE
```

**2. Antes de cada trade:**
```python
async def executar_trade():
    # ... verificações ...
    # (garantia já foi feita no login)
```

**3. Logs em todas operações:**
```python
logger.info(f"🏦 Conta: {tipo_conta}")  # Sempre mostra tipo
```

### Validação de saldo

```python
saldo = self.client.obter_saldo()
if saldo < valor:
    logger.error(f"❌ Saldo insuficiente")
    return False, None
```

---

## 🔄 RECONEXÃO AUTOMÁTICA

### Quando reconectar

- Sessão expirada
- Navegador crashou
- Erro de rede
- Login invalidado

### Como reconectar

```python
async def reconectar():
    logger.info("🔄 Tentando reconectar...")
    await self.fechar()          # Fecha navegador atual
    await asyncio.sleep(5)       # Aguarda 5s
    return await self.iniciar()  # Inicia novamente
```

### No executor

```python
if not self.client.esta_conectado():
    logger.info("🔄 Tentando reconectar...")
    if not await self.client.reconectar():
        return False, None
```

---

## 📊 ESTATÍSTICAS E MONITORAMENTO

### Stats rastreadas

```python
STATS = {
    'vitorias': 0,
    'derrotas': 0,
    'empates': 0,
    'lucro_dia': 0.0,
    'ia_decisoes': {
        'executar': 0,
        'ignorar': 0,
        'risco': 0
    }
}
```

### Registro de operação

```python
stats.registrar_operacao(resultado, valor, lucro)
```

### Winrate

```python
total = vitorias + derrotas + empates
winrate = (vitorias / total * 100) if total > 0 else 0
```

---

## 🐛 DEBUG E LOGS

### Níveis de log

```python
logging.basicConfig(level=logging.INFO)
```

**Tipos de mensagens:**
- `logger.info()` - Operação normal
- `logger.warning()` - Atenção, mas continua
- `logger.error()` - Erro, mas recuperável
- `logger.critical()` - Erro fatal

### Logs importantes

**Sucesso:**
```
✅ Login bem-sucedido!
✅ Conta PRACTICE confirmada
✅ Ativo EURUSD selecionado
✅ Clicou em CALL
✅ Ordem confirmada na interface
✅ WIN - Lucro: $18.00
```

**Erro:**
```
❌ Falha ao conectar
❌ Não encontrou botão CALL
❌ Ordem não confirmada na interface
❌ Erro ao executar trade: ...
```

### Como debugar

**1. Ativar modo visual:**
```python
await iq_client.iniciar(headless=False)
```

**2. Screenshots:**
```python
await page.screenshot(path='debug.png')
```

**3. Print HTML:**
```python
html = await page.content()
print(html)
```

**4. Logs detalhados:**
```python
import traceback
logger.error(traceback.format_exc())
```

---

## 🚀 PERFORMANCE

### Otimizações implementadas

**1. Reutilização de navegador:**
- Navegador fica aberto entre trades
- Evita overhead de inicialização

**2. Espera inteligente:**
```python
await page.wait_for_selector('button', state='visible')
# Ao invés de:
await asyncio.sleep(10)  # Tempo fixo
```

**3. Timeouts curtos:**
```python
timeout=10000  # 10s ao invés de 30s quando possível
```

**4. Fechamento de recursos:**
```python
async def fechar():
    await self.page.close()
    await self.context.close()
    await self.browser.close()
```

### Consumo esperado

**VPS mínimo recomendado:**
- RAM: 1GB (2GB recomendado)
- CPU: 1 core
- Disco: 5GB
- Largura de banda: Ilimitada

**Consumo por operação:**
- Memória: ~200-400MB
- CPU: ~10-20% (1 core)
- Rede: ~5-10MB

---

## 🧪 TESTES

### Teste manual

```bash
source venv/bin/activate
python3 main_playwright.py
```

### Teste Playwright

```bash
./test_playwright.sh
```

### Teste de trade

1. Iniciar bot
2. Enviar sinal: `EURUSD CALL 1M`
3. Acompanhar logs
4. Verificar execução

---

## 📝 CHECKLIST DE DEPLOY

### Antes de rodar em produção

- [ ] .env configurado
- [ ] Playwright instalado
- [ ] Chromium instalado
- [ ] Teste manual funcionou
- [ ] Modo headless ativado
- [ ] Systemd configurado
- [ ] Logs configurados
- [ ] Backup configurado
- [ ] Monitoramento ativo

### Verificações diárias

- [ ] Bot está rodando
- [ ] Logs sem erros
- [ ] Trades executando
- [ ] Saldo correto
- [ ] Conta PRACTICE

---

## 🔮 PRÓXIMAS MELHORIAS

### Roadmap v3.2

- [ ] Screenshot automático de cada trade
- [ ] OCR para ler saldo exato da tela
- [ ] Retry automático em falhas temporárias
- [ ] Dashboard web com métricas
- [ ] Multi-conta (rodar em várias contas)
- [ ] Integração com mais corretoras
- [ ] Machine Learning para análise

### Contribuições

Pull requests são bem-vindos!

Áreas para contribuir:
- Melhorar seletores CSS
- Adicionar testes automatizados
- Otimizar performance
- Documentação

---

## 📚 REFERÊNCIAS

**Playwright:**
- Docs: https://playwright.dev
- Python API: https://playwright.dev/python/docs/intro

**IQ Option:**
- Plataforma: https://iqoption.com

**Python Telegram Bot:**
- Docs: https://docs.python-telegram-bot.org

---

**Desenvolvido com ❤️ e Playwright** 🎭
